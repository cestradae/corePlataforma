CREATE       FUNCTION  [dbo].[fn_PV_CorrelativoDoc] (@sucursal smallint, @caja char(3), @mov smallint)
RETURNS integer AS  
BEGIN
	Declare @Correlat integer
	IF (Select convert(int, no_al) - correlativo - isnull(convert(int,minimo),0) From pv_cajascorrelat Where codigo_sucursal = @Sucursal And Codigo_Caja = @Caja And Codigo_movimiento = @mov) >= 0
		Set @Correlat = (Select Correlativo From pv_cajascorrelat Where codigo_sucursal = @Sucursal And Codigo_Caja = @Caja And Codigo_movimiento = @mov)
	Else
		Set @Correlat = -1

	return @Correlat
end
go

