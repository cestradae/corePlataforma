-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_sdepartamentos]
  (  @oldcodigo_departamento char (2)  )
As DELETE [dbo].[no_siex_departamentos] 
WHERE (codigo_departamento =  @oldcodigo_departamento)
go

