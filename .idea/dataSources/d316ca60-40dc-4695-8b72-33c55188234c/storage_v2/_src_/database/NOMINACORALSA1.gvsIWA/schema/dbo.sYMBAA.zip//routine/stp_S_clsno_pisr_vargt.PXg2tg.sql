
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_pisr_vargt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_variable char (10)  )
As SELECT a.codigo_impuesto,a.codigo_variable,a.tipo_variable,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_isr_vargt] a
WHERE (a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.codigo_variable =  @oldcodigo_variable)
go

