CREATE TRIGGER [dbo].[trinsno_reporte_detalle] ON dbo.no_reporte_detalle 
FOR INSERT, UPDATE
AS

--- Actualizamos los valores reportados

update no_reporte_detalle
      set codigo_val = substring ( inserted.codigo_valor, 2,10)
from inserted
where substring (inserted.codigo_valor,1,1 ) = '1'
    and inserted.codigo_tipo = no_reporte_detalle.codigo_tipo
    and inserted.periodo_id = no_reporte_detalle.periodo_id
    and inserted.no_reporte = no_reporte_detalle.no_reporte
    and inserted.codigo_empleado = no_reporte_detalle.codigo_empleado
    and inserted.codigo_valor = no_reporte_detalle.codigo_valor

if @@error <> 0
begin
   raiserror (' No se pudo actualizar el codigo de valor reportado - trinsno_reporte_detalle ' ,16,1,5000)
   rollback work
   return
end
--- Actualizamos ingresos

update no_reporte_detalle
      set codigo_ingreso = substring ( inserted.codigo_valor, 2,3)
from inserted
where substring (inserted.codigo_valor,1,1 ) = '2'
 and inserted.codigo_tipo = no_reporte_detalle.codigo_tipo
    and inserted.periodo_id = no_reporte_detalle.periodo_id
    and inserted.no_reporte = no_reporte_detalle.no_reporte
    and inserted.codigo_empleado = no_reporte_detalle.codigo_empleado
    and inserted.codigo_valor = no_reporte_detalle.codigo_valor

if @@error <> 0
begin
   raiserror (' No se pudo actualizar el codigo del ingreso reportado - trinsno_reporte_detalle ' ,16,1,5000)
   rollback work
   return
end


--- Actualizamos deducciones

update no_reporte_detalle
      set codigo_deduccion = substring ( inserted.codigo_valor, 2,3)
from inserted
where substring (inserted.codigo_valor,1,1 ) = '3'
 and inserted.codigo_tipo = no_reporte_detalle.codigo_tipo
    and inserted.periodo_id = no_reporte_detalle.periodo_id
    and inserted.no_reporte = no_reporte_detalle.no_reporte
    and inserted.codigo_empleado = no_reporte_detalle.codigo_empleado
    and inserted.codigo_valor = no_reporte_detalle.codigo_valor

if @@error <> 0
begin
   raiserror (' No se pudo actualizar el codigo de la  deduccion  reportada - trinsno_reporte_detalle ' ,16,1,5000)
   rollback work
   return
end


--- Actualizamos deducciones

update no_reporte_detalle
      set codigo_anticipo = substring ( inserted.codigo_valor, 2,3)
from inserted
where substring (inserted.codigo_valor,1,1 ) = '4'
 and inserted.codigo_tipo = no_reporte_detalle.codigo_tipo
    and inserted.periodo_id = no_reporte_detalle.periodo_id
    and inserted.no_reporte = no_reporte_detalle.no_reporte
    and inserted.codigo_empleado = no_reporte_detalle.codigo_empleado
    and inserted.codigo_valor = no_reporte_detalle.codigo_valor

if @@error <> 0
begin
   raiserror (' No se pudo actualizar el codigo del  anticipo  reportado - trinsno_reporte_detalle ' ,16,1,5000)
   rollback work
   return
end

-- Actualizamos grupo_id

update no_reporte_detalle
      set no_reporte_detalle.grupo_id = no_reporte_valores.grupo_id,
            no_reporte_detalle.no_calculo = no_reporte_valores.no_calculo
from inserted , no_reporte_valores
where inserted.codigo_tipo = no_reporte_detalle.codigo_tipo
    and inserted.periodo_id = no_reporte_detalle.periodo_id
    and inserted.no_reporte = no_reporte_detalle.no_reporte
    and inserted.codigo_empleado = no_reporte_detalle.codigo_empleado
    and inserted.codigo_valor = no_reporte_detalle.codigo_valor
    and no_reporte_valores.codigo_tipo = no_reporte_detalle.codigo_tipo
    and no_reporte_valores.periodo_id = no_reporte_detalle.periodo_id
    and no_reporte_valores.no_reporte = no_reporte_detalle.no_reporte


go

