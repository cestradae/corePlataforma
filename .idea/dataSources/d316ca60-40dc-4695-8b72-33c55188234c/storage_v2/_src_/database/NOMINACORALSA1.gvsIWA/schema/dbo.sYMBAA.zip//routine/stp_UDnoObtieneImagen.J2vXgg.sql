Create procedure [dbo].[stp_UDnoObtieneImagen]
   @codigo_empleado char(10)
as
-------------------
-- hecho por lsao
-- fecha 12/10/2010
-- Asunto 
-------------------

select correlativo  Codigo,
       nombre_documento NombreDoc,
       path_documento PathDoc
from no_empleado_documento
where codigo_empleado = @codigo_empleado
go

