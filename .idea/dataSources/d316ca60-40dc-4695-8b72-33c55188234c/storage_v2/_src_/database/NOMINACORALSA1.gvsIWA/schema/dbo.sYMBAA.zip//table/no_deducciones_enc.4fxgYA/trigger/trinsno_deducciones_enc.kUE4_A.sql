CREATE TRIGGER [dbo].[trinsno_deducciones_enc] ON dbo.no_deducciones_enc 
FOR INSERT
AS

declare @codigo_empleado char(10),
             @codigo_tipo char(2),
             @codigo_deduccion char(3),
             @correlativo smallint,
             @usuario_ingreso varchar(35),
             @fecha_ingreso datetime,
             @saldo money,
             @monto money

select @usuario_ingreso = system_user,
          @fecha_ingreso = getdate()

select @codigo_empleado = codigo_empleado,
           @codigo_tipo = codigo_tipo,
           @codigo_deduccion = codigo_deduccion,
           @correlativo = correlativo,
           @monto = monto 
from inserted

select @saldo = @monto

update no_deducciones_enc
    set usuario_ingreso = @usuario_ingreso,
          fecha_ingreso = @fecha_ingreso,
          saldo = @monto
where codigo_empleado = @codigo_empleado
    and codigo_tipo = @codigo_tipo
    and codigo_deduccion = @codigo_deduccion
    and correlativo = @correlativo


go

