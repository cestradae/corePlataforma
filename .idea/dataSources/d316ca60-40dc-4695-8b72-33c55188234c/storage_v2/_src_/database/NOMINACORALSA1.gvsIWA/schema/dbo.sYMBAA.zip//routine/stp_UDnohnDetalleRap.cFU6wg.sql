CREATE procedure [dbo].[stp_UDnohnDetalleRap]
   @empleado_inicial char(10),
   @empleado_final char(10)
as
--------------------------
-- Creado por lsao
-- Fecha 17/03/2011
-- Asunto Reporte de Rentenciones efectuadas al empleado
--------------------------
set nocount on

declare @codigo_rap char(3)

set rowcount 1
select @codigo_rap = codigo_rap
from no_patronos_hn
set rowcount 0

select a.codigo_empleado, b.ano, b.periodo, sum(monto_deduccion) monto
into #deducciones
from no_nomina_det a
   left join no_periodos_pago b on a.periodo_id = b.periodo_id 
where a.codigo_empleado between @empleado_inicial and @empleado_final 
  and codigo_deduccion = @codigo_rap
group by a.codigo_empleado, b.ano , b.periodo

select a.codigo_empleado,
       a.identificacion,
       a.nombre_usual,
       b.ano,
       b.periodo,
       case b.periodo 
           when 1 then '31 Enero ' + convert(char(4),b.ano)
           when 2 then '28 Febrero ' + convert(char(4),b.ano)
           when 3 then '31 Marzo ' + convert(char(4),b.ano)
           when 4 then '30 Abril ' + convert(char(4),b.ano)
           when 5 then '31 Mayo ' + convert(char(4),b.ano)
           when 6 then '30 Junio ' + convert(char(4),b.ano)
           when 7 then '31 Julio ' + convert(char(4),b.ano)
           when 8 then '31 Agosto ' + convert(char(4),b.ano)
           when 9 then '30 Septiembre ' + convert(char(4),b.ano)
           when 10 then '31 Octubre ' + convert(char(4),b.ano)
           when 11 then '30 Noviembre ' + convert(char(4),b.ano)
           when 12 then '31 Diciembre ' + convert(char(4),b.ano)
       
       else '' end Periodo,
       b.monto,
		a.Fecha_Inicio_rel_lab

from no_empleados a
   inner join #deducciones b on a.codigo_empleado = b.codigo_empleado 
order by b.ano, b.periodo
go

