-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_gettiponomina]
As
  select codigo_tipo, descripcion from no_tipos_nomina
go

