-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getnoClases]
As
  SELECT codigo_clase Clase, descripcion Descripcion
FROM no_clases_variables
go

