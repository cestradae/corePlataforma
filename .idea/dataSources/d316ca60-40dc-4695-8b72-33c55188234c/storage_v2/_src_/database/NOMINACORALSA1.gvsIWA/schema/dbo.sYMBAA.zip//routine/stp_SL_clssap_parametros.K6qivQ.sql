-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_parametros]
  As SELECT a.codigo_tipo,a.procedimiento_nomina,a.procedimiento_provisionesq,a.servidor,a.basedatos,a.usuario,a.clave,a.tipo_servidor,a.cuenta_salios_sap,a.lenguaje,a.UsuarioDB,a.ClaveDB FROM [dbo].[sap_parametros] a
go

