create procedure [dbo].[stp_UDNoAbreReporte]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @no_reporte smallint 
as

---------------------------------------------------------------
--Creado por LSAO
--Fecha 07/07/2003
--Asunto Pone el reporte como Operado para poderse modificar  
---------------------------------------------------------------

update no_reporte_valores
   set estado_reporte = 'O'
where codigo_tipo =@codigo_tipo
  and periodo_id = @periodo_id
  and no_reporte = @no_reporte

if @@error <> 0 
begin
   raiserror ( 'Reporte no se pudo abrir - stp_UDNoCierraReporte ', 16,1,5000)
   rollback work
   return
end
go

