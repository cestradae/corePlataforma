-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_MilBancos]
As
  SELECT id_cuenta,id_cuenta + ' ' + nombre_cuenta collate database_default Cuenta
FROM bn_cuentas
ORDER BY nombre_cuenta
go

