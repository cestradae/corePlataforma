-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNoBn_cuentas]
  (  @oldCodigo_banco smallint ,
  @oldCodigo_cuenta varchar (30)  )
As DELETE [dbo].[bn_cuentas] 
WHERE (codigo_banco =  @oldCodigo_banco AND 
codigo_cuenta =  @oldCodigo_cuenta)
go

