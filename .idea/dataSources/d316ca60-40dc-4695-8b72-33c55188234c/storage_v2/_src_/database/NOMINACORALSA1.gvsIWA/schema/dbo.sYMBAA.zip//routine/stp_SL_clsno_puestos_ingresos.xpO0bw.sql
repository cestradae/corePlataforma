-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_puestos_ingresos]
  As SELECT a.codigo_tipo,a.codigo_puesto,a.codigo_ingreso,a.monto_inicial,a.monto_final,a.promedio FROM [dbo].[no_puestos_ingresos] a
go

