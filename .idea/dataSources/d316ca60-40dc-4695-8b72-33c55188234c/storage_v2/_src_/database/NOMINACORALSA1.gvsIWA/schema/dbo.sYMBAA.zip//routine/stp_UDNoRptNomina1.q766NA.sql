CREATE  PROCEDURE [dbo].[stp_UDNoRptNomina1]
  @codigo_tipo char(2),
  @periodo1 char(10),
  @periodo2 char(10),
  @grupo1 char(5),
  @grupo2 char(5),
  @calculo_ini smallint,
  @calculo_fin smallint,
  @reporte smallint,
  @Agrupacion varchar(100),
  @LiquidoCero char(1)
AS
---------------------------------------------
--- Cambio hecho por lsao
--- Fecha 25/08/2008
--- Incluye manejo de multimoneda
---------------------------------------------

Set NoCount On

Declare @columnas smallint
Declare @Contador smallint
Declare @tasa_cambio decimal(18,4)
Declare @no_nomina char(10)
Declare @visto_bueno varchar(50)
Declare @revisado varchar(50)
Declare @autorizado varchar(50)


-- Inicializacion de variables
Declare @ingresos money
Declare @deduccion money
Declare @valor money
Declare @codigo_empleado char(10)
Declare @moneda_nomina money
-- Variables para hacer el update de las columnas variables
Declare @columna varchar(10)
Declare @Instruccion_Sql varchar(5000)
Declare @clasificacion char(1)
Declare @numero_empleados smallint


select @tasa_cambio = tasa_cambio
from no_nomina_enc
where codigo_tipo = @codigo_tipo

select @moneda_nomina = codigo_moneda
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

select @no_nomina = no_nomina
from no_periodos_pago
where periodo_id =  @periodo2 
/*
select @no_nomina = no_nomina 
from no_periodos_pago
where periodo_id =  @periodo2 
*/

select @visto_bueno = isnull(visto_bueno,''),
       @revisado = isnull(revisado,''),
       @autorizado = isnull(autorizado,'')
from no_generales

if @tasa_cambio is null select @tasa_cambio = 1

-- Crea la tabla Temporal para almacenar los valores de la nomina
Create table #Nomina
(
   codigo_tipo char(2)COLLATE Modern_Spanish_CI_AS,
   numero_columnas smallint,
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint null,
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS  null,
   col1 money default 0,
   col2 money default 0,
   col3 money default 0,
   col4 money default 0,
   col5 money default 0,
   col6 money default 0,
   col7 money default 0,
   col8 money default 0,
   col9 money default 0,
   col10 money default 0,
   col11 money default 0,
   col12 money default 0,
   col13 money default 0,
   col14 money default 0,
   col15 money default 0,
   col16 money default 0,
   col17 money default 0,
   col18 money default 0,
   col19 money default 0,
   col20 money default 0,
   col21 money default 0,
   col22 money default 0,
   col23 money default 0,
   col24 money default 0,
   col25 money default 0,
   col26 money default 0,
   col27 money default 0,
   col28 money default 0,
   col29 money default 0,
   col30 money default 0,
   coldesc1 varchar(25) null,
   coldesc2 varchar(25) null,
   coldesc3 varchar(25) null,
   coldesc4 varchar(25) null,
   coldesc5 varchar(25) null,
   coldesc6 varchar(25) null,
   coldesc7 varchar(25) null,
   coldesc8 varchar(25) null,
   coldesc9 varchar(25) null,
   coldesc10 varchar(25) null,
   coldesc11 varchar(25) null,
   coldesc12 varchar(25) null,
   coldesc13 varchar(25) null,
   coldesc14 varchar(25) null,
   coldesc15 varchar(25) null,
   coldesc16 varchar(25) null,
   coldesc17 varchar(25) null,
   coldesc18 varchar(25) null,
   coldesc19 varchar(25) null,
   coldesc20 varchar(25) null,
   coldesc21 varchar(25) null,
   coldesc22 varchar(25) null,
   coldesc23 varchar(25) null,
   coldesc24 varchar(25) null,
   coldesc25 varchar(25) null,
   coldesc26 varchar(25) null,
   coldesc27 varchar(25) null,
   coldesc28 varchar(25) null,
   coldesc29 varchar(25) null,
   coldesc30 varchar(25) null,
   colstr1   varchar(25) null,
   colstr2   varchar(25) null,
   colstr3   varchar(25) null,
   colstr4   varchar(25) null,
   colstr5   varchar(25) null,
   colstr6   varchar(25) null,
   colstr7   varchar(25) null,
   colstr8   varchar(25) null,
   colstr9   varchar(25) null,
   liquido money default 0
)

Create table #Ingresos (
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint   null, 
   codigo_centro varchar(20)  COLLATE Modern_Spanish_CI_AS null, 
   monto_ingreso money default 0,
   numero_columna smallint 
)   

Create table #Deducciones (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   monto_deduccion money default 0,
   numero_columna smallint 
)   

Create table #Valores (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint 
)   

Create table #ValoresSistema (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint 
)   

Create table #ValoresCalculados (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint 
)   


Create table #ValoresConst (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint 
)


Create table #Caracteres (
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint   null, 
   codigo_centro varchar(20)  COLLATE Modern_Spanish_CI_AS null, 
   valor  varchar(25) default '',
   numero_columna smallint 
)   


-- Trae el numero de columnas que va  a trabajar el Reporte

Select @columnas = numero_columnas, 
       @clasificacion = clasificado
from no_nomina_reporte
where codigo_repnomina = @reporte 


-- Ciclo para llenar las columnas

-- Llena los datos de los empleados segun la nomina
Insert Into #Nomina (
     codigo_tipo,
     numero_columnas,
     codigo_empleado,
     codigo_departamento,
     codigo_centro,
     liquido)

select @codigo_tipo, 
       @columnas, 
       nd.codigo_empleado, 
       nd.codigo_departamento,
       isnull(nd.codigo_centro,''),
       sum(nd.monto_ingreso) - sum(nd.monto_deduccion)
  from no_nomina_emplcalc ne , no_nomina_det nd      
  where ne.codigo_tipo = @codigo_tipo
    and ne.periodo_id between  @periodo1 and @periodo2
    and ne.grupo_id between @grupo1 and @grupo2
    and ne.no_calculo between  @calculo_ini and @calculo_fin    
    and ne.codigo_tipo = nd.codigo_tipo
    and ne.periodo_id = nd.periodo_id
    and ne.grupo_id = nd.grupo_id
    and ne.no_calculo= nd.no_calculo
    and ne.codigo_empleado = nd.codigo_empleado
group by nd.codigo_empleado, nd.codigo_departamento,isnull(nd.codigo_centro,'')


-- Creamos ingresos
insert into #Ingresos
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,''), 
       case when c.codigo_moneda = @moneda_nomina then sum(a.monto_ingreso)  
            when d.es_local = 'S' then sum(round(a.monto_ingreso * @tasa_cambio,2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_ingreso / @tasa_cambio,2)) end   monto_ingreso,
       b.numero_columna
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_ingreso = a.codigo_ingreso
  and b.monto_base = 'N'
  and b.codigo_repnomina = c.codigo_repnomina
  and b.numero_columna = c.no_columna
  and d.codigo_moneda = d.codigo_moneda 
group by a.codigo_empleado, c.codigo_moneda, d.es_local, d.es_dolar, 
a.codigo_departamento, isnull(a.codigo_centro,''), b.numero_columna

insert into #Ingresos
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,''), 
       case when c.codigo_moneda = @moneda_nomina then sum(a.monto_base) 
            when d.es_local = 'S' then sum(round(a.monto_base * @tasa_cambio,2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_base / @tasa_cambio,2)) end   monto_ingreso,
       b.numero_columna
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_ingreso = a.codigo_ingreso
  and b.monto_base = 'S'
  and b.codigo_repnomina = c.codigo_repnomina
  and b.numero_columna = c.no_columna
  and d.codigo_moneda = d.codigo_moneda 
group by a.codigo_empleado, a.codigo_departamento, d.es_local, d.es_dolar, c.codigo_moneda,
isnull(a.codigo_centro,''), b.numero_columna


-- Creamos  deducciones

Insert into #Deducciones
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,''), 
       case when c.codigo_moneda = @moneda_nomina then sum(a.monto_deduccion) 
            when d.es_local = 'S' then sum(round(a.monto_deduccion * @tasa_cambio,2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_deduccion / @tasa_cambio,2)) end   monto_deduccion,
       b.numero_columna
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d
where codigo_tipo = @codigo_tipo
  and periodo_id between @periodo1 and @periodo2
  and grupo_id between @grupo1 and @grupo2
  and no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_deduccion = a.codigo_deduccion
  and b.monto_base = 'N'
  and b.codigo_repnomina = c.codigo_repnomina
  and b.numero_columna = c.no_columna
  and d.codigo_moneda = d.codigo_moneda 
group by a.codigo_empleado, a.codigo_departamento, es_local, es_dolar, c.codigo_moneda,
isnull(a.codigo_centro,''), b.numero_columna


Insert into #Deducciones
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,''), 
       case when c.codigo_moneda = @moneda_nomina then sum(a.monto_base) 
            when d.es_local = 'S' then sum(round(a.monto_base * @tasa_cambio,2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_base / @tasa_cambio,2)) end,
       b.numero_columna
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d
where codigo_tipo = @codigo_tipo
  and periodo_id between @periodo1 and @periodo2
  and grupo_id between @grupo1 and @grupo2
  and no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_deduccion = a.codigo_deduccion
  and b.monto_base = 'S'
  and b.codigo_repnomina = c.codigo_repnomina
  and b.numero_columna = c.no_columna
  and d.codigo_moneda = d.codigo_moneda 

group by a.codigo_empleado, a.codigo_departamento, es_local, es_dolar, c.codigo_moneda,
  isnull(a.codigo_centro,''), b.numero_columna


-- Creamos Valores Reportados 

Insert into #Valores
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       sum(a.valor * b.factor) valor,
       b.numero_columna
from no_reporte_detalle a, no_nomina_reportedet b, no_reporte_empleado c
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and a.codigo_tipo = c.codigo_tipo
  and a.periodo_id = c.periodo_id
  and a.no_reporte= c.no_reporte
  and a.codigo_empleado = c.codigo_empleado
  and b.codigo_repnomina = @reporte
  and b.codigo_valor = a.codigo_val
GRoup by a.codigo_empleado, c.codigo_departamento, isnull(c.codigo_centro,''), b.numero_columna




-- Creamos Valores Sistema

Insert into #ValoresSistema
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       sum(a.valor * b.factor) valor,
       b.numero_columna
from no_nomina_variables_sistema a, no_nomina_reportedet b, no_empleados c
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.variable_sistema = a.codigo_variable
  and a.codigo_empleado = c.codigo_empleado
GRoup by a.codigo_empleado, c.codigo_departamento, isnull(c.codigo_centro,''), b.numero_columna


Insert into #ValoresCalculados
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       sum(a.valor * b.factor) valor,
       b.numero_columna
from no_nomina_valores_calculados a, no_nomina_reportedet b, no_empleados c
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and convert(char(10),b.codigo_valor) = convert(char(10),a.codigo_valor)
  and a.codigo_empleado = c.codigo_empleado
GRoup by a.codigo_empleado, c.codigo_departamento, isnull(c.codigo_centro,''), b.numero_columna


-- Creamos Valores Sistema

Insert into #ValoresConst
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       sum(b.valor * b.factor) valor,
       b.numero_columna
from no_nomina_emplcalc a, no_nomina_reportedet b, no_empleados c  
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.constante = 'S'
  and a.codigo_empleado = c.codigo_empleado
GRoup by a.codigo_empleado, c.codigo_departamento, isnull(c.codigo_centro,''), b.numero_columna

-- Procedemos a Actualizar las Fechas de Inicio


-- Creamos Valores Sistema

Insert into #Caracteres
--Fecha Inicio Relacion Laboral
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       convert(varchar(25),c.fecha_inicio_rel_lab,103),
       b.numero_columna
from no_nomina_emplcalc a, no_nomina_reportedet b, no_empleados c  
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_elemento = '701'
  and a.codigo_empleado = c.codigo_empleado

union all


Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,''), 
       replicate(valor,'-'),
       b.numero_columna
from no_nomina_emplcalc a, no_nomina_reportedet b, no_empleados c  
where a.codigo_tipo = @codigo_tipo
  and a.periodo_id between @periodo1 and @periodo2
  and a.grupo_id between @grupo1 and @grupo2
  and a.no_calculo between @calculo_ini and @calculo_fin
  and b.codigo_repnomina = @reporte
  and b.codigo_elemento = '700'
  and a.codigo_empleado = c.codigo_empleado


-- Procedemos a Actualizar Columna por Columna cada Valor



Select @contador = 1

while @contador <= @columnas
begin
   Select @columna = 'col'+ ltrim(rtrim(convert(varchar(2),@contador)))

   -- Actualizamos los ingresos 
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= monto_ingreso '+
         'from #Ingresos a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

   -- Actualizamos los deducciones
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna+ ' - monto_deduccion '+
         'from #Deducciones a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

  -- Actualizamos los Valores Reportados
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + valor '+
         'from #Valores a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)


   -- Actualizamos los Valores Sistema
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + isnull(valor,0) '+
         'from #ValoresSistema a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

   -- Actualizamos los Valores Calculados

   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + isnull(valor,0) '+
         'from #ValoresCalculados a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and convert(char(10),#nomina.codigo_centro) = convert(char(10),a.codigo_centro) ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
    exec (@instruccion_Sql)

-- Actualizamos los Valores Sistema
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + valor '+
         'from #ValoresConst a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

  -- Actualizamos la descripcion de la columna

   Select @columna = 'coldesc'+ ltrim(rtrim(convert(varchar(2),@contador)))
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= linea1 + isnull(b.simbolo,'''') ' +
         'from no_nomina_repcol a , gn_monedas b '+
         'where a.codigo_repnomina  =  ' + convert(char(3), @reporte ) + ' '+
         'and a.no_columna  = '+ convert(char(2), @contador) +' '+
         'and a.codigo_moneda *= b.codigo_moneda'

  
    exec (@instruccion_Sql)

    Select @columna = 'colstr'+ ltrim(rtrim(convert(varchar(2),@contador)))

    Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+  ' + valor '+
         'from #Caracteres a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    if @contador in (1,2,3,4)
    exec (@instruccion_Sql)


   -- Incrementa el contador
  Set @contador =  @contador + 1
     
end


Select @columna = 'coldesc'+ ltrim(rtrim(convert(varchar(2),@contador)))

Select @instruccion_Sql = 
    'Update #nomina set ' + @columna + '= ''Liquido'' , ' +
    '      col'+ ltrim(rtrim(convert(varchar(2),@contador))) +' = Liquido ' 
  
exec (@instruccion_Sql)


select distinct codigo_empleado
into #empleados
from #Nomina

select @numero_empleados = count(*)
from #empleados



--Agrupaciones
--'01', 'Departamento'	
--'02', 'Centro de Costo'	
--'03', 'Seccion'	
--'04', 'Puesto'	
--'05', 'Tipo Pago'	
declare @strGroupBy varchar(5000)
declare @strAgrupaciones  varchar(5000)
declare @strWhereClause varchar(5000)
declare @strTables varchar(5000)
declare @strLiquido varchar(100)
declare @i int
declare @totAgrupaciones int
declare @codigo_agrupacion char(2)


set @strGroupBy = ''
set @strAgrupaciones = ''
set @strWhereClause = ''
set @strTables = ''

set @i = 1
set @totAgrupaciones = 0

while @i <= LEN(@Agrupacion)
begin
	set @totAgrupaciones = @totAgrupaciones + 1
	set @codigo_agrupacion =  SUBSTRING ( @Agrupacion, @i, 2 )
		
	--Clausula Group By
	set @strGroupBy = isnull(@strGroupBy,'') + case 
		when @codigo_agrupacion = '01' then  ',t'+@codigo_agrupacion+'.codigo_departamento,t'+@codigo_agrupacion+'.descripcion'
		when @codigo_agrupacion = '02' then  ',t'+@codigo_agrupacion+'.codigo_centro,t'+@codigo_agrupacion+'.nombre_centro'
		when @codigo_agrupacion = '03' then  ',t'+@codigo_agrupacion+'.codigo_seccion,t'+@codigo_agrupacion+'.nombre_seccion'
		when @codigo_agrupacion = '04' then  ',t'+@codigo_agrupacion+'.codigo_puesto,t'+@codigo_agrupacion+'.nombre_puesto'
		when @codigo_agrupacion = '05' then  ',tipo_pago'
	end
	--Columnas   
	set @strAgrupaciones = isnull(@strAgrupaciones,'') + case 
		when @codigo_agrupacion = '01' then  ',convert(varchar(10),t'+@codigo_agrupacion+'.codigo_departamento) + '' - ''  +t'+@codigo_agrupacion+'.descripcion agrupacion'+convert(varchar(2),@totAgrupaciones)																		
		when @codigo_agrupacion = '02' then  ',t'+@codigo_agrupacion+'.codigo_centro + '' - ''  +t'+@codigo_agrupacion+'.nombre_centro agrupacion'+convert(varchar(2),@totAgrupaciones)
		when @codigo_agrupacion = '03' then  ',t'+@codigo_agrupacion+'.codigo_seccion + '' - ''  +t'+@codigo_agrupacion+'.nombre_seccion agrupacion'+convert(varchar(2),@totAgrupaciones)
		when @codigo_agrupacion = '04' then  ',t'+@codigo_agrupacion+'.codigo_puesto + '' - ''  +t'+@codigo_agrupacion+'.nombre_puesto agrupacion'+convert(varchar(2),@totAgrupaciones)
		when @codigo_agrupacion = '05' then  ',''agrupacion'+convert(varchar(2),@totAgrupaciones)+''' = case when b.tipo_pago = ''D'' then ''Deposito'' when b.tipo_pago = ''C'' then ''Cheque'' end '
	end  
	--Clausula where
	set @strWhereClause = isnull(@strWhereClause,'') + case 
		when @codigo_agrupacion = '01' then  ' AND b.codigo_departamento = t'+@codigo_agrupacion+'.codigo_departamento '
		when @codigo_agrupacion = '02' then  ' AND b.codigo_centro = t'+@codigo_agrupacion+'.codigo_centro '
		when @codigo_agrupacion = '03' then  ' AND b.codigo_seccion = t'+@codigo_agrupacion+'.codigo_seccion '
		when @codigo_agrupacion = '04' then  ' AND b.codigo_puesto = t'+@codigo_agrupacion+'.codigo_puesto '
		when @codigo_agrupacion = '05' then  '  '
	end
	--Clausula para Tablas
	set @strTables = isnull(@strTables,'') + case 
		when @codigo_agrupacion = '01' then  ' , gn_departamentos t'+@codigo_agrupacion
		when @codigo_agrupacion = '02' then  ' , cn_catalogo_centros t'+@codigo_agrupacion
		when @codigo_agrupacion = '03' then  ' , no_secciones t'+@codigo_agrupacion
		when @codigo_agrupacion = '04' then  ' , no_puestos t'+@codigo_agrupacion
		when @codigo_agrupacion = '05' then  ' '
	end
				
	set @i = @i + 3
end

-- agregamos null las agrupaciones faltantes
-- al momento 5 agrupaciones
while  (5 - @totAgrupaciones ) > 0
begin
	set @totAgrupaciones = @totAgrupaciones + 1
	set @strAgrupaciones = isnull(@strAgrupaciones,'')+' , null agrupacion'+convert(varchar(2),@totAgrupaciones)
end


-- verificamos si se desean ver registros con liquido 0  o no
set @strLiquido = ' having sum(liquido) > 0  '
if @LiquidoCero = 'S' set @strLiquido = ''


--select @strTables
--select @strWhereClause
--select @strAgrupaciones
--select @strGroupBy




declare @strsqlFinal varchar(8000)

set @strsqlFinal =   'Select  '+
   'a.codigo_tipo,  '+
   'a.numero_columnas,  '+
   'a.codigo_empleado, '''', '+
   'sum(col1), '+
   'sum(col2) , '+
   'sum(col3), '+
   'sum(col4) , '+
   'sum(col5) , '+
   'sum(col6) , '+
   'sum(col7) , '+
   'sum(col8) , '+
   'sum(col9) , '+
   'sum(col10) , '+
   'sum(col11) , '+
   'sum(col12) , '+
   'sum(col13) , '+
   'sum(col14) , '+
   'sum(col15) , '+
   'sum(col16) , '+
   'sum(col17) , '+
   'sum(col18) , '+
   'sum(col19) , '+
   'sum(col20) , '+
   'sum(col21) , '+
   'sum(col22) , '+
   'sum(col23) , '+
   'sum(col24) , '+
   'sum(col25) , '+
   'sum(col26) , '+
   'sum(col27) , '+
   'sum(col28) , '+
   'sum(col29) , '+
   'sum(col30) , '+
   'coldesc1 , '+
   'coldesc2 , '+
   'coldesc3 , '+
   'coldesc4 , '+
   'coldesc5 , '+
   'coldesc6 , '+
   'coldesc7 , '+
   'coldesc8 , '+
   'coldesc9 , '+
   'coldesc10 , '+
   'coldesc11 , '+
   'coldesc12 , '+
   'coldesc13 , '+ 
   'coldesc14 , '+
   'coldesc15 , '+
   'coldesc16 , '+
   'coldesc17 , '+
   'coldesc18 , '+
   'coldesc19 , '+
   'coldesc20 , '+
   'coldesc21 , '+
   'coldesc22 , '+
   'coldesc23 , '+
   'coldesc24 , '+
   'coldesc25 , '+
   'coldesc26 , '+
   'coldesc27 , '+
   'coldesc28 , '+
   'coldesc29 , '+
   'coldesc30 , '+
   'colstr1 , '+
   'colstr2 , '+
   'sum(liquido) liquido , '+
   'b.nombre_usual  '+
   ','+convert(varchar(20),@tasa_cambio) +' tasa_cambio,  '+
   ''''+@no_nomina +''' no_nomina, '+   
   ''''+@autorizado +''' autorizado, '+
   ''''+@revisado +''' revisado, '+
   ''''+@visto_bueno +''' visto_bueno, '+
   ''''+convert(varchar(20),@numero_empleados) +''' numero_empleados  '+
   @strAgrupaciones +
   ' from #Nomina a, no_empleados b '+
   @strTables +
   ' where a.codigo_empleado = b.codigo_empleado '+
   '  and b.estado_empleado in (''A'',''S'') ' +
   '  and b.codigo_empleado =''00064'' ' +
   @strWhereClause+
   'group by  coldesc1,coldesc2,coldesc3, coldesc4,coldesc5, coldesc6, '+
             'coldesc7,coldesc8,coldesc9,coldesc10,coldesc11,coldesc12, '+
             'coldesc13,coldesc14,coldesc15,coldesc16,coldesc17,coldesc18, '+
             'coldesc19,coldesc20,coldesc21,coldesc22,coldesc23,coldesc24, '+
             'coldesc25,coldesc26,coldesc27,coldesc28,coldesc29,coldesc30, '+
             'colstr1,colstr2,'+
             'a.codigo_tipo,a.numero_columnas,a.codigo_empleado,b.nombre_usual '+
             @strGroupBy
   + @strLiquido
  
  --print @strsqlFinal
--select @strsqlFinal
  exec(@strsqlFinal)
go

