create TRIGGER [dbo].[trinsno_provisiones_empleado]  ON dbo.no_provisiones_empleados 
FOR INSERT, UPDATE
AS

-- Actualizamos el encabezado de las provisiones 

Begin Tran
select  codigo_tipo,
           periodo_id,
           codigo_provision,
           sum(monto_base) monto_base,
           sum(monto_provision ) monto_provision
into #Total 
from inserted
group by codigo_tipo, periodo_id, codigo_provision

-- Actualizamos las provisiones encabezado 

update no_provisiones_det
    set no_provisiones_det.monto_base = no_provisiones_det.monto_base + #Total.monto_base,
         no_provisiones_det.monto_provision =     no_provisiones_det.monto_provision + #Total.monto_provision
from #Total
where #Total.codigo_tipo = no_provisiones_det.codigo_tipo
    and #Total.periodo_id = no_provisiones_det.periodo_id
    and #Total.codigo_provision = no_provisiones_det.codigo_provision

if @@error <> 0 
begin
   raiserror ('No se pudo actualizar el calculo por empleado  - trinsno_provisiones_empleado ' ,16,1,5000 )
   rollback tran
   return
end

          
-- Actualizamos el saldo por empleado 

select  a.codigo_empleado,
            a.codigo_tipo,
            a.codigo_provision,
            a.codigo_departamento,
            a.codigo_centro,
            b.saldo_provision,
            a.codigo_seccion
into #Registro 
from inserted a, no_empleado_provisiones b
where a.codigo_empleado *= b.codigo_empleado
    and a.codigo_tipo *= b.codigo_tipo
    and a.codigo_provision *= b.codigo_provision
    and a.codigo_departamento *= b.codigo_departamento 
    and a.codigo_centro *= b.codigo_centro



-- Procedemos a insertar los registros que no se encuentren

insert into no_empleado_provisiones (
    codigo_empleado,
    codigo_tipo,
    codigo_provision,
    codigo_departamento,
    codigo_centro,
    saldo_provision,
    codigo_seccion
)


select codigo_empleado,
          codigo_tipo,
          codigo_provision,
          codigo_departamento,
          codigo_centro,
          0.00,
          codigo_seccion
from #Registro 
where saldo_provision is null

-- Procemos a actualizar el saldo 

update no_empleado_provisiones 
    set no_empleado_provisiones.saldo_provision  =  no_empleado_provisiones.saldo_provision + inserted.monto_provision
from inserted
where inserted.codigo_empleado = no_empleado_provisiones.codigo_empleado
    and inserted.codigo_tipo = no_empleado_provisiones.codigo_tipo
    and inserted.codigo_provision = no_empleado_provisiones.codigo_provision
    and inserted.codigo_departamento = no_empleado_provisiones.codigo_departamento
    and inserted.codigo_centro = no_empleado_provisiones.codigo_centro 

if @@error <> 0 
begin
   raiserror ('No se pudo actualizar el saldo de provisiones por empleado - trinsno_provisiones_empleado ' ,16,1,5000 )
   rollback tran
   return
end

Commit Tran
go

