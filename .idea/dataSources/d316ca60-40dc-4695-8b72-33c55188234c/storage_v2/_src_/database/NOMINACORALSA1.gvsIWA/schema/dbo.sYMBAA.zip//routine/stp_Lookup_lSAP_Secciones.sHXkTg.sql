-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_Secciones]
As
  Select codigo_seccion, codigo_seccion+' - '+nombre_seccion as nombre_seccion  from no_secciones
go

