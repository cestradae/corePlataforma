

CREATE procedure [dbo].[stp_UDnoMeses_promedioBonoAgui]-- '1','1 20120301','1 1',0,'01'
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_valor char(10)
AS

-------------------------------------------------------------
-- Creado por dortiz
-- Fecha 26/02/2013
-- Asunto Procedimiento que calcula los meses para el promedio de las sumas 
-- de los ingresos para liquidacion si el empleado tiene mas de la cantidad de 
-- meses de los ingresados en valor pone valor sino la cantidad de meses laborados
-------------------------------------------------------------

declare @fecha_inicial datetime
declare @fecha_fin_periodo datetime
declare @fecha_final datetime
declare @suma decimal(22,6)
declare @basedatos varchar(30)
declare @servidor varchar(30)
declare @conexion varchar(60)
declare @ssql varchar(8000)
declare @ano smallint
declare @mes smallint
declare @valor smallint

select @fecha_inicial = fecha_inicial,
       @fecha_final = fecha_final, 
       @ano=ano, 
       @mes=periodo
from no_periodos_pago
where periodo_id = @periodo_id

select @fecha_fin_periodo = dateadd(dd,-1,@fecha_inicial)
select @fecha_fin_periodo
select @valor=valor
from  no_nomina_valores
where codigo_tipo=@codigo_tipo
and codigo_valor=@codigo_valor



select a.codigo_empleado, 
	case when dATEDIFF(mm,a.fecha_inicio_Rel_lab,@fecha_fin_periodo)>@valor then @valor
	else 
	dATEDIFF(mm,a.fecha_inicio_Rel_lab,@fecha_fin_periodo) + 1
	end  meses
into #empleadomeses
from no_empleados a
inner join no_nomina_emplcalc b
on a.codigo_empleado=b.codigo_empleado
where b.codigo_tipo=@codigo_tipo
and b.periodo_id=@periodo_id
and b.grupo_id=@grupo_id
and b.no_calculo=@no_calculo

Begin Tran


begin
  insert into no_nomina_valores_calculados (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        codigo_valor,
        valor )

select @codigo_tipo,
       @periodo_id,
       @grupo_id,
       @no_calculo,
       c.codigo_empleado, 
       @codigo_valor,
       isnull(d.meses,0)
from no_nomina_emplcalc b
inner join no_empleados c
	on b.codigo_empleado=c.codigo_empleado
inner join #empleadomeses d
	on c.codigo_empleado=d.codigo_empleado
where b.codigo_tipo = @codigo_tipo
  and b.periodo_id = @periodo_id
  and b.grupo_id = @grupo_id
  and b.no_calculo = @no_calculo


if @@error <> 0
Begin
   Raiserror ('No se puede calcular la variable %s - stp_UDnoMeses_promedio ', 16,1,@codigo_valor)
   Rollback work
   Return 9
End
end

commit

go

