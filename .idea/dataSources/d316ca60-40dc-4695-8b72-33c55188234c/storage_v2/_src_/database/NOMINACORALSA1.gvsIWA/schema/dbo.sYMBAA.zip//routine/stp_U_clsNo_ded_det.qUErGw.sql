-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_ded_det](  @oldCodigo_empleado char (10) ,
  @oldCodigo_tipo char (2) ,
  @oldCodigo_deduccion char (3) ,
  @oldCorrelativo smallint ,
  @oldPeriodo_id char (10) ,
  @Codigo_empleado char (10) ,
  @Codigo_tipo char (2) ,
  @Codigo_deduccion char (3) ,
  @Correlativo smallint ,
  @Periodo_id char (10) ,
  @Monto money ,
  @Estado char (1) ,
  @Grupo_id char (5) ,
  @Usuario_ingreso varchar (35) ,
  @Fecha_ingreso datetime ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_deducciones_det] 
WHERE codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo AND 
codigo_deduccion =  @oldCodigo_deduccion AND 
correlativo =  @oldCorrelativo AND 
periodo_id =  @oldPeriodo_id 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_deducciones_det] Set 
    codigo_empleado = @Codigo_empleado,
    codigo_tipo = @Codigo_tipo,
    codigo_deduccion = @Codigo_deduccion,
    correlativo = @Correlativo,
    periodo_id = @Periodo_id,
    monto = @Monto,
    estado = @Estado,
    grupo_id = @Grupo_id,
    usuario_ingreso = @Usuario_ingreso,
    fecha_ingreso = @Fecha_ingreso 
WHERE 	( codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo AND 
codigo_deduccion =  @oldCodigo_deduccion AND 
correlativo =  @oldCorrelativo AND 
periodo_id =  @oldPeriodo_id )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_deducciones_det]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
codigo_tipo =  @Codigo_tipo AND 
codigo_deduccion =  @Codigo_deduccion AND 
correlativo =  @Correlativo AND 
periodo_id =  @Periodo_id )
go

