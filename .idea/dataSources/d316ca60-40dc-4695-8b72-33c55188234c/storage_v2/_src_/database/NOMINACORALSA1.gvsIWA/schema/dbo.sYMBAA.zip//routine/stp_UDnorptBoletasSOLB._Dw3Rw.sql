
-- Fecha Creación:  29.Mayo.2009
-- Usuario Creación: Estuardo Arévalo
-- Procedimiento para Boletas de Pago SolBoGua Administrativas

CREATE PROCEDURE[dbo].[stp_UDnorptBoletasSOLB]-- '01','0120110703','015',0,'1','701'
@codigo_tipo char(2),
@periodo char(10),
@grupo char(5),
@no_pago smallint,
@depto1 smallint,
@depto2 smallint

AS



set nocount on

/*
SELECT * FROM dbo.no_puestos
SELECT * FROM no_empleados
SELECT * FROM dbo.no_periodos_pago
stp_UDnorptBoletasSolbogua '02','0220090301','021',0,0,5
select * from dbo.no_grupos_valores

*/


SELECT 
	a.codigo_empleado
	,b.nombre_usual
	,ltrim(rtrim(g.codigo_centro))+' - '+ltrim(rtrim(g.nombre_centro)) AS departamento
	,d.nombre_puesto
	,e.fecha_inicial
	,e.fecha_final
	,e.no_nomina
	,f.descripcion AS grupo
	,SUM(monto_ingreso) as ingresos
	,SUM(monto_deduccion)*-1 as deducciones
	,SUM(monto_ingreso) - SUM(monto_deduccion) as liquido

FROM dbo.no_nomina_det a
	INNER JOIN dbo.no_empleados b
		ON a.codigo_empleado = b.codigo_empleado
	INNER JOIN dbo.gn_departamentos c
		ON b.codigo_departamento = c.codigo_departamento
		AND c.codigo_departamento BETWEEN @depto1 AND @depto2
	INNER JOIN dbo.no_puestos d
		ON b.codigo_puesto = d.codigo_puesto		
	INNER JOIN dbo.no_periodos_pago e
		ON e.periodo_id = a.periodo_id
	INNER JOIN dbo.no_grupos_valores f
		ON a.grupo_id = f.grupo_id
	inner join cn_catalogo_centros g
		on a.codigo_centro=g.codigo_centro
WHERE a.codigo_tipo = @codigo_tipo
AND a.periodo_id = @periodo
AND a.grupo_id = @grupo
AND a.no_calculo = @no_pago
GROUP BY g.codigo_centro
	,g.nombre_centro
	,a.codigo_empleado
	,b.nombre_usual
	,d.nombre_puesto
	,e.fecha_inicial
	,e.fecha_final
	,e.no_nomina
	,f.descripcion
order by g.nombre_centro
	


select * from cn_catalogo_centros
go

