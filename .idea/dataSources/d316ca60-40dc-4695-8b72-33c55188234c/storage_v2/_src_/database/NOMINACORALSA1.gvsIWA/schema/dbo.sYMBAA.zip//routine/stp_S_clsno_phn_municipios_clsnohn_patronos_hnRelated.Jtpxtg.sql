
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_phn_municipios_clsnohn_patronos_hnRelated
(  @oldcodigo_patrono smallint  )
  As 
SELECT a.codigo_patrono,a.id_municipio,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_patronos_hn_municipios] a
WHERE 
a.codigo_patrono =  @oldcodigo_patrono
go

