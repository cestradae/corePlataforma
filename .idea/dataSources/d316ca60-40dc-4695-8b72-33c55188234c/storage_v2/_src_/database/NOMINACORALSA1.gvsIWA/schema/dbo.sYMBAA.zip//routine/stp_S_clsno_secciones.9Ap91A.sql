-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_secciones]
  (  @oldcodigo_seccion varchar (5)  )
As SELECT a.codigo_seccion,a.nombre_seccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_secciones] a
WHERE (a.codigo_seccion =  @oldcodigo_seccion)
go

