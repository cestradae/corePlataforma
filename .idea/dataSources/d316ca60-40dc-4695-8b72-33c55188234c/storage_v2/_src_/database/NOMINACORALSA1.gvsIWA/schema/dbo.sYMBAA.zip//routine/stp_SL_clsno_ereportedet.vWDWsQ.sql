-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_ereportedet]
  As SELECT a.codigo_repnomina,a.codigo_elemento,a.monto_base,a.numero_columna,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.factor,a.valor FROM [dbo].[no_nomina_reportedet] a
go

