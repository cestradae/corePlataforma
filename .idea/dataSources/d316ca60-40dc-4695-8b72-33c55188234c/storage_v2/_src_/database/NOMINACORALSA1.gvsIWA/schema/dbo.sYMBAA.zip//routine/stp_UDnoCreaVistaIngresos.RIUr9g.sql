Create procedure [dbo].[stp_UDnoCreaVistaIngresos]
as 
------------------
-- Hecho por ldr
-- Fecha 18/10/2010
-- Asunto Creacion de vista de ingresos
------------------

Declare @ssql as varchar(8000)
Declare @codigo_ingreso char(3)
Declare @nombre_corto varchar(30)

IF EXISTS ( SELECT 1 FROM	sysobjects where name = 'no_empleado_ingresosv' )
  DROP VIEW no_empleado_ingresosv


Declare cur_ingresos cursor for
     select codigo_ingreso,
            nombre_corto
     from no_catalogo_ingresos


select @ssql =
   ' Create view  no_empleado_ingresosv as ' + 
   '  select codigo_tipo , codigo_empleado ' 

open cur_ingresos
fetch cur_ingresos into @codigo_ingreso, @nombre_corto

while @@fetch_status = 0
Begin
   select @ssql = @ssql +
   ', sum(case when codigo_ingreso = ' + char(39) + @codigo_ingreso + char(39) + ' then monto else null end ) ' + '['+ @nombre_corto +']'
   fetch cur_ingresos into @codigo_ingreso, @nombre_corto

End
close cur_ingresos
deallocate cur_ingresos
select @ssql = @ssql + ' from no_empleado_ingresos group by codigo_tipo, codigo_empleado'

Exec ( @ssql )
   
-----------
-- PROCEDEMOS A ACTUALIZAR LA TABLA DE REPORTES ADMINISTRATIVOS
-----------

delete from no_reportes_generales_campos
   where tabla = 'no_empleado_ingresosv'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'no_empleado_ingresosv.'+a.name,
       a.name,
       'no_empleado_ingresosv',
       'no_empleado_ingresosv.codigo_empleado = no_empleados.codigo_empleado '
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'no_empleado_ingresosv'
order by a.name
go

