Create procedure [dbo].[stp_UDNoInsEmpleado]  
    @codigo_empleado char(10),
    @nombres varchar(50),
    @apellidos varchar(50),
    @no_orden_cedula char(5),
    @numero_cedula char(10),
    @fecha_inicio_rel_lab datetime,
    @numero_seguro_social varchar(20),
    @estado_civil char(1),
    @sexo char(1),
    @fecha_baja datetime,
    @codigo_puesto char(2),
    @codigo_departamento smallint,
    @codigo_centro varchar(20),
    @tipo_pago char(1),
    @codigo_pais smallint,
    @grupo_trabajo smallint,
    @codigo_seccion varchar(5),
    @tipo_nomina char(2),
    @nombres2 varchar(50),
    @apellidos2 varchar(50),
    @identificacion varchar(20),
    @codigo_banco smallint,
    @cuenta_bancaria varchar(30), 
    @result char(1) out
as
---------------------------------
-- hecho por lsao
-- Fecha 22/12/2008
-- Asunto Ingreso de Empleados Rapido
----------------------------------
select @result = ''

Begin Tran
Insert into no_empleados (
   codigo_empleado,
   nombres,
   nombres2,
   apellidos,
   apellidos2,
   estado_civil,
   sexo,
   nombre_usual,
   no_orden_cedula,
   numero_cedula,
   codigo_puesto,
   codigo_departamento,
   codigo_centro,
   tipo_pago,
   codigo_pais,
   grupo_trabajo,
   codigo_seccion,
   estado_empleado,
   fecha_inicio_rel_lab,
   fecha_ult_vacacion,
   fecha_contrato,  
   apellido_casada,
   extendida_en,
   buzon_mensajes,
   identificacion,
   codigo_banco,
   cuenta_bancaria )
values (
   @codigo_empleado,
   @nombres,
   @nombres2,
   @apellidos,
   @apellidos2,
   @estado_civil,
   'M',
   @nombres + ' ' + @nombres2 +' '+ @apellidos+' ' + @apellidos2,
   @no_orden_cedula,
   @numero_cedula,
   @codigo_puesto,
   @codigo_departamento,
   @codigo_centro,
   @tipo_pago,
   @codigo_pais,
   @grupo_trabajo,
   @codigo_seccion,
   'A',
   @fecha_inicio_rel_lab,
   @fecha_inicio_rel_lab,
   @fecha_inicio_rel_lab,
   '',
   '',
   '',
   @identificacion,
   @codigo_banco,
   @cuenta_bancaria )

if @@error <> 0
Begin
   Raiserror ('No se puede insertar el empleado - stp_UDNoInsEmpleado ',16,1,5000)
   Rollback work
   Return
End
   
Insert into no_nomina_empleado (
     codigo_empleado, codigo_tipo, fecha_asignacion, usuario_asignacion )
values ( 
     @codigo_empleado, @tipo_nomina, getdate(), system_user )
    
if @@error <> 0
Begin
   Raiserror ('No se puede asignar el tipo de nomina al empleado - stp_UDnoInsEmpleado ',16,1,5000)
   Rollback work
   Return
End

Commit Tran
go

