
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_pisr_dedgt(@AUTO_EditStamp varchar(30) OUT,
  @codigo_impuesto char (3) ,
  @codigo_Deduccion char (3) ,
  @tipo_deduccion smallint  )
As 
	INSERT INTO [dbo].[no_parametros_isr_dedgt]
(  codigo_impuesto ,
  codigo_Deduccion ,
  tipo_deduccion  )
VALUES (  @codigo_impuesto ,
  @codigo_Deduccion ,
  @tipo_deduccion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_parametros_isr_dedgt]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
codigo_Deduccion =  @codigo_Deduccion )
go

