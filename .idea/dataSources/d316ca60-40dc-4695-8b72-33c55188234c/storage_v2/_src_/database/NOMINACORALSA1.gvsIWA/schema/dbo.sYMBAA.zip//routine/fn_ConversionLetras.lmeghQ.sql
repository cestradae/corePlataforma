CREATE  FUNCTION [dbo].[fn_ConversionLetras] (@numero as money, @TipoConversion as tinyint)  
RETURNS varchar(255) AS  
BEGIN 
   /* Tipo Conversion
      1 = conversion entera
      2 = conversion monetaria 
      3 = conversion monetaria con conversion de decimales a letras 
*/   
   Declare @conversion as varchar(255)
   Declare @decimal as smallint
   Declare @entero as int

   Set @conversion = ''

   If @tipoConversion = 1
	Set @conversion = dbo.fn_numeroletras(@numero)

   If @tipoConversion = 2
	Begin
	   Set @conversion = dbo.fn_numeroletras(@numero)
	   set @decimal = dbo.fn_decimal(@numero)
           Set @entero =  dbo.fn_entero(@numero)
           if (@numero - @entero) > 0
               Set @conversion = @conversion + 'con ' + ltrim(rtrim(convert(char(2),@decimal))) +'/100'
           else
               Set @conversion = @conversion + 'exactos ' 
        end
   If @tipoConversion = 3
             Begin
	   Set @conversion = dbo.fn_numeroletras(@numero)
	   set @decimal = dbo.fn_decimal(@numero)
                Set @conversion = @conversion + 'con ' +dbo.fn_numeroletras(@decimal) 
             end

   Return @conversion
END
go

