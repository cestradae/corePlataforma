


CREATE procedure [dbo].[stp_UDnoDevUMesesIngresos] --'Comisiones','01','0120101102','012',0,'empc0295',0,0.00
   @Ingreso varchar(30),
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @resultado decimal(18,4) out
as
set nocount on

declare @fecha_inicial datetime
declare @fecha_final datetime
declare @fecha_baja datetime
declare @fecha_inicio_rel_lab datetime
declare @codigo_ingreso char(3)
declare @periodo_inicial char(10)
declare @periodo_final char(10)
declare @messtr varchar(2)
declare @diastr varchar(2)
declare @anostr varchar(4)
declare @corr_solicitud int
declare @fecha_suspension datetime
declare @detalle char(1)
declare @fecha_i datetime
declare @anomes int
declare @strsql varchar(1000)
-----------------------------------------------------
-- Hecho por LDR
-- fecha 03-03-2011
-- Asunto se agrego solicitud de suspension  
-- 
------------------------------------------------------

-----------------------------------------------------
-- hecho por Daniel Ortiz
-- fecha 03-01-2011
-- Asunto se agrego min y max a periodos y min(1) por 
-- que es para por lo menos una solicitud de vacaciones
------------------------------------------------------
-----------------------------------------------------
-- hecho por Daniel Ortiz
-- fecha 24-11-2010
-- Asunto Si es por una solicitud de vacaciones se toma
-- el devengado de los meses anteriores
------------------------------------------------------
-----------------------------------------------------
-- hecho por LDR
-- fecha 04-06-2009
-- Asunto Registra el monto devengado de los ultimos meses 
------------------------------------------------------

if substring(@Ingreso,1,1)= '#' -- Significa que el llamado viene de los finiquitos 
Begin
   select @codigo_ingreso = substring(@ingreso,2,3)  
   select @detalle = 'S'
end 
Else
Begin

  select @codigo_ingreso = codigo_ingreso
  from no_catalogo_ingresos
  where nombre_corto = @Ingreso

  select @detalle = 'N'

end

if @no_meses >=1 
Begin
	IF (SELECT min(1) FROM no_solicitud_ausencias a, dbo.no_periodos_pago b
			WHERE a.tipo_solicitud='V'
			AND estado_solicitud in ('A','C')
			AND a.fecha_inicio BETWEEN b.fecha_inicial AND b.fecha_final
			AND b.periodo_id =@periodo_id
			AND a.codigo_empleado=@codigo_empleado)=1
			
	BEGIN 
		   select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + '01'
		   --select @fecha_final = dateadd(dd,-1,@fecha_final)
		   
		   select @fecha_inicial = dateadd(mm,@no_meses * -1 , @fecha_final )

           select @fecha_final = dateadd(dd,-1,@fecha_final)
	END
	else
	begin
	  
       select @corr_solicitud = 0
       select @fecha_inicial = fecha_inicial,
              @fecha_final = fecha_final
       from no_periodos_pago
       where periodo_id = @periodo_id

       select @corr_solicitud = a.corr_solicitud
       from no_solicitud_ausencias a
       left join no_solicitud_ausdet b on a.codigo_empleado = b.codigo_empleado
           and a.corr_solicitud = b.corr_solicitud 
           and a.estado_solicitud in ('A','C')
           and a.tipo_solicitud = 'S' 
           and b.a_fecha between @fecha_inicial and  @fecha_final
       where a.codigo_empleado=@codigo_empleado
         and b.a_fecha is not null

       if @corr_solicitud <> 0
       Begin
          select @fecha_suspension = null

          select @fecha_suspension = fecha_inicio
          from no_solicitud_ausencias 
          where codigo_empleado = @codigo_empleado
            and corr_solicitud = @corr_solicitud

          if @fecha_suspension is not null  
          Begin
             set rowcount 1 
             select @periodo_id = periodo_id
             from no_periodos_pago
             where @fecha_suspension between fecha_inicial and fecha_final
             order by periodo_id
             set rowcount 0
          End

       End

           select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + '01'
		   --select @fecha_final = dateadd(dd,-1,@fecha_final)
		   
		   select @fecha_inicial = dateadd(mm,@no_meses * -1 , @fecha_final )

           select @fecha_final = dateadd(dd,-1,@fecha_final)
    end
end
else 
begin
   select @fecha_inicial = min(fecha_inicial)
   from no_periodos_pago
   where substring(periodo_id,1,8) = substring(@periodo_id,1,8)

   select @fecha_inicial = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + '01'
   select @fecha_final = dateadd(mm,1,@fecha_inicial)
end 


if @fecha_final is null select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + substring(@periodo_id,9,2)

select @fecha_final   = dateadd(dd,-1, @fecha_final)

select @fecha_inicio_rel_lab = fecha_inicio_rel_lab
from no_empleados
where codigo_empleado = @codigo_empleado

select @fecha_baja  = fecha_liquidacion
from no_liquidaciones 
	where periodo_id = @periodo_id
and codigo_empleado = @codigo_empleado
and no_calculo is null

select @periodo_inicial= min(periodo_id)
from no_periodos_pago
where @fecha_inicial between fecha_inicial and fecha_final
and codigo_tipo = @codigo_tipo


if @periodo_inicial is null 
Begin
   select @messtr = datepart(mm,@fecha_inicial)
   select @anostr = datepart(yy,@fecha_inicial)
   select @diastr = datepart(dd,@fecha_inicial)

   select @messtr = replicate ('0', 2 - len(@messtr)) + @messtr
   select @diastr = replicate ('0', 2 - len(@diastr)) + @diastr
   select @periodo_inicial = @codigo_tipo + @anostr + @messtr + @diastr 
End



select @periodo_final=max(periodo_id)
from no_periodos_pago
where @fecha_final between fecha_inicial and fecha_final
and codigo_tipo = @codigo_tipo

if @periodo_final is null 
Begin
   select @messtr = datepart(mm,@fecha_final)
   select @anostr = datepart(yy,@fecha_final)
   select @diastr = datepart(dd,@fecha_final)

   select @messtr = replicate ('0', 2 - len(@messtr)) + @messtr
   select @diastr = replicate ('0', 2 - len(@diastr)) + @diastr
   select @periodo_final = @codigo_tipo + @anostr + @messtr + @diastr 
End

Create table #Devengados (
        anomes int,
        monto money
)


insert into #Devengados (anomes , monto )
select substring(periodo_id,3,6), sum(monto_ingreso)
from no_nomina_det 
where periodo_id between @periodo_inicial and @periodo_final
  and codigo_empleado = @codigo_empleado
  and codigo_ingreso = @codigo_ingreso

group by substring(periodo_id,3,6)

select @resultado = sum(monto)
from #Devengados

if @resultado is null select @resultado = 0



if @detalle = 'S'
Begin
   --- Verificamos que esten todos los periodos 
   if @fecha_inicial is null select @fecha_inicial = @fecha_final

   select @fecha_i = @fecha_inicial 

   while @fecha_i <= @fecha_final 
   Begin

      select @anomes = datepart(yy,@fecha_i) * 100 + datepart(mm,@fecha_i)
      select @fecha_i = dateadd(mm,1,@fecha_i)

      if not exists ( select 1 from #Devengados where anomes = @anomes )
      Begin
         insert into #Devengados ( anomes, monto )
            values ( @anomes, 0.00) 
      End
   End


   select @strsql = 'Select ' +
      ' anomes anomes' + @codigo_ingreso + ' , ' +
      ' monto devengado' + @codigo_ingreso +
      ' from #Devengados  order by anomes ' 

   exec (@strsql)


end 

Drop table #Devengados


go

