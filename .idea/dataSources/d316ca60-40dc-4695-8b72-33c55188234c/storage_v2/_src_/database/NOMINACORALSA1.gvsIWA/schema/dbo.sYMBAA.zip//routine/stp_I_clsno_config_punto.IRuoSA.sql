-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_config_punto](  @codigo_tipo char (2)  )
As 
	INSERT INTO [dbo].[no_configuracion_punto]
(  codigo_tipo  )
VALUES (  @codigo_tipo  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

