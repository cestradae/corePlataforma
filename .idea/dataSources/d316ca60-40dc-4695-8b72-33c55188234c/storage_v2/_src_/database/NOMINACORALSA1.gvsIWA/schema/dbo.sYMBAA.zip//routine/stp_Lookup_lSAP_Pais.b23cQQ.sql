-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_Pais]
As
  SELECT DISTINCT CountryCode, CountryCode Pais
  FROM sap_tr_bancos
  ORDER BY CountryCode
go

