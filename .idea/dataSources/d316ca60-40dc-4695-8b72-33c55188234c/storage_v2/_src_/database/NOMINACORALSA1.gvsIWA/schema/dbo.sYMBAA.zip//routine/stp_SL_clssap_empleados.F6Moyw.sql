-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_empleados]
  As SELECT a.codigo_tipo,a.codigo_empleado,a.cuenta_sap FROM [dbo].[sap_empleados] a
go

