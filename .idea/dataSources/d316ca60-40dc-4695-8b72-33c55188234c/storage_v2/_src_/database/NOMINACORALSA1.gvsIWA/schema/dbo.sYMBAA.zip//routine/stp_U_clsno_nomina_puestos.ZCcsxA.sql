-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_nomina_puestos](  @oldcodigo_puesto char (10) ,
  @oldcodigo_tipo char (2) ,
  @codigo_puesto char (10) ,
  @codigo_tipo char (2) ,
  @fecha_asignacion datetime  )
As 
UPDATE [dbo].[no_nomina_puestos] Set 
    codigo_puesto = @codigo_puesto,
    codigo_tipo = @codigo_tipo,
    fecha_asignacion = @fecha_asignacion 
WHERE 	( codigo_puesto =  @oldcodigo_puesto AND 
codigo_tipo =  @oldcodigo_tipo )
go

