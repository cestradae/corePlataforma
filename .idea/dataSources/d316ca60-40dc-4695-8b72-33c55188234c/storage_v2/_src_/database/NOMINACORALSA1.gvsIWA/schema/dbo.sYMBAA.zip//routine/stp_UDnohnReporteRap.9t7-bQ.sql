CREATE procedure [dbo].[stp_UDnohnReporteRap]
     @codigo_patrono smallint,
     @ano smallint,
     @periodo smallint 
as 

-----------------------
-- Hecho por ldr
-- Fecha 17/03/2011
-- Asunto Reporte del Rap, Ajustes
-----------------------

-----------------------
-- Hecho por ldr
-- Fecha 11/03/2011
-- Asunto Reporte del Rap
-----------------------
declare @numero_patronal varchar(50)
declare @strmes char(2)
declare @strano char(4)
declare @no_patronal varchar(30)
declare @codigo_deduccion char(3)
declare @local char(1)
declare @largo int

select @no_patronal=numero_patronal,
       @codigo_deduccion = codigo_rap
from no_patronos_hn
where codigo_patrono = @codigo_patrono

select @largo= len(@no_patronal)
select @local= substring(@no_patronal,@largo,1)

select @strano = @ano
select @strmes = @periodo

if len(ltrim(rtrim(@strmes))) = 1 
   select @strmes = '0' + ltrim(rtrim(@strmes))
  

select dbo.func_EliminaEspGuiones(a.identificacion) identificacion,
       rtrim(ltrim(a.apellidos)) + ' '+isnull(rtrim(ltrim(apellidos2)),'') apellidos,
       rtrim(ltrim(a.nombres)) + ' '+isnull(rtrim(ltrim(nombres2)),'') nombres,
       dbo.func_EliminaULTIMO(@no_patronal) no_patronal,
       @local local,
       sum(monto_deduccion) patronal_rap,
       sum(monto_deduccion) empleado_rap,
       convert(char(7),@strmes+'/'+@strano) periodo
from no_empleados a
   inner join no_periodos_pago b on b.ano = @ano and b.periodo = @periodo
   inner join no_siex_municipios d on a.slabora_municipio = d.codigo_municipio 
   inner join no_nomina_det c on b.periodo_id = c.periodo_id 
         and c.codigo_empleado = a.codigo_empleado 
         and c.codigo_deduccion = @codigo_deduccion 
   inner join no_patronos_hn_municipios e on d.id_municipio = e.id_municipio and e.codigo_patrono = @codigo_patrono
group by a.identificacion, a.nombres, a.nombres2, 
a.apellidos, a.apellidos2
having sum(monto_deduccion)>0
go

