-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_ndet]
  (  @oldCodigo_tipo char (2) ,
  @oldPeriodo_id char (10) ,
  @oldCodigo_empleado char (10) ,
  @oldCorrelativo smallint ,
  @oldGrupo_id char (5) ,
  @oldNo_calculo smallint  )
As DELETE [dbo].[no_nomina_det] 
WHERE (codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
codigo_empleado =  @oldCodigo_empleado AND 
correlativo =  @oldCorrelativo AND 
grupo_id =  @oldGrupo_id AND 
no_calculo =  @oldNo_calculo)
go

