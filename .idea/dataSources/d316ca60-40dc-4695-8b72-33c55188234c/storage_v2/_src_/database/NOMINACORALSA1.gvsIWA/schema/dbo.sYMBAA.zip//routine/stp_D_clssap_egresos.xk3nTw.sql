-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_egresos]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_deduccion char (3)  )
As DELETE [dbo].[sap_egresos] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
codigo_deduccion =  @oldcodigo_deduccion)
go

