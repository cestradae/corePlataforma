-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoSiexRegiones]
As
  SELECT codigo_region as Codigo, codigo_region + ' - ' + nombre_region as Descripcion
FROM no_siex_regiones
go

