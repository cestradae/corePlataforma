-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_provisiones](  @codigo_tipo char (2) ,
  @codigo_provision char (3) ,
  @cuenta_sap nchar (15) ,
  @cuenta_sap_gasto char (15)  )
As 
	INSERT INTO [dbo].[sap_provisiones]
(  codigo_tipo ,
  codigo_provision ,
  cuenta_sap ,
  cuenta_sap_gasto  )
VALUES (  @codigo_tipo ,
  @codigo_provision ,
  @cuenta_sap ,
  @cuenta_sap_gasto  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

