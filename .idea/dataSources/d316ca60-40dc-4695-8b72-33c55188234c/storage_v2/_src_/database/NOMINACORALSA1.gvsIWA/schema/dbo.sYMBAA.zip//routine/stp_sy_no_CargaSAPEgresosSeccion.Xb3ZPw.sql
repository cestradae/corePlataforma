CREATE PROCEDURE [dbo].[stp_sy_no_CargaSAPEgresosSeccion]
				@codigo_tipo CHAR(2),
				@codigo_deduccion CHAR(3),
				@codigo_seccion VARCHAR(5),
				@socio_negocio VARCHAR(20),
				@cuenta_sap Varchar(35),
				@socio_empleado VARCHAR(1)
AS

----------------------------------------------------
--Hecho por Daniel Ortiz
--Fecha:23/11/2010
--Asunto:Carga de deducciones por seccion
----------------------------------------------------
SET NOCOUNT ON

DECLARE @status int
            DECLARE @mensaje varchar(100)
            set @mensaje=''
            set @status=0
declare @cuenta varchar(50)

             IF  @codigo_tipo is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_tipo esta en blanco, es llave primaria'
             END
             
             IF  @codigo_deduccion is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_ingreso esta en blanco, es llave primaria'
             END
             
             IF  @codigo_seccion is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_centro esta en blanco, es llave primaria'
             END
             
             IF  @cuenta_sap is null and @status<1
             begin
                         set @status=2
                         set @mensaje='cuenta_sap esta en blanco'
             END

SELECT @socio_negocio= ISNULL(@socio_negocio,'')

IF RTRIM(LTRIM(@socio_empleado))=''
	SELECT @socio_empleado= 'N'
ELSE
	SELECT @socio_empleado= ISNULL(@socio_empleado,'N')

select  @cuenta = acctcode 
from sap_tr_cuentas 
WHERE charindex('-',acctname)>=1
AND substring(acctname,1,charindex('-',acctname)-1) = Replace(@cuenta_sap,'-','')

 IF  @cuenta IS null
 BEGIN
 
 	set @status=2
	set @mensaje='cuenta_sap no existe para '+ Replace(@cuenta_sap,'-','')

END 
ELSE 
BEGIN

	 INSERT INTO dbo.sap_deducciones_secciones(
		codigo_tipo,
		codigo_deduccion,
		codigo_seccion,
		socio_negocio,
		cuenta_sap,
		socio_empleado
	) VALUES
	(	@codigo_tipo,
		@codigo_deduccion,
		@codigo_seccion,
		@socio_negocio,
		@cuenta,
		@socio_empleado
	)
END

SELECT @status AS status, @mensaje AS mensaje
go

