CREATE procedure [dbo].[stp_UDnoFormula53]   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @SSDiasAntiguedad decimal(18,4) 
declare @tmp2 decimal(18,4)
declare @tmp3 decimal(18,4)
declare @tmp4 decimal(18,4)
declare @tmp5 decimal(18,4)
declare @BaseOrd decimal(18,4) 
declare @tmp1 decimal(18,4) 

begin
  select @SSDiasAntiguedad = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSDiasAnt' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
exec stp_UDnoBasUMesesIngresos 'Ord',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 ,  @tmp2 out
exec stp_UDnoDevUMesesIngresos 'Boni_Ince',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 , @tmp3 out
exec stp_UDnoDevUMesesIngresos 'Hrs_extS',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 , @tmp4 out
exec stp_UDnoDevUMesesIngresos 'Hrs_extD',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 , @tmp5 out
Select @BaseOrd= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ord'
if ((isnull(@SSDiasAntiguedad,0)>30)) select @tmp1=@tmp2+@tmp3+@tmp4+@tmp5 else select @tmp1=isnull(@BaseOrd,0)

  set @result=@tmp1
end
go

