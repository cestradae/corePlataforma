-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_prov_enc]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint  )
As DELETE [dbo].[no_provisiones_enc] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo)
go

