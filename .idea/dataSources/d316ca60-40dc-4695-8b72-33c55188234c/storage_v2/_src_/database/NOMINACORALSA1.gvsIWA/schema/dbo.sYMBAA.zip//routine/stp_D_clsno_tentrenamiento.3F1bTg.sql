-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_tentrenamiento]
  (  @oldtipo_entrenamiento smallint  )
As DELETE [dbo].[no_tipos_entrenamiento] 
WHERE (tipo_entrenamiento =  @oldtipo_entrenamiento)
go

