-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_pseghn_ingresos]
  (  @oldcodigo_seguro smallint ,
  @oldingreso_afecto char (3)  )
As DELETE [dbo].[no_parametros_seghn_ingresos] 
WHERE (codigo_seguro =  @oldcodigo_seguro AND 
ingreso_afecto =  @oldingreso_afecto)
go

