-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_pvecinal_hn]
  As SELECT TOP 1000 a.impuesto_vecinal,a.nombre_impuesto,a.codigo_impuesto,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_vecinal_hn] a
go

