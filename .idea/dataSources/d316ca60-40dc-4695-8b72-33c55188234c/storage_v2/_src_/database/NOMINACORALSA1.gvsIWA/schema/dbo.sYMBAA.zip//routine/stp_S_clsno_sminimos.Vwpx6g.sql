-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_sminimos]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10)  )
As SELECT a.codigo_tipo,a.periodo_id,a.salario,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_salarios_minimos] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id)
go

