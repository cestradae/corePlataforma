
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_pisr_dedgt
  As SELECT a.codigo_impuesto,a.codigo_Deduccion,a.tipo_deduccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_isr_dedgt] a
go

