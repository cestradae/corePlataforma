create procedure stp_UDnoFormula12
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @HSIMPLES decimal(22,6) 
declare @BaseOrd decimal(18,4) 

begin
  if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '02        ' ) = '1'  begin Select @HSIMPLES= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '02        ' end else begin Select @HSIMPLES= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '02        ' end 
Select @BaseOrd= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ord'

  set @result=isnull(@HSIMPLES,0)*isnull(@BaseOrd,0)/30/8*1.5
end
go

