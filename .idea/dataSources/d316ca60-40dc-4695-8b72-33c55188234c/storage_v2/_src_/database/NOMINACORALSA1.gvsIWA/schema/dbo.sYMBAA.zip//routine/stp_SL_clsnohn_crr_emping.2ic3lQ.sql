
-- Procedure definition
CREATE PROCEDURE stp_SL_clsnohn_crr_emping
  As SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.codigo_ingreso,a.monto_devengado,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_rentahn_emping] a
go

