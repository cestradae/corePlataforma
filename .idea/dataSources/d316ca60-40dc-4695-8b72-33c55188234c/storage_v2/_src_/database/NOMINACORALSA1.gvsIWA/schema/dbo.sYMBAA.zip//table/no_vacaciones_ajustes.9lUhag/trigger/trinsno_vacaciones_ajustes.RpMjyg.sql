
CREATE TRIGGER [trinsno_vacaciones_ajustes]
   ON  [dbo].[no_vacaciones_ajustes] 
   FOR INSERT
AS 
BEGIN
-- =============================================
-- Author:		LDR
-- Create date: 29/05/2009
-- Description:	Actualiza las vacaciones 
-- =============================================

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;

declare @codigo_empleado char(10)
declare @periodo_ajuste datetime
declare @fecha_ult_vacacion datetime
declare	@dias_ajuste_derecho decimal(18,4)
declare @dias_ajuste_gozados decimal(18,4)
declare @dias_ajuste_pagados decimal(18,4)

---- Procedemos a hacer el cambio

select @codigo_empleado = codigo_empleado,
       @periodo_ajuste = periodo_ajuste,
       @fecha_ult_vacacion = fecha_ult_vacacion,
       @dias_ajuste_derecho = dias_ajuste_derecho,
       @dias_ajuste_gozados = dias_ajuste_gozados,
       @dias_ajuste_pagados = dias_ajuste_pagados
from inserted

if @dias_ajuste_derecho is null select @dias_ajuste_derecho = 0
if @dias_ajuste_gozados is null select @dias_ajuste_gozados = 0
if @dias_ajuste_pagados is null select @dias_ajuste_pagados = 0

update no_empleado_vacaciones
   set dias_derecho = dias_derecho + @dias_ajuste_derecho,
       dias_gozados = dias_gozados + @dias_ajuste_gozados,
       dias_pagados = dias_pagados + @dias_ajuste_pagados
where codigo_empleado = @codigo_empleado
and periodo = @periodo_ajuste

if @@error <> 0
Begin
   Raiserror ('No se puede actualizar las vacaciones del empleado - trinsno_vacaciones_ajustes ' , 16,1,5000)
   Rollback work
   Return
End    


END



go

