-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_gtrabajo]
  As SELECT a.grupo_trabajo,a.nombre_grupo,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_grupos_trabajo] a
go

