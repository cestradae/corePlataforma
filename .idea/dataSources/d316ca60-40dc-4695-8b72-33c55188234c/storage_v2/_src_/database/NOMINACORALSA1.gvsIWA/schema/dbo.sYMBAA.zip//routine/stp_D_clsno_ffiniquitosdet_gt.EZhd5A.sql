
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_ffiniquitosdet_gt
  (  @oldcodigo_formato smallint ,
  @oldcorrelativo smallint  )
As DELETE [dbo].[no_formatos_finiquitos_det] 
WHERE (codigo_formato =  @oldcodigo_formato AND 
correlativo =  @oldcorrelativo)
go

