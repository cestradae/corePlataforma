Create procedure [dbo].[Stp_udNo_cuotas_centro]
@tipo char(2),
@periodo1 char(10),
@periodo2 char(10),
@provision1 char(3),
@provision2 char(3),
@centro1 varchar(20),
@centro2 varchar(20)
as
set nocount on
Select 	a.codigo_tipo,
	b.descripcion,

	c.codigo_centro,
	d.nombre_centro,
	
	c.codigo_empleado,
	e.nombre_usual,
	c.porcentaje,
	sum(c.monto_base) monto_base,
	sum(c.monto_provision) monto_prov
		

from	no_provisiones_enc a,
	no_catalogo_provisiones b,
	no_provisiones_empleados c,
	cn_catalogo_centros d,
	no_empleados e
	
Where	
	-- join de no_provisiones_empleados c con no_provisiones_enc 
	c.codigo_tipo = a.codigo_tipo
	-- join de no_provisiones_empleados con no_catalogo_provisiones 
	and c.codigo_provision = b.codigo_provision
	-- se aplican los filtros
	and c.codigo_tipo = @tipo
	and c.periodo_id between @periodo1 and @periodo2
	and c.codigo_provision between @provision1 and @provision2
	and c.codigo_centro between @centro1 and @centro2
	-- join de no_provisiones_empleados con cn_catalogo_centros
	and c.codigo_centro = d.codigo_centro
	-- join de no_provisiones_empleados con no_empleados
	and c.codigo_empleado = e.codigo_empleado
group by a.codigo_tipo, b.descripcion, c.codigo_centro, d.nombre_centro, c.codigo_empleado, e.nombre_usual, c.porcentaje
go

