-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_nvarsistema]
  (  @oldcodigo_empleado char (10) ,
  @oldcodigo_variable varchar (20) ,
  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint  )
As SELECT a.codigo_empleado,a.codigo_variable,a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.valor,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_nomina_variables_sistema] a
WHERE (a.codigo_empleado =  @oldcodigo_empleado AND 
a.codigo_variable =  @oldcodigo_variable AND 
a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id AND 
a.grupo_id =  @oldgrupo_id AND 
a.no_calculo =  @oldno_calculo)
go

