CREATE PROCEDURE [dbo].[stp_sy_no_nominaempleado]
		@codigo_empleado	CHAR(10),
		@codigo_tipo	CHAR(2),
		@fecha_asignacion	DATETIME,
		@usuario_asignacion	SMALLINT,
		@usuario_traslado SMALLINT,
		@fecha_traslado	DATETIME

AS
----------------------------------------------------
--Hecho por Mario Juarros
--Fecha:06/07/2010
--Asunto:Carga de nominas por empleado
----------------------------------------------------
SET NOCOUNT ON

DECLARE @status int
            DECLARE @mensaje varchar(100)
            set @mensaje=''
            set @status=0
            

             IF  @codigo_empleado is null and @status<1
             begin
                         set @status=2
                         set @mensaje='Codigo de Empleado esta en blanco, es llave primaria'
             END
                          
			 IF  @codigo_tipo is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_tipo esta en blanco, es llave primaria'
             END
             
             IF  @fecha_asignacion is null and @status<1
             begin
                         set @status=1
                         set @mensaje='fecha_asignacion esta en blanco'                         
             END
             
             IF  @usuario_asignacion is null and @status<1
             begin
                         set @status=1
                         set @mensaje='usuario_asignacion esta en blanco'                         
             END
             
             IF  @usuario_traslado is null and @status<1
             begin
                         set @status=1
                         set @mensaje='usuario_traslado esta en blanco'
             END
             
             IF  @fecha_traslado is null and @status<1
             begin
                         set @status=1
                         set @mensaje='fecha_traslado esta en blanco'
             END
IF @fecha_asignacion IS NULL OR @usuario_asignacion IS NULL OR @fecha_asignacion = '18991231'
BEGIN
INSERT INTO dbo.no_nomina_empleado (
	codigo_empleado,
	codigo_tipo,
	fecha_asignacion,
	usuario_asignacion
) VALUES(
	@codigo_empleado,
	@codigo_tipo,
	GETDATE(),
	01
	)	
END
ELSE
BEGIN
INSERT INTO dbo.no_nomina_empleado (
	codigo_empleado,
	codigo_tipo,
	fecha_asignacion,
	usuario_asignacion
) VALUES(
	@codigo_empleado,
	@codigo_tipo,
	@fecha_asignacion,
	@usuario_asignacion)
END


SELECT @status AS status, @mensaje AS mensaje
go

