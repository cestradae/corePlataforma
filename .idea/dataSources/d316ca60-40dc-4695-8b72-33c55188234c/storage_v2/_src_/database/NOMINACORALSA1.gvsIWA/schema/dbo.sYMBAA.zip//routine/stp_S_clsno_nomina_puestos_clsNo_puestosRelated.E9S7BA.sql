-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_nomina_puestos_clsNo_puestosRelated]
(  @oldcodigo_puesto char (10)  )
  As 
SELECT a.codigo_puesto,a.codigo_tipo,a.fecha_asignacion FROM [dbo].[no_nomina_puestos] a
WHERE 
a.codigo_puesto =  @oldcodigo_puesto
go

