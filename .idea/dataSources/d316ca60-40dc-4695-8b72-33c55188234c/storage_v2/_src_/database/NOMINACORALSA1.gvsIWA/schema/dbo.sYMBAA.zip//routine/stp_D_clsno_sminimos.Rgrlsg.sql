-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_sminimos]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10)  )
As DELETE [dbo].[no_salarios_minimos] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id)
go

