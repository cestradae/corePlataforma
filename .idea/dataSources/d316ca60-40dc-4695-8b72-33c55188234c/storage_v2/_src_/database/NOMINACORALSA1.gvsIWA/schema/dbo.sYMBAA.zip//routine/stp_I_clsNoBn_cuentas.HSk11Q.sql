-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNoBn_cuentas](@AUTO_EditStamp varchar(30) OUT,
  @Codigo_banco smallint ,
  @Codigo_cuenta varchar (30) ,
  @Codigo_moneda smallint ,
  @Nombre_cuenta varchar (60) ,
  @Tipo_cuenta char (1) ,
  @Numero_cheque int ,
  @formato varchar (50) ,
  @cuenta_contable varchar (30) ,
  @codigo_centro varchar (20) ,
  @numero_cta_banco varchar (50) ,
  @formato_lote varchar (60)  )
As 
	INSERT INTO [dbo].[bn_cuentas]
(  codigo_banco ,
  codigo_cuenta ,
  codigo_moneda ,
  nombre_cuenta ,
  tipo_cuenta ,
  numero_cheque ,
  formato ,
  cuenta_contable ,
  codigo_centro ,
  numero_cta_banco ,
  formato_lote  )
VALUES (  @Codigo_banco ,
  @Codigo_cuenta ,
  @Codigo_moneda ,
  @Nombre_cuenta ,
  @Tipo_cuenta ,
  @Numero_cheque ,
  @formato ,
  @cuenta_contable ,
  @codigo_centro ,
  @numero_cta_banco ,
  @formato_lote  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[bn_cuentas]
  WHERE ( codigo_banco =  @Codigo_banco AND 
codigo_cuenta =  @Codigo_cuenta )
go

