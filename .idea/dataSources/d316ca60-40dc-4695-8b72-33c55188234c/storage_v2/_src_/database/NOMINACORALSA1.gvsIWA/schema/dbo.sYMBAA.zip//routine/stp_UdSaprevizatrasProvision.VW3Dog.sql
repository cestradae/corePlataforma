CREATE procedure [dbo].[stp_UdSaprevizatrasProvision] --'01','0220081101','1',null
  @codigo_tipo char(2),
  @periodo char(10),
  @grupo char(5),
  @no_pago smallint
AS
-------------------------------------------------------------------------------------------------------------
--Creado por: Daniel Ortiz
--Fecha: 08/06/2010
--Observaciones: Procedimiento para revizar si esta trasladado una Provision
-------
-----------------------------------------------------------------------------------------------------

IF EXISTS (SELECT 1 FROM dbo.no_provisiones_enc
		  WHERE codigo_tipo=@codigo_tipo
			AND periodo_id=@periodo
			AND grupo_id=@grupo
			AND no_calculo = @no_pago
			AND (contabilizado_sap<>'S' OR contabilizado_sap IS NULL))
    -- Si la provision no esta traslada devuelve 0
	SELECT 0
ELSE
	-- si la provision esta trasladada devuelve 1
	SELECT 1
go

