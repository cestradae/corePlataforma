Create function [dbo].[fn_noanosdevida] (
	@codigo_empleado	char(10))
		
returns numeric
As
-------------------------------------------------
--Hecho por: Mario Juarros
--Fecha: 17/01/2009
--Retorna la edad de un individuo
-------------------------------------------------
begin
declare @anos numeric,
		@meses numeric,
		@dias numeric,
		@ano numeric,
		@mes numeric,
		@dia numeric,
		@fecha datetime,
		@fechaactual datetime,		
		@bisiesto varchar(20),
		@resp numeric

		
select @fecha=fecha_nacimiento from no_empleados where codigo_empleado=@codigo_empleado

select @fechaactual=fecha from vw_nofechaactual
select @ano=datepart(yyyy,@fechaactual)
select @bisiesto=convert(varchar,@ano)+ '0229'
select @anos=datediff(yyyy,@fecha,@fechaactual)
select @meses=datediff(mm,@fecha,@fechaactual)
select @dias=datediff(dd,@fecha,@fechaactual)


select @resp=isdate(@bisiesto)	
	if @resp<>0
		begin
			if @dias>366*@anos
				select @anos=@anos+1
		end
return @anos
end
go

