-- =============================================
-- Author:		Estuardo Arévalo
-- Create date: 15.julio.2009
-- Description:	Toma los datos de nomina_ingresos, deducciones y provisiones 
-- y los inserta para puestos_ingresos, deducciones y provisiones
-- =============================================
CREATE TRIGGER [dbo].[trinsno_nomina_puestos]
   ON  [dbo].[no_nomina_puestos]
   AFTER  INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @codigo_tipo char(2)
	declare @codigo_puesto char(10)

	BEGIN TRAN

		select @codigo_tipo = codigo_tipo
					,@codigo_puesto = codigo_puesto
		from inserted
		
		-- INSERTAMOS INGRESOS

		insert into no_puestos_ingresos (codigo_puesto, codigo_tipo, codigo_ingreso)
		select @codigo_puesto, @codigo_tipo, codigo_ingreso 
		from no_nomina_ingresos
		where codigo_tipo = @codigo_tipo
		and codigo_ingreso not in (select codigo_ingreso from no_puestos_ingresos
													where codigo_tipo = @codigo_tipo 
													and codigo_puesto = @codigo_puesto ) 

		if @@error <> 0 
		begin
			Raiserror ('Ocurrió un error al insertar los ingresos default del tipo de nomina  - trinsno_nomina_puestos' , 16,1,5000)
			rollback work
			return
		end

		-- INSERTAMOS DEDUCCIONES
		insert into no_puestos_deducciones (codigo_puesto, codigo_tipo, codigo_deduccion)
		select @codigo_puesto, @codigo_tipo, codigo_deduccion
		from no_nomina_deducciones
		where codigo_tipo = @codigo_tipo
		and codigo_deduccion not in (select codigo_deduccion from no_puestos_deducciones
													where codigo_tipo = @codigo_tipo 
													and codigo_puesto = @codigo_puesto ) 

		if @@error <> 0 
		begin
			Raiserror ('Ocurrió un error al insertar las deducciones default del tipo de nomina  - trinsno_nomina_puestos' , 16,1,5000)
			rollback work
			return
		end


		-- INSERTAMOS PROVISIONES
		insert into no_puestos_provisiones (codigo_puesto, codigo_tipo, codigo_provision)
		select @codigo_puesto, @codigo_tipo, codigo_provision
		from no_nomina_provisiones
		where codigo_tipo = @codigo_tipo
		and codigo_provision not in (select codigo_provision from no_puestos_provisiones
													where codigo_tipo = @codigo_tipo 
													and codigo_puesto = @codigo_puesto ) 

		if @@error <> 0 
		begin
			Raiserror ('Ocurrió un error al insertar las provisiones default del tipo de nomina  - trinsno_nomina_puestos' , 16,1,5000)
			rollback work
			return
		end


	COMMIT TRAN

END


go

