CREATE  PROCEDURE  [dbo].[stp_UDnorpttiponomina] AS

Select codigo_tipo,descripcion 
  from no_tipos_nomina
  order by descripcion
go

