create PROCEDURE [dbo].[stp_sy_no_CambioSAPIngresosCentroSeccion]
				@codigo_tipo CHAR(2),
				@codigo_ingreso CHAR(3),
				@codigo_centro VARCHAR(20),
				@codigo_seccion varchar(5),
				@cuenta_sap Varchar(20),
				@socio_negocio NVARCHAR(20),
				@socio_empleado VARCHAR(1)
AS

----------------------------------------------------
--Hecho por Daniel Ortiz
--Fecha:09/03/2012
--Asunto:Cambio de ingresos por Centros y Seccion
----------------------------------------------------
SET NOCOUNT ON

DECLARE @status int
            DECLARE @mensaje varchar(100)
            set @mensaje='Cargado exitosamente'
            set @status=0

Declare @cuenta nvarchar(20)

             IF  @codigo_tipo is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_tipo esta en blanco, es llave primaria'
             END
             
             IF  @codigo_ingreso is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_ingreso esta en blanco, es llave primaria'
             END
             
             IF  @codigo_centro is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_centro esta en blanco, es llave primaria'
             END
             
             IF  @codigo_seccion is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_seccion esta en blanco, es llave primaria'
             END
             
             IF  @cuenta_sap is null and @status<1
             begin
                         set @status=2
                         set @mensaje='cuenta_sap esta en blanco'
             END

IF RTRIM(LTRIM(@socio_empleado))=''
	SELECT @socio_empleado= 'N'
ELSE
	SELECT @socio_empleado= ISNULL(@socio_empleado,'N')

--validacion de longitud de cuenta de SAP 

select  @cuenta = acctcode 
from sap_tr_cuentas 
WHERE charindex('-',acctname)>=1
AND substring(acctname,1,charindex('-',acctname)-1) = @cuenta_sap

 IF  @cuenta IS null
 BEGIN
 
 	set @status=2
	set @mensaje='cuenta_sap no existe para '+ @cuenta_sap

END 


-- si no se producen errores de data hace el insert
if @status=0
	 update dbo.sap_ingresos_centro_seccion
	 set cuenta_sap=@cuenta,
		socio_negocio=@socio_negocio,
		socio_empleado=@socio_empleado
	 where codigo_tipo=@codigo_tipo
		and codigo_ingreso=@codigo_ingreso
		and codigo_centro=@codigo_centro
		and codigo_seccion=@codigo_seccion


SELECT @status AS status, @mensaje AS mensaje


go

