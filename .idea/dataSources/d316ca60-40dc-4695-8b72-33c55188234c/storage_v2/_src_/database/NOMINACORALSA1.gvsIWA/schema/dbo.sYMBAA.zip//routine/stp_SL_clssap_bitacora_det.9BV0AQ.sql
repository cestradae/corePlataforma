-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_bitacora_det]
  As SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.calculo,a.correlativo,a.cuenta_contable,a.cargos,a.abonos,a.codigo_asociado,a.codigo_centro,a.nombre_asociado,a.nombre_centro FROM [dbo].[sap_bitacora_det] a
go

