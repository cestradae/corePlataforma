-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_prov_enc](  @AUTO_usuario_ingreso varchar (35) OUT,
  @AUTO_fecha_ingreso datetime OUT,
  @AUTO_estado char (1) OUT,
  @AUTO_usuario_cierre varchar (35) OUT,
  @AUTO_fecha_cierre datetime OUT,
@AUTO_EditStamp varchar(30) OUT,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @no_calculo smallint  )
As 
	INSERT INTO [dbo].[no_provisiones_enc]
(  codigo_tipo ,
  periodo_id ,
  grupo_id ,
  no_calculo  )
VALUES (  @codigo_tipo ,
  @periodo_id ,
  @grupo_id ,
  @no_calculo  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_usuario_ingreso = usuario_ingreso, @AUTO_fecha_ingreso = fecha_ingreso, @AUTO_estado = estado, @AUTO_usuario_cierre = usuario_cierre, @AUTO_fecha_cierre = fecha_cierre, @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_provisiones_enc]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
grupo_id =  @grupo_id AND 
no_calculo =  @no_calculo )
go

