CREATE procedure [dbo].[stp_udnohngenerarepvecinal]
   @impuesto_vecinal smallint,
   @ano smallint
as 

---------------------
-- Hecho por ldr
-- Fecha 17/03/2011
-- Reporte Ajuste al impuesto vecinal
--------------------

---------------------
-- Hecho por ldr
-- Fecha 04/03/2011
-- Reporte Impuesto Vecinal
--------------------

set nocount on 

declare @nombre_empresa varchar(100)
declare @numero_patronal varchar(30)
declare @codigo_patrono smallint

select @codigo_patrono = codigo_patrono
from no_parametros_vecinal_hn
where impuesto_vecinal = @impuesto_vecinal

select @nombre_empresa = nombre_patrono,
       @numero_patronal = numero_patronal
from no_patronos_hn
where codigo_patrono = @codigo_patrono

select @nombre_empresa nombre_empresa,
       @numero_patronal identificacion_tributaria,
       a.codigo_empleado,
       b.identificacion,
       b.apellidos,
       isnull(b.apellidos2,'') apellidos2,
       b.nombres + isnull(b.nombres2,'') nombres,
       case b.sexo when 'F' then 'Femenino' else  'Masculino' end Sexo,
       b.fecha_nacimiento,
       a.monto_afecto,
       a.monto_impuesto
from no_reporte_vechn_empleado a
  left join no_empleados b on a.codigo_empleado = b.codigo_empleado
where a.impuesto_vecinal = @impuesto_vecinal
  and a.ano = @ano
go

