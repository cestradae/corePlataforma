--------------------------

--[stp_UDnoPartidaNominaSOLB02] '11','1120100401','111',0

CREATE procedure [dbo].[stp_UDnoPartidaNominaSOLB02] 
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo int
AS
--------------------------
-- Cambio por Mario Juarros
-- Fecha 26/06/2010
-- Asunto : Se modifica para que no aparezcan los descuentos en la partida.
--------------------------

--------------------------
-- Hecho por Daniel Ortiz
-- Fecha 02.Marzo.2010
-- Asunto : Los Ingresos con saldo Negativo se colocan en el area de deducciones
--          y los codigos de centro se van a agarrar del historico.
--------------------------
--------------------------
-- Hecho por Daniel Ortiz
-- Fecha 12.febrero.2010
-- Asunto : seleccion de los centros del historico de pagos y no del maestro de empleados
--------------------------

--------------------------
-- Hecho por Estuardo Arévalo
-- Fecha 29.julio.2009
-- Asunto : Creacion de partidas de Planillas con utilizacion de proyects
--------------------------


set nocount on

declare @tasa_cambio decimal(12,6)

DECLARE @dias_periodo MONEY
DECLARE @dias_resto MONEY
DECLARE @FECHA_INI_MES  DATETIME
DECLARE @ANO_STR CHAR(4)
DECLARE @MES_STR CHAR(2)
DECLARE @FECHA_FIN_MES  DATETIME
DECLARE	@suma_monto MONEY,
		@suma_monto_dolar	MONEY


SELECT @ANO_STR = DATEPART(YY,fecha_final)
FROM NO_PERIODOS_PAGO
WHERE PERIODO_ID = @periodo_id 

SELECT @MES_STR = DATEPART(MM,fecha_final)
FROM NO_PERIODOS_PAGO
WHERE PERIODO_ID = @periodo_id 


IF LEN(RTRIM(LTRIM(@MES_STR))) = 1  SELECT @MES_STR = '0' + LTRIM(RTRIM(@MES_STR))

SELECT @FECHA_INI_MES = @ANO_STR + @MES_STR + '01'
SELECT @FECHA_FIN_MES = DATEADD(MM, 1, @FECHA_INI_MES)
SELECT @FECHA_FIN_MES = DATEADD(DD, -1, @FECHA_FIN_MES)

SELECT @dias_periodo = DATEDIFF(dd, fecha_inicial, fecha_final) + 1,
       @dias_resto = DATEDIFF (dd, fecha_final, @FECHA_FIN_MES )
FROM NO_PERIODOS_PAGO
WHERE PERIODO_ID = @periodo_id 




select @tasa_cambio = tasa_cambio from no_nomina_enc 
	where codigo_tipo = @codigo_tipo
		and periodo_id = @periodo_id
		and grupo_id = @grupo_id
		and no_calculo = @no_calculo



Create table #Partida (
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,     
     cargo money,
     abono money,
     cargo_dolar money, 
     abono_dolar money, 
     asociado varchar(60) COLLATE Modern_Spanish_CI_AS,
    codigo_centro  varchar(20)  COLLATE Modern_Spanish_CI_AS
)


Create table #Partida2 (
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,     
     cargo money,
     abono money,
     cargo_dolar money, 
     abono_dolar money, 
     asociado varchar(60) COLLATE Modern_Spanish_CI_AS,
    codigo_centro  varchar(20)  COLLATE Modern_Spanish_CI_AS
)

Create table #Partida3 (
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,     
     liquido money,
     codigo_centro  varchar(20)  COLLATE Modern_Spanish_CI_AS
)


Create table #Ingresos (
     codigo_tipo char(2) COLLATE Modern_Spanish_CI_AS ,     
     codigo_ingreso char(2) COLLATE Modern_Spanish_CI_AS ,     
     cuenta_sap varchar(20) COLLATE Modern_Spanish_CI_AS ,     
     codigo_renglon int ,    
    codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS       
)


Create table #Deducciones (
     codigo_tipo char(2) COLLATE Modern_Spanish_CI_AS ,     
     codigo_deduccion char(2) COLLATE Modern_Spanish_CI_AS ,     
     cuenta_sap varchar(20) COLLATE Modern_Spanish_CI_AS ,     
     codigo_renglon int,
    codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS 
)


Create table #Empleados (
     codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS ,          
     cuenta_sap varchar(20) COLLATE Modern_Spanish_CI_AS ,     
    codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS ,      
    asociado varchar(60) COLLATE Modern_Spanish_CI_AS
)


Create table #Centros (
     codigo_tipo char(10) COLLATE Modern_Spanish_CI_AS ,          
	 codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS ,      
     PrjCode nchar(16) COLLATE Modern_Spanish_CI_AS ,     
	 PrjName nchar(60) COLLATE Modern_Spanish_CI_AS ,		
)
Create table #Centros1 (
     codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS ,          
	 codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS ,      	
)


--obtenemos los renglones de los ingresos
insert into #Ingresos
		(codigo_tipo, codigo_ingreso, cuenta_sap, codigo_renglon,codigo_centro )
select  a.codigo_tipo, a.codigo_ingreso, a.cuenta_sap, b.codigo_renglon , a.codigo_centro
from sap_ingresos_proyectos a
	left join sap_renglones_ingresos  b
		on a.codigo_ingreso = b.codigo_ingreso
		and a.codigo_tipo = b.codigo_tipo
where a.codigo_tipo = @codigo_tipo



--obtenemos los renglones de deducciones
insert into #Deducciones
	( codigo_tipo, codigo_deduccion, cuenta_sap, codigo_renglon, codigo_centro )
select  a.codigo_tipo, a.codigo_deduccion, a.cuenta_sap, b.codigo_renglon , a.codigo_centro
from sap_deducciones_proyectos a
	left join sap_renglones_deducciones  b
		on a.codigo_deduccion = b.codigo_deducciones
		and a.codigo_tipo = b.codigo_tipo
where a.codigo_tipo = @codigo_tipo


-- Empleados
insert Into #Empleados
	(codigo_empleado, cuenta_sap, codigo_centro, asociado)
SELECT a.codigo_empleado, NULL, a.codigo_centro, a.nombre_corto
FROM no_empleados a
/*left join sap_empleados b
	on a.codigo_empleado = b.codigo_empleado
	and b.codigo_tipo = @codigo_tipo
*/
--Centros	
insert into #Centros
	(codigo_tipo, codigo_centro, PrjCode, PrjName)
select  a.codigo_tipo, a.codigo_centro, b.PrjCode, b.PrjName
from sap_centros a
	inner join sap_tr_proyectos b
		on a.codigo_sap = b.PrjCode
where a.codigo_tipo = @codigo_tipo
	
--- Primero los ingresos 
insert into #Partida
select 
	  'cuenta_sap' = b.cuenta_sap,
       sum(monto_ingreso),
       0,
      (sum(monto_ingreso)/@tasa_cambio),
       0, 
       c.asociado,
      a.codigo_centro
from no_nomina_det a, #Ingresos b, #Empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_ingreso = a.codigo_ingreso 
and a.codigo_empleado = c.codigo_empleado
and b.codigo_centro = c.codigo_centro
group by b.cuenta_sap, c.cuenta_sap ,a.codigo_centro, b.codigo_renglon, c.asociado
having sum(monto_ingreso) > 0


-- Sueldos por Liquidar

--Seleccionamos los codigos de centros del historico
INSERT INTO #Centros1 (
	codigo_empleado,
	codigo_centro)
SELECT DISTINCT codigo_empleado, codigo_centro 
FROM no_nomina_det
WHERE codigo_tipo=@codigo_tipo
AND periodo_id=@periodo_id
AND grupo_id=@grupo_id
AND no_calculo=@no_calculo



insert into #Partida
select b.cuenta_salios_sap ,
       0,
       sum(liquido)+0.005,
      0,
       sum(liquido)/@tasa_cambio, 
       '',d.codigo_centro
from no_nomina_emplcalc a, sap_parametros b, no_empleados c, #Centros1 d
where a.codigo_tipo = @codigo_tipo
and a.periodo_id = @periodo_id
and a.grupo_id = @grupo_id
and a.no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and a.codigo_empleado = c.codigo_empleado
and a.codigo_empleado=d.codigo_empleado
group by b.cuenta_salios_sap, d.codigo_centro


--- Cuenta de descuentos

--Obtenemos los descuentos por cuenta y por centro.
select 'cuenta_sap' = b.cuenta_sap,				
       0 cargo,
       sum(monto_deduccion)monto,
      0 cargo_dolar,
       sum(monto_deduccion)/@tasa_cambio monto_dolar, 
       c.asociado, 
      a.codigo_centro
INTO #descuentospartida
from no_nomina_det a, #Deducciones b, #Empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_empleado = c.codigo_empleado
and b.codigo_centro = c.codigo_centro
group by b.cuenta_sap, c.cuenta_sap ,a.codigo_centro, b.codigo_renglon, c.asociado
having sum(monto_deduccion) > 0

--Totalizamos los descuentos por centro
SELECT codigo_centro, SUM(monto)montoT, SUM(monto_dolar)monto_dolarT
INTO #descuentosporcentro
FROM #descuentospartida
GROUP BY codigo_centro

--Actualizamos tabla temporal
UPDATE #Partida SET abono = (abono + montoT), abono_dolar = (abono_dolar + monto_dolarT)
FROM #descuentosporcentro a
WHERE #Partida.codigo_centro = a.codigo_centro
AND #Partida.abono>0

/*
OBTIENE DESCUENTOS!!!, SE QUITA A PETICION DE SOLEL BONEH, NO QUIEREN QUE APAREZCAN EN EL REPORTE.

insert into #Partida
select 'cuenta_sap' = b.cuenta_sap,				
       0,
       sum(monto_deduccion),
      0,
       sum(monto_deduccion)/@tasa_cambio, 
       c.asociado, 
      a.codigo_centro
from no_nomina_det a, #Deducciones b, #Empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_empleado = c.codigo_empleado
and b.codigo_centro = c.codigo_centro
group by b.cuenta_sap, c.cuenta_sap ,a.codigo_centro, b.codigo_renglon, c.asociado
having sum(monto_deduccion) > 0
*/


-- Inserta los ingresos con saldo negativo a descuentos

insert into #Partida
select 
	  'cuenta_sap' =  b.cuenta_sap,
		0, 
       sum(monto_ingreso*-1),
       0,
      (sum(monto_ingreso*-1)/@tasa_cambio),
       
       c.asociado,
      a.codigo_centro
from no_nomina_det a, #Ingresos b, #Empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_ingreso = a.codigo_ingreso 
and a.codigo_empleado = c.codigo_empleado
and b.codigo_centro = c.codigo_centro
group by b.cuenta_sap, c.cuenta_sap ,a.codigo_centro, b.codigo_renglon, c.asociado
having sum(monto_ingreso) < 0

UPDATE #Partida SET asociado = ''
WHERE cuenta_contable NOT IN ( SELECT renglon FROM sap_renglones WHERE codigo_tipo = @codigo_tipo )

insert into #Partida2
	(cuenta_contable, cargo, abono, cargo_dolar, abono_dolar, asociado, codigo_centro)

Select a.cuenta_contable, SUM(a.cargo), SUM(a.abono), SUM(a.cargo_dolar), SUM(a.abono_dolar), a.asociado, b.PrjCode
from #Partida a
	left join #Centros b
		on a.codigo_centro  collate Modern_Spanish_CI_AS = b.codigo_centro  collate Modern_Spanish_CI_AS
		and b.codigo_tipo  collate Modern_Spanish_CI_AS = @codigo_tipo
group by a.cuenta_contable,  a.asociado, b.PrjCode

/* 
select a.cuenta_contable, d.AcctName as nombre_cuenta, a.cargo,  a.abono,
     'asociado' = CASE 
					 WHEN rtrim(ltrim(e.PrjCode)) <>  '' THEN e.PrjCode
					 ELSE a.cuenta_contable
				  END
	 ,'nombre_asociado' = CASE 
					 WHEN rtrim(ltrim(a.asociado)) <>  '' THEN (Select top 1 isnull(e.nombres,'') + ' ' + isnull(e.apellidos,'') from no_empleados e where e.nombre_corto =  a.asociado)
					 ELSE ''
				  END
	 , GETDATE() AS fecha_final, 'Reg Nomina No.'+b.no_nomina+ ' '+ c.descripcion as concepto
	,  isnull(ltrim(rtrim(e.PrjCode)),'')+'-'+isnull(e.PrjName,'') as nombre_proyecto
	,cargo_dolar
	,abono_dolar
	,@tasa_cambio
	, '' referencia 
from #Partida a, no_periodos_pago b, no_grupos_valores c, sap_tr_cuentas d, #Centros e
where b.periodo_id = @periodo_id
and c.grupo_id = @grupo_id
and a.codigo_centro *= e.codigo_centro
and a.cuenta_contable = d.AcctCode
order by cuenta_contable asc, e.PrjCode asc
*/


--   FORMA RESUMIDA
DECLARE @nombre_corto VARCHAR(30)
SELECT @nombre_corto = nombre_corto FROM dbo.no_tipos_nomina
	WHERE codigo_tipo = @codigo_tipo

IF @nombre_corto IS NULL SET @nombre_corto = ''



select a.cuenta_contable, d.AcctName as nombre_cuenta, 
ROUND((a.cargo /@dias_periodo * @dias_resto),2)   cargo,   ROUND((a.abono /@dias_periodo * @dias_resto),2) abono,
     'asociado' = CASE 
					 WHEN rtrim(ltrim(a.asociado)) <>  '' THEN a.asociado
					 ELSE a.cuenta_contable
				  END	
	 ,'nombre_asociado' = CASE 
					 WHEN rtrim(ltrim(a.asociado)) <>  '' THEN (Select top 1 isnull(e.nombres,'') + ' ' + isnull(e.apellidos,'') from no_empleados e where e.nombre_corto =  a.asociado)
					 ELSE ''
				  END
	 , GETDATE() AS fecha_final, ''+@nombre_corto+' '+RTRIM(b.no_nomina)+ ' AL '+ CONVERT ( VARCHAR(20), b.fecha_final , 105 ) as concepto
	,  isnull(ltrim(rtrim(e.PrjCode)),'')+'-'+isnull(e.PrjName,'') as nombre_proyecto
	,cargo_dolar/@dias_periodo * @dias_resto cargo_dolar
	,abono_dolar/@dias_periodo * @dias_resto abono_dolar
	,@tasa_cambio tasa_cambio
	, '' referencia 
	,'proyecto' = CASE 
					 WHEN rtrim(ltrim(a.codigo_centro)) <>  '' THEN rtrim(ltrim(a.codigo_centro))
					 ELSE rtrim(ltrim(a.cuenta_contable))
				  END				 
INTO #resultados
from #Partida2 a, no_periodos_pago b, no_grupos_valores c, sap_tr_cuentas d, sap_tr_proyectos e
where b.periodo_id = @periodo_id
and c.grupo_id = @grupo_id
and a.codigo_centro *= e.PrjCode
and a.cuenta_contable = d.AcctCode
order by d.AcctName asc, e.PrjCode asc

DECLARE @ajuste MONEY,
		@ajuste_dolar MONEY,
		@cuenta_salios_sap VARCHAR(20),
		@proyecto	VARCHAR(20)

SELECT @cuenta_salios_sap=cuenta_salios_sap FROM dbo.sap_parametros
WHERE codigo_tipo = @codigo_tipo

DECLARE curajuste CURSOR FOR
SELECT proyecto
FROM #resultados
OPEN curajuste
FETCH curajuste INTO @proyecto
WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @ajuste = SUM(cargo) - SUM(abono), @ajuste_dolar = SUM(cargo_dolar)- SUM(abono_dolar)
		FROM #resultados
		WHERE proyecto = @proyecto
		
		IF ((@ajuste<=0.10)AND(@ajuste>=-0.10))
		UPDATE #resultados SET abono = abono + @ajuste, abono_dolar = abono_dolar + @ajuste_dolar
		WHERE proyecto = @proyecto AND
		cuenta_contable = @cuenta_salios_sap
FETCH curajuste INTO @proyecto
	END
CLOSE curajuste
DEALLOCATE curajuste

SELECT cuenta_contable, nombre_cuenta, cargo, abono, asociado, nombre_asociado, fecha_final, concepto, 
	nombre_proyecto, cargo_dolar, abono_dolar, tasa_cambio, referencia, proyecto
FROM #resultados
--compute sum(cargo), sum(abono)
-- [stp_UDnoPartidaPlanillaSOLB] '01' , '0120090601', '010',0
go

