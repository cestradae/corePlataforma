-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_ereportedet_clsno_erepcolRelated]
(  @oldcodigo_repnomina smallint ,
  @oldnumero_columna smallint  )
  As 
SELECT a.codigo_repnomina,a.codigo_elemento,a.monto_base,a.numero_columna,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.factor,a.valor FROM [dbo].[no_nomina_reportedet] a
WHERE 
a.codigo_repnomina =  @oldcodigo_repnomina AND 
a.numero_columna =  @oldnumero_columna
go

