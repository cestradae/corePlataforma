CREATE TRIGGER [dbo].[trinsno_solicitud_ausencias] ON [dbo].[no_solicitud_ausencias] 
FOR INSERT, UPDATE
AS

------------------------
-- Cambiado por Daniel Ortiz
-- Fecha 05/01/2011
-- Asunto si el estado_solicitud no cambia y estado_solicitud_old no es null se sale 
-------------------------
------------------------
-- Cambiado por ldr
-- Fecha 05/10/2010
-- Asunto se incluyeron estandares
-------------------------

DECLARE @estado_solicitud CHAR(1),
		@estado_solicitud_old CHAR(1)

declare @codigo_empleado char(10),
             @corr_solicitud smallint,
             @codigo_tipo char(2),
             @dias_solicitar decimal(8,4),
             @fecha_inicial datetime,
             @descuenta_sabados char(1),
             @fecha_final datetime,
             @dias char(10)


select @codigo_empleado = codigo_empleado,
          @corr_solicitud = corr_solicitud,
          @codigo_tipo = codigo_tipo,
          @dias_solicitar = dias_solicitar,
          @fecha_inicial = fecha_inicio,
          @descuenta_sabados = descuenta_sabados,
          @estado_solicitud=estado_solicitud
from INSERTED

SELECT @estado_solicitud_old=estado_solicitud
FROM DELETED

IF @estado_solicitud=@estado_solicitud_old AND @estado_solicitud IS NOT NULL
	RETURN

select @dias = convert(char(10),@dias_solicitar )

if ( select count(*) from no_solicitud_ausdet where codigo_empleado = @codigo_empleado and corr_solicitud = @corr_solicitud ) = 0
begin
     exec stp_UDNoGEtFecha_Final  @codigo_tipo, @fecha_inicial,  @dias, @descuenta_sabados, @fecha_final out

    insert into no_solicitud_ausdet (
    codigo_empleado,
    corr_solicitud,
    corr_dias,
    de_fecha,
    a_fecha,
    no_dias )
    select @codigo_empleado,
    @corr_solicitud,
    1,
    @fecha_inicial,
    @fecha_final ,
    @dias_solicitar

    if @@error <> 0
    Begin
       Raiserror ('No se puede insertar el detalle de vacaciones - trinsno_solicitud_ausencias' ,16,1,5000)
       Rollback work
       Return
    End

end



go

