-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_cvariables]
  As SELECT a.tipo_valor,a.codigo_clase,a.descripcion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_clases_variables] a
go

