-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_sregiones]
  (  @oldcodigo_region varchar (10)  )
As SELECT TOP 1000 a.codigo_region,a.nombre_region FROM [dbo].[no_siex_regiones] a
WHERE (a.codigo_region =  @oldcodigo_region)
go

