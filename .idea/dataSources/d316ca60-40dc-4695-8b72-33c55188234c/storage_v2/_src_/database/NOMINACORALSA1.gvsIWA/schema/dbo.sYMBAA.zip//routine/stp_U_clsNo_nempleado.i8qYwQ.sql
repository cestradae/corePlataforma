-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_nempleado](  @oldCodigo_empleado char (10) ,
  @oldCodigo_tipo char (2) ,
  @Codigo_empleado char (10) ,
  @Codigo_tipo char (2) ,
  @Fecha_asignacion datetime ,
  @Usuario_asignacion varchar (35) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_nomina_empleado] 
WHERE codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_nomina_empleado] Set 
    codigo_empleado = @Codigo_empleado,
    codigo_tipo = @Codigo_tipo,
    fecha_asignacion = @Fecha_asignacion,
    usuario_asignacion = @Usuario_asignacion 
WHERE 	( codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_nomina_empleado]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
codigo_tipo =  @Codigo_tipo )
go

