Create procedure [dbo].[stp_sapcns_parametro]
   @codigo_tipo char(2)
as

set nocount on
 
Select 
      servidor,
      basedatos,
      usuario,
      clave,
      tipo_servidor,
	  lenguaje,
	  UsuarioDB,
	  ClaveDb
   from sap_parametros
  where codigo_tipo = @codigo_tipo
Return
go

