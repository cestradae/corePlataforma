-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_No_empleado_campos]
  (  @oldCodigo_empleado char (10) ,
  @oldNombre_campo varchar (10) ,
  @oldValor_lista varchar (20)  )
As SELECT a.codigo_empleado,a.nombre_campo,a.valor_lista,a.valor,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_empleado_campos] a
WHERE (a.codigo_empleado =  @oldCodigo_empleado AND 
a.nombre_campo =  @oldNombre_campo AND 
a.valor_lista =  @oldValor_lista)
go

