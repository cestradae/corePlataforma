-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_ndet]
  As SELECT a.periodo_id,a.codigo_tipo,a.grupo_id,a.no_calculo,a.codigo_empleado,a.correlativo,a.codigo_ingreso,a.monto_ingreso,a.codigo_deduccion,a.monto_deduccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.monto_base,a.codigo_departamento,a.codigo_centro FROM [dbo].[no_nomina_det] a
go

