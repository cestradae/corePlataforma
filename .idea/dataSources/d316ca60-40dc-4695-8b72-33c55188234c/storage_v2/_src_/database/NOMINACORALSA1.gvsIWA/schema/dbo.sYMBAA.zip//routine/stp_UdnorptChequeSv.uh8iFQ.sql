--use nsolbogua
CREATE PROCEDURE [dbo].[stp_UdnorptChequeSv] 
-------------------------------------------------------------------------------------------------------------
--Creado por: Mario Juarros
--Fecha: 07/11/2008
--Observaciones: Procedimiento para impresion de cheque para siembras vision
-------
-----------------------------------------------------------------------------------------------------
@id_cuenta as varchar(50),
			@numerocheque_Inicial as int,
			@numerocheque_final as int
			

AS
set nocount on


SELECT 	
	datepart(dd,f.fecha_cheque)dia
	,datepart(mm,f.fecha_cheque)mes
	,datepart(yy,f.fecha_cheque)ano
	,b.nombre_usual as beneficiario
	,a.monto_pagado as monto_cheque
	,f.concepto
	,a.id_cuenta
	,h.username as usuario_ingreso
	,a.numero_cheque
	,dbo.fn_ConversionLetras(a.monto_pagado,2)as Monto_Letras	
	,c.nombre_cuenta
	,a.codigo_empleado	
	,d.no_nomina + ' DEL ' + convert(varchar(20),d.fecha_inicial,103)+ ' AL ' + convert(varchar(20),d.fecha_final,103) as pago_numero
	,g.descripcion + ' ' + e.descripcion as concepto_pago
	,i.monto_ingreso
	,j.descripcion as nombre_ingreso
	,(i.monto_deduccion)*-1.00 as monto_deduccion
	,k.descripcion as nombre_deduccion
	,l.nombre_banco
	
/*
	,a.codigo_tipo
	,a.periodo_id
	,a.grupo_id
	,a.no_calculo
	
	,d.fecha_inicial
	,d.fecha_final
	,d.no_nomina
	
*/	
	
FROM no_nomina_emplcalc_det a
	INNER JOIN no_empleados b
		ON a.codigo_empleado = b.codigo_empleado
	INNER JOIN bn_cuentas c
		ON a.id_cuenta = c.id_cuenta
	INNER JOIN no_periodos_pago d
		ON a.periodo_id = d.periodo_id
	INNER JOIN no_grupos_valores e
		ON a.grupo_id = e.grupo_id
	INNER JOIN bn_cheques_enc f
		ON a.numero_cheque = f.numero_cheque
	INNER JOIN no_tipos_nomina g
		ON a.codigo_tipo = g.codigo_tipo
	LEFT JOIN _users h
		ON a.usuario_ingreso = h.userid
	INNER JOIN no_nomina_det i
		ON a.codigo_tipo = i.codigo_tipo
		and a.periodo_id = i.periodo_id
		and a.grupo_id = i.grupo_id
		and a.no_calculo = i.no_calculo
		and a.codigo_empleado = i.codigo_empleado
	LEFT JOIN no_catalogo_ingresos j
		ON i.codigo_ingreso = j.codigo_ingreso
	LEFT JOIN no_catalogo_deducciones k
		ON i.codigo_deduccion = k.codigo_deduccion
	LEFT JOIN bn_bancos l
		ON l.codigo_banco = c.codigo_banco
where a.id_cuenta=@id_cuenta and a.numero_cheque between @numerocheque_Inicial and @numerocheque_final
and (i.monto_ingreso > 0 or i.monto_deduccion > 0)
go

