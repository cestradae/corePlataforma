-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_config_punto]
  (  @oldcodigo_tipo char (2)  )
As SELECT a.codigo_tipo FROM [dbo].[no_configuracion_punto] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo)
go

