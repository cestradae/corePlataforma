-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_nomina_puestos]
  (  @oldcodigo_puesto char (10) ,
  @oldcodigo_tipo char (2)  )
As SELECT a.codigo_puesto,a.codigo_tipo,a.fecha_asignacion FROM [dbo].[no_nomina_puestos] a
WHERE (a.codigo_puesto =  @oldcodigo_puesto AND 
a.codigo_tipo =  @oldcodigo_tipo)
go

