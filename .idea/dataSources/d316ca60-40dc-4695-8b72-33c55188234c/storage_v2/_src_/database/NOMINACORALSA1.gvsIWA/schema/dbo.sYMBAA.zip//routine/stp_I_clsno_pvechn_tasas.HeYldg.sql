-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_pvechn_tasas](@AUTO_EditStamp varchar(30) OUT,
  @impuesto_vecinal smallint ,
  @correlativo smallint ,
  @monto_de money ,
  @monto_a money ,
  @tasa decimal (18,4)  )
As 
	INSERT INTO [dbo].[no_parametros_vechn_tasas]
(  impuesto_vecinal ,
  correlativo ,
  monto_de ,
  monto_a ,
  tasa  )
VALUES (  @impuesto_vecinal ,
  @correlativo ,
  @monto_de ,
  @monto_a ,
  @tasa  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_parametros_vechn_tasas]
  WHERE ( impuesto_vecinal =  @impuesto_vecinal AND 
correlativo =  @correlativo )
go

