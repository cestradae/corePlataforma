
-- Procedure definition
CREATE PROCEDURE stp_D_clsnohn_rrentahn_emp
  (  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10)  )
As DELETE [dbo].[no_reporte_rentahn_empleado] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado)
go

