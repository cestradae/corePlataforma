
-- Procedure definition
CREATE PROCEDURE stp_I_clsnohn_patronos_hn(@AUTO_EditStamp varchar(30) OUT,
  @codigo_patrono smallint ,
  @nombre_patrono varchar (100) ,
  @direccion_patrono varchar (100) ,
  @numero_patronal varchar (50) ,
  @codigo_rap char (3) ,
  @codigo_infop char (3) ,
  @codigo_seguro char (3)  )
As 
	INSERT INTO [dbo].[no_patronos_hn]
(  codigo_patrono ,
  nombre_patrono ,
  direccion_patrono ,
  numero_patronal ,
  codigo_rap ,
  codigo_infop ,
  codigo_seguro  )
VALUES (  @codigo_patrono ,
  @nombre_patrono ,
  @direccion_patrono ,
  @numero_patronal ,
  @codigo_rap ,
  @codigo_infop ,
  @codigo_seguro  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_patronos_hn]
  WHERE ( codigo_patrono =  @codigo_patrono )
go

