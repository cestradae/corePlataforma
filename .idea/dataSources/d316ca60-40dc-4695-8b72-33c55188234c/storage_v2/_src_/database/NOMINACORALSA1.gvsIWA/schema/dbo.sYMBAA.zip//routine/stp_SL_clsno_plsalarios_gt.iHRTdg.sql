-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_plsalarios_gt]
  As SELECT a.codigo_tipo,a.ing_ordinario,a.ing_extraordinario,a.ing_septimos,a.ing_asuetos,a.ing_vacaciones,a.ing_aguinaldo,a.ing_bono14,a.ing_indemnizacion,a.ing_otros,a.ing_bonificacion,a.ded_igss,a.ded_descuentos,a.ded_anticipos,a.ded_prestamos,a.ded_otras,a.val_dias,a.va_horasextras FROM [dbo].[no_parametros_libro_salarios_gt] a
go

