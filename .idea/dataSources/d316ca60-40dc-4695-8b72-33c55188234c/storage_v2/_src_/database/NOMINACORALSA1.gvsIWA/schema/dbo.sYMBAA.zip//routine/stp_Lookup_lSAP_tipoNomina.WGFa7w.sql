-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_tipoNomina]
As
  SELECT codigo_tipo, codigo_tipo +' - '+Descripcion as Descripcion
 FROM no_tipos_nomina
 ORDER BY descripcion
go

