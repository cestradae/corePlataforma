-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_solausenciasC]
  (  @oldcodigo_empleado char (10) ,
  @oldcorr_solicitud smallint  )
As DELETE [dbo].[no_solicitud_ausencias] 
WHERE (codigo_empleado =  @oldcodigo_empleado AND 
corr_solicitud =  @oldcorr_solicitud)
go

