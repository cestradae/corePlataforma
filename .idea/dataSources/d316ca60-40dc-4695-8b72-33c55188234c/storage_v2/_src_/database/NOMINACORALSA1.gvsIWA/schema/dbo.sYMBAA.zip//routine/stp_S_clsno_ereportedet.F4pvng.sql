-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_ereportedet]
  (  @oldcodigo_repnomina smallint ,
  @oldnumero_columna smallint ,
  @oldcodigo_elemento varchar (11)  )
As SELECT a.codigo_repnomina,a.codigo_elemento,a.monto_base,a.numero_columna,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.factor,a.valor FROM [dbo].[no_nomina_reportedet] a
WHERE (a.codigo_repnomina =  @oldcodigo_repnomina AND 
a.numero_columna =  @oldnumero_columna AND 
a.codigo_elemento =  @oldcodigo_elemento)
go

