-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_config_punto](  @oldcodigo_tipo char (2) ,
  @codigo_tipo char (2)  )
As 
UPDATE [dbo].[no_configuracion_punto] Set 
    codigo_tipo = @codigo_tipo 
WHERE 	( codigo_tipo =  @oldcodigo_tipo )
go

