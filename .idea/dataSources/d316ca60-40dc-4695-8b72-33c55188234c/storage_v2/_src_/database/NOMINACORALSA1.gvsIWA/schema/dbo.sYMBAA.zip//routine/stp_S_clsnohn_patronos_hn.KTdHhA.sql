
-- Procedure definition
CREATE PROCEDURE stp_S_clsnohn_patronos_hn
  (  @oldcodigo_patrono smallint  )
As SELECT a.codigo_patrono,a.nombre_patrono,a.direccion_patrono,a.numero_patronal,a.codigo_rap,a.codigo_infop,a.codigo_seguro,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_patronos_hn] a
WHERE (a.codigo_patrono =  @oldcodigo_patrono)
go

