-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_ingresos_proy_clssap_ingresosRelated]
(  @oldcodigo_tipo char (2) ,
  @oldcodigo_ingreso varchar (3)  )
  As 
SELECT a.codigo_tipo,a.codigo_ingreso,a.codigo_clase,a.codigo_centro,a.cuenta_sap FROM [dbo].[sap_ingresos_proyectos] a
WHERE 
a.codigo_tipo =  @oldcodigo_tipo AND 
a.codigo_ingreso =  @oldcodigo_ingreso
go

