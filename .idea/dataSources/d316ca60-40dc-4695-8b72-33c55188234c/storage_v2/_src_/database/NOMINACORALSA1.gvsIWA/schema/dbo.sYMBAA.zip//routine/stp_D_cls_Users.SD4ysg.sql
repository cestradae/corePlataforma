-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_cls_Users]
  (  @oldUserID int  )
As DELETE [dbo].[_Users] 
WHERE (UserID =  @oldUserID)
go

