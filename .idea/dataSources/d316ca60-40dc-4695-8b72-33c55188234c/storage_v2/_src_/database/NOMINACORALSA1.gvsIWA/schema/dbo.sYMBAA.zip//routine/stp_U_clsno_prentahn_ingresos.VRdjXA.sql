-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_prentahn_ingresos](  @oldcodigo_impuesto char (3) ,
  @oldcodigo_ingreso char (3) ,
  @codigo_impuesto char (3) ,
  @codigo_ingreso char (3) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_parametros_rentahn_ingresos] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_ingreso =  @oldcodigo_ingreso 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_parametros_rentahn_ingresos] Set 
    codigo_impuesto = @codigo_impuesto,
    codigo_ingreso = @codigo_ingreso 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_ingreso =  @oldcodigo_ingreso )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_parametros_rentahn_ingresos]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
codigo_ingreso =  @codigo_ingreso )
go

