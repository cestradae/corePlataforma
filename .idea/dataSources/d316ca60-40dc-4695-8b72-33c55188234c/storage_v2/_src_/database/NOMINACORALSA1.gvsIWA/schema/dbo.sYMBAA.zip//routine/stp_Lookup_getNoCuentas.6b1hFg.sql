-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoCuentas]
As
  SELECT id_cuenta IDCuenta , codigo_cuenta +'-'+ nombre_cuenta Cuenta
FROM bn_cuentas
go

