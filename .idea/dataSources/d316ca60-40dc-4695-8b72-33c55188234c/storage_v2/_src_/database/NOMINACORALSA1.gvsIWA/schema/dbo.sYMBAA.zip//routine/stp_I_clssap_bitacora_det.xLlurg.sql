-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_bitacora_det](  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @calculo int ,
  @correlativo int ,
  @cuenta_contable varchar (20) ,
  @cargos money ,
  @abonos money ,
  @codigo_asociado varchar (20) ,
  @codigo_centro varchar (20) ,
  @nombre_asociado varchar (300) ,
  @nombre_centro varchar (300)  )
As 
	INSERT INTO [dbo].[sap_bitacora_det]
(  codigo_tipo ,
  periodo_id ,
  grupo_id ,
  calculo ,
  correlativo ,
  cuenta_contable ,
  cargos ,
  abonos ,
  codigo_asociado ,
  codigo_centro ,
  nombre_asociado ,
  nombre_centro  )
VALUES (  @codigo_tipo ,
  @periodo_id ,
  @grupo_id ,
  @calculo ,
  @correlativo ,
  @cuenta_contable ,
  @cargos ,
  @abonos ,
  @codigo_asociado ,
  @codigo_centro ,
  @nombre_asociado ,
  @nombre_centro  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

