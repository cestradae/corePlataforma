-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_nvarsistema](  @oldcodigo_empleado char (10) ,
  @oldcodigo_variable varchar (20) ,
  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint ,
  @codigo_empleado char (10) ,
  @codigo_variable varchar (20) ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @no_calculo smallint ,
  @valor decimal (18,4) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_nomina_variables_sistema] 
WHERE codigo_empleado =  @oldcodigo_empleado AND 
codigo_variable =  @oldcodigo_variable AND 
codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_nomina_variables_sistema] Set 
    codigo_empleado = @codigo_empleado,
    codigo_variable = @codigo_variable,
    codigo_tipo = @codigo_tipo,
    periodo_id = @periodo_id,
    grupo_id = @grupo_id,
    no_calculo = @no_calculo,
    valor = @valor 
WHERE 	( codigo_empleado =  @oldcodigo_empleado AND 
codigo_variable =  @oldcodigo_variable AND 
codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_nomina_variables_sistema]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
codigo_variable =  @codigo_variable AND 
codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
grupo_id =  @grupo_id AND 
no_calculo =  @no_calculo )
go

