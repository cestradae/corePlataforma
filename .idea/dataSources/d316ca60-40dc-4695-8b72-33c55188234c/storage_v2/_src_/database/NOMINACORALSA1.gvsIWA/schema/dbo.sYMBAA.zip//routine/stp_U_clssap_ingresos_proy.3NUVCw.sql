-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_ingresos_proy](  @oldcodigo_tipo char (2) ,
  @oldcodigo_ingreso varchar (3) ,
  @oldcodigo_clase varchar (20) ,
  @oldcodigo_centro varchar (20) ,
  @codigo_tipo char (2) ,
  @codigo_ingreso varchar (3) ,
  @codigo_clase varchar (20) ,
  @codigo_centro varchar (20) ,
  @cuenta_sap nvarchar (15)  )
As 
UPDATE [dbo].[sap_ingresos_proyectos] Set 
    codigo_tipo = @codigo_tipo,
    codigo_ingreso = @codigo_ingreso,
    codigo_clase = @codigo_clase,
    codigo_centro = @codigo_centro,
    cuenta_sap = @cuenta_sap 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_ingreso =  @oldcodigo_ingreso AND 
codigo_clase =  @oldcodigo_clase AND 
codigo_centro =  @oldcodigo_centro )
go

