create  procedure [dbo].[stp_UDnoBorraNominas] --'04','06'
  @tipo_inicial char(2),
  @tipo_final char(2)
as 

--------------------------
-- Borrar Tablas 
-- Fecha 04/02/2010
--------------------------
BEGIN tran
delete from no_nomina_det where codigo_tipo between @tipo_inicial and @tipo_final 
delete from no_nomina_emplcalc where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_emplcalc_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_enc where codigo_tipo between @tipo_inicial and @tipo_final 
delete from no_empleado_ingresos_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_ingresos where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_deducciones where codigo_tipo between @tipo_inicial and @tipo_final 
delete from no_nomina_asistencia where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_valores_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_valores_calculados where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_variables_sistema where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_parametros_liquidacion where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_provisiones_empleados where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_provisiones_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_provisiones_enc where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_provisiones_sap where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_parametros_gt_tipos where codigo_tipo between @tipo_inicial and @tipo_final
--delete from no_parametros_gt_centros 
delete from no_parametros_gt_det 
delete from no_reporte_detalle where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_reporte_empleado where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_reporte_valores   where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_reporte_valores_estadistico where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_reporte_valores_ingreso where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_reportes_autorizaciones where codigo_tipo between @tipo_inicial and @tipo_final
UPDATE dbo.no_deducciones_det SET estado = 'A' WHERE codigo_tipo between @tipo_inicial and @tipo_final
delete from no_deducciones_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_deducciones_ajustes where codigo_tipo between @tipo_inicial and @tipo_final
UPDATE dbo.no_deducciones_enc SET saldo = monto WHERE codigo_tipo between @tipo_inicial and @tipo_final
delete from no_deducciones_enc where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_vacdet where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_grupos_detalle where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_grupos_valores where codigo_tipo between @tipo_inicial and @tipo_final

select a.codigo_empleado
into #Empleados
from no_empleados a, no_nomina_empleado b
where a.codigo_empleado = b.codigo_empleado 
 and b.codigo_tipo between @tipo_inicial and @tipo_final

DELETE FROM dbo.no_empleado_provision_enc
	WHERE codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)

delete from no_nomina_empleado
  where codigo_tipo between @tipo_inicial and @tipo_final

delete from no_liquidaciones
  where codigo_tipo between @tipo_inicial and @tipo_final


  
delete from no_solicitud_ausdet-----------------------------------------------------------------------------
    where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)
OR codigo_empleado NOT IN (SELECT codigo_empleado FROM dbo.no_empleados)


delete from no_solicitud_ausvac-----------------------------------------------------------------------------
    where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)

delete from no_solicitud_ausencias
    where codigo_tipo between @tipo_inicial and @tipo_final

delete from no_salarios_minimos
       where codigo_tipo between @tipo_inicial and @tipo_final

--delete from no_puestos_provisiones
--     where codigo_tipo between @tipo_inicial and @tipo_final

--
--delete from no_puestos_ingresos
--      where codigo_tipo between @tipo_inicial and @tipo_final


delete from no_periodos_pago
    where codigo_tipo between @tipo_inicial and @tipo_final
/*
delete from no_valores_sistema
    where codigo_tipo between @tipo_inicial and @tipo_final
*/
delete from no_nomina_valores_det
    where codigo_tipo between @tipo_inicial and @tipo_final


delete from no_nomina_valores
    where codigo_tipo between @tipo_inicial and @tipo_final


delete from no_nomina_vacparam       where codigo_tipo between @tipo_inicial and @tipo_final
--delete from no_nomina_puestos        where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_liqprovision   where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_ingresos       where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_deducciones    where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_provisiones    where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_autorizadores  where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_asuetos        where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_nomina_asistencia     where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_deducciones  where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_campos       where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)-----------------------------------------------------------------------------
delete from no_empleado_anticipos    where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_nivel_acadamico where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)
delete from no_empleado_valores where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_supervisores where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)-----------------------------------------------------------------------------
delete from no_empleado_provisiones where codigo_tipo between @tipo_inicial and @tipo_final
--delete from no_empleado_provisiones_det where codigo_tipo between @tipo_inicial and @tipo_final
delete from no_empleado_entrenamiento where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)-----------------------------------------------------------------------------
delete from no_empleado_vacaciones where codigo_empleado IN (SELECT codigo_empleado FROM #Empleados)-----------------------------------------------------------------------------
delete from no_empleado_vacdet where codigo_tipo between @tipo_inicial and @tipo_final

delete from no_empleados 
from #Empleados
where #Empleados.codigo_empleado = no_empleados.codigo_empleado

DELETE FROM dbo.no_tipos_nomina WHERE codigo_tipo BETWEEN @tipo_inicial AND @tipo_final

COMMIT TRAN
go

