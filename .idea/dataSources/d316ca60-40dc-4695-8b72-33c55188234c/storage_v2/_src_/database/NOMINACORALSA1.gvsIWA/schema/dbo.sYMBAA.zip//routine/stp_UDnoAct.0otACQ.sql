create procedure stp_UDnoAct
   @periodo_id_ingreso char(10)
as 

declare
  @codigo_tipo char(2)
  ,@periodo_id char(10)
  ,@tipo_Valor char(1) 
  ,@codigo_valor char(11)
  ,@codigo_empleado char(10)
  ,@codigo_departamento smallint
  ,@codigo_centro varchar(10)


declare cur_actualiza cursor for
  select  codigo_tipo 
  ,periodo_id 
  ,tipo_Valor  
  ,codigo_valor 
  ,codigo_empleado 
  ,codigo_departamento 
  ,codigo_centro 

   from no_reporte_valores_ingreso
   where periodo_id = @periodo_id_ingreso
open cur_actualiza 
   
fetch cur_actualiza into 
  @codigo_tipo
  ,@periodo_id
  ,@tipo_Valor 
  ,@codigo_valor 
  ,@codigo_empleado 
  ,@codigo_departamento  
  ,@codigo_centro 

while @@fetch_status = 0
Begin

print @codigo_empleado
update no_reporte_valores_ingreso
   set valor = valor
where  codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id
  and tipo_Valor = @tipo_valor 
  and codigo_valor = @codigo_valor
  and codigo_empleado = @codigo_empleado
  and codigo_departamento = @codigo_departamento
  and codigo_centro = @codigo_centro



fetch cur_actualiza into 
   @codigo_tipo
  ,@periodo_id
  ,@tipo_Valor 
  ,@codigo_valor 
  ,@codigo_empleado 
  ,@codigo_departamento  
  ,@codigo_centro 

End

close cur_actualiza
deallocate cur_actualiza


go

