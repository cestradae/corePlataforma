
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_isr_proy_integ_clsno_ipdetalleRelated
(  @oldcodigo_empleado char (10) ,
  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint  )
  As 
SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.sueldos,a.sueldos_p,a.sueldos_t,a.horas_extras,a.horas_extras_p,a.horas_extras_t,a.bono_decreto,a.bono_decreto_p,a.bono_decreto_t,a.otras_bonificiaciones,a.otras_bonificaciones_p,a.otras_bonificaciones_t,a.comisiones,a.comisiones_p,a.comisiones_t,a.propinas,a.propinas_p,a.propinas_t,a.aguinaldo,a.aguinaldo_p,a.aguinaldo_t,a.bono14,a.bono14_p,a.bono14_t,a.viaticos,a.viaticos_p,a.viaticos_t,a.gastos_rep,a.gastos_rep_p,a.gastos_rep_t,a.dietas,a.dietas_p,a.dietas_t,a.gratificaciones,a.gratificaciones_p,a.gratificaciones_t,a.remuneraciones,a.remuneraciones_p,a.remuneraciones_t,a.prestaciones_igss,a.prestaciones_igss_p,a.prestaciones_igss_t,a.otros,a.otros_p,a.otros_t,a.indemnizacionesm,a.indemnizacionesm_p,a.indemnizacionesm_t,a.indemnizacionest,a.indemnizacionest_p,a.indemnizacionest_t,a.diplomaticos,a.diplomaticos_p,a.diplomaticos_t,a.representacion,a.representacion_p,a.representacion_t,a.viaticos_com,a.viaticos_com_p,a.viaticos_com_t,a.cuota_laboral,a.cuota_laboral_p,a.cuota_laboral_t,a.otros_planes,a.otros_planes_p,a.otros_planes_t,a.donaciones,a.seguro_vida,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_isr_proyeccion_integracion] a
WHERE 
a.codigo_empleado =  @oldcodigo_empleado AND 
a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.ano =  @oldano AND 
a.mes =  @oldmes
go

