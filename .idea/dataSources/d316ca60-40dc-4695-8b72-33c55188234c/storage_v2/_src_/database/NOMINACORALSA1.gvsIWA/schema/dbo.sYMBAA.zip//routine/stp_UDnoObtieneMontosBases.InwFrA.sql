CREATE procedure [dbo].[stp_UDnoObtieneMontosBases]
as
-----------------------
-- Usuario lsao
-- fecha 03-03-2008
-- Asunto Obtiene variables reportadas
----------------------
select 'Base'+nombre_corto, 'Base ' +descripcion, 'declare @Base' + nombre_corto +  ' decimal(18,4) ' variable,
 'Select @Base'+nombre_corto+'= case tipo_moneda when ''1'' then isnull(monto,0) '+
                                               ' when ''2'' then isnull(round(monto/tasa_cambio,2),0) '+
                                               ' when ''3'' then isnull(round(monto*tasa_cambio,2),0) end ' +
  'from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d '+
  'where a.codigo_tipo = @codigo_tipo  ' +
  'and a.codigo_tipo = c.codigo_tipo ' +
  'and a.codigo_ingreso = c.codigo_ingreso ' +
  'and d.codigo_tipo = @codigo_tipo ' +
  'and d.grupo_id = @grupo_id ' +
  'and d.periodo_id = @periodo_id ' +
  'and d.no_calculo = @no_calculo ' +
  'and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso ' +
  'and b.nombre_corto = ' + char(39)+nombre_corto+char(39) query, 
 'isnull(@Base' + nombre_corto+',0)' variableA
from no_catalogo_ingresos
go

