create procedure stp_UDnoFormula37   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @tmp1 decimal(18,4)
declare @tmp2 decimal(18,4)
declare @tmp3 decimal(18,4)
declare @DNOLAB decimal(22,6) 

begin
  exec stp_UDnoBasUMesesIngresos 'Ord',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  1 ,  @tmp1 out
exec stp_UDnoBasUMesesIngresos 'Boni_Ince',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  1 ,  @tmp2 out
exec stp_UDnoBasUMesesIngresos 'Boni_Decre',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  1 ,  @tmp3 out
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '18        ' ) = '1'  begin Select @DNOLAB= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '18        ' end else begin Select @DNOLAB= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '18        ' end 

  set @result=(@tmp1+@tmp2+@tmp3)/30*isnull(@DNOLAB,0)
end
go

