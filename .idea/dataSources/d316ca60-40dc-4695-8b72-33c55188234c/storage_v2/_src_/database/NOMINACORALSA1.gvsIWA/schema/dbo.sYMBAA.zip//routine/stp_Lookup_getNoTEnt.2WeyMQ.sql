-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoTEnt]
As
  SELECT tipo_entrenamiento Tipo, descripcion Descripcion
FROM no_tipos_entrenamiento
go

