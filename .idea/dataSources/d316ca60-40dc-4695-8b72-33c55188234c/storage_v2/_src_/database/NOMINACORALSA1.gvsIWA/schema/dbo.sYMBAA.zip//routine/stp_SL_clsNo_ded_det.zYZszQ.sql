-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_ded_det]
  As SELECT a.codigo_empleado,a.codigo_tipo,a.codigo_deduccion,a.correlativo,a.periodo_id,a.monto,a.estado,a.grupo_id,a.usuario_ingreso,a.fecha_ingreso,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_deducciones_det] a
go

