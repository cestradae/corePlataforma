-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_sminimos_clsNo_tipos_nominaRelated]
(  @oldcodigo_tipo char (2)  )
  As 
SELECT a.codigo_tipo,a.periodo_id,a.salario,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_salarios_minimos] a
WHERE 
a.codigo_tipo =  @oldcodigo_tipo
go

