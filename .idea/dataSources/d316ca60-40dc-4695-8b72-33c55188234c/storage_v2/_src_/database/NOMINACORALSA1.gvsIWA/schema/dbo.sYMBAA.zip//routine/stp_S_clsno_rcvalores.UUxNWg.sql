-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_rcvalores]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldno_reporte smallint  )
As SELECT a.codigo_tipo,a.periodo_id,a.no_reporte,a.grupo_id,a.no_calculo,a.fecha_reporte,a.genera_aut,a.estado_reporte,a.fecha_ingreso,a.usuario_ingreso,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_valores] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id AND 
a.no_reporte =  @oldno_reporte)
go

