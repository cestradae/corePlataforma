-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_provisiones]
  As SELECT a.codigo_tipo,a.codigo_provision,a.cuenta_sap,a.cuenta_sap_gasto FROM [dbo].[sap_provisiones] a
go

