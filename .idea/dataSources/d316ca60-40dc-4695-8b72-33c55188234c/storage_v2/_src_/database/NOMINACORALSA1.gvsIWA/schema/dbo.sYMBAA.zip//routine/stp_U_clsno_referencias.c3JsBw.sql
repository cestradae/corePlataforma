-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_referencias](  @oldreferencia varchar (20) ,
  @referencia varchar (20) ,
  @descripcion varchar (100) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_referencias] 
WHERE referencia =  @oldreferencia 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_referencias] Set 
    referencia = @referencia,
    descripcion = @descripcion 
WHERE 	( referencia =  @oldreferencia )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_referencias]
  WHERE ( referencia =  @referencia )
go

