-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_nomina_puestos]
  As SELECT a.codigo_puesto,a.codigo_tipo,a.fecha_asignacion FROM [dbo].[no_nomina_puestos] a
go

