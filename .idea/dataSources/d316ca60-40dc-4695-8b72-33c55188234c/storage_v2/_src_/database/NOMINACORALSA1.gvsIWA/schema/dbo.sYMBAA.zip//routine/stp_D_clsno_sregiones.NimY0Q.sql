-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_sregiones]
  (  @oldcodigo_region varchar (10)  )
As DELETE [dbo].[no_siex_regiones] 
WHERE (codigo_region =  @oldcodigo_region)
go

