CREATE TRIGGER [dbo].[trinsno_reporte_valores_ingreso] ON [dbo].[no_reporte_valores_ingreso] 
FOR INSERT
AS
------------------
-- Creado por dortiz
-- Fecha 24-03-2011
-- Asunto Si el orden es 2 no valida que el empleado pertenezca al departamento
-------------------
------------------
-- Creado por lsao
-- Fecha 27-08-2008
-- Asunto Ingreso de valores reportados
-------------------
declare @codigo_tipo char(2)
declare @periodo_id char(10)
declare @no_reporte smallint
declare @grupo_id char(5)
declare @no_calculo smallint
declare @fecha_reporte datetime
declare @codigo_empleado char(10)
declare @codigo_departamento smallint
declare @codigo_centro varchar(20)
declare @tipo_valor char(1)
declare @codigo_valor char(10)
declare @valor decimal(18,4)
declare @usuario_ingreso int
declare @fecha_ingreso datetime
declare @codigo_seccion smallint
declare @codigo_puesto smallint
declare @periodo varchar(6)
declare @valor1 decimal(18,4)
declare @valor2 decimal(18,4)
declare @valor3 decimal(18,4)
declare @valor4 decimal(18,4)
declare @valor5 decimal(18,4)
declare @codigo_dato char(10)
declare @unidad varchar(10)
declare @correlativo INT
DECLARE @es_extra CHAR(1)
DECLARE @orden_ingreso INTEGER
declare @fechaerror varchar(10)



select @codigo_tipo =codigo_tipo,
          @periodo_id = periodo_id,
          @no_reporte = no_reporte,
          @grupo_id = grupo_id,
          @no_calculo = no_calculo,
          @fecha_reporte = DATEADD(dd, DATEDIFF(dd, 0, fecha_reporte), 0), -- Eliminacion de horas a cero JHERRERA
          @codigo_empleado  = codigo_empleado, 
          @codigo_departamento = codigo_departamento,
          @codigo_centro = codigo_centro,
          @tipo_valor = tipo_valor,
          @codigo_valor = codigo_valor,
          @valor = valor,
          @usuario_ingreso = usuario_ingreso,
          @fecha_ingreso = fecha_ingreso,
          @valor1 = isnull(valor1,0),
        
  @valor2 = isnull(valor2,0),
          @valor3 = isnull(valor3,0),
          @valor4 = isnull(valor4,0),
          @valor5 = isnull(valor5,0),
          @correlativo = isnull(correlativo,0),
          @es_extra = es_extra
from inserted

SELECT @orden_ingreso=ISNULL(orden_ingreso,1) FROM dbo.no_generales

--- Valida datos de catalogos

if not exists ( select 1 from no_empleados where codigo_empleado = @codigo_empleado )
Begin
   Raiserror ('Empleado no existe -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return
End

/*
IF @orden_ingreso<>2
BEGIN 

	if not exists ( select 1 from no_empleados where codigo_empleado = @codigo_empleado and codigo_departamento = @codigo_departamento )
	Begin
	   Raiserror ('Empleado no pertenece al departamento ingresado - trinsno_reporte_valores_ingreso ', 16,1,5000)
	   Rollback work
	   Return
	END
END
*/
if not exists ( select 1 from gn_departamentos where codigo_departamento = @codigo_departamento )
Begin
   Raiserror ('Departamento no existe -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return
End

if not exists ( select 1 from cn_catalogo_centros where codigo_centro = @codigo_centro )
Begin
   Raiserror ('Centro de costo no existe -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return

End


---- Fecha Reporte


if not exists ( select 1 from no_periodos_pago where @fecha_reporte between DATEADD(dd, DATEDIFF(dd, 0, fecha_inicial), 0) and DATEADD(dd, DATEDIFF(dd, 0, fecha_final), 0) and periodo_id = @periodo_id )
Begin
   Raiserror ('Fecha no corresponde al periodo de pago -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return

End

---- Validamos el grupo de pago, periodo

if not exists ( select 1 from no_grupos_valores where codigo_tipo = @codigo_tipo and grupo_id = @grupo_id )
Begin
   Raiserror ('Grupo de pago no pertenece a la  tipo de nomina que se está trabajando -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return
End

---- Validadmos el periodo de pago
if not exists ( select 1 from no_periodos_pago where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id )
Begin
   Raiserror ('Periodo de pago no pertenece a la  tipo de nomina que se está trabajando -  trinsno_reporte_valores_ingreso ', 16,1,5000)
   Rollback work
   Return
End

---- Validamos que una tarea sea ingresada para el periodo una vez en el dia

if exists ( select 1 from no_reporte_valores_ingreso where codigo_tipo = @codigo_tipo 
	and periodo_id = @periodo_id and codigo_valor = @codigo_valor 
	and tipo_valor=@tipo_valor	and  fecha_reporte = @fecha_reporte and codigo_empleado = @codigo_empleado 
	and codigo_centro = @codigo_centro and correlativo <> @correlativo 
	AND ISNULL(es_extra,'') = ISNULL(@es_extra,'') )
Begin
	set @fechaerror=convert(varchar(10),@fecha_reporte,110)
   Raiserror ('Valor Reportado ya fue ingresado para esta fecha %s y empleado %s- trinsno_reporte_valores_ingreso ', 16,1,@fechaerror,@codigo_empleado)
   Rollback work
   Return
End


select @codigo_seccion = codigo_seccion,
          @codigo_puesto = codigo_puesto
from no_empleados
where codigo_empleado = @codigo_empleado


if not exists ( select 1 from no_reporte_valores where codigo_tipo = @codigo_tipo  
	and periodo_id = @periodo_id and no_reporte = @no_reporte )
Begin
   ----- Creamos el encabezado del reporte

   insert into no_reporte_valores (  
            codigo_tipo,
            periodo_id,
            no_reporte,
            grupo_id,
            no_calculo,
            fecha_reporte,
            genera_aut,
            estado_reporte,
            fecha_ingreso,
            usuario_ingreso,
            no_autorizaciones )
    values ( @codigo_tipo, @periodo_id, @no_reporte, @grupo_id, @no_calculo, @fecha_reporte, 'N', 'O' , @fecha_ingreso, @usuario_ingreso, 0 )

   if @@error <> 0
   Begin
         Raiserror (' No se puede insertar el encabezado - trinsno_reporte_valores_ingreso ', 16,1,5000)
         Rollback work
         Return
   End   
End


---- Procedemos a ingresar el reporte en el detalle

if not exists ( select 1 from no_reporte_empleado where codigo_tipo = @codigo_tipo 
	and periodo_id = @periodo_id and no_reporte = @no_reporte 
	and codigo_empleado = @codigo_empleado )
Begin

     insert
 into no_reporte_empleado (
          codigo_tipo,
          periodo_id,
          no_reporte,
          codigo_empleado,
          codigo_departamento,
          codigo_centro,
          estado_reporte,
          codigo_Seccion,
          codigo_puesto )

      values (
         @codigo_tipo,
         @periodo_id,
         @no_reporte,
         @codigo_empleado,
         @codigo_departamento,	
         @codigo_centro,
         'O' ,
         @codigo_seccion,
         @codigo_puesto )

   if @@error <> 0
 
  Begin
        Raiserror (' No se puede insertar el detalle del empleado - trinsno_reporte_valores_ingreso ', 16,1,5000)
        Rollback work
        Return
   End
         
End

select @codigo_valor = @tipo_valor + @codigo_Valor

if exists ( select 1 from no_reporte_detalle where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and no_reporte = @no_reporte and codigo_empleado = @codigo_empleado and codigo_valor = @codigo_valor )
Begin
     delete from no_reporte_Detalle
           where codigo_tipo = @codigo_tipo
               and periodo_id = @periodo_id
               and no_reporte = @no_reporte
               and codigo_empleado = @codigo_empleado
               and codigo_valor = @codigo_valor

     if @@error <> 0
     Begin
           Raiserror ('No se puede eliminar el valor ingresado - trinsno_reporte_valores_ingreso ', 16,1,5000)
           Rollback work
           Return
     End
End


insert into no_reporte_detalle (
     codigo_tipo,
     periodo_id, 
     no_reporte,
     codigo_empleado,
     codigo_valor,
     no_calculo,
     valor )
values (
    @codigo_tipo,
    @periodo_id,
    @no_reporte,
    @codigo_empleado,
    @codigo_valor,
    @no_calculo,
    @valor
)

if @@error <> 0
Begin
    Raiserror ('No se puede insertar el valor del detalle - trinsno_reporte_valores_ingreso ', 16,1,5000)
    Rollback work
    Return
End

---- Procedeos a insertar la asistencia 

if not exists ( select 1 from no_nomina_asistencia where codigo_empleado = @codigo_empleado 
	and codigo_tipo = @codigo_tipo and grupo_id = @grupo_id and periodo_id = @periodo_id 
	and no_calculo = @no_calculo and fecha = @fecha_reporte )
Begin
   insert into no_nomina_asistencia (
       codigo_empleado,
       codigo_tipo,
       grupo_id,
       periodo_id,
       no_calculo,
       fecha )
   values (
       @codigo_empleado,
       @codigo_tipo,
       @grupo_id,
       @periodo_id,
       @no_calculo,
       @fecha_reporte )

    if @@error <> 0 
    Begin
       Raiserror ('No existe se pudo insertar la existencia - trinsno_reporte_valores_ingreso ' ,16,1,5000)
       Rollback work
       Return
    End
End

----- Procedemos a insertar los estadisticos
if @tipo_valor = 1 --- Variables
Begin
  if @valor1  <> 0
  Begin
      select @codigo_dato = ''
      select @unidad = ''
      select @codigo_dato = codigo_dato,
                @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 1 

      if @codigo_dato is null select @codigo_dato = ''
      if @unidad is null select @unidad = ''
      if len(@codigo_dato) > 0 
      Begin
      
        insert into no_reporte_valores_estadistico (
               codigo_tipo,
               periodo_id,
               grupo_id, 
               no_reporte,
               no_calculo,
               codigo_empleado,
               codigo_departamento,
               codigo_centro,
               codigo_valor,
               codigo_dato,
               unidad,
               valor,
               fecha_reporte )
         values ( @codigo_tipo,
                       @periodo_id,
                       @grupo_id,
                       @no_reporte,
                       @no_calculo,
                       @codigo_empleado,
                       @codigo_departamento,
                       @codigo_centro,
                       @codigo_valor,
                       @codigo_dato,
                       @unidad,
                       @valor1,
                       @fecha_reporte )

   
        if @@error <> 0
           Begin
                 Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
                 Rollback work
                 Return
           End
        End
  End

  if @valor2 
 <> 0
  Begin
      select @codigo_dato = ''
      select @unidad = ''
  
     select @codigo_dato = codigo_dato,
                @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 2 

      if @codigo_dato is null select @codigo_dato = ''
      if @unidad is null select @unidad = ''

      if len(@codigo_dato) > 0 
      Begin
      
        insert into no_reporte_valores_estadistico (
               codigo_tipo,
               periodo_id,
               grupo_id, 
               no_reporte,
               no_calculo,
               codigo_empleado,
               codigo_departamento,
               codigo_centro,
               codigo_valor,
               codigo_dato,
               unidad,
               valor,
               fecha_reporte )
         values ( @codigo_tipo,
                       @periodo_id,
                       @grupo_id,
                       @no_reporte,
                       @no_calculo,
                       @codigo_empleado,
                       @codigo_departamento,
                       @codigo_centro,
                       @codigo_valor,
                       @codigo_dato,
                       @unidad,
                       @valor2,
                       @fecha_reporte )

           if @@error <> 0
           Begin
                 Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
                 Rollback work
      
           Return
           End
        End  
  End

  if @valor3  <> 0
  Begin
      select @codigo_dato = ''
      select @unidad = ''
 
      select @codigo_dato = codigo_dato,
                @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 3 

      if @codigo_dato is null select @codigo_dato = ''
      if @unidad is null select @unidad = ''

      if len(@codigo_dato) > 0 
       Begin
      
   
     insert into no_reporte_valores_estadistico (
               codigo_tipo,
               periodo_id,
               grupo_id, 
               no_reporte,
               no_calculo,
               codigo_empleado,
               codigo_departamento,
               codigo_centro,
               codigo_valor,
               codigo_dato,
               unidad,
               valor,
               fecha_reporte )
         values ( @codigo_tipo,
                       @periodo_id,
                       @grupo_id,
                       @no_reporte,
                       @no_calculo,
                       @codigo_empleado,
                       @codigo_departamento,
                       @codigo_centro,
                       @codigo_valor,
                       @codigo_dato,
                       @unidad,
                       @valor3,
                       @fecha_reporte )

           if @@error <> 0
           Begin
                 Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
                 Rollback work
                 Return
           End
         End
  End

  if @valor4  <> 0
  Begin
      select @codigo_dato = ''
      select @unidad = ''
 
      select @codigo_dato = codigo_dato,
       
         @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 4
      if @codigo_dato is null select @codigo_dato = ''
      if @unidad is null select @unidad = ''

      if len(@codigo_dato) > 0 
      Begin
      
        insert into no_reporte_valores_estadistico (
               codigo_tipo,
               periodo_id,
               grupo_id, 
               no_reporte,
               no_calculo,
      
         codigo_empleado,
               codigo_departamento,
               codigo_centro,
               codigo_valor,
               codigo_dato,
               unidad,
               valor,
               fecha_reporte )
         values ( @codigo_tipo
,
                       @periodo_id,
                       @grupo_id,
                       @no_reporte,
                       @no_calculo,
                       @codigo_empleado,
                       @codigo_departamento,
                       @codigo_centro,
                       @codigo_valor,
                       @codigo_dato,
                       @unidad,
                       @valor4,
                       @fecha_reporte )

           if @@error <> 0
           Begin
                 Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
                 Rollback work
                 Return
           End
         End
  End

  if @valor5  <> 0
  Begin
     select @codigo_dato = ''
     select @unidad = ''
  
     select @codigo_dato = codigo_dato,
                @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 5
      if @codigo_dato is null
 select @codigo_dato = ''
      if @unidad is null select @unidad = ''

      if len(@codigo_dato) > 0 
      Begin
     insert into no_reporte_valores_estadistico (
               codigo_tipo,
               periodo_id,
               grupo_id, 
               no_reporte,
               no_calculo,
               codigo_empleado,
               codigo_departamento,
               codigo_centro,
               codigo_valor,
               codigo_dato,
               unidad,
               valor,
               fecha_reporte )
         values (   @codigo_tipo,
                       @periodo_id,
                       @grupo_id,
                       @no_reporte,
		               @no_calculo,
                       @codigo_empleado,
                       @codigo_departamento,
                       @codigo_centro,
                       @codigo_valor,
                       @codigo_dato,
                       @unidad,
                       @valor5,
                       @fecha_reporte )

           if @@error <> 0
           Begin
                 Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
                 Rollback work
                 Return
           End
         End
  End

End



go

