-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_sminimos](@AUTO_EditStamp varchar(30) OUT,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @salario money  )
As 
	INSERT INTO [dbo].[no_salarios_minimos]
(  codigo_tipo ,
  periodo_id ,
  salario  )
VALUES (  @codigo_tipo ,
  @periodo_id ,
  @salario  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_salarios_minimos]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id )
go

