
CREATE function [dbo].[fnno_ObtieneIngHistorico](
          @codigo_tipo char(2),
          @periodo_id char(10),
          @codigo_empleado char(10),
          @mes smallint,
          @codigo_ingreso char(3) )

Returns Money 
as
----------------------------
-- Modificador por dortiz
-- Fecha 11/12/2014
-- Asunto Se agreo funcionalidad de meses variables por medio de valores negativos
----------------------------
-- Modificador por dortiz
-- Fecha 25/05/2011
-- Asunto Se compone el año el año del ingreso que muestra
----------------------------
-- Hecho por lsao
-- Fecha 07/10/2010
-- Asunto Obtiene Ingresos
----------------------------
Begin

Declare @resultado money
Declare @ano_periodo smallint
Declare @mes_periodo smallint
Declare @ano smallint
Declare @periodo_busqueda char(10)

select @ano_periodo = substring(@periodo_id, 3,4)
select @mes_periodo = substring(@periodo_id, 7,2)

-- si el @mes es negativo
If @mes<0
begin 
	if (@mes*-1)>=@mes_periodo
	begin 
		select @mes=12+@mes+@mes_periodo
	end 
	else 
	begin 
		select @mes=@mes_periodo+@mes
	end
end 

if @mes >= @mes_periodo 
	select @ano = @ano_periodo - 1
else
	select @ano = @ano_periodo


select @periodo_busqueda = @codigo_tipo+CONVERT(char(10), @ano*10000+@mes*100+ 01)
   
 
select @resultado = dbo.FnNo_IngresoMes  (@codigo_tipo,@codigo_ingreso,
@codigo_empleado,@periodo_busqueda )


if @resultado is null select @resultado = 0


Return @resultado 

End

go

