-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoSecciones]
As
  SELECT codigo_seccion Codigo, nombre_seccion Nombre
FROM no_secciones
go

