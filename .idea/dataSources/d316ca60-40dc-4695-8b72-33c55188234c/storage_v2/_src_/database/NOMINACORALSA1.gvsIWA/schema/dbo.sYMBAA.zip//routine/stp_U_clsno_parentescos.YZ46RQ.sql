-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_parentescos](  @oldcodigo_empleado char (10) ,
  @oldcorrelativo smallint ,
  @codigo_empleado char (10) ,
  @correlativo smallint OUT  ,
  @nombre_pariente varchar (100) ,
  @fecha_nacimiento datetime ,
  @codigo_parentesco smallint ,
  @EditStamp varchar(30) OUT ,
  @edad int OUT   )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_parentescos] 
WHERE codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_parentescos] Set 
    codigo_empleado = @codigo_empleado,
    nombre_pariente = @nombre_pariente,
    fecha_nacimiento = @fecha_nacimiento,
    codigo_parentesco = @codigo_parentesco 
WHERE 	( codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @correlativo = correlativo, @EditStamp = convert(varchar(30),convert(INT,EditStamp )), @edad = ISNULL(edad,0) From [dbo].[no_parentescos]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
correlativo =  @correlativo )
go

