-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_referencias]
  As SELECT a.referencia,a.descripcion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_referencias] a
go

