-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getnoSeguroDed]
As
  SELECT codigo_seguro, descripcion
FROM no_parametros_seguro_gt
go

