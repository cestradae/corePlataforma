CREATE procedure [dbo].[stp_UDnoCalulaOrdinarioSV]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_ingreso char(3)
AS
declare @fecha_inicial datetime
declare @fecha_final datetime

select @fecha_inicial = fecha_inicial,
       @fecha_final = fecha_final
from no_periodos_pago
where periodo_id = @periodo_id


select @codigo_tipo,
       @periodo_id,
       @grupo_id,
       @no_calculo,
       a.codigo_empleado, 
       a.codigo_departamento, 
       a.codigo_centro, 
       @codigo_ingreso,
        sum(total),
        sum(total) ,
       a.tipo_valor
from no_reporte_valores_ingreso a, no_empleados b, no_nomina_valores c,
     no_nomina_emplcalc d
where a.fecha_reporte between  @fecha_inicial and @fecha_final
  and a.codigo_tipo = @codigo_tipo
  and a.periodo_id = @periodo_id
  and a.grupo_id = @grupo_id
  and a.no_calculo = @no_calculo
  and a.tipo_valor = 1
  and a.codigo_empleado = b.codigo_empleado
  and a.codigo_valor = c.codigo_valor
  and a.codigo_tipo = c.codigo_tipo
  and isnull(c.extra,'') = 'N'
  and a.codigo_tipo = d.codigo_tipo
  and a.periodo_id = d.periodo_id
  and a.grupo_id = d.grupo_id
  and a.no_calculo = d.no_calculo
  and a.codigo_empleado = d.codigo_empleado
group by a.codigo_empleado, a.codigo_centro, a.codigo_departamento, b.codigo_puesto, a.tipo_valor


Begin Tran

  insert into no_nomina_det (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        codigo_departamento,
        codigo_centro,
        codigo_ingreso,
        monto_ingreso,
        monto_ingreso_o )

select @codigo_tipo,
       @periodo_id,
       @grupo_id,
       @no_calculo,
       a.codigo_empleado, 
       a.codigo_departamento, 
       a.codigo_centro, 
       @codigo_ingreso,
        sum(total),
        sum(total) 
from no_reporte_valores_ingreso a, no_empleados b, no_nomina_valores c
where a.fecha_reporte between  @fecha_inicial and @fecha_final
  and a.codigo_tipo = @codigo_tipo
  and a.periodo_id = @periodo_id
  and a.grupo_id = @grupo_id
  and a.no_calculo = @no_calculo
  and a.tipo_valor = 1
  and a.codigo_empleado = b.codigo_empleado
  and a.codigo_valor = c.codigo_valor
  and a.codigo_tipo = c.codigo_tipo
  and isnull(c.extra,'') = 'N'
group by a.codigo_empleado, a.codigo_centro, a.codigo_departamento, b.codigo_puesto


if @@error <> 0
Begin
   Raiserror ('No se puede calcular el ingreso - stp_UDnoCalulaOrdinarioSV ', 16,1,5000)
   Rollback work
   Return 9
End

Commit Tran
go

