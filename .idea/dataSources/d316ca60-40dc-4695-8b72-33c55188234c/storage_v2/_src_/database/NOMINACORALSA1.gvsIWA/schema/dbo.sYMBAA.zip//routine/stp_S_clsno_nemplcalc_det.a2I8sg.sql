-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_nemplcalc_det]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint ,
  @oldnumero_cheque int ,
  @oldid_cuenta varchar (32) ,
  @oldtipo_movimiento smallint ,
  @oldcodigo_empleado char (10)  )
As SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.numero_cheque,a.id_cuenta,a.tipo_movimiento,a.codigo_empleado,a.monto_pagado,a.estado_cheque,a.fecha_anulacion,a.usuario_anulacion,a.fecha_ingreso,a.usuario_ingreso FROM [dbo].[no_nomina_emplcalc_det] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id AND 
a.grupo_id =  @oldgrupo_id AND 
a.no_calculo =  @oldno_calculo AND 
a.numero_cheque =  @oldnumero_cheque AND 
a.id_cuenta =  @oldid_cuenta AND 
a.tipo_movimiento =  @oldtipo_movimiento AND 
a.codigo_empleado =  @oldcodigo_empleado)
go

