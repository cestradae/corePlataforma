CREATE procedure [dbo].[stp_UDNoEliminaCargaReporte]
   @error char(1) out
as
------------------------
-- Hecho por LDR
-- Fecha 22/05/2009
-- Elimina la carga Inicial
-------------------------
Begin Tran
select @error = ''
delete from no_carga_reporte
if @@error <> 0
Begin
   Raiserror ('No se pudo eliminar la carga - stp_UDNoEliminaCargaReporte ' , 16,1,5000)
   Rollback work
   Return
End
Commit Tran
go

