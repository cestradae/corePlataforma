
-- Procedure definition
CREATE PROCEDURE stp_I_clsnohn_crr_emptasas(@AUTO_EditStamp varchar(30) OUT,
  @codigo_impuesto char (3) ,
  @ano smallint ,
  @mes smallint ,
  @codigo_empleado char (10) ,
  @correlativo smallint ,
  @hasta money ,
  @porcentaje decimal (18,4) ,
  @monto_impuesto money  )
As 
	INSERT INTO [dbo].[no_reporte_rentahn_emptasas]
(  codigo_impuesto ,
  ano ,
  mes ,
  codigo_empleado ,
  correlativo ,
  hasta ,
  porcentaje ,
  monto_impuesto  )
VALUES (  @codigo_impuesto ,
  @ano ,
  @mes ,
  @codigo_empleado ,
  @correlativo ,
  @hasta ,
  @porcentaje ,
  @monto_impuesto  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_reporte_rentahn_emptasas]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
ano =  @ano AND 
mes =  @mes AND 
codigo_empleado =  @codigo_empleado AND 
correlativo =  @correlativo )
go

