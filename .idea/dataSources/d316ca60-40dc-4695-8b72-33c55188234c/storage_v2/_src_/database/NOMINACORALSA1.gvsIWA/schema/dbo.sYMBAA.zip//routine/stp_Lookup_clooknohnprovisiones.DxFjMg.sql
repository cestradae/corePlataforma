-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohnprovisiones]
As
  SELECT codigo_provision, descripcion
from no_catalogo_provisiones
go

