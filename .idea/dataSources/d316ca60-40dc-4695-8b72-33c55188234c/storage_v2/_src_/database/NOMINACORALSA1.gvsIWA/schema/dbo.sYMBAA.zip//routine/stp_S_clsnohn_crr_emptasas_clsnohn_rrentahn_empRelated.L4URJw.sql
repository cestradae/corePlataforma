
-- Procedure definition
CREATE PROCEDURE stp_S_clsnohn_crr_emptasas_clsnohn_rrentahn_empRelated
(  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10)  )
  As 
SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.correlativo,a.hasta,a.porcentaje,a.monto_impuesto,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_rentahn_emptasas] a
WHERE 
a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.ano =  @oldano AND 
a.mes =  @oldmes AND 
a.codigo_empleado =  @oldcodigo_empleado
go

