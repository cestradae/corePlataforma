CREATE TRIGGER [dbo].[trinsno_nomina_asuetos] ON dbo.no_nomina_asuetos 
FOR INSERT, UPDATE
AS

declare @fecha_asueto datetime,
             @codigo_tipo char(2)

select @fecha_asueto = fecha_asueto,
           @codigo_tipo = codigo_tipo
from inserted

update no_nomina_asuetos
    set no_nomina_asuetos.fecha_asueto = convert(char(4),datepart(yy,no_nomina_asuetos.fecha_asueto)) +'/'+
                                   convert(char(2),datepart(dd,no_nomina_asuetos.fecha_asueto)) +'/'+
                                   convert(char(2),datepart(mm,no_nomina_asuetos.fecha_asueto))
from inserted
where inserted.codigo_tipo = no_nomina_asuetos.codigo_tipo
    and inserted.fecha_asueto = no_nomina_asuetos.fecha_asueto


go

