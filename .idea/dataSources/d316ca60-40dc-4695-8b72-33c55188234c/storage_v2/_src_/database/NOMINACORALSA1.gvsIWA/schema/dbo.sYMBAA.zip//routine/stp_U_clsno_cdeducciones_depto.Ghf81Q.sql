-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_cdeducciones_depto](  @oldcodigo_deduccion char (3) ,
  @oldcodigo_departamento smallint ,
  @codigo_deduccion char (3) ,
  @codigo_departamento smallint ,
  @cuenta_contable varchar (30) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_catalogo_deducciones_depto] 
WHERE codigo_deduccion =  @oldcodigo_deduccion AND 
codigo_departamento =  @oldcodigo_departamento 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_catalogo_deducciones_depto] Set 
    codigo_deduccion = @codigo_deduccion,
    codigo_departamento = @codigo_departamento,
    cuenta_contable = @cuenta_contable 
WHERE 	( codigo_deduccion =  @oldcodigo_deduccion AND 
codigo_departamento =  @oldcodigo_departamento )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_catalogo_deducciones_depto]
  WHERE ( codigo_deduccion =  @codigo_deduccion AND 
codigo_departamento =  @codigo_departamento )
go

