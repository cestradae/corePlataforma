-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_ndet](  @AUTO_Correlativo smallint OUT,
@AUTO_EditStamp varchar(30) OUT,
  @Periodo_id char (10) ,
  @Codigo_tipo char (2) ,
  @Grupo_id char (5) ,
  @No_calculo smallint ,
  @Codigo_empleado char (10) ,
  @Codigo_ingreso char (3) ,
  @Monto_ingreso money ,
  @Codigo_deduccion char (3) ,
  @Monto_deduccion money ,
  @Monto_base money ,
  @codigo_departamento smallint ,
  @codigo_centro varchar (20)  )
As 
	INSERT INTO [dbo].[no_nomina_det]
(  periodo_id ,
  codigo_tipo ,
  grupo_id ,
  no_calculo ,
  codigo_empleado ,
  codigo_ingreso ,
  monto_ingreso ,
  codigo_deduccion ,
  monto_deduccion ,
  monto_base ,
  codigo_departamento ,
  codigo_centro  )
VALUES (  @Periodo_id ,
  @Codigo_tipo ,
  @Grupo_id ,
  @No_calculo ,
  @Codigo_empleado ,
  @Codigo_ingreso ,
  @Monto_ingreso ,
  @Codigo_deduccion ,
  @Monto_deduccion ,
  @Monto_base ,
  @codigo_departamento ,
  @codigo_centro  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  Select @AUTO_Correlativo = @@IDENTITY
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_nomina_det]
  WHERE ( codigo_tipo =  @Codigo_tipo AND 
periodo_id =  @Periodo_id AND 
codigo_empleado =  @Codigo_empleado AND 
correlativo =  @AUTO_Correlativo AND 
grupo_id =  @Grupo_id AND 
no_calculo =  @No_calculo )
go

