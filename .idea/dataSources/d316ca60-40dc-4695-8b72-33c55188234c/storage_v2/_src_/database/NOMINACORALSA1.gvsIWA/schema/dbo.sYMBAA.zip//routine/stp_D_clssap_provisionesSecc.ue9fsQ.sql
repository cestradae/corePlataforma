-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_provisionesSecc]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_provision char (3) ,
  @oldcodigo_seccion varchar (5)  )
As DELETE [dbo].[sap_provisiones_secciones] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
codigo_provision =  @oldcodigo_provision AND 
codigo_seccion =  @oldcodigo_seccion)
go

