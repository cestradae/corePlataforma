-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_empleados](  @oldcodigo_tipo char (2) ,
  @oldcodigo_empleado char (10) ,
  @codigo_tipo char (2) ,
  @codigo_empleado char (10) ,
  @cuenta_sap varchar (30)  )
As 
UPDATE [dbo].[sap_empleados] Set 
    codigo_tipo = @codigo_tipo,
    codigo_empleado = @codigo_empleado,
    cuenta_sap = @cuenta_sap 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_empleado =  @oldcodigo_empleado )
go

