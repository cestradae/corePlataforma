-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_sminimos](  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @salario money ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_salarios_minimos] 
WHERE codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_salarios_minimos] Set 
    codigo_tipo = @codigo_tipo,
    periodo_id = @periodo_id,
    salario = @salario 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_salarios_minimos]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id )
go

