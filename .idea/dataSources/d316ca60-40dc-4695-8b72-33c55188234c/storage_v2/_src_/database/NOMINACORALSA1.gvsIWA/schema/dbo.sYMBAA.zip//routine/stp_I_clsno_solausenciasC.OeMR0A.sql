-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_solausenciasC](@AUTO_EditStamp varchar(30) OUT,
  @codigo_empleado char (10) ,
  @corr_solicitud smallint ,
  @codigo_tipo char (2) ,
  @fecha_solicitud datetime ,
  @dias_solicitar decimal (8,2) ,
  @descuenta_sabados char (1) ,
  @fecha_inicio datetime ,
  @tipo_solicitud char (1) ,
  @motivo char (1) ,
  @observaciones varchar (100) ,
  @dia_descontado char (1) ,
  @estado_solicitud char (10) ,
  @fecha_autoriza datetime ,
  @usuario_autoriza varchar (35) ,
  @fecha_alta datetime ,
  @usuario_alta varchar (35)  )
As 
	INSERT INTO [dbo].[no_solicitud_ausencias]
(  codigo_empleado ,
  corr_solicitud ,
  codigo_tipo ,
  fecha_solicitud ,
  dias_solicitar ,
  descuenta_sabados ,
  fecha_inicio ,
  tipo_solicitud ,
  motivo ,
  observaciones ,
  dia_descontado ,
  estado_solicitud ,
  fecha_autoriza ,
  usuario_autoriza ,
  fecha_alta ,
  usuario_alta  )
VALUES (  @codigo_empleado ,
  @corr_solicitud ,
  @codigo_tipo ,
  @fecha_solicitud ,
  @dias_solicitar ,
  @descuenta_sabados ,
  @fecha_inicio ,
  @tipo_solicitud ,
  @motivo ,
  @observaciones ,
  @dia_descontado ,
  @estado_solicitud ,
  @fecha_autoriza ,
  @usuario_autoriza ,
  @fecha_alta ,
  @usuario_alta  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_solicitud_ausencias]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
corr_solicitud =  @corr_solicitud )
go

