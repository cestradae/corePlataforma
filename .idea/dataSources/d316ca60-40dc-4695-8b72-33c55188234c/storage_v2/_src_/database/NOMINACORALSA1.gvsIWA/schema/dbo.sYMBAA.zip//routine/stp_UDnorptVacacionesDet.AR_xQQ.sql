CREATE procedure [dbo].[stp_UDnorptVacacionesDet] 
   @tipo_inicial char(2),
   @tipo_final char(2),
   @empleado_inicial char(10),
   @empleado_final char(10),
   @depto_inicial smallint,
   @depto_final smallint
as
set nocount on

if @tipo_final = '' select @tipo_final = max(codigo_tipo) from no_tipos_nomina
if @empleado_final = '' select @empleado_final = max(codigo_empleado) from no_empleados
if @depto_inicial = 0 select @depto_inicial = min(codigo_departamento) from gn_departamentos
if @depto_final = 0 select @depto_final = max(codigo_departamento) from gn_departamentos


select a.codigo_empleado, a.codigo_tipo, fecha_solicitud, 
       fecha_inicio, a.observaciones, de_fecha, a_fecha, no_dias, b.periodo
from no_solicitud_ausencias a, no_solicitud_ausvac b, 
     no_solicitud_ausdet c, no_empleados d
where  a.tipo_solicitud = 'V'
and a.codigo_empleado = b.codigo_empleado
and a.corr_solicitud = b.corr_solicitud
and b.codigo_empleado = c.codigo_empleado
and b.corr_solicitud = c.corr_solicitud
and b.corr_dias = c.corr_dias
and a.codigo_empleado = d.codigo_empleado
and a.codigo_tipo between @tipo_inicial and @tipo_final
and d.codigo_departamento between @depto_inicial and @depto_final
and a.codigo_empleado between @empleado_inicial and @empleado_final
go

