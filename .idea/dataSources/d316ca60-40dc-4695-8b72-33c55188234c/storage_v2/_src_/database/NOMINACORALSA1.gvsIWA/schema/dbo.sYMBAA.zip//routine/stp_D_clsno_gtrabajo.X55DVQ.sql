-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_gtrabajo]
  (  @oldgrupo_trabajo smallint  )
As DELETE [dbo].[no_grupos_trabajo] 
WHERE (grupo_trabajo =  @oldgrupo_trabajo)
go

