CREATE TRIGGER [dbo].[trdelno_provisiones_empleados] ON dbo.no_provisiones_empleados 
FOR  UPDATE, DELETE 
AS


-- Actualizamos el encabezado de las provisiones 

Begin Tran

select  codigo_tipo,
           periodo_id,
           codigo_provision,
           sum(monto_base) monto_base,
           sum(monto_provision ) monto_provision
into #Total 
from deleted
group by codigo_tipo, periodo_id, codigo_provision

-- Actualizamos las provisiones encabezado 

update no_provisiones_det
    set no_provisiones_det.monto_base = no_provisiones_det.monto_base - #Total.monto_base,
         no_provisiones_det.monto_provision =     no_provisiones_det.monto_provision - #Total.monto_provision
from #Total
where #Total.codigo_tipo = no_provisiones_det.codigo_tipo
    and #Total.periodo_id = no_provisiones_det.periodo_id
    and #Total.codigo_provision = no_provisiones_det.codigo_provision

if @@error <> 0 
begin
   raiserror ('No se pudo actualizar el calculo por empleado  - trdelno_provisiones_empleado ' ,16,1,5000 )
   rollback tran
   return
end

          
-- Actualizamos el saldo por empleado 

-- Procemos a actualizar el saldo 

update no_empleado_provisiones 
    set no_empleado_provisiones.saldo_provision  = no_empleado_provisiones.saldo_provision - deleted.monto_provision
from deleted
where deleted.codigo_empleado = no_empleado_provisiones.codigo_empleado
    and deleted.codigo_tipo = no_empleado_provisiones.codigo_tipo
    and deleted.codigo_provision = no_empleado_provisiones.codigo_provision
    and deleted.codigo_departamento = no_empleado_provisiones.codigo_departamento
    and deleted.codigo_centro = no_empleado_provisiones.codigo_centro 

if @@error <> 0 
begin
   raiserror ('No se pudo actualizar el saldo de provisiones por empleado - trdelno_provisiones_empleado ' ,16,1,5000 )
   rollback tran
   return
end

Commit Tran
go

