-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_plsalarios_gt](  @oldcodigo_tipo char (2) ,
  @codigo_tipo char (2) ,
  @ing_ordinario char (3) ,
  @ing_extraordinario char (3) ,
  @ing_septimos char (3) ,
  @ing_asuetos char (3) ,
  @ing_vacaciones char (3) ,
  @ing_aguinaldo char (3) ,
  @ing_bono14 char (3) ,
  @ing_indemnizacion char (3) ,
  @ing_otros char (3) ,
  @ing_bonificacion char (3) ,
  @ded_igss char (3) ,
  @ded_descuentos char (3) ,
  @ded_anticipos char (3) ,
  @ded_prestamos char (3) ,
  @ded_otras char (3) ,
  @val_dias char (10) ,
  @va_horasextras char (10)  )
As 
UPDATE [dbo].[no_parametros_libro_salarios_gt] Set 
    codigo_tipo = @codigo_tipo,
    ing_ordinario = @ing_ordinario,
    ing_extraordinario = @ing_extraordinario,
    ing_septimos = @ing_septimos,
    ing_asuetos = @ing_asuetos,
    ing_vacaciones = @ing_vacaciones,
    ing_aguinaldo = @ing_aguinaldo,
    ing_bono14 = @ing_bono14,
    ing_indemnizacion = @ing_indemnizacion,
    ing_otros = @ing_otros,
    ing_bonificacion = @ing_bonificacion,
    ded_igss = @ded_igss,
    ded_descuentos = @ded_descuentos,
    ded_anticipos = @ded_anticipos,
    ded_prestamos = @ded_prestamos,
    ded_otras = @ded_otras,
    val_dias = @val_dias,
    va_horasextras = @va_horasextras 
WHERE 	( codigo_tipo =  @oldcodigo_tipo )
go

