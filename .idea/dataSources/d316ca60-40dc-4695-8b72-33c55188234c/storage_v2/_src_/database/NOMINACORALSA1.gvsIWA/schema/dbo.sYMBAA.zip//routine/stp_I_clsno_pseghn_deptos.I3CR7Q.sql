-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_pseghn_deptos](@AUTO_EditStamp varchar(30) OUT,
  @codigo_seguro smallint ,
  @codigo_departamento char (2)  )
As 
	INSERT INTO [dbo].[no_parametros_seghn_deptos]
(  codigo_seguro ,
  codigo_departamento  )
VALUES (  @codigo_seguro ,
  @codigo_departamento  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_parametros_seghn_deptos]
  WHERE ( codigo_seguro =  @codigo_seguro AND 
codigo_departamento =  @codigo_departamento )
go

