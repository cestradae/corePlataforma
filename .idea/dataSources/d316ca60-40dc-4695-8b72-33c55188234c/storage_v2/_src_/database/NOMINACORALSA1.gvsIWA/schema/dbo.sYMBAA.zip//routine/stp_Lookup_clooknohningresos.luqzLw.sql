-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohningresos]
As
  SELECT codigo_ingreso, descripcion
FROM no_catalogo_ingresos
go

