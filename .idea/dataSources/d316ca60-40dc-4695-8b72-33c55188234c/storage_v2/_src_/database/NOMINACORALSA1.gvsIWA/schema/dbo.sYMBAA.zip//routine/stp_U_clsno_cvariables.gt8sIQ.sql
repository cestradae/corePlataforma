-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_cvariables](  @oldcodigo_clase varchar (20) ,
  @tipo_valor char (10) ,
  @codigo_clase varchar (20) ,
  @descripcion varchar (50) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_clases_variables] 
WHERE codigo_clase =  @oldcodigo_clase 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_clases_variables] Set 
    tipo_valor = @tipo_valor,
    codigo_clase = @codigo_clase,
    descripcion = @descripcion 
WHERE 	( codigo_clase =  @oldcodigo_clase )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_clases_variables]
  WHERE ( codigo_clase =  @codigo_clase )
go

