-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_nvalores_det]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_valor char (10) ,
  @oldcodigo_dato char (10)  )
As DELETE [dbo].[no_nomina_valores_det] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
codigo_valor =  @oldcodigo_valor AND 
codigo_dato =  @oldcodigo_dato)
go

