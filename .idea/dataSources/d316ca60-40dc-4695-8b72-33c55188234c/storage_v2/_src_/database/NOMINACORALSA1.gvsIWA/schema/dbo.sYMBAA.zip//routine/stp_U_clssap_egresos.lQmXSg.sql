-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_egresos](  @oldcodigo_tipo char (2) ,
  @oldcodigo_deduccion char (3) ,
  @codigo_tipo char (2) ,
  @codigo_deduccion char (3) ,
  @cuenta_sap nchar (15)  )
As 
UPDATE [dbo].[sap_egresos] Set 
    codigo_tipo = @codigo_tipo,
    codigo_deduccion = @codigo_deduccion,
    cuenta_sap = @cuenta_sap 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_deduccion =  @oldcodigo_deduccion )
go

