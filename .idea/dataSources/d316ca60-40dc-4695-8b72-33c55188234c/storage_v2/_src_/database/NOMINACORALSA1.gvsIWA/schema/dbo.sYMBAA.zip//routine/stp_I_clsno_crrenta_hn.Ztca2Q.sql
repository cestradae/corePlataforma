
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_crrenta_hn(@AUTO_EditStamp varchar(30) OUT,
  @codigo_impuesto char (3) ,
  @ano smallint ,
  @mes smallint ,
  @no_cuotas smallint ,
  @fecha_generacion datetime ,
  @usuario_generacion int ,
  @estado char (1) ,
  @fecha_cierre datetime ,
  @usuario_cierre int  )
As 
	INSERT INTO [dbo].[no_reporte_renta_hn]
(  codigo_impuesto ,
  ano ,
  mes ,
  no_cuotas ,
  fecha_generacion ,
  usuario_generacion ,
  estado ,
  fecha_cierre ,
  usuario_cierre  )
VALUES (  @codigo_impuesto ,
  @ano ,
  @mes ,
  @no_cuotas ,
  @fecha_generacion ,
  @usuario_generacion ,
  @estado ,
  @fecha_cierre ,
  @usuario_cierre  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_reporte_renta_hn]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
ano =  @ano AND 
mes =  @mes )
go

