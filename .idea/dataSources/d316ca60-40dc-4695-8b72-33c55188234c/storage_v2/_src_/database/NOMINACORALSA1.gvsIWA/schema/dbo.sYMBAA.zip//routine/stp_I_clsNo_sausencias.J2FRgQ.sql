-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_sausencias](  @AUTO_corr_solicitud smallint OUT,
@AUTO_EditStamp varchar(30) OUT,
  @codigo_empleado char (10) ,
  @codigo_tipo char (2) ,
  @fecha_solicitud datetime ,
  @dias_solicitar decimal (8,2) ,
  @descuenta_sabados char (1) ,
  @fecha_inicio datetime ,
  @tipo_solicitud char (1) ,
  @motivo char (1) ,
  @observaciones varchar (100) ,
  @dia_descontado char (1) ,
  @estado_solicitud char (10)  )
As 

declare @corr_solicitud int

select @corr_solicitud = max(corr_solicitud) + 1
from no_solicitud_ausencias
where codigo_empleado = @codigo_empleado

if @corr_solicitud is null select @corr_solicitud = 1

	INSERT INTO [dbo].[no_solicitud_ausencias]
(  codigo_empleado ,
   corr_solicitud ,
  fecha_solicitud ,
  codigo_tipo ,
  dias_solicitar ,
  descuenta_sabados ,
  fecha_inicio ,
  tipo_solicitud ,
  observaciones ,
  dia_descontado ,
  estado_solicitud,
  motivo )
VALUES (  @Codigo_empleado ,
  @corr_solicitud ,
  @Fecha_solicitud ,
  @codigo_tipo ,
  @Dias_solicitar ,
  @Descuenta_sabados ,
  @fecha_inicio ,
  @Tipo_solicitud ,
  @Observaciones ,
  @Dia_descontado ,
  'O',
  @motivo )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_Corr_solicitud = corr_solicitud, @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_solicitud_ausencias]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
corr_solicitud =  @Corr_solicitud )
go

