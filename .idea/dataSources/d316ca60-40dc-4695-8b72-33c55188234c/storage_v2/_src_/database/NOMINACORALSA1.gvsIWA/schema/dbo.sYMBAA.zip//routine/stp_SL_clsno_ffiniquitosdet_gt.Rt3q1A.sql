
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_ffiniquitosdet_gt
  As SELECT a.codigo_formato,a.correlativo,a.nombre_procedimiento,a.tipo_resultado,a.prefijo,a.no_meses,a.codigo_valor,a.condensa FROM [dbo].[no_formatos_finiquitos_det] a
go

