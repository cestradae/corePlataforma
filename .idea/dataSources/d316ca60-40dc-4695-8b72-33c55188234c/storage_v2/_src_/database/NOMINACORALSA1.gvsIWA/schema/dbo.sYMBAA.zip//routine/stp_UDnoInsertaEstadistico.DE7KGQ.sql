CREATE procedure [dbo].[stp_UDnoInsertaEstadistico] 
   @fecha_inicial datetime,
   @fecha_final datetime
as
declare @codigo_tipo char(2)
declare @grupo_id char(5)
declare @periodo_id char(10)
declare @unidad varchar(10)
declare @no_calculo int
declare @no_reporte int
declare @codigo_departamento smallint
declare @codigo_centro varchar(20)
declare @codigo_empleado char(10)
declare @codigo_valor char(11)
declare @codigo_dato char(10)
declare @valor1 decimal(18,4)
declare @valor2 decimal(18,4)
declare @valor3 decimal(18,4)
declare @valor4 decimal(18,4)
declare @valor5 decimal(18,4)
declare @fecha_reporte datetime

select @fecha_final = @fecha_final + ' 23:59:59'

declare cur_inserta_variables cursor for
   select codigo_tipo,
          periodo_id,
          grupo_id,
          no_reporte,
          no_calculo,
          codigo_departamento,
          codigo_centro,
          codigo_empleado,
          codigo_valor,
          valor1,
          valor2,
          valor3,
          valor4,
          valor5,
          fecha_reporte
   from no_reporte_valores_ingreso
   where fecha_reporte between @fecha_inicial and @fecha_final
     and tipo_valor = 1

open cur_inserta_variables 
fetch cur_inserta_variables into @codigo_tipo, @periodo_id, @grupo_id, @no_reporte, @no_calculo,
                                 @codigo_departamento, @codigo_centro, @codigo_empleado, @codigo_valor,
                                 @valor1, @valor2, @valor3, @valor4, @valor5, @fecha_reporte
while @@fetch_status = 0
Begin

  if @valor1  <> 0
  Begin
      select @codigo_dato = codigo_dato,
              @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 1 

      insert into no_reporte_valores_estadistico (
             codigo_tipo,
             periodo_id,
             grupo_id, 
             no_reporte,
             no_calculo,
             codigo_empleado,
             codigo_departamento,
             codigo_centro,
             codigo_valor,
             codigo_dato,
             unidad,
             valor,
             fecha_reporte )
       values ( @codigo_tipo,
                     @periodo_id,
                     @grupo_id,
                     @no_reporte,
                     @no_calculo,
                     @codigo_empleado,
                     @codigo_departamento,
                     @codigo_centro,
                     @codigo_valor,
                     @codigo_dato,
                     @unidad,
                     @valor1,
                     @fecha_reporte )

         if @@error <> 0
         Begin
               Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
               Rollback work
               Return
         End
   End


  if @valor2  <> 0
  Begin
      select @codigo_dato = codigo_dato,
              @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 2 

      insert into no_reporte_valores_estadistico (
             codigo_tipo,
             periodo_id,
             grupo_id, 
             no_reporte,
             no_calculo,
             codigo_empleado,
             codigo_departamento,
             codigo_centro,
             codigo_valor,
             codigo_dato,
             unidad,
             valor,
             fecha_reporte )
       values ( @codigo_tipo,
                     @periodo_id,
                     @grupo_id,
                     @no_reporte,
                     @no_calculo,
                     @codigo_empleado,
                     @codigo_departamento,
                     @codigo_centro,
                     @codigo_valor,
                     @codigo_dato,
                     @unidad,
                     @valor2,
                     @fecha_Reporte )

         if @@error <> 0
         Begin
               Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
               Rollback work
               Return
         End
   End

  if @valor3  <> 0
  Begin
      select @codigo_dato = codigo_dato,
              @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 3 

      insert into no_reporte_valores_estadistico (
             codigo_tipo,
             periodo_id,
             grupo_id, 
             no_reporte,
             no_calculo,
             codigo_empleado,
             codigo_departamento,
             codigo_centro,
             codigo_valor,
             codigo_dato,
             unidad,
             valor,
             fecha_reporte )
       values ( @codigo_tipo,
                     @periodo_id,
                     @grupo_id,
                     @no_reporte,
                     @no_calculo,
                     @codigo_empleado,
                     @codigo_departamento,
                     @codigo_centro,
                     @codigo_valor,
                     @codigo_dato,
                     @unidad,
                     @valor3,
                     @fecha_reporte )

         if @@error <> 0
         Begin
               Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
               Rollback work
               Return
         End
   End
   
  if @valor4  <> 0
  Begin
      select @codigo_dato = codigo_dato,
              @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 4

      insert into no_reporte_valores_estadistico (
             codigo_tipo,
             periodo_id,
             grupo_id, 
             no_reporte,
             no_calculo,
             codigo_empleado,
             codigo_departamento,
             codigo_centro,
             codigo_valor,
             codigo_dato,
             unidad,
             valor,
             fecha_reporte )
       values ( @codigo_tipo,
                     @periodo_id,
                     @grupo_id,
                     @no_reporte,
                     @no_calculo,
                     @codigo_empleado,
                     @codigo_departamento,
                     @codigo_centro,
                     @codigo_valor,
                     @codigo_dato,
                     @unidad,
                     @valor4,
                     @fecha_reporte )

         if @@error <> 0
         Begin
               Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
               Rollback work
               Return
         End
   End


  if @valor5  <> 0
  Begin
      select @codigo_dato = codigo_dato,
              @unidad = unidad 
      from no_nomina_valores_det
      where codigo_tipo = @codigo_tipo
         and codigo_valor = @codigo_valor
         and orden = 5 

      insert into no_reporte_valores_estadistico (
             codigo_tipo,
             periodo_id,
             grupo_id, 
             no_reporte,
             no_calculo,
             codigo_empleado,
             codigo_departamento,
             codigo_centro,
             codigo_valor,
             codigo_dato,
             unidad,
             valor,
             fecha_reporte )
       values ( @codigo_tipo,
                     @periodo_id,
                     @grupo_id,
                     @no_reporte,
                     @no_calculo,
                     @codigo_empleado,
                     @codigo_departamento,
                     @codigo_centro,
                     @codigo_valor,
                     @codigo_dato,
                     @unidad,
                     @valor5,
                     @fecha_reporte )

         if @@error <> 0
         Begin
               Raiserror ('No se puede insertar estadisticos - trinsno_reporte_valores_iongreso ', 16,1,5000)
               Rollback work
               Return
         End
   End


   fetch cur_inserta_variables into @codigo_tipo, @periodo_id, @grupo_id, @no_reporte, @no_calculo,
                                    @codigo_departamento, @codigo_centro, @codigo_empleado, @codigo_valor,
                                    @valor1, @valor2, @valor3, @valor4, @valor5, @fecha_reporte

End
close cur_inserta_variables
deallocate cur_inserta_variables
go

