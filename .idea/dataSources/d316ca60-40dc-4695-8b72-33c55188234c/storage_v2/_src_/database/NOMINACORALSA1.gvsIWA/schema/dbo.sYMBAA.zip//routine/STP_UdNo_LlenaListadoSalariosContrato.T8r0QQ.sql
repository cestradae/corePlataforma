CREATE PROCEDURE [dbo].[STP_UdNo_LlenaListadoSalariosContrato]
		@codigo_empleado char(10)

 AS
---------------------------------------------------------------------------------------------------
-- Creado Por: Mario Juarros
-- Fecha: 30/10/20008
-- Observaciones: Procedimiento que llena datos de salarios en
--		  documento excel para generar el contrato de trabajo.
---------------------------------------------------------------------------------------------------

select a.codigo_ingreso, a.descripcion, ISNULL(d.simbolo,'')+CONVERT(VARCHAR,isnull(b.monto,0),110)  as monto
from no_catalogo_ingresos a
left join no_empleado_ingresos b
on a.codigo_ingreso = b.codigo_ingreso
and b.codigo_empleado =@codigo_empleado
left JOIN dbo.no_nomina_ingresos c
ON a.codigo_ingreso=c.codigo_ingreso
AND b.codigo_tipo=c.codigo_tipo
left JOIN dbo.gn_monedas d
 ON c.codigo_moneda=d.codigo_moneda
go

