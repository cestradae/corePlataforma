create procedure [dbo].[stp_sapins_bancos]
  @BankCode  nvarchar(30),
  @BankName  nchar(32),
  @CountryCode nchar(3),
  @dfltacct nvarchar(50)
 as

INSERT INTO sap_tr_bancos
           (BankCode,
            BankName,
            CountryCode,
            dfltacct)
     VALUES
           (@BankCode,
            @BankName, 
            @CountryCode,
            @dfltacct)
Return
go

