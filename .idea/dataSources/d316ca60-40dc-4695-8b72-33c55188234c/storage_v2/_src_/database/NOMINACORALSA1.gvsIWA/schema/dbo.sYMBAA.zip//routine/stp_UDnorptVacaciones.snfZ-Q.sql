CREATE procedure [dbo].[stp_UDnorptVacaciones] (
   @tipo_inicial char(2),
   @tipo_final char(2),
   @empleado_inicial char(10),
   @empleado_final char(10),
   @depto_inicial smallint,
   @depto_final smallint,
   @solo_pendientes char(1)
)

As

set nocount on
if @tipo_final = '' select @tipo_final = max(codigo_tipo) from no_tipos_nomina
if @empleado_final = '' select @empleado_final = max(codigo_empleado) from no_empleados
if @depto_inicial = 0 select @depto_inicial = min(codigo_departamento) from gn_departamentos
if @depto_final = 0 select @depto_final = max(codigo_departamento) from gn_departamentos

Create table #Vacaciones (
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS ,
   nombre_usual varchar(100) COLLATE Modern_Spanish_CI_AS,
   codigo_puesto smallint,
   codigo_departamento smallint,
   fecha_inicio_rel_lab datetime,
   fecha_ult_goce_vac datetime,
   fecha_ult_vacacion datetime ,
   codigo_tipo char(2) COLLATE Modern_Spanish_CI_AS)

insert into #Vacaciones
select a.codigo_empleado, nombre_usual, codigo_puesto, codigo_departamento,
       fecha_inicio_rel_lab, fecha_ult_goce_vac, fecha_ult_vacacion,
       b.codigo_tipo
from no_empleados a, no_nomina_empleado b
where a.codigo_empleado = b.codigo_empleado
and  b.codigo_tipo between @tipo_inicial and @tipo_final 
and  a.codigo_departamento between @depto_inicial and @depto_final
--and a.estado_empleado in ('A', 'S')
AND a.codigo_empleado between @empleado_inicial and @empleado_final
 

if @solo_pendientes = '1'

select a.codigo_tipo + '-'+ e.descripcion tipo,
       a.codigo_empleado, 
       a.nombre_usual, 
       convert(char(5),a.codigo_puesto)+'-'+ c.nombre_puesto  Puesto, 
       convert(char(5),a.codigo_departamento)+'-'+ d.descripcion Departamento,
       b.fecha_iniciaL FECHAINICIAL, 
       b.fecha_final FECHAFINAL, 
       b.dias_derecho, 
       b.dias_gozados, 
       b.dias_pagados, 
       isnull(b.saldo_dias,0) saldo,
       a.fecha_inicio_rel_lab, 
       a.fecha_ult_goce_vac, 
       a.fecha_ult_vacacion,
       b.periodo

from #Vacaciones a, no_empleado_vacaciones b,
     no_puestos c, gn_departamentos d, no_tipos_nomina e
where a.codigo_empleado = b.codigo_empleado
   and a.codigo_puesto *= c.codigo_puesto
   and a.codigo_departamento *= d.codigo_departamento
   and isnull(b.saldo_dias,0) > 0
   and a.codigo_tipo = e.codigo_tipo
else

select a.codigo_tipo + '-'+ e.descripcion tipo,
       a.codigo_empleado, 
       a.nombre_usual, 
       convert(char(5),a.codigo_puesto)+'-'+ c.nombre_puesto  Puesto, 
       convert(char(5),a.codigo_departamento)+'-'+ d.descripcion Departamento,
       b.fecha_iniciaL FECHAINICIAL, 
       b.fecha_final FECHAFINAL, 
       b.dias_derecho, 
       b.dias_gozados, 
       b.dias_pagados, 
       isnull(b.saldo_dias,0) saldo,
       a.fecha_inicio_rel_lab, 
       a.fecha_ult_goce_vac, 
       a.fecha_ult_vacacion,
       b.periodo

from #Vacaciones a, no_empleado_vacaciones b, no_tipos_nomina e,
     no_puestos c, gn_departamentos d
where a.codigo_empleado *= b.codigo_empleado
   and a.codigo_puesto *= c.codigo_puesto
   and a.codigo_departamento *= d.codigo_departamento
   and a.codigo_tipo = e.codigo_tipo
go

