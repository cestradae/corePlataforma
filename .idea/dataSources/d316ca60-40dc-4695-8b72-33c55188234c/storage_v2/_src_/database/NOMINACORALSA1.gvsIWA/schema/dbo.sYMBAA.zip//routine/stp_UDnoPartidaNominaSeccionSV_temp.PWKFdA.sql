CREATE procedure [dbo].[stp_UDnoPartidaNominaSeccionSV_temp]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo int
as
--------------------------
-- Hecho por lsao
-- Fecha 27/11/2008
-- Asunto : Creacion de partidas de Nomina, Esta partida no usa proyectos
---------------------------

set nocount on

Create table #Partida (
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,
     cargo money,
     abono money,
     asociado varchar(20) COLLATE Modern_Spanish_CI_AS
)

--- Primero los ingresos 
insert into #Partida
select b.cuenta_sap,
       sum(monto_ingreso),
       0,
       ''
from no_nomina_det a, sap_ingresos_secciones b, no_empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_ingreso = a.codigo_ingreso 
and a.codigo_empleado = c.codigo_empleado
and b.codigo_seccion = c.codigo_seccion
group by b.cuenta_sap

--- Sueldos por Liquidar
insert into #Partida
select b.cuenta_salios_sap,
       0,
       sum(liquido),
       ''
from no_nomina_emplcalc a, sap_parametros b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
group by b.cuenta_salios_sap


--- Cuenta de descuentos que no sean prestamos

insert into #Partida
select cuenta_sap,
       0,
       sum(monto_deduccion),
       ''
from no_nomina_det a, sap_egresos b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_deduccion <> '03'
group by cuenta_sap

insert into #Partida
select cuenta_sap,
       0,
       sum(monto_deduccion),
       c.nombre_corto
from no_nomina_det a, sap_egresos b, no_empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_deduccion = '03'
and a.codigo_empleado = c.codigo_empleado
group by cuenta_sap, c.nombre_corto


select a.cuenta_contable,d.AcctName, a.cargo,  a.abono,
     'asociado' = CASE 
					 WHEN rtrim(ltrim(a.asociado)) <>  '' THEN a.asociado
					 ELSE a.cuenta_contable
				  END
	 , GETDATE() AS fecha_final, 'Reg Nomina No.'+b.no_nomina+ ' '+ c.descripcion + ' de '+ DATENAME(month,b.fecha_final) + ' '+ CONVERT(varchar(4),DATEPART(year,b.fecha_final)) as concepto
from #Partida a, no_periodos_pago b, no_grupos_valores c, sap_tr_cuentas d
where b.periodo_id = @periodo_id
and c.grupo_id = @grupo_id
and a.cuenta_contable = d.AcctCode

--select * from no_grupos_valores
go

