-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_gtrabajo](@AUTO_EditStamp varchar(30) OUT,
  @grupo_trabajo smallint ,
  @nombre_grupo varchar (50)  )
As 
	INSERT INTO [dbo].[no_grupos_trabajo]
(  grupo_trabajo ,
  nombre_grupo  )
VALUES (  @grupo_trabajo ,
  @nombre_grupo  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_grupos_trabajo]
  WHERE ( grupo_trabajo =  @grupo_trabajo )
go

