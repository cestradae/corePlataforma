--stp_udnoEgresosLiquidacion '01','0016','0120070302','017'
CREATE proc [dbo].[stp_udnoEgresosLiquidacion]
		@codigo_tipo	varchar(10),
		@codigo_empleado	varchar(10),
		@periodo_id	varchar(10),
		@grupo_id	varchar(10)
as
-------------------------------------------------
--Hecho por: Mario Juarros
--Fecha:27/02/2009
--Ultimos ingresos de empleado
-------------------------------------------------

select codigo_deduccion, monto_deduccion
from no_nomina_det 
where codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and monto_deduccion>0
go

