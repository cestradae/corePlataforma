-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_cdeducciones_depto]
  (  @oldcodigo_deduccion char (3) ,
  @oldcodigo_departamento smallint  )
As DELETE [dbo].[no_catalogo_deducciones_depto] 
WHERE (codigo_deduccion =  @oldcodigo_deduccion AND 
codigo_departamento =  @oldcodigo_departamento)
go

