-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNo_nempleado_No_empleadosRelated]
(  @oldCodigo_empleado char (10)  )
  As 
SELECT a.codigo_empleado,a.codigo_tipo,a.fecha_asignacion,a.usuario_asignacion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_nomina_empleado] a
WHERE 
a.codigo_empleado =  @oldCodigo_empleado
go

