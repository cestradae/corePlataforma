CREATE procedure [dbo].[stp_UDNoGenera_Provisiones] 
    @codigo_tipo char(2),
    @periodo_id char(10),
    @grupo_id char(5),
    @no_calculo smallint ,
    @error char(1) out
as

SET NOCOUNT ON
---------------------------------------------------------------------------------
-- Asunto Se agregaron provisiones por empleado
-- Creado por LSAO
-- Fecha 27/11/2008
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------
-- Asunto Se agregaron las provisiones por empleado
-- Creado por LSAO
-- Fecha 04/08/2008
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
-- Asunto Generamos Las provisiones para todos los empleados
-- Creado por LSAO
-- Fecha 22/08/2003
---------------------------------------------------------------------------------
select @error = ''


declare @codigo_provision char(3),
        @codigo_ingreso char(3),
        @codigo_deduccion char(3),
        @lleva_saldo char(1),
        @tipo_provision char(1),
        @procedimiento varchar(50),
        @codigo_formula char(5),
        @porcentaje decimal(8,4)

Begin Tran

if exists ( select 1 from no_provisiones_enc where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id ) 
begin
   delete from no_provisiones_empleados
       where codigo_tipo = @codigo_tipo 
         and periodo_id = @periodo_id
         and grupo_id = @grupo_id
         and no_calculo = @no_calculo
   
   if @@error <> 0
   begin
      raiserror ('No se pudo borrar detalle de empleados - stp_UDNoGeneraProvisiones ' , 16,1,5000 )
      rollback tran
      return 
   end

   delete from no_provisiones_det 
   where codigo_tipo = @codigo_tipo 
     and periodo_id = @periodo_id
     and grupo_id = @grupo_id
     and no_calculo = @no_calculo

   if @@error <> 0
   begin
      raiserror ('No se pudo borrar detalle de provisiones - stp_UDNoGeneraProvisiones ' , 16,1,5000 )
      rollback tran
      return 
   end

   delete from no_provisiones_enc 
   where codigo_tipo = @codigo_tipo 
     and periodo_id = @periodo_id
     and grupo_id = @grupo_id
     and no_calculo = @no_calculo

   if @@error <> 0
   begin
      raiserror ('No se pudo borrar calculo de provisiones - stp_UDNoGeneraProvisiones ' , 16,1,5000 )
      rollback tran
      return 
   end


end

-- Creamos el registro de calculo

insert into no_provisiones_enc (
  codigo_tipo,
  periodo_id,
  grupo_id,
  no_calculo,
  fecha_ingreso,
  usuario_ingreso
)
values ( @codigo_tipo, 
         @periodo_id,
         @grupo_id,
         @no_calculo,
         getdate(),
         system_user )

if @@error <> 0
begin
   raiserror ('No se pudo generar calculo de provisiones - stp_UDNoGeneraProvisiones ' , 16,1,5000 )
   rollback tran
   return 
end


 
declare cur_mov cursor for
   select codigo_provision
   from no_nomina_provisiones
   where codigo_tipo = @codigo_tipo

open cur_mov 
fetch cur_mov into @codigo_provision

while @@fetch_status = 0
begin

   -- Creamos el registro de provisiones
   insert into no_provisiones_det ( codigo_tipo, periodo_id, codigo_provision, monto_base , monto_provision , grupo_id, no_calculo)
   values ( @codigo_tipo, @periodo_id, @codigo_provision, 0.00, 0.00, @grupo_id, @no_calculo )
 
   -- Buscamos los datos referentes a la provision 

   select @lleva_saldo = lleva_saldo,
          @codigo_deduccion = codigo_deduccion,
          @codigo_ingreso = codigo_ingreso,
          @codigo_formula = codigo_formula,
          @procedimiento = procedimiento,
          @porcentaje = porcentaje ,
          @tipo_provision = tipo_provision 
   from no_nomina_provisiones
   where codigo_tipo = @codigo_tipo
     and codigo_provision = @codigo_provision
   
   -- Si tipo de provision = C - Calculado utilizamos el procedimiento almacenado F utilizamos Formula
   if @tipo_provision = 'C' -- Procedimiento alamacenado  
   begin
     
      if @codigo_ingreso is not null 
      begin
         exec @procedimiento @codigo_tipo, @periodo_id, @codigo_provision, @codigo_ingreso, @porcentaje, @lleva_saldo , @grupo_id, @no_calculo
         if @@error <> 0 
         begin
            raiserror ('No se pudo ejecutar procedimiento %s para provision %s ' ,16,1, @procedimiento, @codigo_provision )
            rollback tran
            deallocate cur_mov
            return
         end
      end
      else
      Begin
         if @codigo_deduccion is not null
         begin
             exec @procedimiento @codigo_tipo, @periodo_id, @codigo_provision, @codigo_deduccion, @porcentaje, @lleva_saldo , @grupo_id, @no_calculo
             if @@error <> 0 
             begin
                raiserror ('No se pudo ejecutar procedimiento %s para provision %s ' ,16,1, @procedimiento, @codigo_provision )
                rollback tran
                deallocate cur_mov
                return
             end    
         end
         else
         Begin
             exec @procedimiento @codigo_tipo, @periodo_id, @codigo_provision, @codigo_ingreso, @porcentaje, @lleva_saldo , @grupo_id, @no_calculo
             if @@error <> 0 
             begin
                raiserror ('No se pudo ejecutar procedimiento %s para provision %s ' ,16,1, @procedimiento, @codigo_provision )
                rollback tran
                deallocate cur_mov
                return
             end
         End 
       End 
     
   end 
   if @tipo_provision = 'F'
   Begin
      exec stp_UDNoCalculoProvFormula  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_provision
      if @@error <> 0
      Begin
         Raiserror ('No se pudo actualizar el calculo de de la formula para el ingreso %s - stp_UDnoGenera_Provisiones ',16,1,@codigo_provision )
         Rollback work
         Close cur_mov
         Deallocate cur_mov
         return 9
      End


   End 
   fetch cur_mov into @codigo_provision   
end
close cur_mov
deallocate cur_mov

select 1
	
commit tran
go

