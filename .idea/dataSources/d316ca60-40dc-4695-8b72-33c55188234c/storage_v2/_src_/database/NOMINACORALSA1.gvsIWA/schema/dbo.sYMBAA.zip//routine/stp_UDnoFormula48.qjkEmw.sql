create procedure [dbo].[stp_UDnoFormula48]   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(18,4) out ) AS

  declare @DTRAPLA decimal(18,4) 
declare @SEPTPLA decimal(18,4) 
declare @Ordinario decimal(18,4) 
declare @S_Extra_Simple decimal(18,4) 
declare @tmp1 decimal(18,4) 

begin
  if 2 <> ( select top 1 tipo_variable from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = 'DTRAPLA   ' ) begin Select @DTRAPLA= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'DTRAPLA   ' end else begin Select @DTRAPLA= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'DTRAPLA   ' end 
if 2 <> ( select top 1 tipo_variable from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = 'SEPTPLA   ' ) begin Select @SEPTPLA= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'SEPTPLA   ' end else begin Select @SEPTPLA= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'SEPTPLA   ' end 
Select @Ordinario= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ordinario'
Select @S_Extra_Simple= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'S_Extra_Simple'
if ((@DTRAPLA>0)) select @tmp1=@SEPTPLA*(@Ordinario+@S_Extra_Simple)/@DTRAPLA else select @tmp1=0

  set @result=@tmp1
end
go

