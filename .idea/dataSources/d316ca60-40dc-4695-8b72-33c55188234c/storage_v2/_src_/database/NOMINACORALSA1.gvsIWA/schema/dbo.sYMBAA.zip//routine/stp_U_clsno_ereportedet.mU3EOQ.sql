-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_ereportedet](  @oldcodigo_repnomina smallint ,
  @oldnumero_columna smallint ,
  @oldcodigo_elemento varchar (11) ,
  @codigo_repnomina smallint ,
  @codigo_elemento varchar (11) ,
  @monto_base char (1) ,
  @numero_columna smallint ,
  @EditStamp varchar(30) OUT ,
  @factor decimal (8,4) ,
  @valor decimal (18,4)  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_nomina_reportedet] 
WHERE codigo_repnomina =  @oldcodigo_repnomina AND 
numero_columna =  @oldnumero_columna AND 
codigo_elemento =  @oldcodigo_elemento 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_nomina_reportedet] Set 
    codigo_repnomina = @codigo_repnomina,
    codigo_elemento = @codigo_elemento,
    monto_base = @monto_base,
    numero_columna = @numero_columna,
    factor = @factor,
    valor = @valor 
WHERE 	( codigo_repnomina =  @oldcodigo_repnomina AND 
numero_columna =  @oldnumero_columna AND 
codigo_elemento =  @oldcodigo_elemento )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_nomina_reportedet]
  WHERE ( codigo_repnomina =  @codigo_repnomina AND 
numero_columna =  @numero_columna AND 
codigo_elemento =  @codigo_elemento )
go

