-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_ffiniquitos_det]
  (  @oldcodigo_formato smallint ,
  @oldcorrelativo smallint  )
As DELETE [dbo].[no_formatos_finiquitos_det] 
WHERE (codigo_formato =  @oldcodigo_formato AND 
correlativo =  @oldcorrelativo)
go

