CREATE procedure [dbo].[stp_UDnoObtieneIngresos]
as
-----------------------
-- Usuario lsao
-- fecha 03-01-2007
-- Asunto Obtiene variables reportadas
----------------------
select nombre_corto, descripcion, 'declare @' + nombre_corto +  ' decimal(18,4) ' variable,
 'Select @'+nombre_corto+'= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b '+
  'where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id ' +
  'and grupo_id = @grupo_id and no_calculo = @no_calculo ' +
  'and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso ' +
  'and b.nombre_corto = ' + char(39)+nombre_corto+char(39) query, 
 'isnull(@' + nombre_corto+',0)' variableA
from no_catalogo_ingresos
go

