
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_pisr_dedgt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_Deduccion char (3)  )
As DELETE [dbo].[no_parametros_isr_dedgt] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_Deduccion =  @oldcodigo_Deduccion)
go

