-------------------------------------------------------------------------------
CREATE Procedure [dbo].[stp_udnotr_bitacora_traslado]	
	@valores_rep	decimal(18,4),
	@empleados		decimal(18,4),
	@liquidaciones	decimal(18,4),
	@horas	decimal(18,4),
	@error	char(1) OUT,
	@usuario	INT
as
set nocount on

DELETE FROM no_datos_transferidos_tr
Begin tran
insert into no_datos_transferidos
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	1,
	getdate(),
	@valores_rep,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar valores reportados - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	2,
	getdate(),
	@empleados,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar empleados - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	3,
	getdate(),
	@liquidaciones,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar liquidaciones - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	4,
	getdate(),
	@horas,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar horas - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		END
-----

insert into no_datos_transferidos_tr
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	1,
	getdate(),
	@valores_rep,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar valores reportados - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos_tr
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	2,
	getdate(),
	@empleados,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar empleados - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos_tr
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	3,
	getdate(),
	@liquidaciones,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar liquidaciones - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end

insert into no_datos_transferidos_tr
(
	tipo_dato,
	fecha_envio,
	valor_cuadre,
	usuario_traslado
)
values
(
	4,
	getdate(),
	@horas,
	@usuario
)
	if @@error <> 0
		Begin
			raiserror('Error al insertar horas - stp_udnotr_bitacora_traslado',16,1)
			rollback work
			select @error = 'S'
			return
		end		
commit tran
if @error is null select @error = 'N'
go

