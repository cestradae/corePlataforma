-- =============================================
-- Author:		Daniel Ortiz
-- Create date: 10/08/2011
-- Description:	Agregado de campos nuevos
-- =============================================
-- =============================================
-- Author:		Estuardo Arévalo
-- Create date: 09/07/2009
-- Description:	Copia Empleados
-- =============================================
CREATE PROCEDURE [dbo].[stp_udnoCopiaEmpleado]
											@oldcodigo_empleado char(10),
											@oldcodigo_tipo char(2),
											@codigo_empleado char(10),
											@codigo_tipo char(2),
											@fecha_inicio_rel_lab datetime,
											@usuario_asignacion varchar(30),
											@xerror char(1) out
AS
BEGIN
	SET NOCOUNT ON;

	set @xerror = ''
	
	BEGIN TRAN
	
	-- verificamos que el codigo_empleado nuevo no exista
	if exists ( select top 1 1 from no_empleados where codigo_empleado = @codigo_empleado )
	begin
		raiserror ( ' El nuevo código de empleado ya existe, ingrese un código diferente. - stp_udnoCopiaEmpleado' , 16,1,5000)
		rollback work
		return
	end
	
	declare @oldfecha_inicio_rel_lab datetime
	
	-- obtenemos la fecha_inicio_rel_lab anterior para insertarla en fecha_original del nuevo codigo
	SELECT @oldfecha_inicio_rel_lab = fecha_inicio_rel_lab
	FROM [dbo].[no_empleados]
	WHERE codigo_empleado = @oldcodigo_empleado
	
	-- copiamos la ficha del empleado
	
	INSERT INTO [dbo].[no_empleados]
           ([codigo_empleado], [nombres], [apellidos]
			,[apellido_casada], [estado_civil], [sexo] 
			,[nombre_usual], [codigo_puesto]
			, [no_orden_cedula], [numero_cedula]
			,[extendida_en], [codigo_departamento] 
			,[codigo_centro], [fecha_inicio_rel_lab]
			, [fecha_contrato], [numero_seguro_social] 
			,[numero_irtra], [tipo_pago]
			,[cuenta_bancaria], [buzon_mensajes], [fecha_ult_vacacion]
			, [fecha_baja], [estado_empleado], [codigo_profesion], [codigo_pais], [foto]
			,[login_entrada], [nivel_seguridad], [nivel_autorizacion]
			, [grupo_trabajo], [nombre_corto], [codigo_seccion], [telefono], [movil], [pasaporte]
			,[fecha_nacimiento], [lugar_nacimiento], [observaciones]
			, [numero_tributario], [direccion], [contrato_emitido], [fecha_ult_goce_vac], [codigo_motivo]
			,[nacionalidad], [vecino_de_municipio]
			, [vecino_de_depto], [tipo_cuenta], [snumero_permiso], [slabora_region], [slabora_depto]
			, [slabora_municipio], [socupacion], [soriginario_region]
			, [soriginario_depto], [soriginario_municipio], [sextendida_region], [sextendida_depto] 
			,[sextendida_municipio], [stipo_contrato], [snivel_academico]
			, [setnia], [codigo_jornada], [fecha_original], [fecha_venc_irtra], [codigo_banco]
			,[observaciones_cheque], [codigo_anterior] 
			,[calle_avenida],[numero_casa],[apartamento],[zona],[colonia_barrio],[fax],[apartado_postal]
			,[correo_e],[codigo_postal],[referencia],[identificacion],[nombres2],[apellidos2]
			,[codigo_depto],[codigo_municipio])
     SELECT @codigo_empleado, [nombres], [apellidos], [apellido_casada], [estado_civil], [sexo], [nombre_usual], [codigo_puesto]
			, [no_orden_cedula], [numero_cedula], [extendida_en], [codigo_departamento], [codigo_centro], @fecha_inicio_rel_lab
			, [fecha_contrato], [numero_seguro_social], [numero_irtra], [tipo_pago], [cuenta_bancaria], [buzon_mensajes], [fecha_ult_vacacion]
			, [fecha_baja], [estado_empleado], [codigo_profesion], [codigo_pais], [foto], [login_entrada], [nivel_seguridad], [nivel_autorizacion]
			, [grupo_trabajo], [nombre_corto], [codigo_seccion], [telefono], [movil], [pasaporte], [fecha_nacimiento], [lugar_nacimiento], [observaciones]
			, [numero_tributario], [direccion], [contrato_emitido], [fecha_ult_goce_vac], [codigo_motivo], [nacionalidad], [vecino_de_municipio]
			, [vecino_de_depto], [tipo_cuenta], [snumero_permiso], [slabora_region], [slabora_depto], [slabora_municipio], [socupacion], [soriginario_region]
			, [soriginario_depto], [soriginario_municipio], [sextendida_region], [sextendida_depto], [sextendida_municipio], [stipo_contrato], [snivel_academico]
			, [setnia], [codigo_jornada], @oldfecha_inicio_rel_lab, [fecha_venc_irtra], [codigo_banco], [observaciones_cheque], @oldcodigo_empleado, [calle_avenida]
			,[numero_casa],[apartamento],[zona],[colonia_barrio],[fax],[apartado_postal]
			,[correo_e],[codigo_postal],[referencia],[identificacion],[nombres2],[apellidos2]
			,[codigo_depto],[codigo_municipio]			
	FROM [dbo].[no_empleados]
	WHERE codigo_empleado = @oldcodigo_empleado
	
	if @@ERROR <> 0
	begin
		raiserror ( ' Ocurrió un error al intentar copiar la ficha del empleado - stp_udnoCopiaEmpleado' , 16,1,5000)
		rollback work
		return
	end
	
	INSERT INTO no_nomina_empleado (codigo_empleado,codigo_tipo)
	SELECT @codigo_empleado, @codigo_tipo
	
	if @@ERROR <> 0
	begin
		raiserror ( ' Ocurrió un error al intentar Asignar el nuevo Código a la Nómina de Destino - stp_udnoCopiaEmpleado' , 16,1,5000)
		rollback work
		return
	end
          
	COMMIT TRAN          

END
go

