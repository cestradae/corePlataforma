-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_ded_det]
  (  @oldCodigo_empleado char (10) ,
  @oldCodigo_tipo char (2) ,
  @oldCodigo_deduccion char (3) ,
  @oldCorrelativo smallint ,
  @oldPeriodo_id char (10)  )
As DELETE [dbo].[no_deducciones_det] 
WHERE (codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo AND 
codigo_deduccion =  @oldCodigo_deduccion AND 
correlativo =  @oldCorrelativo AND 
periodo_id =  @oldPeriodo_id)
go

