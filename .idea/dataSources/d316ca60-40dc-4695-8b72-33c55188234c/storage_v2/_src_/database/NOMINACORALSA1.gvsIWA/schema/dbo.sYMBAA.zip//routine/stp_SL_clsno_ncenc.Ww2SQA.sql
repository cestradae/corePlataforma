-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_ncenc]
  As SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.tasa_cambio,a.estado,a.usuario_generacion,a.fecha_generacion,a.usuario_cierre,a.fecha_cierre,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_nomina_enc] a
go

