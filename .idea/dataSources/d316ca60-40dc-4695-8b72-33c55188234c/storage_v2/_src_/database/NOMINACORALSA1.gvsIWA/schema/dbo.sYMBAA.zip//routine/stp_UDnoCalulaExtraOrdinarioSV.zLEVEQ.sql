CREATE procedure [dbo].[stp_UDnoCalulaExtraOrdinarioSV]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_ingreso char(3)
AS
declare @fecha_inicial datetime
declare @fecha_final datetime

select @fecha_inicial = fecha_inicial,
       @fecha_final = fecha_final
from no_periodos_pago
where periodo_id = @periodo_id

Begin Tran

  insert into no_nomina_det (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        codigo_departamento,
        codigo_centro,
        codigo_ingreso,
        monto_ingreso,
        monto_ingreso_o,
        codigo_puesto,
        codigo_seccion )

select @codigo_tipo,
       @periodo_id,
       @grupo_id,
       @no_calculo,
       a.codigo_empleado, 
       a.codigo_departamento, 
       a.codigo_centro, 
       @codigo_ingreso,
        sum(total),
        sum(total),
       b.codigo_puesto,
       b.codigo_seccion
from no_reporte_valores_ingreso a, no_empleados b, no_nomina_valores c
where a.fecha_reporte between  @fecha_inicial and @fecha_final
  and a.codigo_tipo = @codigo_tipo
  and a.periodo_id = @periodo_id
  and a.grupo_id = @grupo_id
  and a.no_calculo = @no_calculo
  and a.tipo_valor = 1
  and a.codigo_empleado = b.codigo_empleado
  and a.codigo_valor = c.codigo_valor
  and a.codigo_tipo = c.codigo_tipo
  and isnull(c.extra,'') = 'S'
group by a.codigo_empleado, a.codigo_centro, a.codigo_departamento, b.codigo_puesto, b.codigo_seccion


if @@error <> 0
Begin
   Raiserror ('No se puede calcular el ingreso - stp_UDnoCalulaOrdinarioSV ', 16,1,5000)
   Rollback work
   Return 9
End

Commit Tran


/****** Object:  StoredProcedure [dbo].[stp_UDnoCalulaOrdinarioSV]    Script Date: 10/23/2008 14:06:33 ******/
SET ANSI_NULLS ON
go

