-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_provisiones]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_provision char (3)  )
As DELETE [dbo].[sap_provisiones] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
codigo_provision =  @oldcodigo_provision)
go

