-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_CatalogoIngresos]
As
  SELECT codigo_ingreso,codigo_ingreso+' - '+descripcion AS descripcion FROM NO_catalogo_ingresos
order by descripcion
go

