-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_prenta_hn]
  (  @oldcodigo_impuesto char (3)  )
As DELETE [dbo].[no_parametros_renta_hn] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto)
go

