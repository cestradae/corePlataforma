-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_rvalores](  @oldCodigo_tipo char (2) ,
  @oldPeriodo_id char (10) ,
  @oldNo_reporte smallint ,
  @Codigo_tipo char (2) ,
  @Periodo_id char (10) ,
  @No_reporte smallint ,
  @Grupo_id char (5) ,
  @no_calculo smallint OUT  ,
  @Fecha_reporte datetime ,
  @Genera_aut char (1) ,
  @Estado_reporte char (1) OUT  ,
  @Fecha_ingreso datetime OUT  ,
  @Usuario_ingreso varchar (35) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_reporte_valores] 
WHERE codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
no_reporte =  @oldNo_reporte 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_reporte_valores] Set 
    codigo_tipo = @Codigo_tipo,
    periodo_id = @Periodo_id,
    no_reporte = @No_reporte,
    grupo_id = @Grupo_id,
    fecha_reporte = @Fecha_reporte,
    genera_aut = @Genera_aut,
    usuario_ingreso = @Usuario_ingreso 
WHERE 	( codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
no_reporte =  @oldNo_reporte )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @no_calculo = no_calculo, @Estado_reporte = estado_reporte, @Fecha_ingreso = fecha_ingreso, @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_reporte_valores]
  WHERE ( codigo_tipo =  @Codigo_tipo AND 
periodo_id =  @Periodo_id AND 
no_reporte =  @No_reporte )
go

