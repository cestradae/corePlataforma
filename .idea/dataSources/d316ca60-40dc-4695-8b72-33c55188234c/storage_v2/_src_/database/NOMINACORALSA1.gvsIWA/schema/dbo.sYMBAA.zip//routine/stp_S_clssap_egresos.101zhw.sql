-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_egresos]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_deduccion char (3)  )
As SELECT a.codigo_tipo,a.codigo_deduccion,a.cuenta_sap FROM [dbo].[sap_egresos] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.codigo_deduccion =  @oldcodigo_deduccion)
go

