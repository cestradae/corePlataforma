-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_pseghn_deptos](  @oldcodigo_seguro smallint ,
  @oldcodigo_departamento char (2) ,
  @codigo_seguro smallint ,
  @codigo_departamento char (2) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_parametros_seghn_deptos] 
WHERE codigo_seguro =  @oldcodigo_seguro AND 
codigo_departamento =  @oldcodigo_departamento 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_parametros_seghn_deptos] Set 
    codigo_seguro = @codigo_seguro,
    codigo_departamento = @codigo_departamento 
WHERE 	( codigo_seguro =  @oldcodigo_seguro AND 
codigo_departamento =  @oldcodigo_departamento )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_parametros_seghn_deptos]
  WHERE ( codigo_seguro =  @codigo_seguro AND 
codigo_departamento =  @codigo_departamento )
go

