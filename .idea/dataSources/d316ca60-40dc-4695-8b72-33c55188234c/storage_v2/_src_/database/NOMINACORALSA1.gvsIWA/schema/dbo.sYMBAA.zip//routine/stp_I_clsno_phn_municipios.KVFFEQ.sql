
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_phn_municipios(@AUTO_EditStamp varchar(30) OUT,
  @codigo_patrono smallint ,
  @id_municipio smallint  )
As 
	INSERT INTO [dbo].[no_patronos_hn_municipios]
(  codigo_patrono ,
  id_municipio  )
VALUES (  @codigo_patrono ,
  @id_municipio  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_patronos_hn_municipios]
  WHERE ( codigo_patrono =  @codigo_patrono AND 
id_municipio =  @id_municipio )
go

