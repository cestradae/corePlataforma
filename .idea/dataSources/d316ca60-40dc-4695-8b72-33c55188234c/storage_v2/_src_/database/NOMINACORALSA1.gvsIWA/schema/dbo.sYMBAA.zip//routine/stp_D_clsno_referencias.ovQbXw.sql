-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_referencias]
  (  @oldreferencia varchar (20)  )
As DELETE [dbo].[no_referencias] 
WHERE (referencia =  @oldreferencia)
go

