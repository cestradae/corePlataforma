-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_egresos]
  As SELECT a.codigo_tipo,a.codigo_deduccion,a.cuenta_sap FROM [dbo].[sap_egresos] a
go

