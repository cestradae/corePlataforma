-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNo_ndet_clsNo_nemplcalcRelated]
(  @oldCodigo_tipo char (2) ,
  @oldPeriodo_id char (10) ,
  @oldGrupo_id char (5) ,
  @oldCodigo_empleado char (10) ,
  @oldNo_calculo smallint  )
  As 
SELECT a.periodo_id,a.codigo_tipo,a.grupo_id,a.no_calculo,a.codigo_empleado,a.correlativo,a.codigo_ingreso,a.monto_ingreso,a.codigo_deduccion,a.monto_deduccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.monto_base,a.codigo_departamento,a.codigo_centro FROM [dbo].[no_nomina_det] a
WHERE 
a.codigo_tipo =  @oldCodigo_tipo AND 
a.periodo_id =  @oldPeriodo_id AND 
a.grupo_id =  @oldGrupo_id AND 
a.codigo_empleado =  @oldCodigo_empleado AND 
a.no_calculo =  @oldNo_calculo
go

