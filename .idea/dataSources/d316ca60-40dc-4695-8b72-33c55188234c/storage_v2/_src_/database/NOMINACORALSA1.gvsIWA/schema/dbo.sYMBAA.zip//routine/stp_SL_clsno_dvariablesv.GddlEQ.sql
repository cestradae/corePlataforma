-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_dvariablesv]
  As SELECT a.descripcion,a.Tipo_valor,a.Clase,a.codigo_valor,a.nombre_valor,a.unidad_medida,a.valor,a.extra,a.meta,a.tipo_meta FROM [dbo].[no_detalle_variablesv] a
go

