-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_secciones](  @oldcodigo_seccion varchar (5) ,
  @codigo_seccion varchar (5) ,
  @nombre_seccion varchar (60) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_secciones] 
WHERE codigo_seccion =  @oldcodigo_seccion 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_secciones] Set 
    codigo_seccion = @codigo_seccion,
    nombre_seccion = @nombre_seccion 
WHERE 	( codigo_seccion =  @oldcodigo_seccion )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_secciones]
  WHERE ( codigo_seccion =  @codigo_seccion )
go

