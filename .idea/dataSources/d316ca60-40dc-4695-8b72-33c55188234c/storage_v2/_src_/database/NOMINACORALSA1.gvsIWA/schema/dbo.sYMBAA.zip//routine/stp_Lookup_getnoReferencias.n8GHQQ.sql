-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getnoReferencias]
As
  SELECT referencia , descripcion
FROM no_referencias
go

