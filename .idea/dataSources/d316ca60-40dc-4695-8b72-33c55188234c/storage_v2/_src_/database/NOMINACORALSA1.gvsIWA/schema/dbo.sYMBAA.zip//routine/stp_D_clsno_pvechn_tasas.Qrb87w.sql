-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_pvechn_tasas]
  (  @oldimpuesto_vecinal smallint ,
  @oldcorrelativo smallint  )
As DELETE [dbo].[no_parametros_vechn_tasas] 
WHERE (impuesto_vecinal =  @oldimpuesto_vecinal AND 
correlativo =  @oldcorrelativo)
go

