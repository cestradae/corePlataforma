-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_sregiones]
  As SELECT TOP 1000 a.codigo_region,a.nombre_region FROM [dbo].[no_siex_regiones] a
go

