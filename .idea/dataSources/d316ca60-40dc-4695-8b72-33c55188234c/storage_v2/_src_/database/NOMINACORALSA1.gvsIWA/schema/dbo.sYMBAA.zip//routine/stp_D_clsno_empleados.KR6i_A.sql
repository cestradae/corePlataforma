-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_empleados]
  (  @oldcodigo_empleado char (10)  )
As DELETE [dbo].[no_empleados] 
WHERE (codigo_empleado =  @oldcodigo_empleado)
go

