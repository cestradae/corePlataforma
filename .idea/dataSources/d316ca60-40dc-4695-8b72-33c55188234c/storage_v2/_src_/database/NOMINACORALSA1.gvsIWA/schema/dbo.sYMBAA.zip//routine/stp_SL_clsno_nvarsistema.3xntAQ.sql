-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_nvarsistema]
  As SELECT a.codigo_empleado,a.codigo_variable,a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.valor,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_nomina_variables_sistema] a
go

