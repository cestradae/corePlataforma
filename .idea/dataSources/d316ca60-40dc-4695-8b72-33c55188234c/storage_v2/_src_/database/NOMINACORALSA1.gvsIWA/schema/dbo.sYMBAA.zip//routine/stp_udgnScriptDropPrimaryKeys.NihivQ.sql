CREATE PROCEDURE [dbo].[stp_udgnScriptDropPrimaryKeys]
					@table_name varchar(200),
					@script varchar(8000) out
AS


-- Get all existing primary keys
DECLARE cPK CURSOR FOR
   SELECT TABLE_NAME, CONSTRAINT_NAME 
   FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  where TABLE_NAME = @table_name
  and CONSTRAINT_NAME like '%PK%'
   ORDER BY TABLE_NAME

DECLARE @PkTable SYSNAME
DECLARE @PkName SYSNAME

-- Loop through all the primary keys
OPEN cPK
FETCH NEXT FROM cPK INTO @PkTable, @PkName
WHILE (@@FETCH_STATUS = 0)
BEGIN
   DECLARE @PKSQL NVARCHAR(4000) SET @PKSQL = ''
   SET @PKSQL = 'ALTER TABLE ' + @PkTable + ' DROP CONSTRAINT ' + @PkName 
   
   --PRINT @PKSQL
  if @script is null
  begin
	SET @script = isnull(@script,'')+ '  ' + @PKSQL
  end
  else
  begin 
	SET @script = isnull(@script,'')+ char(10) + ''  + char(10) + @PKSQL
  end


   FETCH NEXT FROM cPK INTO @PkTable, @PkName
END
CLOSE cPK
DEALLOCATE cPK

--select @script
go

