CREATE procedure [dbo].[stp_udnofiniquitoMeses] 
   @codigo_tipo char(2),
   @grupo_id char(5),
   @periodo_id char(10),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @codigo_valor char(10) 
as 
------------------------------
-- Hecho por ldr
-- Fecha 03/03/2011
-- Asunto se generan los meses  
------------------------------

set nocount on

declare @fecha_inicial datetime
declare @fecha_final datetime
declare @fecha_baja datetime
declare @fecha_inicio_rel_lab datetime
declare @codigo_ingreso char(2)
declare @periodo_inicial char(10)
declare @periodo_final char(10)
declare @messtr varchar(2)
declare @diastr varchar(2)
declare @anostr varchar(4)
declare @corr_solicitud int
declare @fecha_suspension datetime
declare @fecha_i datetime
declare @ano smallint
declare @mes smallint
declare @descmes varchar(20)
-----------------------------------------------------
-- hecho por LDR
-- fecha 03-03-2011
-- Asunto se agrego solicitud de suspension  
-- que es para por lo menos una solicitud de vacaciones
------------------------------------------------------

if @no_meses >=1 
Begin
	IF (SELECT min(1) FROM no_solicitud_ausencias a, dbo.no_periodos_pago b
			WHERE a.tipo_solicitud='V'
			AND estado_solicitud in ('A','C')
			AND a.fecha_inicio BETWEEN b.fecha_inicial AND b.fecha_final
			AND b.periodo_id =@periodo_id
			AND a.codigo_empleado=@codigo_empleado)=1
			
	BEGIN 
		   select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + '01'
		   --select @fecha_final = dateadd(dd,-1,@fecha_final)
		   
		   select @fecha_inicial = dateadd(mm,@no_meses * -1 , @fecha_final )

           select @fecha_final = dateadd(dd,-1,@fecha_final)
	END
	else
	begin
	  
       select @corr_solicitud = 0
  
       select @corr_solicitud = a.corr_solicitud
       from no_solicitud_ausencias a
       left join no_solicitud_ausdet b on a.codigo_empleado = b.codigo_empleado
           and a.corr_solicitud = b.corr_solicitud 
           and a.estado_solicitud in ('A','C')
           and a.tipo_solicitud = 'S' 
           and b.a_fecha between @fecha_inicial and  @fecha_final
       where a.codigo_empleado=@codigo_empleado
         and b.a_fecha is not null

       if @corr_solicitud <> 0
       Begin
          select @fecha_suspension = null

          select @fecha_suspension = fecha_inicio
          from no_solicitud_ausencias 
          where codigo_empleado = @codigo_empleado
            and corr_solicitud = @corr_solicitud

          if @fecha_suspension is not null  
          Begin
             set rowcount 1 
             select @periodo_id = periodo_id
             from no_periodos_pago
             where @fecha_suspension between fecha_inicial and fecha_final
             order by periodo_id
             set rowcount 0
          End

       End

       select @fecha_final = fecha_inicial
	   from no_periodos_pago
	   where periodo_id = @periodo_id
	   
   	   select @fecha_inicial = dateadd(mm,@no_meses * -1 , @fecha_final )
    end
end
else 
begin
   select @fecha_inicial = min(fecha_inicial)
   from no_periodos_pago
   where substring(periodo_id,1,8) = substring(@periodo_id,1,8)

   select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + '01'
   select @fecha_final = dateadd(mm,1,@fecha_final)
end 


if @fecha_final is null select @fecha_final = substring(@periodo_id,3,4) + substring(@periodo_id,7,2) + substring(@periodo_id,9,2)

select @fecha_final   = dateadd(dd,-1, @fecha_final)

select @fecha_inicio_rel_lab = fecha_inicio_rel_lab
from no_empleados
where codigo_empleado = @codigo_empleado


select @fecha_baja  = fecha_liquidacion
from no_liquidaciones 
	where periodo_id = @periodo_id
and codigo_empleado = @codigo_empleado
and no_calculo is null

if @fecha_inicial is null 
   select @fecha_inicial = @fecha_final

Create table #AnoMes 
   ( ano smallint,
     mes smallint, 
     descmes varchar(20),
     anomes varchar(30) ) 

select @fecha_i = @fecha_inicial 

while @fecha_i <= @fecha_final 
Begin
   select @ano = datepart(yy,@fecha_i)
   select @mes = datepart(mm,@fecha_i)
   if @mes = 1 select @descmes = 'Enero' 
   if @mes = 2 select @descmes = 'Febrero' 
   if @mes = 3 select @descmes = 'Marzo' 
   if @mes = 4 select @descmes = 'Abril' 
   if @mes = 5 select @descmes = 'Mayo' 
   if @mes = 6 select @descmes = 'Junio' 
   if @mes = 7 select @descmes = 'Julio' 
   if @mes = 8 select @descmes = 'Agosto' 
   if @mes = 9 select @descmes = 'Septiembre' 
   if @mes = 10 select @descmes = 'Octubre' 
   if @mes = 11 select @descmes = 'Noviembre' 
   if @mes = 12 select @descmes = 'Diciembre' 
   
   insert into #Anomes (ano, mes ,descmes,anomes)
      values (  @ano, @mes, @descmes, convert(char(4),@ano ) +'-'+@descmes ) 

   select @fecha_i = dateadd(mm,1,@fecha_i)
End 

select *
from #Anomes
order by ano,mes

Drop table #Anomes
go

