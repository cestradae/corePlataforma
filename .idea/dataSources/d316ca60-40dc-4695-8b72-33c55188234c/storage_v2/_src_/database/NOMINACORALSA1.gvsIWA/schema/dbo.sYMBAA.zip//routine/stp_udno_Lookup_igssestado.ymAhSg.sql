CREATE PROCEDURE [dbo].[stp_udno_Lookup_igssestado]
As
-------------------------------------------------
-- Creado por Jhurtarte
-- Fecha 21/07/2011
-- Lookup de seleccion del estado del igss
-------------------------------------------------
  SELECT '1' Codigo , 'Prueba' Descripcion union all    
  SELECT '0', 'Produccion'
go

