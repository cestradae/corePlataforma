-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_ded_det](@AUTO_EditStamp varchar(30) OUT,
  @Codigo_empleado char (10) ,
  @Codigo_tipo char (2) ,
  @Codigo_deduccion char (3) ,
  @Correlativo smallint ,
  @Periodo_id char (10) ,
  @Monto money ,
  @Estado char (1) ,
  @Grupo_id char (5) ,
  @Usuario_ingreso varchar (35) ,
  @Fecha_ingreso datetime  )
As 
	INSERT INTO [dbo].[no_deducciones_det]
(  codigo_empleado ,
  codigo_tipo ,
  codigo_deduccion ,
  correlativo ,
  periodo_id ,
  monto ,
  estado ,
  grupo_id ,
  usuario_ingreso ,
  fecha_ingreso  )
VALUES (  @Codigo_empleado ,
  @Codigo_tipo ,
  @Codigo_deduccion ,
  @Correlativo ,
  @Periodo_id ,
  @Monto ,
  @Estado ,
  @Grupo_id ,
  @Usuario_ingreso ,
  @Fecha_ingreso  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_deducciones_det]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
codigo_tipo =  @Codigo_tipo AND 
codigo_deduccion =  @Codigo_deduccion AND 
correlativo =  @Correlativo AND 
periodo_id =  @Periodo_id )
go

