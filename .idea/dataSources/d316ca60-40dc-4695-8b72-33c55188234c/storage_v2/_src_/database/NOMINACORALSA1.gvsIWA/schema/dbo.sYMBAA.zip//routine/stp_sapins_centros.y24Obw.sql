Create procedure [dbo].[stp_sapins_centros]
	@PrcCode nchar(8),
    @PrcName nchar(30)
as

INSERT INTO sap_tr_centros
           (PrcCode,
           PrcName)
     VALUES
           (@PrcCode,
            @PrcName )
Return
go

