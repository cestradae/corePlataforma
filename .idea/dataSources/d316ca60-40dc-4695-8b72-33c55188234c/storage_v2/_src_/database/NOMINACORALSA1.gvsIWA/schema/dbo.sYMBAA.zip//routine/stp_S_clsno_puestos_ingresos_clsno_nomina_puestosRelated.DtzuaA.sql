-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_puestos_ingresos_clsno_nomina_puestosRelated]
(  @oldcodigo_puesto char (10) ,
  @oldcodigo_tipo char (2)  )
  As 
SELECT a.codigo_tipo,a.codigo_puesto,a.codigo_ingreso,a.monto_inicial,a.monto_final,a.promedio FROM [dbo].[no_puestos_ingresos] a
WHERE 
a.codigo_puesto =  @oldcodigo_puesto AND 
a.codigo_tipo =  @oldcodigo_tipo
go

