CREATE    FUNCTION [dbo].[FnInv_CostoMovimiento]  (@serie char(2), @numero int, @codigo_producto char(10), @TipoMov char(1))  
RETURNS decimal (19,7) AS  
BEGIN 

Declare @costo decimal(18,7)
Declare @es_kit char(1)

DECLARE @pkcodigo_producto char(10)
Declare @CostoKit decimal(19,7)
Declare @CostoTotal decimal(19,7)	

Set @costo = 0

Select @es_kit=es_kit from in_productos  where codigo_producto = @codigo_producto

If @TipoMov = 'F'
	if @es_kit <> 'S'
		Select  top 1 @costo = round(im.costo_unitario,7)
	                  from in_movimientos_det im, pv_facturas_inv fi
               	  where im.codigo_tipo = fi.codigo_tipo
                                        and im.codigo_bodega = fi.codigo_bodega
			and im.numero_movimiento = fi.numero_movimiento
                                        and im.codigo_producto = @codigo_producto
			and fi.serie = @serie
                                        and fi.numero = @numero
               Else
		Begin
			Select  top 1 @costo = round(im.costo_unitario,7)
		                  from in_movimientos_det im, pv_facturas_inv fi
		             	 where im.codigo_tipo = fi.codigo_tipo
		                 and im.codigo_bodega = fi.codigo_bodega
		                 and im.numero_movimiento = fi.numero_movimiento
		                 and im.codigo_producto = @codigo_producto
			    and fi.serie = @serie
		                 and fi.numero = @numero
                                     if ISNULL(@costo,0) = 0
                                     Begin

			DECLARE cKits CURSOR
			READ_ONLY
			FOR Select pk.codigo_producto_det from in_productos_kit pk
			         where pk.codigo_producto = @codigo_producto		

			
			Set @CostoTotal = 0

			OPEN ckits

			FETCH NEXT FROM ckits INTO @pkcodigo_producto
			WHILE (@@fetch_status <> -1)
				BEGIN
					IF (@@fetch_status <> -2)
					BEGIN
                                                                             Set @costoKit = 0
					           Select  top 1 @costoKit = round(im.costo_unitario,7)
					                  from in_movimientos_det im, pv_facturas_inv fi
				               	  where im.codigo_tipo = fi.codigo_tipo
			                                        and im.codigo_bodega = fi.codigo_bodega
						and im.numero_movimiento = fi.numero_movimiento
			                                        and im.codigo_producto = @pkcodigo_producto
						and fi.serie = @serie
			                                        and fi.numero = @numero
			
						Set @costototal = @costototal + @CostoKit	      
					END
					FETCH NEXT FROM ckits INTO @pkcodigo_producto
				END

			CLOSE ckits
			DEALLOCATE ckits

			Set @costo = @Costototal
                                    End
		
		End
               
If @TipoMov = 'C'
	if @es_kit <> 'S'
		Select  top 1 @costo = round(im.costo_unitario,7)
	                  from in_movimientos_det im, pv_ncredito_inv ni
               	  where im.codigo_tipo = ni.codigo_tipo
                                        and im.codigo_bodega = ni.codigo_bodega
			and im.numero_movimiento = ni.numero_movimiento
                                        and im.codigo_producto = @codigo_producto
			and ni.serie = @serie
                                        and ni.numero = @numero
	Else
		Begin
			Select  top 1 @costo = round(im.costo_unitario,7)
		                  from in_movimientos_det im, pv_facturas_inv fi
		             	 where im.codigo_tipo = fi.codigo_tipo
		                 and im.codigo_bodega = fi.codigo_bodega
		                 and im.numero_movimiento = fi.numero_movimiento
		                 and im.codigo_producto = @codigo_producto
			    and fi.serie = @serie
		                 and fi.numero = @numero

                                     if isnull(@costo,0) = 0 
                                     Begin
			DECLARE cKits CURSOR
			READ_ONLY
			FOR Select pk.codigo_producto_det from in_productos_kit pk
			         where pk.codigo_producto = @codigo_producto

			Set @costoKit = 0
			Set @CostoTotal = 0

			OPEN ckits

			FETCH NEXT FROM ckits INTO @pkcodigo_producto
			WHILE (@@fetch_status <> -1)
				BEGIN
					IF (@@fetch_status <> -2)
					BEGIN					          
						Select  top 1 @costoKit = round(im.costo_unitario,7)
					                  from in_movimientos_det im, pv_ncredito_inv ni
				               	  where im.codigo_tipo = ni.codigo_tipo
				                                        and im.codigo_bodega = ni.codigo_bodega
							and im.numero_movimiento = ni.numero_movimiento
				                                        and im.codigo_producto = @pkcodigo_producto
							and ni.serie = @serie
				                                        and ni.numero = @numero
			
						Set @costototal = @costototal + @CostoKit	      
					END
					FETCH NEXT FROM ckits INTO @pkcodigo_producto
				END

			CLOSE ckits
			DEALLOCATE ckits

			Set @costo = @Costototal
                                     End
		End

If @TipoMov = 'D'
	if @es_kit <> 'S'
		Select  top 1 @costo = round(im.costo_unitario,7)
	                  from in_movimientos_det im, pv_ndebito_inv ni
               	  where im.codigo_tipo = ni.codigo_tipo
                                        and im.codigo_bodega = ni.codigo_bodega
			and im.numero_movimiento = ni.numero_movimiento
                                        and im.codigo_producto = @codigo_producto
			and ni.serie = @serie
                                        and ni.numero = @numero
	Else
		Begin
   		   Select  top 1 @costo = round(im.costo_unitario,7)
	                  from in_movimientos_det im, pv_ndebito_inv ni
               	   where im.codigo_tipo = ni.codigo_tipo
                                        and im.codigo_bodega = ni.codigo_bodega
			and im.numero_movimiento = ni.numero_movimiento
                                        and im.codigo_producto = @codigo_producto
			and ni.serie = @serie
                                        and ni.numero = @numero

                               if isnull(@costo,0) = 0
                               Begin
			DECLARE cKits CURSOR
			READ_ONLY
			FOR Select pk.codigo_producto_det from in_productos_kit pk
			         where pk.codigo_producto = @codigo_producto

			Set @costoKit = 0
			Set @CostoTotal = 0

			OPEN ckits

			FETCH NEXT FROM ckits INTO @pkcodigo_producto
			WHILE (@@fetch_status <> -1)
				BEGIN
					IF (@@fetch_status <> -2)
					BEGIN	
						Select  top 1 @costoKit = round(im.costo_unitario,7)
					                  from in_movimientos_det im, pv_ndebito_inv ni
				               	  where im.codigo_tipo = ni.codigo_tipo
				                                        and im.codigo_bodega = ni.codigo_bodega
							and im.numero_movimiento = ni.numero_movimiento
				                                        and im.codigo_producto = @pkcodigo_producto
							and ni.serie = @serie
				                                        and ni.numero = @numero
			
						Set @costototal = @costototal + @CostoKit	      
					END
					FETCH NEXT FROM ckits INTO @pkcodigo_producto
				END

			CLOSE ckits
			DEALLOCATE ckits

			Set @costo = @Costototal

                                End
		End


  Return @costo
END
go

