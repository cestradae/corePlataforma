CREATE PROCEDURE [dbo].[stp_udnoObtieneSiexDepartamentos]
													@codigo_region varchar(10),
													@xerror char(1) out
AS
BEGIN

-- =============================================
-- Author:		Estuardo Arévalo
-- Create date: 08/07/2009
-- Description:	Trae el Catalogo de Departamentos para Siex
-- =============================================

	
	SET NOCOUNT ON;

	select @xerror = ''
    
	SELECT codigo_departamento as Codigo, codigo_departamento + ' - ' + nombre_departamento  as Departamento
	From no_siex_departamentos
	where codigo_region = @codigo_region
	
END
go

