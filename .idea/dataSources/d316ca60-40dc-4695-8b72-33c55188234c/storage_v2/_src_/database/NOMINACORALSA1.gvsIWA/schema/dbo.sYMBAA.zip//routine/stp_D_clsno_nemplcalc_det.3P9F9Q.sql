-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_nemplcalc_det]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint ,
  @oldnumero_cheque int ,
  @oldid_cuenta varchar (32) ,
  @oldtipo_movimiento smallint ,
  @oldcodigo_empleado char (10)  )
As DELETE [dbo].[no_nomina_emplcalc_det] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo AND 
numero_cheque =  @oldnumero_cheque AND 
id_cuenta =  @oldid_cuenta AND 
tipo_movimiento =  @oldtipo_movimiento AND 
codigo_empleado =  @oldcodigo_empleado)
go

