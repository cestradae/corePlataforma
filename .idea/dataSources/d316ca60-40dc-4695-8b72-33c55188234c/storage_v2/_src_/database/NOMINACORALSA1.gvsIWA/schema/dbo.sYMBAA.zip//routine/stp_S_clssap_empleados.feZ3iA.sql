-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_empleados]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_empleado char (10)  )
As SELECT a.codigo_tipo,a.codigo_empleado,a.cuenta_sap FROM [dbo].[sap_empleados] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.codigo_empleado =  @oldcodigo_empleado)
go

