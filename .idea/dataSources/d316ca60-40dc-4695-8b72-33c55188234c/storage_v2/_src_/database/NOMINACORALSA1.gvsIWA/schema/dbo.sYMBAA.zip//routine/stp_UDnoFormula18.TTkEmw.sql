create procedure stp_UDnoFormula18
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @BaseOrd decimal(18,4) 
declare @PAsso decimal(22,6) 

begin
  Select @BaseOrd= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ord'
Select @PAsso= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'PAsso'

  set @result=isnull(@BaseOrd,0)*isnull(@PAsso,0)/100
end
go

