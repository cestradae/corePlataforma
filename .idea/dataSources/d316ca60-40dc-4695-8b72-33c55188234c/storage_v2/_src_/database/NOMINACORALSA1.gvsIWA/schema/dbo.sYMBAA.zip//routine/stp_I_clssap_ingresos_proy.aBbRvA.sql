-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_ingresos_proy](  @codigo_tipo char (2) ,
  @codigo_ingreso varchar (3) ,
  @codigo_clase varchar (20) ,
  @codigo_centro varchar (20) ,
  @cuenta_sap nvarchar (15)  )
As 
	INSERT INTO [dbo].[sap_ingresos_proyectos]
(  codigo_tipo ,
  codigo_ingreso ,
  codigo_clase ,
  codigo_centro ,
  cuenta_sap  )
VALUES (  @codigo_tipo ,
  @codigo_ingreso ,
  @codigo_clase ,
  @codigo_centro ,
  @cuenta_sap  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

