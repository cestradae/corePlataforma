
CREATE procedure [dbo].[stp_UdSapCargaCheques] --'01','0220081101','1',null
    @codigo_tipo char(2),
  @periodo char(10),
  @grupo char(5),
  @no_pago_inicial smallint,
  @no_pago_final smallint,
  @fecha datetime,
  @codigo_banco int = 0,
  @id_cuenta varchar(30) = ''
as
    set nocount on
	set dateformat dmy
   
  declare @CtaCargo char(15)
  declare @fecha_inicial datetime
  declare @fecha_final datetime

  CREATE TABLE [dbo].[#ChequesTMP](
	[id_cuenta] [varchar](32) COLLATE Modern_Spanish_CI_AS NOT NULL,
	[codigo_empleado] [char](10) COLLATE Modern_Spanish_CI_AS NULL,
	[numero_cheque] [int] NOT NULL,
	[monto_cheque] [money] NOT NULL,
	[fecha_cheque] [datetime] NOT NULL,
	[beneficiario] [varchar](200) COLLATE Modern_Spanish_CI_AS NOT NULL,   
	[concepto] [varchar](200) COLLATE Modern_Spanish_CI_AS NOT NULL,   
	[codigo_centro] [varchar](20) COLLATE Modern_Spanish_CI_AS NOT NULL,   
) ON [PRIMARY]

	Create table #Centros (
     codigo_tipo char(10) COLLATE Modern_Spanish_CI_AS ,          
	 codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS ,      
     PrcCode nchar(16) COLLATE Modern_Spanish_CI_AS ,     
	 PrcName nchar(60) COLLATE Modern_Spanish_CI_AS ,		
    
)

--Centros	
insert into #Centros
	(codigo_tipo, codigo_centro, PrcCode, PrcName)
select  a.codigo_tipo, a.codigo_centro, b.PrjCode, b.PrjName
from sap_centros a
	inner join sap_tr_proyectos b
		on a.codigo_sap = b.PrjCode
where a.codigo_tipo = @codigo_tipo


  if isnull(@codigo_banco,0) = 0 select @codigo_banco = codigo_banco from no_tipos_nomina where codigo_tipo = @codigo_tipo
  if isnull(@id_cuenta,'') = '' select @id_cuenta = id_cuenta from no_tipos_nomina where codigo_tipo = @codigo_tipo
  
  
  -- Trae la cuenta Cargo
	Select @CtaCargo = Cuenta_salios_sap 
      from sap_parametros
     where codigo_tipo = @codigo_tipo

  Declare @concepto varchar(50)  	
	DECLARE @nombre_corto VARCHAR(30)
	DECLARE @no_nomina VARCHAR(10)
	
  -- fechas del periodo
	select @fecha_inicial = fecha_inicial,
			@fecha_final = fecha_final,
			@no_nomina = no_nomina
	 from no_periodos_pago
	 where periodo_id = @periodo
		and codigo_tipo = @codigo_tipo

	--Definimos el Concepto de la Partida
	SELECT @nombre_corto = nombre_corto FROM dbo.no_tipos_nomina 
			WHERE codigo_tipo = @codigo_tipo
	
	
	SET @concepto = @nombre_corto+' '+RTRIM(@no_nomina)+ ' AL '+ CONVERT ( VARCHAR(20), @fecha_final , 105 ) 


   INSERT into #ChequesTMP
   
   select a.id_cuenta, a.codigo_empleado,a.numero_cheque,monto_pagado,a.fecha_ingreso, b.nombre_usual,
		
		 @concepto as concepto, b.codigo_centro

   from no_nomina_emplcalc_det a, no_empleados b, no_grupos_valores c
   where  --estado_cheque = 'I' and 
		a.codigo_tipo = @codigo_tipo
    and periodo_id = @periodo
    and a.grupo_id = @grupo
    and no_calculo between @no_pago_inicial and @no_pago_final
	--and trasladado = 'N'
    and a.codigo_empleado = b.codigo_empleado
	and a.grupo_id = c.grupo_id
	--and b.codigo_banco = @codigo_banco
	and a.id_cuenta = @id_cuenta

	
    select c.numero_cheque,/*c.codigo_empleado*/SE.codigo_empleado, se.nombre_usual as beneficiario,c.concepto, @fecha as fecha_cheque , sb.banco_sap, sb.dfltacct , c.monto_cheque,  RTRIM(cn.PrcCode)+' '+cn.PrcName AS PrcName
		, @CtaCargo CtaCargo, @Ctacargo cuenta_sap  , sb.pais_sap, @id_cuenta,  ISNULL(RTRIM(cn.PrcCode),'') AS PrcCode
      from #ChequesTMP c, no_empleados se, sap_bancos sb, #Centros cn
     where c.codigo_empleado = se.codigo_empleado
       and c.id_cuenta *= sb.id_cuenta  
       AND cn.codigo_centro =* c.codigo_centro
          
          
	
Return



go

