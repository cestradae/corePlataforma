-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_ul_usuarios]
As
  SELECT userid Usuario, username Nombre
   FROM _users
   ORDER BY userid
go

