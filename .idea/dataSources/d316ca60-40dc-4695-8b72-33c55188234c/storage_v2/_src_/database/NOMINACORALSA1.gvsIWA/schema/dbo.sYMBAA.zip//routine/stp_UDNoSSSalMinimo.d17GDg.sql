Create procedure  [dbo].[stp_UDNoSSSalMinimo] 
    @codigo_empleado char(10), 
    @codigo_tipo char(2), 
    @periodo_id char(10), 
    @grupo_id char(5),
    @no_calculo int,
    @SSSalminimo money out
as
---------------------------
-- Hecho por lsao
-- Fecha 04-08-2008
-- Calculo de vacaciones solicitudas
---------------------------

set rowcount 1
select @SSSalminimo = salario
from no_salarios_minimos
where codigo_tipo = @codigo_tipo
 and periodo_id <= @periodo_id
order by periodo_id desc
set rowcount 0

if @SSSalminimo is null select @SSSalminimo = 0
go

