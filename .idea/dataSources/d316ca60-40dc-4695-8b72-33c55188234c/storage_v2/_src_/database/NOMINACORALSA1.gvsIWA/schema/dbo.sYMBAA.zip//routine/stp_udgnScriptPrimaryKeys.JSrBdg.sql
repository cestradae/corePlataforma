CREATE PROCEDURE [dbo].[stp_udgnScriptPrimaryKeys]
					@table_name varchar(200),
					@script varchar(8000) out
AS


-- Get all existing primary keys
DECLARE cPK CURSOR FOR
   SELECT TABLE_NAME, CONSTRAINT_NAME 
   FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
  where TABLE_NAME = @table_name
  and CONSTRAINT_NAME like '%PK%'
   ORDER BY TABLE_NAME

DECLARE @PkTable SYSNAME
DECLARE @PkName SYSNAME

-- Loop through all the primary keys
OPEN cPK
FETCH NEXT FROM cPK INTO @PkTable, @PkName
WHILE (@@FETCH_STATUS = 0)
BEGIN
   DECLARE @PKSQL NVARCHAR(4000) SET @PKSQL = ''
   SET @PKSQL = 'ALTER TABLE ' + @PkTable + ' ADD CONSTRAINT ' + @PkName + ' PRIMARY KEY CLUSTERED ('

   -- Get all columns for the current primary key
   DECLARE cPKColumn CURSOR FOR
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
      WHERE TABLE_NAME = @PkTable AND CONSTRAINT_NAME = @PkName
      ORDER BY ORDINAL_POSITION
   OPEN cPKColumn

   DECLARE @PkColumn SYSNAME
   DECLARE @PkFirstColumn BIT SET @PkFirstColumn = 1
   -- Loop through all columns and append the sql statement
   FETCH NEXT FROM cPKColumn INTO @PkColumn
   WHILE (@@FETCH_STATUS = 0)
   BEGIN
      IF (@PkFirstColumn = 1)
         SET @PkFirstColumn = 0
      ELSE
         SET @PKSQL = @PKSQL + ', '

      SET @PKSQL = @PKSQL + @PkColumn

      FETCH NEXT FROM cPKColumn INTO @PkColumn
   END
   CLOSE cPKColumn
   DEALLOCATE cPKColumn

   SET @PKSQL = @PKSQL + ')'
   -- Print the primary key statement
   --PRINT @PKSQL
  if @script is null
  begin
	SET @script = isnull(@script,'')+ '  ' + @PKSQL
  end
  else
  begin 
	SET @script = isnull(@script,'')+ char(10) + ''  + char(10) + @PKSQL
  end


   FETCH NEXT FROM cPK INTO @PkTable, @PkName
END
CLOSE cPK
DEALLOCATE cPK

--select @script
go

