-- [stp_UdSapActualizaEstadoProvision] '01','0120100501','011',0

CREATE procedure [dbo].[stp_UdSapActualizaEstadoProvision] 
  @codigo_tipo char(2),
  @periodo char(10),
  @grupo char(5),
  @no_pago smallint,
  @user_id INT
as
  
-----------------------------------------------------------------------------------------------------
--Creado por: Daniel Ortiz
--Fecha: 08/06/2010
--Observaciones: Procedimiento para actualizar el estado del trasladado de una Provision
-------
-----------------------------------------------------------------------------------------------------

	BEGIN TRAN

   update no_provisiones_enc
	set contabilizado_sap = 'S',
		usuario_sap=@user_id,
		fecha_sap=GETDATE()
   where codigo_tipo = @codigo_tipo
    and periodo_id = @periodo
    and grupo_id = @grupo
    and no_calculo = @no_pago

	IF @@error <> 0 
	BEGIN
		raiserror ( ' No se pudo Actualizar trasladado en no_provisiones_enc - [stp_UdSapActualizaEstadoProvision] ', 16,1,5000)
		ROLLBACK work
		return
	END

	COMMIT TRAN    

RETURN
go

