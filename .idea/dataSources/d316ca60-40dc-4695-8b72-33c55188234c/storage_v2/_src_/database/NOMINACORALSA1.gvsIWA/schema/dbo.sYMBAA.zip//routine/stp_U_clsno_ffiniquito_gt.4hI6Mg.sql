
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_ffiniquito_gt(  @oldcodigo_formato smallint ,
  @codigo_formato smallint ,
  @descripcion_formato varchar (50) ,
  @nombre_formato varchar (50)  )
As 
UPDATE [dbo].[no_formatos_finiquitos] Set 
    codigo_formato = @codigo_formato,
    descripcion_formato = @descripcion_formato,
    nombre_formato = @nombre_formato 
WHERE 	( codigo_formato =  @oldcodigo_formato )
go

