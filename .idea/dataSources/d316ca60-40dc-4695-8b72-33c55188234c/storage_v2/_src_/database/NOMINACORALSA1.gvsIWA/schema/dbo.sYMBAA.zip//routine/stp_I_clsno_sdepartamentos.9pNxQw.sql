-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_sdepartamentos](  @codigo_region varchar (10) ,
  @codigo_departamento char (2) ,
  @nombre_departamento varchar (100)  )
As 
	INSERT INTO [dbo].[no_siex_departamentos]
(  codigo_region ,
  codigo_departamento ,
  nombre_departamento  )
VALUES (  @codigo_region ,
  @codigo_departamento ,
  @nombre_departamento  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

