-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_cprovisiones]
  As SELECT a.codigo_provision,a.descripcion,a.linea_1Reporte,a.linea_2Reporte,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.cuenta_contable,a.nombre_corto FROM [dbo].[no_catalogo_provisiones] a
go

