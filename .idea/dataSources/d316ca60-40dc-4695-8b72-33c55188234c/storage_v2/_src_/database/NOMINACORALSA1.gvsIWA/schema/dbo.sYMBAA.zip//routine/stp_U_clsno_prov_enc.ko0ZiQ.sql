-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_prov_enc](  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @no_calculo smallint ,
  @usuario_ingreso varchar (35) OUT  ,
  @fecha_ingreso datetime OUT  ,
  @estado char (1) OUT  ,
  @usuario_cierre varchar (35) OUT  ,
  @fecha_cierre datetime OUT  ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_provisiones_enc] 
WHERE codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_provisiones_enc] Set 
    codigo_tipo = @codigo_tipo,
    periodo_id = @periodo_id,
    grupo_id = @grupo_id,
    no_calculo = @no_calculo 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @usuario_ingreso = usuario_ingreso, @fecha_ingreso = fecha_ingreso, @estado = estado, @usuario_cierre = usuario_cierre, @fecha_cierre = fecha_cierre, @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_provisiones_enc]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
grupo_id =  @grupo_id AND 
no_calculo =  @no_calculo )
go

