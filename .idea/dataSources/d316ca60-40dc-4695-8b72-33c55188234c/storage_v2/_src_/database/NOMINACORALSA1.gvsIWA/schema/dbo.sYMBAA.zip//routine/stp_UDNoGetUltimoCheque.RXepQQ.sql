CREATE procedure [dbo].[stp_UDNoGetUltimoCheque]
    @id_cuenta varchar(32),
    @ultimo_cheque int out
as

select @ultimo_cheque = numero_cheque
from bn_cuentas
where id_cuenta = @id_cuenta 

select @ultimo_cheque = @ultimo_cheque + 1
if @ultimo_cheque is null select @ultimo_cheque = 1
go

