-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNo_ded_det]
  (  @oldCodigo_empleado char (10) ,
  @oldCodigo_tipo char (2) ,
  @oldCodigo_deduccion char (3) ,
  @oldCorrelativo smallint ,
  @oldPeriodo_id char (10)  )
As SELECT a.codigo_empleado,a.codigo_tipo,a.codigo_deduccion,a.correlativo,a.periodo_id,a.monto,a.estado,a.grupo_id,a.usuario_ingreso,a.fecha_ingreso,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_deducciones_det] a
WHERE (a.codigo_empleado =  @oldCodigo_empleado AND 
a.codigo_tipo =  @oldCodigo_tipo AND 
a.codigo_deduccion =  @oldCodigo_deduccion AND 
a.correlativo =  @oldCorrelativo AND 
a.periodo_id =  @oldPeriodo_id)
go

