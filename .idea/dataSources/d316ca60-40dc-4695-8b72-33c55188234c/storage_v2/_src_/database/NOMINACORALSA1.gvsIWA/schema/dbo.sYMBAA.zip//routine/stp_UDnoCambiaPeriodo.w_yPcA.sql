Create procedure [dbo].[stp_UDnoCambiaPeriodo]
   @periodo_id_equivocado char(10),
   @periodo_id_correcto char(10)
as

update no_calculo_ingresos  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_calculo_sueldos  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_cheques_eliminados  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_deducciones_cuotas  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 

alter table no_deducciones_det disable trigger all
update no_deducciones_det  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
alter table no_deducciones_det enable trigger all

update no_deducciones_enc  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_empleado_ingresos_historico  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 

alter table no_empleado_vacdet disable trigger all
update no_empleado_vacdet  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
alter table no_empleado_vacdet enable trigger all

update no_liquidaciones  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_liquidaciones_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_asistencia  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_det  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_det_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_emplcalc  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_emplcalc_det  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_emplcalc_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_enc  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_enc_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_liqprovision  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_valores_calculados  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_nomina_variables_sistema  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_periodos_pago  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_provisiones_det  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_provisiones_empleados  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_provisiones_enc  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_provisiones_sap  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_detalle  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_detalle_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_empleado  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_empleado_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_grupos  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_valores  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reporte_valores_estadistico  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 

alter table no_reporte_valores_ingreso disable trigger all
update no_reporte_valores_ingreso  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
alter table no_reporte_valores_ingreso enable trigger all

update no_reporte_valores_ingreso_tr  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_reportes_autorizaciones  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update no_salarios_minimos  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 

alter table no_solicitud_ausencias disable trigger all
update no_solicitud_ausencias  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
alter table no_solicitud_ausencias enable trigger all

update sap_bitacora_det  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado 
update sap_bitacora_enc  set periodo_id = @periodo_id_correcto where periodo_id = @periodo_id_equivocado
go

