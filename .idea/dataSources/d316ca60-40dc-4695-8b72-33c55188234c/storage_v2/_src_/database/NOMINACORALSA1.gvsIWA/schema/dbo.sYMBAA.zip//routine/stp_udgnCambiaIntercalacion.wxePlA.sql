CREATE PROCEDURE  [dbo].[stp_udgnCambiaIntercalacion] 
			@nombre_tabla varchar(200),
			@intercalacion varchar(500)
as
BEGIN

	BEGIN TRAN
	
	declare @nombre_columnas varchar(200)
	declare @strsql varchar(5000)
	declare @object_id int
	declare @max_length int
	declare @typename varchar(100)
	declare @old_intercalacion varchar(500)
	declare @isnullable int
	declare @strnullable varchar(100)
	
	declare @scriptCreatePrimary varchar(8000)
	declare @scriptCreateForeign varchar(8000)
	declare @scriptDropPrimary varchar(8000)
	declare @scriptDropForeign varchar(8000)
	
	
	EXEC stp_udgnScriptForeignKeys @nombre_tabla,@scriptCreateForeign out
	EXEC stp_udgnScriptDropForeignKeys @nombre_tabla,@scriptDropForeign out
	EXEC stp_udgnScriptPrimaryKeys @nombre_tabla,@scriptCreatePrimary out
	EXEC stp_udgnScriptDropPrimaryKeys @nombre_tabla,@scriptDropPrimary out
	
	
	print  @scriptCreateForeign	
	print @scriptDropForeign 	
	print @scriptCreatePrimary
	print @scriptDropPrimary
	
	exec(@scriptDropForeign)
	if @@error <> 0
	begin
		raiserror ( ' Error al hacer drop de foreign keys ' , 16, 1 )
		rollback work
		return
	end
	
	exec(@scriptDropPrimary)
	if @@error <> 0
	begin
		raiserror ( ' Error al hacer drop de primary keys ' , 16, 1 )
		rollback work
		return
	end
	
	
	declare curColumnas cursor for
		SELECT name, collation_name, OBJECT_ID, is_nullable
			FROM sys.columns
			WHERE OBJECT_ID IN ( SELECT OBJECT_ID
													FROM sys.objects
													WHERE type = 'U'
													AND name = @nombre_tabla)
			AND collation_name is not null
			and is_identity = 0
			and is_computed = 0
	open curColumnas
	fetch curColumnas into @nombre_columnas, @old_intercalacion,@object_id,@isnullable
	while @@FETCH_STATUS = 0 
	begin

			if @isnullable > 0 
			begin
					SET @strnullable = ' NULL'
			end
			else
			begin
					SET @strnullable = ' NOT NULL'
			end
		

			SELECT
			--	OBJECT_NAME(c.OBJECT_ID) TableName
			--	,c.name AS ColumnName
			--	,SCHEMA_NAME(t.schema_id) AS SchemaName
				@typename = t.name --AS TypeName
			--	,t.is_user_defined
			--	,t.is_assembly_type
				,@max_length = c.max_length
			--	,c.PRECISION
			--	,c.scale
			FROM sys.columns AS c
			JOIN sys.types AS t ON c.user_type_id=t.user_type_id
			WHERE 
				c.OBJECT_ID = @object_id and
				c.name = @nombre_columnas and
				t.name in ('char','varchar','nchar','nvarchar')
			ORDER BY c.OBJECT_ID;


					set @strsql = ''+
								'ALTER TABLE '+@nombre_tabla+' '+
								'ALTER COLUMN '+@nombre_columnas+' '+@typename+'('+CONVERT(varchar(10),@max_length)+') '+ 
								'COLLATE '+@intercalacion+' ' + @strnullable + ' '
					exec(@strsql)
					
					if @@error <> 0
					begin
						raiserror ( ' Error al hacer alter a la tabla ' , 16, 1 )
						close curColumnas
						deallocate curColumnas
						rollback work
						return
					end

			select @object_id as [OBJECT_ID], @nombre_tabla as NombreTabla
								,@nombre_columnas as NombreColumna, @old_intercalacion as AntiguaIntercalacion, @intercalacion as NuevaIntercalacion
		
		fetch curColumnas into @nombre_columnas, @old_intercalacion,@object_id, @isnullable
	end
	close curColumnas
	deallocate curColumnas


	exec(@scriptCreatePrimary)
	if @@error <> 0
	begin
		raiserror ( ' Error al crear Primary Keys ' , 16, 1 )
		rollback work
		return
	end
	
	exec(@scriptCreateForeign)
	if @@error <> 0
	begin
		raiserror ( ' Error al crear Foreign Keys ' , 16, 1 )
		rollback work
		return
	end
	
	COMMIT TRAN

END
go

