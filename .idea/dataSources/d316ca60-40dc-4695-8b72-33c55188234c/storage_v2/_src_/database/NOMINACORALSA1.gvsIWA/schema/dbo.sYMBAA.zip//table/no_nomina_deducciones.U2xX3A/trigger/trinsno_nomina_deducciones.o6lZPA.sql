Create TRIGGER [dbo].[trinsno_nomina_deducciones] ON dbo.no_nomina_deducciones 
FOR INSERT
AS
----------------------------
-- Hecho por lsao
-- Fecha 21/08/2008
-- Asunto Manejo de multiples monedas
----------------------------

declare @codigo_tipo char(2)
declare @codigo_deduccion varchar(3)
declare @codigo_moneda smallint
declare @moneda_nomina smallint
declare @es_local char(1)
declare @tipo_moneda char(1)

select @codigo_tipo = codigo_tipo,
       @codigo_deduccion = codigo_deduccion,
       @codigo_moneda = codigo_moneda
from inserted

select @moneda_nomina = codigo_moneda
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

if @moneda_nomina = @codigo_moneda
Begin 
   select @tipo_moneda = '1'  --- La moneda es igual, no convierte
End
Else
Begin
   select @es_local = es_local
   from gn_monedas
   where codigo_moneda = @codigo_moneda 

   if @es_local is null select @es_local = 'S'
   if @es_local = 'S'
   Begin
      select @tipo_moneda = '2'  -- La moneda del ingreso es local , divide por tasa_cambio
   End
   else
   Begin
      select @tipo_moneda = '3'  -- La moneda es diferente de dolar, divide por tasa_cambio
   End
End

update no_nomina_deducciones
   set tipo_moneda = @tipo_moneda
where codigo_tipo = @codigo_tipo
  and codigo_deduccion = @codigo_deduccion

if @@error <> 0
Begin
   Raiserror ('No se pudo modificar el deduccion - trinsno_nomina_ingresos ',16,1,5000)
   Rollback work
   Return
End


go

