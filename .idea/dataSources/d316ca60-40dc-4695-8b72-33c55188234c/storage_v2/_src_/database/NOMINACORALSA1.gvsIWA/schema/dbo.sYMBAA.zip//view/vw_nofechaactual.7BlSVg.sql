CREATE view [dbo].[vw_nofechaactual]
as
-------------------------------------------------
--Hecho por:Mario Juarros
--Fecha:17/01/2009
--obtiene fecha actual para la funcion [fn_noanosdevida]
-------------------------------------------------
select getdate() as fecha
go

