CREATE FUNCTION [dbo].[func_PlazaVacantes] (@codigo_puesto char(10),
  @cant_plazas smallint )  
RETURNS smallint AS  
BEGIN 
---
-- Creado por LDR
-- fecha 08-06-2009
-- Plazas Vacantes
declare @resultado smallint

if @cant_plazas > 0 
Begin
select @resultado = @cant_plazas - count(*)
from no_empleados 
where codigo_puesto = @codigo_puesto
  and estado_empleado in ( 'A','S')
End
Else
Begin
   select @resultado = 0
End

if @resultado is null select @resultado = 0

return @resultado

END
go

