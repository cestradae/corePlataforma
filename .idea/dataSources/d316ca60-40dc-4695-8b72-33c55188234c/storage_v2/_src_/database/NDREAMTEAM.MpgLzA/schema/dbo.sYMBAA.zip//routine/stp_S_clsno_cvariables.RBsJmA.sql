-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_cvariables]
  (  @oldcodigo_clase varchar (20)  )
As SELECT a.tipo_valor,a.codigo_clase,a.descripcion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_clases_variables] a
WHERE (a.codigo_clase =  @oldcodigo_clase)
go

