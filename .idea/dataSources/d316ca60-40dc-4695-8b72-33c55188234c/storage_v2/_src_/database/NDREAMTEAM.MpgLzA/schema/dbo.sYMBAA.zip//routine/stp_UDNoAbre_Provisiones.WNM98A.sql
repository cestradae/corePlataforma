CREATE procedure [dbo].[stp_UDNoAbre_Provisiones]
   @codigo_tipo char(2),
   @periodo_id char(10)
as


----------------------------------------------------------------------------
--Abre calculo de provisiones para que no se pueda eliminar
--Fecha 25/08/2003
--Creado por LSAO
----------------------------------------------------------------------------

declare @estado char(1)

select @estado = estado
from no_provisiones_enc
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id

if @estado = 'O' 
begin
   raiserror ('Calculo de provisiones no esta cerrado !!!- stp_UDNoAbre_Provisiones ', 16,1,5000 )
   return
end

Begin Tran

-- Actualizamos el estado de la provision 

Update no_provisiones_enc
   set estado= 'A' 
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id

if @@error <> 0
begin
   raiserror ('No se pudo actualizar el estado del calculo - stp_UDNoAbre_provisiones' ,16,1,5000 )
   rollback tran
   return
end 


Commit tran
go

