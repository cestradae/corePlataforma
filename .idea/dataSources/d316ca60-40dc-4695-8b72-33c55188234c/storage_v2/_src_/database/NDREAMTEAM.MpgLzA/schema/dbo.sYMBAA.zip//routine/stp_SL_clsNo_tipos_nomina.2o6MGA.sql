-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_tipos_nomina]
  As SELECT a.codigo_tipo,a.descripcion,a.no_autorizaciones,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.codigo_moneda,a.codigo_banco,a.id_cuenta,a.cuenta_nomina,a.centro_nomina,a.formato_recibo,a.monto_maximo,a.formato_banco,a.formato_lote_cheque,a.referencia_cheque,a.reporte_libro,a.nombre_corto,a.formato_depositos,a.impresora,a.orden,a.observaciones_cheque,a.ch_aut_por,a.ch_rev_por FROM [dbo].[no_tipos_nomina] a
go

