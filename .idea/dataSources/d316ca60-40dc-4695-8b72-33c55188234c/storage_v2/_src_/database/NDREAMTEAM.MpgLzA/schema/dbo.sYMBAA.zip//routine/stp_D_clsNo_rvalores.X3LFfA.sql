-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_rvalores]
  (  @oldCodigo_tipo char (2) ,
  @oldPeriodo_id char (10) ,
  @oldNo_reporte smallint  )
As DELETE [dbo].[no_reporte_valores] 
WHERE (codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
no_reporte =  @oldNo_reporte)
go

