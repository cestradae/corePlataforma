-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoProcProv]
As
  SELECT procedimiento Procedimiento, descripcion Descripcion
FROM no_nomina_proc
WHERE tipo_proc = 'P'
go

