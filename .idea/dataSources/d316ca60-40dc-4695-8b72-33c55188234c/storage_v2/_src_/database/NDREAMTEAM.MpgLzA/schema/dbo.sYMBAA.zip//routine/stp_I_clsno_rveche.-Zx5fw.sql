-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_rveche](@AUTO_EditStamp varchar(30) OUT,
  @impuesto_vecinal smallint ,
  @ano smallint ,
  @codigo_empleado char (10) ,
  @monto_afecto money ,
  @monto_impuesto money ,
  @observaciones varchar (100) ,
  @no_cuotas smallint ,
  @fecha_inicio_cobro datetime  )
As 
	INSERT INTO [dbo].[no_reporte_vechn_empleado]
(  impuesto_vecinal ,
  ano ,
  codigo_empleado ,
  monto_afecto ,
  monto_impuesto ,
  observaciones ,
  no_cuotas ,
  fecha_inicio_cobro  )
VALUES (  @impuesto_vecinal ,
  @ano ,
  @codigo_empleado ,
  @monto_afecto ,
  @monto_impuesto ,
  @observaciones ,
  @no_cuotas ,
  @fecha_inicio_cobro  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_reporte_vechn_empleado]
  WHERE ( impuesto_vecinal =  @impuesto_vecinal AND 
ano =  @ano )
go

