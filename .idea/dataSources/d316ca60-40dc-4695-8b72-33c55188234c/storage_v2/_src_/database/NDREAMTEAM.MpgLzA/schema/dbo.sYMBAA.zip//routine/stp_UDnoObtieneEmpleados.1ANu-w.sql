CREATE procedure [dbo].[stp_UDnoObtieneEmpleados]
    @codigo_tipo char(2),
    @codigo_Departamento smallint
as

SELECT a.codigo_Empleado codigo, a.codigo_Empleado + nombre_usual nombre
FROM no_empleados a, no_nomina_empleado b
WHERE b.codigo_tipo = @codigo_tipo
  and a.codigo_empleado = b.codigo_empleado
  and a.codigo_departamento = @codigo_departamento
ORDER BY a.codigo_empleado
go

