-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_rcvalores](  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldno_reporte smallint ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @no_reporte smallint ,
  @grupo_id char (5) ,
  @no_calculo smallint ,
  @fecha_reporte datetime ,
  @genera_aut char (1) ,
  @estado_reporte char (1) ,
  @fecha_ingreso datetime ,
  @usuario_ingreso varchar (35) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_reporte_valores] 
WHERE codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
no_reporte =  @oldno_reporte 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_reporte_valores] Set 
    codigo_tipo = @codigo_tipo,
    periodo_id = @periodo_id,
    no_reporte = @no_reporte,
    grupo_id = @grupo_id,
    no_calculo = @no_calculo,
    fecha_reporte = @fecha_reporte,
    genera_aut = @genera_aut,
    estado_reporte = @estado_reporte,
    fecha_ingreso = @fecha_ingreso,
    usuario_ingreso = @usuario_ingreso 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
no_reporte =  @oldno_reporte )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_reporte_valores]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
no_reporte =  @no_reporte )
go

