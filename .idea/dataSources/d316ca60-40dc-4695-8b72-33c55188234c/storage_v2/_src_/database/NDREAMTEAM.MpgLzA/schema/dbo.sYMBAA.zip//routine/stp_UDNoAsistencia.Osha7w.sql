Create procedure [dbo].[stp_UDNoAsistencia] 
   @tipo_inicial char(2),
   @tipo_final char(2),
   @fecha_inicial datetime,
   @fecha_final datetime
as
----------------------------------------
--- Hecho por LDR
--- Fecha 31/05/2009
--- Asunto : Generacion de Partida 
----------------------------------------

select @fecha_final = @fecha_final + ' 23:59:59'
select a.codigo_empleado + b.nombre_usual empleado , convert(char(4),b.codigo_departamento) +'-' + c.descripcion departamento, 
       isnull(convert(char(4),b.codigo_seccion) + d.nombre_seccion,'Sin Sección') seccion, f.descripcion grupo_pago, 
       a.no_calculo, a.fecha,
       replicate('0', 2-len(rtrim(ltrim(convert(char(2),datepart(dd,a.fecha)))))) +  rtrim(ltrim(convert(char(2),datepart(dd,a.fecha)))) +'-'+
       case datepart(dw,a.fecha) when 1 then 'Dom' when 2 then 'Lun' when 3 then 'Mar'
                                 when 4 then 'Mie' when 5 then 'Jue' when 6 then 'Vie'
                                 when 7 then 'Sab' end + case when  fecha in ( select fecha from no_nomina_asuetos aa where aa.codigo_tipo = a.codigo_tipo  and a.fecha = aa.fecha_asueto ) then '-A' else '' end DiaSemana,
       case when  fecha in ( select fecha from no_nomina_asuetos aa where aa.codigo_tipo = a.codigo_tipo  and a.fecha = aa.fecha_asueto ) then 'S' else 'A' end Asueto,
       a.codigo_tipo + '-' + h.descripcion TipoNomina, 1 Asistencia
from no_nomina_asistencia a , no_empleados b, gn_departamentos c,
     no_secciones d, no_puestos e, no_grupos_valores f, no_periodos_pago g,
     no_tipos_nomina h
where a.codigo_empleado = b.codigo_empleado
  and b.codigo_departamento *= c.codigo_departamento
  and b.codigo_seccion *= d.codigo_seccion
  and b.codigo_puesto *= e.codigo_puesto
  and a.grupo_id = f.grupo_id
  and a.periodo_id = g.periodo_id
  and a.codigo_tipo between @tipo_inicial and @tipo_final
  and a.fecha between @fecha_inicial and @fecha_final
  and a.codigo_tipo = h.codigo_tipo
go

