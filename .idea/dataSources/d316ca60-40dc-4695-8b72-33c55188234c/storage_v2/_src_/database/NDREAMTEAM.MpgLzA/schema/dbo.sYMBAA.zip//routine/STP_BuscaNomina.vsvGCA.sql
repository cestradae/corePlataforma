Create PROCEDURE [dbo].[STP_BuscaNomina] 
      @tipo_nomina char(2)

As

-- Declaramos un cursor llamado "CURSORITO". 
Declare @codigo Char(10) 
Declare CURSORITO Cursor For

Select a.codigo_empleado 
From no_empleados A,no_nomina_empleado B  
Where A.codigo_empleado = b.codigo_empleado
and b.codigo_tipo=  @tipo_nomina

Open CURSORITO 
-- Avanzamos un registro y cargamos en las variables los valores encontrados en el primer registro 
Fetch next from CURSORITO 
into @codigo

    while @@fetch_status = 0 
        begin 

        -- Avanzamos otro registro 
             fetch next from CURSORITO 
        into @codigo

            Print @codigo

   End 

-- Cerramos el cursor 
Close CURSORITO 
Deallocate CURSORITO
go

