-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_parentescos]
  (  @oldcodigo_empleado char (10) ,
  @oldcorrelativo smallint  )
As DELETE [dbo].[no_parentescos] 
WHERE (codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo)
go

