CREATE TRIGGER [trinsno_nomina_reportedet] ON [dbo].[no_nomina_reportedet] 
FOR INSERT
AS
-----------------------
-- hecho por lsao
-- fecha 04/11/2010
-- Cambio para que traiga datos mensuales base
------------------------

-----------------------
-- hecho por lsao
-- fecha 04/10/2010
-- Cambio para que traiga datos mensuales
------------------------



-- Actualizamos ingresos

update no_nomina_reportedet 
      set codigo_ingreso = substring(inserted.codigo_elemento,2,3 )
      ,codigo_deduccion = null
      ,codigo_valor = null
      ,codigo_anticipo = null
      ,variable_sistema = null
      ,constante = null
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 2
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento

-- Actualizamos deducciones

update no_nomina_reportedet 
      set codigo_deduccion = substring(inserted.codigo_elemento,2,3 )
      ,codigo_ingreso = null
      ,codigo_valor = null
      ,codigo_anticipo = null
      ,variable_sistema = null
      ,constante = null
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 3
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento
 
-- Actulizamos valores reportados

update no_nomina_reportedet 
      set codigo_valor = substring(inserted.codigo_elemento,2,10 )
      ,codigo_ingreso = null
      ,codigo_deduccion = null      
      ,codigo_anticipo = null
      ,variable_sistema = null
      ,constante = null
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 1
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento

-- Actualizamos anticipos

update no_nomina_reportedet 
      set codigo_anticipo = substring(inserted.codigo_elemento,2,3 )
      ,codigo_ingreso = null
      ,codigo_deduccion = null
      ,codigo_valor = null      
      ,variable_sistema = null
      ,constante = null
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 4
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento

-- Actualizamos Variables Sistema

update no_nomina_reportedet 
      set variable_sistema = substring(inserted.codigo_elemento,2,10 )
      ,codigo_ingreso = null
      ,codigo_deduccion = null
      ,codigo_valor = null
      ,codigo_anticipo = null      
      ,constante = null
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 5
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento


-- Actualizamos Constantes


update no_nomina_reportedet 
      set constante = 'S'
      ,codigo_ingreso = null
      ,codigo_deduccion = null
      ,codigo_valor = null
      ,codigo_anticipo = null
      ,variable_sistema = null      
from inserted
where substring(inserted.codigo_elemento,1,1 ) = 6
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento

-- Actualizamos Ingresos Mensuales

update no_nomina_reportedet 
      set codigo_ingreso = null
      ,codigo_deduccion = null
      ,codigo_valor = null
      ,codigo_anticipo = null
      ,variable_sistema = null
      ,constante = null
      ,ingreso_mensual = substring(inserted.codigo_elemento,2,3 )
from inserted
where substring(inserted.codigo_elemento,1,1 ) in ('9','0')
and no_nomina_reportedet.codigo_repnomina = inserted.codigo_repnomina
and no_nomina_reportedet.codigo_elemento = inserted.codigo_elemento



go

