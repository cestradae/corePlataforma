create procedure stp_UDnoFormula31   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @SSDiasAntiguedad decimal(18,4) 
declare @tmp2 decimal(18,4)
declare @tmp3 decimal(18,4)
declare @DAGUI decimal(22,6) 
declare @BaseOrd decimal(18,4) 
declare @BaseBoni_Ince decimal(18,4) 
declare @SSDiasAno decimal(18,4) 
declare @tmp1 decimal(18,4) 

begin
  select @SSDiasAntiguedad = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSDiasAnt' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
exec stp_UDnoPromUMesesIngresos 'Ord',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 ,  @tmp2 out
exec stp_UDnoPromUMesesIngresos 'Boni_Ince',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 ,  @tmp3 out
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '11        ' ) = '1'  begin Select @DAGUI= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '11        ' end else begin Select @DAGUI= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '11        ' end 
Select @BaseOrd= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ord'
Select @BaseBoni_Ince= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Boni_Ince'
select  @SSdiasAno = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSdiasAno' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
if ((isnull(@SSDiasAntiguedad,0)>30)) select @tmp1=(@tmp2+@tmp3)*6/6/365*isnull(@DAGUI,0) else select @tmp1=(isnull(@BaseOrd,0)+isnull(@BaseBoni_Ince,0))/isnull(@SSDiasAno,0)*isnull(@DAGUI,0)

  set @result=@tmp1
end
go

