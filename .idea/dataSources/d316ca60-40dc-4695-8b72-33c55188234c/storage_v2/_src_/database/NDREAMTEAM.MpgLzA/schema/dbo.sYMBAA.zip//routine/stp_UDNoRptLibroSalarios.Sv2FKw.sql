-- [stp_UDNoRptLibroSalarios]'02', '02', 2016
CREATE PROCEDURE [dbo].[stp_UDNoRptLibroSalarios]
	@codigo_inicial char(2),
	@codigo_final char(2),		
	@ano	smallint
AS
Set NoCount On
-------------------
-- Modificado por ghuerta
-- fecha 16/02/2015
-- Se modifico la fecha de baja para que no aapresca si el empleado esta de alta
-- y no aparesca si el empleado fue despedido desde del año que se esta imprimiendo
-------------------
-------------------------------------------------
--Hecho por: Daniel Ortiz
--Fecha: 25/05/2011
--Modificado: Se cambio el tipo de datos de 
--   codigo_centro en tablas temporales
-------------------------------------------------
-------------------------------------------------
--Hecho por: Daniel Ortiz
--Fecha: 25/05/2011
--Modificado: Se cambio para que vaya a buscar el reporte 
-- con la descripcion 'Libro de salarios'
-------------------------------------------------
-------------------------------------------------
--Hecho por: Daniel Ortiz
--Fecha: 28/02/2011
--Modificado: Uso del historico real del sueldo base
-- y agregado de los valores calculados
-------------------------------------------------
-------------------------------------------------
--Hecho por: Mario Juarros
--Fecha: 17/01/2009
--Script para reporte de libro de salarios
-------------------------------------------------

/*declare @periodo1 char(10),
		@periodo2 char(10),
		@grupo1 char(5),
		@grupo2 char(5),
		@calculo_ini smallint,
		@calculo_fin smallint,*/
		declare @reporte smallint

select @reporte=codigo_repnomina 
from no_nomina_reporte
where UPPER(ltrim(rtrim(descripcion)))='LIBRO DE SALARIOS'


if @reporte is null 
	Begin
	   Raiserror ('No existe configuracion de libro de salarios - stp_UDNoRptLibroSalarios', 16,1,5000)
	   Return 9
	End


Declare @columnas smallint
Declare @Contador smallint
Declare @tasa_cambio decimal(18,4)
Declare @no_nomina char(10)


-- Inicializacion de variables
Declare @ingresos money
Declare @deduccion money
Declare @valor money
Declare @codigo_empleado char(10)
Declare @moneda_nomina money
-- Variables para hacer el update de las columnas variables
Declare @columna varchar(10)
Declare @Instruccion_Sql varchar(500)
Declare @clasificacion char(1)



/*select @tasa_cambio = tasa_cambio
from no_nomina_enc
where codigo_tipo = @codigo_tipo

select @moneda_nomina = codigo_moneda
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

select @no_nomina = no_nomina
from no_periodos_pago
where periodo_id =  @periodo1 

select @no_nomina = '-' + @no_nomina +no_nomina
from no_periodos_pago
where periodo_id =  @periodo2 */



--if @tasa_cambio is null select @tasa_cambio = 1

-- Crea la tabla Temporal para almacenar los valores de la nomina
Create table #Nomina
(
   codigo_tipo char(2)COLLATE Modern_Spanish_CI_AS,
   numero_columnas smallint,
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint null,
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null,
   col1 money default 0/2,
   col2 money default 0,
   col3 money default 0,
   col4 money default 0,
   col5 money default 0,
   col6 money default 0,
   col7 money default 0,
   col8 money default 0,
   col9 money default 0,
   col10 money default 0,
   col11 money default 0,
   col12 money default 0,
   col13 money default 0,
   col14 money default 0,
   col15 money default 0,
   col16 money default 0,
   col17 money default 0,
   col18 money default 0,
   col19 money default 0,
   col20 money default 0,
   col21 money default 0,
   col22 money default 0,
   col23 money default 0,
   col24 money default 0,
   col25 money default 0,
   col26 money default 0,
   col27 money default 0,
   col28 money default 0,
   col29 money default 0,
   col30 money default 0,
   coldesc1 varchar(25) null,
   coldesc2 varchar(25) null,
   coldesc3 varchar(25) null,
   coldesc4 varchar(25) null,
   coldesc5 varchar(25) null,
   coldesc6 varchar(25) null,
   coldesc7 varchar(25) null,
   coldesc8 varchar(25) null,
   coldesc9 varchar(25) null,
   coldesc10 varchar(25) null,
   coldesc11 varchar(25) null,
   coldesc12 varchar(25) null,
   coldesc13 varchar(25) null,
   coldesc14 varchar(25) null,
   coldesc15 varchar(25) null,
   coldesc16 varchar(25) null,
   coldesc17 varchar(25) null,
   coldesc18 varchar(25) null,
   coldesc19 varchar(25) null,
   coldesc20 varchar(25) null,
   coldesc21 varchar(25) null,
   coldesc22 varchar(25) null,
   coldesc23 varchar(25) null,
   coldesc24 varchar(25) null,
   coldesc25 varchar(25) null,
   coldesc26 varchar(25) null,
   coldesc27 varchar(25) null,
   coldesc28 varchar(25) null,
   coldesc29 varchar(25) null,
   coldesc30 varchar(25) null,
   liquido money default 0,
   periodo_id char(10)	
)

Create table #Ingresos (
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint   null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   monto_ingreso money default 0,
   numero_columna smallint,
   periodo_id varchar(10)
)   

Create table #Deducciones (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   monto_deduccion money default 0,
numero_columna smallint,
periodo_id varchar(10)
)   

Create table #Valores (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint,
   periodo_id varchar(10) 
)   


Create table #ValoresCalculados (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   codigo_departamento smallint  null, 
   codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS null, 
   valor money default 0,
   numero_columna smallint, 
   periodo_id varchar(10) 
)   

-- Trae el numero de columnas que va  a trabajar el Reporte

Select @columnas = numero_columnas, 
       @clasificacion = clasificado
from no_nomina_reporte
where codigo_repnomina = @reporte 


-- Ciclo para llenar las columnas

-- Llena los datos de los empleados segun la nomina
Insert Into #Nomina (
     codigo_tipo,
     numero_columnas,
     codigo_empleado,
     codigo_departamento,
     codigo_centro,
     liquido,
	 periodo_id)

select ne.codigo_tipo, 
       @columnas, 
       nd.codigo_empleado, 
       nd.codigo_departamento,
       isnull(nd.codigo_centro,0),
       sum(nd.monto_ingreso) - sum(nd.monto_deduccion),
		nd.periodo_id
  from no_nomina_emplcalc ne , no_nomina_det nd
  where ne.codigo_tipo between @codigo_inicial and @codigo_final
   -- and ne.periodo_id between  @periodo1 and @periodo2
    --and ne.grupo_id not in ('011')
    --and ne.no_calculo between  @calculo_ini and @calculo_fin    
	and @ano=substring(nd.periodo_id,3,4)
    and ne.codigo_tipo Collate Modern_Spanish_CI_AS = nd.codigo_tipo Collate Modern_Spanish_CI_AS		
    and ne.periodo_id Collate Modern_Spanish_CI_AS= nd.periodo_id Collate Modern_Spanish_CI_AS		
    and ne.grupo_id Collate Modern_Spanish_CI_AS = nd.grupo_id Collate Modern_Spanish_CI_AS		
    and ne.no_calculo = nd.no_calculo	
    and ne.codigo_empleado Collate Modern_Spanish_CI_AS = nd.codigo_empleado Collate Modern_Spanish_CI_AS

	
group by nd.codigo_empleado, nd.codigo_departamento,isnull(nd.codigo_centro,0),ne.codigo_tipo, nd.periodo_id

-- Creamos ingresos
insert into #Ingresos
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,'0'), 
       case when c.codigo_moneda = f.codigo_moneda then sum(a.monto_ingreso) 
            when d.es_local = 'S' then sum(round(a.monto_ingreso * isnull(e.tasa_cambio,1),2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_ingreso / isnull(e.tasa_cambio,1),2)) end   monto_ingreso,
       b.numero_columna, a.periodo_id
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d, no_nomina_enc e, no_tipos_nomina f
where a.codigo_tipo between @codigo_inicial and @codigo_final
  --and a.periodo_id between @periodo1 and @periodo2
   --and a.grupo_id not in ('011')
  --and a.no_calculo between @calculo_ini and @calculo_fin
	and @ano=substring(a.periodo_id,3,4)
	and b.codigo_repnomina = @reporte
	and b.codigo_ingreso Collate Modern_Spanish_CI_AS = a.codigo_ingreso Collate Modern_Spanish_CI_AS
	and b.monto_base = 'N'
	and b.codigo_repnomina = c.codigo_repnomina 
	and b.numero_columna  = c.no_columna 
	and d.codigo_moneda = d.codigo_moneda 
		and a.codigo_tipo Collate Modern_Spanish_CI_AS = e.codigo_tipo Collate Modern_Spanish_CI_AS
		and a.periodo_id Collate Modern_Spanish_CI_AS = e.periodo_id Collate Modern_Spanish_CI_AS
		and a.grupo_id Collate Modern_Spanish_CI_AS = e.grupo_id Collate Modern_Spanish_CI_AS
		and a.no_calculo = e.no_calculo
		and a.codigo_tipo Collate Modern_Spanish_CI_AS = f.codigo_tipo Collate Modern_Spanish_CI_AS	
group by a.codigo_empleado, c.codigo_moneda, d.es_local, d.es_dolar, 
a.codigo_departamento, a.codigo_centro, b.numero_columna, 
f.codigo_moneda, a.periodo_id

insert into #Ingresos
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,0), 
       case when c.codigo_moneda = f.codigo_moneda then sum(a.monto_base) 
            when d.es_local = 'S' then sum(round(a.monto_base * isnull(e.tasa_cambio,1),2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_base / isnull(e.tasa_cambio,1),2)) end   monto_ingreso,
       b.numero_columna,a.periodo_id
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d, no_nomina_enc e, no_tipos_nomina f
where a.codigo_tipo between @codigo_inicial and @codigo_final
  --and a.periodo_id between @periodo1 and @periodo2
   --and a.grupo_id not in ('011')
  --and a.no_calculo between @calculo_ini and @calculo_fin
	and @ano = substring(a.periodo_id,3,4)
  and b.codigo_repnomina = @reporte
  and b.codigo_ingreso Collate Modern_Spanish_CI_AS = a.codigo_ingreso Collate Modern_Spanish_CI_AS
  and b.monto_base = 'S'
  and b.codigo_repnomina  = c.codigo_repnomina 
  and b.numero_columna = c.no_columna 
  and d.codigo_moneda = d.codigo_moneda 
	and a.codigo_tipo Collate Modern_Spanish_CI_AS= e.codigo_tipo Collate Modern_Spanish_CI_AS
	and a.periodo_id Collate Modern_Spanish_CI_AS= e.periodo_id Collate Modern_Spanish_CI_AS
	--and a.grupo_id Collate Modern_Spanish_CI_AS = e.grupo_id Collate Modern_Spanish_CI_AS
	--and a.no_calculo  = e.no_calculo 
	and a.codigo_tipo Collate Modern_Spanish_CI_AS = f.codigo_tipo Collate Modern_Spanish_CI_AS
group by a.codigo_empleado, a.codigo_departamento, d.es_local, d.es_dolar, c.codigo_moneda, f.codigo_moneda,
isnull(a.codigo_centro,0), b.numero_columna,a.periodo_id,a.grupo_id

-- Creamos  deducciones

Insert into #Deducciones
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,0), 
       case when c.codigo_moneda = f.codigo_moneda then sum(a.monto_deduccion) 
            when d.es_local = 'S' then sum(round(a.monto_deduccion * isnull(e.tasa_cambio,1),2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_deduccion / isnull(e.tasa_cambio,1),2)) end   monto_deduccion,
       b.numero_columna, a.periodo_id
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d, no_nomina_enc e, no_tipos_nomina f
where a.codigo_tipo between @codigo_inicial and @codigo_final
  --and periodo_id between @periodo1 and @periodo2
   --and a.grupo_id not in ('011')
  --and no_calculo between @calculo_ini and @calculo_fin
	and @ano = substring(a.periodo_id,3,4)
  and b.codigo_repnomina = @reporte
  and b.codigo_deduccion  = a.codigo_deduccion 
  and b.monto_base = 'N'
  and b.codigo_repnomina = c.codigo_repnomina 
  and b.numero_columna  = c.no_columna 
  and d.codigo_moneda = d.codigo_moneda
	and a.codigo_tipo Collate Modern_Spanish_CI_AS= e.codigo_tipo Collate Modern_Spanish_CI_AS
	and a.periodo_id Collate Modern_Spanish_CI_AS= e.periodo_id Collate Modern_Spanish_CI_AS
	and a.grupo_id Collate Modern_Spanish_CI_AS= e.grupo_id Collate Modern_Spanish_CI_AS
	and a.no_calculo  = e.no_calculo 
	and a.codigo_tipo Collate Modern_Spanish_CI_AS= f.codigo_tipo Collate Modern_Spanish_CI_AS
group by a.codigo_empleado, a.codigo_departamento, es_local, es_dolar, c.codigo_moneda, f.codigo_moneda,
isnull(a.codigo_centro,0), b.numero_columna, a.periodo_id,a.grupo_id


Insert into #Deducciones
Select a.codigo_empleado, 
       a.codigo_departamento, 
       isnull(a.codigo_centro,0), 
       case when c.codigo_moneda = f.codigo_moneda then sum(a.monto_base) 
            when d.es_local = 'S' then sum(round(a.monto_base * isnull(e.tasa_cambio,1),2)) 
            when d.es_dolar = 'S' then sum(round(a.monto_base / isnull(e.tasa_cambio,1),2)) end,
       b.numero_columna, a.periodo_id
from no_nomina_det a, no_nomina_reportedet b, no_nomina_repcol c, gn_monedas d, no_nomina_enc e, no_tipos_nomina f
where a.codigo_tipo between @codigo_inicial and @codigo_final
  --and periodo_id between @periodo1 and @periodo2
  --and a.grupo_id  not in ('011')
  --and no_calculo between @calculo_ini and @calculo_fin
	and @ano = substring(a.periodo_id,3,4)
  and b.codigo_repnomina = @reporte
  and b.codigo_deduccion = a.codigo_deduccion 
  and b.monto_base = 'S'
  and b.codigo_repnomina = c.codigo_repnomina 
  and b.numero_columna = c.no_columna
  and d.codigo_moneda  = d.codigo_moneda
	and a.codigo_tipo Collate Modern_Spanish_CI_AS= e.codigo_tipo Collate Modern_Spanish_CI_AS
	and a.periodo_id Collate Modern_Spanish_CI_AS = e.periodo_id Collate Modern_Spanish_CI_AS
	and a.grupo_id Collate Modern_Spanish_CI_AS = e.grupo_id Collate Modern_Spanish_CI_AS
	and a.no_calculo = e.no_calculo 
	and a.codigo_tipo Collate Modern_Spanish_CI_AS = f.codigo_tipo Collate Modern_Spanish_CI_AS

group by a.codigo_empleado, a.codigo_departamento, es_local, es_dolar, c.codigo_moneda, f.codigo_moneda,
  isnull(a.codigo_centro,0), b.numero_columna, a.periodo_id,a.grupo_id


-- Creamos Valores Reportados 

Insert into #Valores
Select a.codigo_empleado, 
       c.codigo_departamento, 
       isnull(c.codigo_centro,0), 
       sum(a.valor) valor,
       b.numero_columna, a.periodo_id
from no_reporte_detalle a, no_nomina_reportedet b, no_reporte_empleado c
where a.codigo_tipo between @codigo_inicial and @codigo_final
  --and a.periodo_id between @periodo1 and @periodo2
   --and a.grupo_id not in ('011')
  --and a.no_calculo between @calculo_ini and @calculo_fin
	and @ano = substring(a.periodo_id,3,4)
  and a.codigo_tipo Collate Modern_Spanish_CI_AS = c.codigo_tipo Collate Modern_Spanish_CI_AS
  and a.periodo_id Collate Modern_Spanish_CI_AS = c.periodo_id Collate Modern_Spanish_CI_AS
  and a.no_reporte = c.no_reporte 
  and a.codigo_empleado Collate Modern_Spanish_CI_AS = c.codigo_empleado Collate Modern_Spanish_CI_AS
  and b.codigo_repnomina = @reporte
  and b.codigo_valor Collate Modern_Spanish_CI_AS = a.codigo_val Collate Modern_Spanish_CI_AS
 GRoup by a.codigo_empleado, c.codigo_departamento, isnull(c.codigo_centro,0), b.numero_columna, a.periodo_id, a.grupo_id

Insert into #ValoresCalculados
Select a.codigo_empleado, 
       e.codigo_departamento, 
       isnull(e.codigo_centro,''), 
       sum(a.valor * b.factor) valor,
       b.numero_columna,
       a.periodo_id
from no_nomina_valores_calculados a, no_nomina_reportedet b,no_empleados e
where a.codigo_tipo BETWEEN @codigo_inicial AND @codigo_final
  and @ano = substring(a.periodo_id,3,4)
   --and a.grupo_id not in ('011')
  and b.codigo_repnomina = @reporte
  and convert(char(10),b.codigo_valor) = convert(char(10),a.codigo_valor)
 and a.codigo_empleado = e.codigo_empleado
GRoup by a.codigo_empleado, e.codigo_departamento, isnull(e.codigo_centro,''), b.numero_columna,a.periodo_id
,a.grupo_id
-- Procedemos a Actualizar Columna por Columna cada Valor

Select @contador = 1

while @contador <= @columnas
begin
  Select @columna = 'col'+ ltrim(rtrim(convert(varchar(2),@contador)))

   -- Actualizamos los ingresos 
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= monto_ingreso '+
         'from #Ingresos a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
         'and #nomina.codigo_centro = a.codigo_centro ' +
         'and #nomina.periodo_id = a.periodo_id '+
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

   -- Actualizamos los deducciones
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna+ ' - monto_deduccion '+
         'from #Deducciones a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and #nomina.codigo_departamento = a.codigo_departamento ' +
'and #nomina.codigo_centro = a.codigo_centro ' +
         'and #nomina.periodo_id = a.periodo_id '+
         'and a.numero_columna  = '+ convert(char(2), @contador)
                  
 
    exec (@instruccion_Sql)

  -- Actualizamos los Valores Reportados
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + valor '+
         'from #Valores a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
        -- 'and #nomina.codigo_departamento = a.codigo_departamento ' +
        -- 'and #nomina.codigo_centro = a.codigo_centro ' +
         'and #nomina.periodo_id = a.periodo_id '+
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)
    
       Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + valor '+
         'from #ValoresCalculados a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
        -- 'and #nomina.codigo_departamento = a.codigo_departamento ' +
        -- 'and #nomina.codigo_centro = a.codigo_centro ' +
         'and #nomina.periodo_id = a.periodo_id '+
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)

  -- Actualizamos la descripcion de la columna

   Select @columna = 'coldesc'+ ltrim(rtrim(convert(varchar(2),@contador)))
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= linea1 + isnull(b.simbolo,'''') ' +
         'from no_nomina_repcol a , gn_monedas b '+
         'where a.codigo_repnomina  =  ' + convert(char(3), @reporte ) + ' '+
         'and a.no_columna  = '+ convert(char(2), @contador) +' '+
         'and a.codigo_moneda *= b.codigo_moneda'

  
    exec (@instruccion_Sql)
    
       -- Actualizamos los Valores Calculados

   -- Incrementa el contador
  Set @contador =  @contador + 1
     
end

select codigo_empleado, codigo_tipo,  monto, fecha_inicio
into #Salarios 
from no_empleado_ingresos ,  no_generales
where codigo_ingreso Collate Modern_Spanish_CI_AS = ing_ordinario Collate Modern_Spanish_CI_AS
and codigo_tipo between @codigo_inicial and @codigo_final
	Union all
select codigo_empleado, codigo_tipo, monto, fecha_inicio
from no_empleado_ingresos_det, no_generales
where codigo_ingreso Collate Modern_Spanish_CI_AS = ing_ordinario Collate Modern_Spanish_CI_AS
and codigo_tipo between @codigo_inicial and @codigo_final
and monto>0

select b.codigo_empleado, sum(b.monto) salario, a.periodo_id,fecha_inicio
into #Temporal1
from no_periodos_pago a, #Salarios b
where b.fecha_inicio <=a.fecha_inicial
and datepart(yy,a.fecha_inicial)=@ano
and a.codigo_tipo = b.codigo_tipo
group by codigo_empleado, periodo_id,fecha_inicio
order by fecha_inicio desc


select codigo_empleado, MAX(salario) salario, periodo_id,max(fecha_inicio) fecha_inicio
into #Temporal
from #Temporal1
group by codigo_empleado, periodo_id

if @clasificacion Collate Modern_Spanish_CI_AS = '1'    

   Select 
   a.codigo_tipo, 
   a.numero_columnas, 
   a.codigo_empleado,
   ' 'espacios,
   sum (col1)col1,    
   sum(col2)col2 ,
   sum(col3)col3,
   sum(col4)col4 ,
   sum(col5)col5 ,
   sum(col6)col6 ,
   sum(col7)col7 ,
   sum(col8)col8 ,
   sum(col9)col9 ,
   sum(col10)col10 ,
   sum(col11)col11 ,
   sum(col12)col12 ,
   sum(col13)col13 ,
   sum(col14)col14 ,
   sum(col15)col15 ,
   sum(col16)col16 ,
   sum(col17)col17 ,
   sum(col18)col18 ,
   sum(col19)col19 ,
   sum(col20)col20 ,
   sum(col21)col21 ,
   sum(col22)col22 ,
   sum(col23)col23 ,
   sum(col24)col24 ,
   sum(col25)col25 ,
   sum(col26)col26 ,
   sum(col27)col27 ,
   sum(col28)col28 ,
   sum(col29)col29 ,
   sum(col30)col30 ,  
   sum(liquido) liquido,
   replicate(' ', 10 - len(convert(varchar(10),c.codigo_departamento))) + convert(varchar(10),c.codigo_departamento) + ' - '  +c.descripcion agrupacion,
	b.nombre_usual, 
	b.fecha_nacimiento, 
	b.sexo,
	b.nacionalidad, 
	b.numero_seguro_social, 
	CASE WHEN (len(b.identificacion)) > 0 then b.identificacion
	    WHEN (len(b.identificacion)) = 0 then b.no_orden_cedula + ' ' + b.numero_cedula
	END cedula,
	 b.fecha_inicio_rel_lab,
	case when b.estado_empleado = 'A' then '' else
		case when b.fecha_baja > '19991230' then 
			case when YEAR(b.fecha_baja) > @ano then '' else 
				convert(varchar,b.fecha_baja,103)end end 
    end as fecha_baja, 
	d.nombre_profesion, 
	e.no_nomina num_nomina, 
	(@ano - YEAR(b.fecha_nacimiento)) anos, 
	f.salario, 
	f.periodo_id, 
	e.fecha_inicial, 
	e.fecha_final
into #resultados
   from #Nomina a
   join no_empleados b 
		on a.codigo_empleado Collate Modern_Spanish_CI_AS = b.codigo_empleado Collate Modern_Spanish_CI_AS
   Left join gn_departamentos c 
		on a.codigo_departamento = c.codigo_departamento
   Left join gn_profesiones d
		on b.codigo_profesion = d.codigo_profesion
   join no_periodos_pago e
		on a.periodo_id Collate Modern_Spanish_CI_AS = e.periodo_id	Collate Modern_Spanish_CI_AS
   Left join #temporal f
		on a.codigo_empleado Collate Modern_Spanish_CI_AS= f.codigo_empleado Collate Modern_Spanish_CI_AS
		and a.periodo_id Collate Modern_Spanish_CI_AS= f.periodo_id Collate Modern_Spanish_CI_AS 		
group by a.codigo_tipo, a.numero_columnas, a.codigo_empleado, a.liquido, c.codigo_departamento, c.descripcion, b.nombre_usual, b.fecha_nacimiento, b.sexo,
b.nacionalidad, b.numero_seguro_social, b.no_orden_cedula, b.numero_cedula, b.fecha_inicio_rel_lab, b.fecha_baja, d.nombre_profesion, e.no_nomina, f.salario,
e.ano, e.periodo, e.numero_pago, f.periodo_id, e.fecha_inicial, e.fecha_final, f.fecha_inicio, b.identificacion, b.fecha_baja
,b.estado_empleado
else

   Select 
   a.codigo_tipo, 
   a.numero_columnas, 
   a.codigo_empleado, ' 'espacios,
   sum (col1)col1,    
   sum(col2)col2 ,
   sum(col3)col3,
   sum(col4)col4 ,
   sum(col5)col5 ,
   sum(col6)col6 ,
   sum(col7)col7 ,
   sum(col8)col8 ,
   sum(col9)col9 ,
   sum(col10)col10 ,
   sum(col11)col11 ,
   sum(col12)col12 ,
   sum(col13)col13 ,
   sum(col14)col14 ,
   sum(col15)col15 ,
   sum(col16)col16 ,
   sum(col17)col17 ,
   sum(col18)col18 ,
   sum(col19)col19 ,
   sum(col20)col20 ,
   sum(col21)col21 ,
   sum(col22)col22 ,
   sum(col23)col23 ,
   sum(col24)col24 ,
   sum(col25)col25 ,
   sum(col26)col26 ,
   sum(col27)col27 ,
   sum(col28)col28 ,
   sum(col29)col29 ,
   sum(col30)col30 ,   
   sum(liquido) , 
   c.codigo_centro + ' - ' + c.nombre_centro agrupacion, 
   b.nombre_usual, 
   b.fecha_nacimiento, 
   b.sexo,b.nacionalidad, 
   b.numero_seguro_social, 
   CASE WHEN (len(b.identificacion)) > 0 then b.identificacion
	    WHEN (len(b.identificacion)) = 0 then b.no_orden_cedula + ' ' + b.numero_cedula
	END cedula,
    b.fecha_inicio_rel_lab, 
     CASE WHEN (b.fecha_baja < b.fecha_inicio_rel_lab) then null 
	    WHEN (b.fecha_baja > b.fecha_inicio_rel_lab) then b.fecha_baja
	END fecha_baja, 
    d.nombre_profesion,
     isnull(e.no_nomina,convert(varchar,e.ano) + convert(varchar,e.periodo) + convert(varchar,e.numero_pago)) num_nomina, 
	(@ano - YEAR(b.fecha_nacimiento)) anos, 
	f.salario,
	f.periodo_id
into resultados
   from #Nomina a
   join no_empleados b 
		on a.codigo_empleado Collate Modern_Spanish_CI_AS = b.codigo_empleado Collate Modern_Spanish_CI_AS
   Left join cn_catalogo_centros c  
		on a.codigo_centro = c.codigo_centro
   join gn_profesiones d 
		on b.codigo_profesion = d.codigo_profesion
   join no_periodos_pago e 
		on a.periodo_id Collate Modern_Spanish_CI_AS = e.periodo_id Collate Modern_Spanish_CI_AS
   join #temporal f 
		on  a.periodo_id = f.periodo_id
		and a.codigo_empleado Collate Modern_Spanish_CI_AS = f.codigo_empleado Collate Modern_Spanish_CI_AS	
			 	
group by a.codigo_tipo, a.numero_columnas, a.codigo_empleado, c.codigo_centro, c.nombre_centro, b.nombre_usual, b.fecha_nacimiento, b.sexo,
b.nacionalidad, b.numero_seguro_social, b.no_orden_cedula, b.numero_cedula, b.fecha_inicio_rel_lab, b.fecha_baja, d.nombre_profesion, e.no_nomina, f.salario,
e.ano, e.periodo, e.numero_pago,f.periodo_id, b.identificacion

--select * from #resultados

select max(a.codigo_tipo)codigo_tipo, 
   max(a.numero_columnas)numero_columnas, 
   a.codigo_empleado, 
   max(a.espacios)espacios,
   sum(isnull(a.col1,0.00))col1,    
   sum(isnull(col2 ,0.00))col2,
   sum(isnull(a.col3,0.00))col3,
   sum(isnull(a.col4 ,0.00))col4,
   sum(isnull(a.col5 ,0.00))col5,
   sum(isnull(a.col6 ,0.00))col6,
   sum(isnull(a.col7 ,0.00))col7,
   sum(isnull(a.col8 ,0.00))col8,
   sum(isnull(a.col9 ,0.00))col9,
   sum(isnull(a.col10 ,0.00))col10,
   sum(isnull(a.col11 ,0.00))col11,
   sum(isnull(a.col12 ,0.00))col12,
   sum(isnull(a.col13 ,0.00))col13,
   sum(isnull(a.col14 ,0.00))col14,
   sum(isnull(a.col15 ,0.00))col15,
   sum(isnull(a.col16 ,0.00))col16,
   sum(isnull(a.col17 ,0.00))col17,
   sum(isnull(a.col18 ,0.00))col18,
   sum(isnull(a.col19 ,0.00))col19,
   sum(isnull(a.col20 ,0.00))col20,
   sum(isnull(a.col21 ,0.00))col21,
   sum(isnull(a.col22 ,0.00))col22,
   sum(isnull(a.col23 ,0.00))col23,
   sum(isnull(a.col24 ,0.00))col24,
   sum(isnull(a.col25 ,0.00))col25,
   sum(isnull(a.col26 ,0.00))col26,
   sum(isnull(a.col27 ,0.00))col27,
   sum(isnull(a.col28 ,0.00))col28,
   sum(isnull(a.col29 ,0.00))col29,
   sum(isnull(a.col30 ,0.00))col30,   
   sum(a.liquido)liquido, 
	max(a.agrupacion)agrupacion, 
	max(ltrim(rtrim(a.nombre_usual)))as nombre_usual,
	 max(a.fecha_nacimiento)fecha_nacimiento, 
	 max(a.sexo)sexo, 
	 max(a.nacionalidad)nacionalidad,
	  max(a.numero_seguro_social)numero_seguro_social, 
	  max(a.cedula)cedula, 
	  max(a.fecha_inicio_rel_lab)fecha_inicio_rel_lab,
	max(a.fecha_baja)fecha_baja,
	 max(a.nombre_profesion)nombre_profesion, 
	 a.num_nomina, 
	 max(isnull(a.anos,0))anos, 
	 max(isnull(a.salario, b.salario))salario_minimo, 
	 min(fecha_inicial)fecha_inicial,
     max(fecha_final)fecha_final,
     max(a.periodo_id)periodo_id
into #fecha
from #resultados a 
LEFT join no_salarios_minimos b
	on a.codigo_tipo Collate Modern_Spanish_CI_AS = b.codigo_tipo Collate Modern_Spanish_CI_AS
	and substring (b.periodo_id,1,2) = @codigo_inicial
	and a.periodo_id Collate Modern_Spanish_CI_AS = b.periodo_id Collate Modern_Spanish_CI_AS
group by a.codigo_empleado, a.num_nomina


	Select 
	a.codigo_tipo, 
	a.numero_columnas, 
	a.codigo_empleado, 
	a.espacios,
	a.col1,    
	a.col2,    
	a.col3,    
	a.col4,    
	a.col5,    
	a.col6,    
	a.col7,    
	a.col8,    
	a.col9,    
	a.col10, 
	a.col11,    
	a.col12,    
	a.col13,    
	a.col14,    
	a.col15,    
	a.col16,    
	a.col17,    
	a.col18,    
	a.col19,    
	a.col20,    
	a.col21,    
	a.col22,    
	a.col23,    
	a.col24,    
	a.col25,    
	a.col26,    
	a.col27,    
	a.col28,    
	a.col29,    
	a.col30,     
	a.liquido, 
	a.agrupacion, 
	a.nombre_usual,
	a.fecha_nacimiento, 
	a.sexo, a.nacionalidad, 
	a.numero_seguro_social, 
	a.cedula, 
	a.fecha_inicio_rel_lab,
	a.fecha_baja, 
	a.nombre_profesion, 
	a.num_nomina, 
	a.anos,
	a.salario_minimo,
	a.fecha_inicial,
	a.fecha_final

From 
#fecha a
where codigo_empleado is not null
--where codigo_empleado = 'A0018     '
 Order By a.codigo_empleado Asc, a.fecha_inicial asc
go

