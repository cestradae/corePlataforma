create procedure [dbo].[stp_UDNoGetCuentaBanco]
    @codigo_tipo char(2),
    @id_cuenta varchar(32) out
as
------------------------------------------------------------------------------------
--Fecha 10/10/2003
--Asunto Obtenemos la cuenta par el tipo de nomina
--Creado por LSAO
------------------------------------------------------------------------------------
select @id_cuenta = id_cuenta
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

if @id_cuenta is null select @id_cuenta
go

