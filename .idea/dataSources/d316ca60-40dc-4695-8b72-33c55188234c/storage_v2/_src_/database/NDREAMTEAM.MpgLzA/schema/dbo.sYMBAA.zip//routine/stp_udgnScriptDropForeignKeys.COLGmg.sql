CREATE PROCEDURE [dbo].[stp_udgnScriptDropForeignKeys]
					@table_name varchar(200),
					@script varchar(8000) out
AS


CREATE TABLE #Temp(
PKTABLE_QUALIFIER NVARCHAR(128),
PKTABLE_OWNER NVARCHAR(128),
PKTABLE_NAME NVARCHAR(128),
PKCOLUMN_NAME NVARCHAR(128),
FKTABLE_QUALIFIER NVARCHAR(128),
FKTABLE_OWNER NVARCHAR(128),
FKTABLE_NAME NVARCHAR(128),
FKCOLUMN_NAME NVARCHAR(128),
KEY_SEQ INT,
UPDATE_RULE INT,
DELETE_RULE INT,
FK_NAME NVARCHAR(128),
PK_NAME NVARCHAR(128),
DEFERRABILITY INT)

INSERT #Temp
EXEC dbo.sp_fkeys @table_name


-- Get all existing primary keys
DECLARE cPK CURSOR FOR
   SELECT distinct FKTABLE_NAME, fk_name
   FROM #Temp
  
DECLARE @PkTable SYSNAME
DECLARE @PkName SYSNAME

-- Loop through all the primary keys
OPEN cPK
FETCH NEXT FROM cPK INTO @PkTable, @PkName
WHILE (@@FETCH_STATUS = 0)
BEGIN
   DECLARE @PKSQL NVARCHAR(4000) SET @PKSQL = ''
   SET @PKSQL = 'ALTER TABLE ' + @PkTable + ' DROP CONSTRAINT ' + @PkName 
   
   --PRINT @PKSQL
  if @script is null
  begin
	SET @script = isnull(@script,'')+ '  ' + @PKSQL
  end
  else
  begin 
	SET @script = isnull(@script,'')+ char(10) + ''  + char(10) + @PKSQL
  end

   FETCH NEXT FROM cPK INTO @PkTable, @PkName
END
CLOSE cPK
DEALLOCATE cPK

--select @script
go

