create procedure stp_UDnoFormula62   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  
begin
  
  set @result=10
end
go

