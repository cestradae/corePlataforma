-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_cvariables_clsno_tvaloresRelated]
(  @oldtipo_valor char (10)  )
  As 
SELECT a.tipo_valor,a.codigo_clase,a.descripcion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_clases_variables] a
WHERE 
a.tipo_valor =  @oldtipo_valor
go

