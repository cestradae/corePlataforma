-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_ereportedet](@AUTO_EditStamp varchar(30) OUT,
  @codigo_repnomina smallint ,
  @codigo_elemento varchar (11) ,
  @monto_base char (1) ,
  @numero_columna smallint ,
  @factor decimal (8,4) ,
  @valor decimal (18,4)  )
As 
	INSERT INTO [dbo].[no_nomina_reportedet]
(  codigo_repnomina ,
  codigo_elemento ,
  monto_base ,
  numero_columna ,
  factor ,
  valor  )
VALUES (  @codigo_repnomina ,
  @codigo_elemento ,
  @monto_base ,
  @numero_columna ,
  @factor ,
  @valor  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_nomina_reportedet]
  WHERE ( codigo_repnomina =  @codigo_repnomina AND 
numero_columna =  @numero_columna AND 
codigo_elemento =  @codigo_elemento )
go

