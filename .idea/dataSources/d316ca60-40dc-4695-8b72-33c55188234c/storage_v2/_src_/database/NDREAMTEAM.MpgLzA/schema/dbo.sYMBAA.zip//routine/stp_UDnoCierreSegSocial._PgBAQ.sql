create procedure [dbo].[stp_UDnoCierreSegSocial]
    @ano smallint,
    @periodo smallint
as
---------------------------------------------------------------------
--Creado por LSAO
--Fecha 25/10/2003
--Asunto Cierra Reporte del igss
---------------------------------------------------------------------


update no_reporte_seguro
  set estado_reporte = 'C'
where ano = @ano
  and periodo = @periodo

if @@error <> 0 
begin
   raiserror ('Reporte de Seguro no pudo ser cerrado - stp_UDnoCierreSegSocial ', 16,1,5000)
   rollback work
   return
end
go

