CREATE procedure [dbo].[stp_UDnoObtieneProvisiones] 
as
-----------------------
-- Usuario lsao
-- fecha 03-01-2007
-- Asunto Obtiene Anticipos
----------------------
select nombre_corto, descripcion, '@' + nombre_corto +  ' decimal(18,4),' variable, 'Select @'+nombre_corto+'= isnull('+ nombre_corto+',0) from no_resumen_reporte ' query, 'isnull(@' + nombre_corto+',0)' variableA
from no_catalogo_provisiones
go

