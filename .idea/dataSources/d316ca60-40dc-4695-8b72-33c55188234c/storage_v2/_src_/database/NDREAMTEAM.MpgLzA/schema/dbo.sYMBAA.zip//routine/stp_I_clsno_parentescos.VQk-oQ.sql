-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_parentescos](  @AUTO_correlativo smallint OUT,
@AUTO_EditStamp varchar(30) OUT,
  @AUTO_edad int OUT,
  @codigo_empleado char (10) ,
  @nombre_pariente varchar (100) ,
  @fecha_nacimiento datetime ,
  @codigo_parentesco smallint  )
As 

declare @correlativo smallint

select @correlativo = max(correlativo) + 1
from no_parentescos
where codigo_empleado = @codigo_empleado

if @correlativo is null select @correlativo = 1

	INSERT INTO [dbo].[no_parentescos]
(  codigo_empleado ,
  correlativo ,
  nombre_pariente ,
  fecha_nacimiento ,
  codigo_parentesco  )
VALUES (  @codigo_empleado ,
  @correlativo ,
  @nombre_pariente ,
  @fecha_nacimiento ,
  @codigo_parentesco  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_correlativo = correlativo, @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp)) , @AUTO_edad = ISNULL(edad,0) From [dbo].[no_parentescos]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
correlativo =  @correlativo )
go

