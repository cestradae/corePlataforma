create procedure [dbo].[stp_UDNoGetNoReporte] 
   @codigo_tipo char(2),
   @periodo_id char(10),
   @no_reporte smallint out 
as
---------------------------------------------------------------
--Creado por LSAO
--Fecha 07/07/2003
--Asunto Obtiene el ultimo numero 
---------------------------------------------------------------
select @no_reporte = max(no_reporte) + 1
from no_reporte_valores
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id

if @no_reporte is null select @no_reporte= 1
go

