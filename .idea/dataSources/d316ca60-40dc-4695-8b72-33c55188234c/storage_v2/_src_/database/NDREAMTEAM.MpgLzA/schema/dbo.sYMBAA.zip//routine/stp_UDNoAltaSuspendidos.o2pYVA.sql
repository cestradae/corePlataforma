Create procedure [dbo].[stp_UDNoAltaSuspendidos] 
     @codigo_empleado char(10), 
     @corr_solicitud smallint
as
-----------------------------------------------------
--Hecho por LSAO
--Fecha 21/08/2003
--Asunto Alta de empleados suspendidos
-----------------------------------------------------
begin Tran

update no_empleados
   set estado_empleado = 'A'
where codigo_empleado = @codigo_empleado

if @@error <> 0 
begin
   raiserror ('No se pudo dar de alta al empleado %s', 16,1,@codigo_empleado)
   rollback tran
   return
end

update no_solicitud_ausencias 
   set fecha_alta = getdate(),
       usuario_alta = system_user
where codigo_empleado = @codigo_empleado
  and corr_solicitud = @corr_solicitud

if @@error <> 0
begin
   raiserror ('No se pudo actualizar la solicitud %d para el empleado %s' , 16,1, @corr_solicitud, @codigo_empleado )
   rollback tran
   return
end
commit tran
go

