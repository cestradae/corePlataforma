-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_dvariablesv]
  (  @oldClase varchar (71) ,
  @oldcodigo_valor char (10) ,
  @olddescripcion varchar (60)  )
As SELECT a.descripcion,a.Tipo_valor,a.Clase,a.codigo_valor,a.nombre_valor,a.unidad_medida,a.valor,a.extra,a.meta,a.tipo_meta FROM [dbo].[no_detalle_variablesv] a
WHERE (a.Clase =  @oldClase AND 
a.codigo_valor =  @oldcodigo_valor AND 
a.descripcion =  @olddescripcion)
go

