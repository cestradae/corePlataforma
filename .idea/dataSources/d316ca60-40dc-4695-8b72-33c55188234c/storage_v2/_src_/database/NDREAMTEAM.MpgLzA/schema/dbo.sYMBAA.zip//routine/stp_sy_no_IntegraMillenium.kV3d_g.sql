CREATE PROCEDURE [dbo].[stp_sy_no_IntegraMillenium]
				@codigo_tipo CHAR(2),
				@periodo_id char(10),
				@grupo_id char(5),
				@no_calculo smallint,
				@codigo_empleado char(10),
				@codigo_departamento smallint,
				@codigo_centro varchar(20),
				@codigo_valor char(11),
				@valor decimal(18,4),
				@fecha_reporte datetime
				
AS
----------------------------------------------------
--Hecho por Daniel Ortiz
--Fecha:09/03/2012
--Asunto:Carga de reporte de valores ingreso de la integracioin con Virtual Verifier
----------------------------------------------------
SET NOCOUNT ON

declare @no_reporte smallint

select @no_reporte=0

INSERT INTO [no_reporte_valores_ingreso]
           ([codigo_tipo]
           ,[periodo_id]
           ,[no_reporte]
           ,[grupo_id]
           ,[no_calculo]
           ,[fecha_reporte]
           ,[codigo_empleado]
           ,[codigo_departamento]
           ,[codigo_centro]
           ,[tipo_valor]
           ,[codigo_valor]
           ,[valor]
           ,[usuario_ingreso]
           ,[fecha_ingreso]
           ,[estado_reporte]
           )
    select @codigo_tipo,
		   @periodo_id,
		   @no_reporte,
		   @grupo_id,
		   @no_calculo,
		   @fecha_reporte,
		   @codigo_empleado,
		   @codigo_departamento,
		   @codigo_centro,
		   '1',
		   @codigo_valor,
		   @valor,
		   1,
		   getdate(),
		   'O'
go

