-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNo_Users]
As
  SELECT userid Id, username Nombre
FROM _Users
ORDER BY username
go

