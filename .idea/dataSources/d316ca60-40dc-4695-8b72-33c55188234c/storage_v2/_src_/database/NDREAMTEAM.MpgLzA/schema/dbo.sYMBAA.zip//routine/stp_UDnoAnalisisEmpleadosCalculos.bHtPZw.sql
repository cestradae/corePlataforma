create procedure [dbo].[stp_UDnoAnalisisEmpleadosCalculos]
   @tipo_inicial char(2),
   @tipo_final char(2),
   @ano_inicial smallint,
   @mes_inicial smallint,
   @ano_final smallint,
   @mes_final smallint
as
----------------------------------------
-- Hecho por dortiz
-- Fecha 02/02/2012
-- Para las provisiones se toma el codigo seccion del historico de provisiones
----------------------------------------
-- Hecho por ldr
-- Fecha 03/11/2011
-- Cubo se incluyeron las provisiones y los ingresos
--------------------------------------------------------------
-- Hecho por lsao
-- Fecha 12/12/2008
-- Asunto Consulta de ingresos y egresos por empleados 
---------------------------------------------------------------

set nocount on
select a.codigo_tipo,
       a.periodo_id,
       a.grupo_id,
       a.no_calculo,
       a.codigo_empleado,
       a.codigo_departamento,
       a.codigo_centro,
       convert(char(12),'Ingresos') Tipo,
       a.codigo_ingreso codigo,
       a.monto_ingreso monto,
       a.monto_base base,
       b.descripcion,
       a.codigo_puesto,
       a.periodo,
       a.codigo_seccion
into #DetalleNomina
from no_nomina_det a, no_catalogo_ingresos b
where a.codigo_tipo between @tipo_inicial and @tipo_final
  and substring(a.periodo_id,3,6) between @ano_inicial * 100 + @mes_inicial and @ano_final * 100 + @mes_final
  and a.monto_ingreso <> 0
  and a.codigo_ingreso = b.codigo_ingreso

union all
 
select a.codigo_tipo,
       a.periodo_id,
       a.grupo_id,
       a.no_calculo,
       a.codigo_empleado,
       a.codigo_departamento,
       a.codigo_centro,
       convert(char(12),'Deducciones') Egresos,
       a.codigo_deduccion,
       a.monto_deduccion * -1,
       a.monto_base,
       b.descripcion,
       a.codigo_puesto,
       a.periodo,
       a.codigo_seccion
from no_nomina_det a, no_catalogo_deducciones b
where codigo_tipo between @tipo_inicial and @tipo_final
  and substring(a.periodo_id,3,6) between @ano_inicial * 100 + @mes_inicial and @ano_final * 100 + @mes_final
  and monto_deduccion <> 0
  and a.codigo_deduccion = b.codigo_deduccion

union all
 
select a.codigo_tipo,
       a.periodo_id,
       a.grupo_id,
       a.no_calculo,
       a.codigo_empleado,
       a.codigo_departamento,
       a.codigo_centro,
       convert(char(12),'Provisiones') Egresos,
       a.codigo_provision,
       a.monto_provision ,
       a.monto_base,
       b.descripcion,
       c.codigo_puesto,
       substring(a.periodo_id,3,8),
       isnull(a.codigo_seccion,c.codigo_seccion)
from no_provisiones_empleados a
left join no_catalogo_provisiones b on a.codigo_provision = b.codigo_provision
left join no_empleados c on a.codigo_empleado = c.codigo_empleado
where a.codigo_tipo between @tipo_inicial and @tipo_final
  and substring(a.periodo_id,3,6) between @ano_inicial * 100 + @mes_inicial and @ano_final * 100 + @mes_final
  and a.monto_provision <> 0


select a.codigo_tipo+ '-'+ g.descripcion TipoNomina,
       convert(char(10),f.fecha_inicial,103) + '-'+ convert(char(10),f.fecha_final,103) Periodo,
       i.descripcion Grupo,
       a.no_calculo,
       a.codigo_empleado + '-' + c.nombre_usual nombre,
       isnull(a.codigo_centro+' '+d.nombre_centro,'<Sin Centro>') Centro,
       a.tipo,
       a.codigo,
       a.monto ,
       a.base,
       a.descripcion,
       b.descripcion Departamento,
       isnull(e.descripcion,'<Sin Puesto>') Puesto,
       substring(a.periodo_id,3,4) ano,
       substring(a.periodo_id,7,2) mes,
       isnull(h.nombre_seccion, '<Sin Sección>') Seccion
from #DetalleNomina a, gn_departamentos b, no_empleados c, cn_catalogo_centros d,
      no_puestos e, no_periodos_pago f, no_tipos_nomina g, no_secciones h,
      no_grupos_valores i
where a.codigo_departamento *= b.codigo_departamento
  and a.codigo_empleado *= c.codigo_empleado
  and a.codigo_centro *= d.codigo_centro
  and a.codigo_puesto *= e.codigo_puesto
  and a.periodo_id = f.periodo_id
  and a.codigo_tipo = g.codigo_tipo
  and a.codigo_seccion *= h.codigo_seccion
  and a.grupo_id *= i.grupo_id

go

