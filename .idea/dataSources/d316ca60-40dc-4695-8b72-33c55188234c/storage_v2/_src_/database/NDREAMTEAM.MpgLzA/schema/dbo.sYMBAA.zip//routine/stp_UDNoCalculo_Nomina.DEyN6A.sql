

CREATE procedure [dbo].[stp_UDNoCalculo_Nomina] --'01','0120120102','013',0,2,'admin',''
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @tasa_cambio decimal(8,6),
   @usuario_generacion varchar(35),
   @xerror char(1) out
 with recompile
AS

-----------------------
-- Modificado por dortiz
-- Fecha 23/05/2011
-- Se agrego para que guarde el tipo de pago de los empleados
-----------------------
-----------------------
-- Modificado por dortiz
-- Fecha 28/04/2011
-- Se cambio de lugar el calculo de las vacaciones correspondientes al periodo trabajado
-----------------------
-----------------------
-- Modificado por LDR
-- Fecha 28/03/2011
-- Se cambio para no incluya los que tienen liquidaciones en el mes
-----------------------
-----------------------
-- Modificado por LDR
-- Fecha 15/13/2011
-- Se cambio para no incluya los que tienen liquidaciones en el mes
-----------------------

------------------
-- Modificado por LDR
-- Fecha 05/10/2010
-- Se cambio el orden de calculo de los campos definidos por el usuario para que calculara al inicio
-------------------

-------------------------------------------------------------
--Modificado por LSAO
--Fecha 14/12/2010
--Asunto aGREGO EL TIPO_CALCULO P = Pagos periodicos o prestaciones 
--      
-------------------------------------------------------------

-------------------------------------------------------------
--Modificado por LDR
--Fecha 07/10/2010
--Se agregan campos definidos por el usuario
--Se agregan Validacion de SAp
--Se agrega Historico de Ingresos para usos posteriores      
--Se agrega que los empleados suspendidos se trasladen a alta si la fecha de inicio de alta es anterior a la fecha inicio periodo
-------------------------------------------------------------
-------------------------------------------------------------
--Modificado por DORTIZ
--Fecha 13/08/2010
--Asunto Solo toma empleados activos y suspendidos durante el periodo de pago
--      
------------------------------------------------------------
-------------------------------------------------------------
--Modificado por DORTIZ
--Fecha 14/07/2010
--Asunto Solo toma empleados activos y suspendidos durante el periodo de pago
--      
-------------------------------------------------------------

-------------------------------------------------------------
--Modificado por DORTIZ
--Fecha 04/11/2009
--Asunto Impresion de varias nominas en una sola llamada y 
-- arreglo usuario de generacion
-------------------------------------------------------------
-------------------------------------------------------------
--Modificado por DORTIZ
--Fecha 04/11/2009
--Asunto Incluye inclusion de emnpleado de baja en el periodo
-------------------------------------------------------------
-------------------------------------------------------------
--Creado por LSAO
--Fecha 04/08/2008
--Calculo de vacaciones  
-------------------------------------------------------------
-------------------------------------------------------------
--Creado por LSAO
--Fecha 31/06/2003
--Asunto Calculo de Nominas y Planillas 
-------------------------------------------------------------
set nocount on
declare @codigo_grupo smallint,
        @codigo_ingreso char(3),
        @tipo_ingreso char(1),
        @orden_calculo smallint,
        @perioricidad char(1),
        @tipo_calculo char(1),
        @procedimiento varchar(50),
        @tipo_calc_grupo char(1),
        @codigo_deduccion char(3),
        @tipo_deduccion char(1),
        @fecha_generacion datetime,
        @lleva_saldo char(1),
        @codigo_provision char(3),
        @err_proc int ,
        @error int,
        @tipo_calculo_grupo char(1),
        @solo_reportado char(1),
		@fecha_ini datetime,
		@fecha_fin datetime,
        @fecha_ini_mes datetime,
        @fecha_fin_mes datetime,
        @messtr char(2)

IF EXISTS (SELECT 1
			FROM no_nomina_enc
			WHERE codigo_tipo=@codigo_tipo
			  AND periodo_id=@periodo_id
			  AND grupo_id = @grupo_id
			  AND no_calculo = @no_calculo 
			  AND contabilizado_sap='S')
BEGIN
	RAISERROR ('Esta Nomina ya fue trasladada a SAP, imposible volver a calcular Nomina - stp_UDNoCalculo_Nomina',16,1,5000)
	return 9
END




select @fecha_generacion = getdate()

select @fecha_ini=fecha_inicial,
       @fecha_fin=fecha_final
from no_periodos_pago
where periodo_id =  @periodo_id

select @fecha_fin_mes = @fecha_fin

if datepart(mm,@fecha_fin) < 10
   select @messtr =  '0' + convert(char(1),datepart(mm,@fecha_fin))
else
   select @messtr =  convert(char(2),datepart(mm,@fecha_fin))

select @fecha_ini_mes = convert(char(4),datepart(yy,@fecha_fin)) + @messtr + '01'



-- Obtenemos el codigo de grupo
select @error = ''
select @xerror = ''
select @codigo_grupo = codigo_grupo,
       @tipo_calc_grupo = tipo_calculo
from no_grupos_valores 
where grupo_id = @grupo_id



-- Creamos la tabla temporal para calcular el liquido

select @tipo_calculo_grupo = tipo_calculo,
       @solo_reportado = solo_reportado
from no_grupos_valores
where grupo_id = @grupo_id


create table #Liquido (
    codigo_empleado char(10)   COLLATE Modern_Spanish_CI_AS,
    ingresos money,
    deducciones money,
    liquido money)
    
create table #ingresos ( codigo_ingreso char(3)    COLLATE Modern_Spanish_CI_AS )

create table #deducciones ( codigo_deduccion char(3)   COLLATE Modern_Spanish_CI_AS)

create table #anticipos (codigo_anticipo char(3)   COLLATE Modern_Spanish_CI_AS)

-- Obtenemos los ingresos que deben ser procesados 


insert into #ingresos
select convert(char(3),substring(codigo_valor,2,3)) codigo_ingreso 
from no_grupos_detalle
where codigo_tipo = @codigo_tipo
and codigo_grupo = @codigo_grupo
and substring(codigo_valor,1,1) = '2'


-- Obtenemos los egresos que deben ser procesados 

insert into #deducciones 
select convert(char(3),substring(codigo_valor,2,3)) codigo_deduccion 
from no_grupos_detalle
where codigo_tipo = @codigo_tipo
and codigo_grupo = @codigo_grupo
and substring(codigo_valor,1,1) = '3'


insert into #anticipos
select convert(char(3),substring(codigo_valor,2,3)) codigo_anticipo
from no_grupos_detalle
where codigo_tipo = @codigo_tipo
and codigo_grupo = @codigo_grupo
and substring(codigo_valor,1,1) = '4'

-- Obtenemos todos los empleados que se van a incliur en la nomina

Begin Tran

-- Borramos el calculo de nomina

exec @error =  stp_UDNoEliminacion_Calculo @codigo_tipo, @periodo_id, @grupo_id, @no_calculo

if @error <> 0
begin
    raiserror ('No se pudo eliminar calculo - stp_UDNoCalculo_Nomina' ,16,1,5000)
    rollback work
    return 9
end

EXEC @error = stp_UDnoHistorico_Ingresos @codigo_tipo, @periodo_id, @grupo_id, @no_calculo 


if @error <> 0
Begin
    raiserror('No se pueden crear el historico de ingresos para esta nomina - stp_UDnoCalculo_Nomina',16,1,5000)
    rollback work
    return 9
End

-- Insertamos el encabezado de la nomina

insert into no_nomina_enc (
   codigo_tipo,
   periodo_id,
   grupo_id,
   no_calculo,
   tasa_cambio,
   estado, 
   usuario_generacion,
   fecha_generacion )
values (
   @codigo_tipo,
   @periodo_id,
   @grupo_id,
   @no_calculo,
   @tasa_cambio,
   'O',
   @usuario_generacion,
   @fecha_generacion )

-- Insertamos el detalle de empleados de Nomina


-- Procedemos a actualizar si los empleados estan Suspendidos 

update no_empleados
   set estado_empleado = 'A' 
where fecha_alta_suspension <= @fecha_ini	
and estado_empleado = 'S'

if @@error <> 0 
begin
      raiserror (' No se puede actualizar el estado del empleado de suspendido a activo en calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
      rollback work
      return
end



-- Insertamos el detalle de empleados de Nomina

if @solo_reportado = 'N' and @tipo_calculo_grupo = 'N'
Begin

  insert into no_nomina_emplcalc (
     codigo_tipo,
     periodo_id,
     grupo_id,
     no_calculo,
     codigo_empleado,
     estado_empleado,
     fecha_emision,
     usuario_emision,
	 tipo_pago )  --agregado de tipo de pago

   select  @codigo_tipo,
           @periodo_id,
           @grupo_id,
           @no_calculo,
           a.codigo_empleado,
           a.estado_empleado,
           getdate(),
           system_user,
		   a.tipo_pago
   from no_empleados a, no_nomina_empleado b
   where  a.codigo_empleado = b.codigo_empleado
      and b.codigo_tipo = @codigo_tipo 
      and ((a.estado_empleado  in ( 'A' , 'S' ) AND fecha_inicio_rel_lab <= @fecha_fin)
         or ( (a.estado_empleado='B' and  a.fecha_baja between @fecha_ini and @fecha_fin) and 
                not exists ( select 1 from no_liquidaciones c where c.codigo_empleado = a.codigo_empleado 
                   and c.estado = 'C' and c.fecha_liquidacion between @fecha_ini and @fecha_fin ) ))

   if @@error <> 0 
   begin
         raiserror (' No se puede insertar  el detalle de empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
         rollback work
         return 9
  end
  
End


Else -- Tipo @solo_reportado = 'N' and @tipo_calculo_grupo = 'N'

Begin


   if @tipo_calculo_grupo = 'L' 
   begin
       insert into no_nomina_emplcalc (
        codigo_tipo,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        estado_empleado,
        fecha_emision,
        usuario_emision,
		tipo_pago )    --agregado de tipo de pago

      select  @codigo_tipo,
              @periodo_id,
              @grupo_id,
              @no_calculo,
              a.codigo_empleado,
              a.estado_empleado,
              getdate(),
              system_user,
			  a.tipo_pago
      from no_empleados a, no_nomina_empleado b, no_liquidaciones c
      where  a.codigo_empleado = b.codigo_empleado
        and b.codigo_tipo = @codigo_tipo 
        and ((a.estado_empleado  in ( 'A' , 'S' ) AND fecha_inicio_rel_lab <= @fecha_fin)
          or ( a.estado_empleado='B' and  a.fecha_baja between @fecha_ini and @fecha_fin))
        and a.codigo_empleado = c.codigo_empleado
        and c.no_calculo is null
		and c.estado='A'
        and c.periodo_id = @periodo_id

      if @@error <> 0 
      begin
         raiserror (' No se puede insertar  el detalle de empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
         rollback work
         return 9
      end
   End  
   Else  -- @tipo_calculo = 'L'  Liquidacion
   
   
   Begin

      IF @tipo_calculo_grupo = 'V'
  	  Begin
         insert into no_nomina_emplcalc (
           codigo_tipo,
           periodo_id,
           grupo_id,
           no_calculo,
           codigo_empleado,
           estado_empleado,
           fecha_emision,
           usuario_emision,
		   tipo_pago)  -- agregado de tipo de pago
         select  @codigo_tipo,
           @periodo_id,
           @grupo_id,
           @no_calculo,
           a.codigo_empleado,
           a.estado_empleado,
           getdate(),
           system_user,
		   a.tipo_pago
         from  no_empleados a, no_nomina_empleado b, no_solicitud_ausencias c
         where  a.codigo_empleado COLLATE Modern_Spanish_CI_AS = b.codigo_empleado COLLATE Modern_Spanish_CI_AS
	       AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS = c.codigo_empleado COLLATE Modern_Spanish_CI_AS
           and b.codigo_tipo = @codigo_tipo 
           AND c.codigo_tipo COLLATE Modern_Spanish_CI_AS =b.codigo_tipo COLLATE Modern_Spanish_CI_AS
           AND c.tipo_solicitud= 'V'
           AND estado_solicitud='A'
           AND c.fecha_inicio <= @fecha_fin 
           AND (a.estado_empleado= 'A' AND fecha_inicio_rel_lab <= @fecha_fin)
           AND c.periodo_id IS NULL 
        
        
	      if @@error <> 0 
	      begin
             raiserror (' No se puede insertar  el detalle de empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
             rollback work
             return 9
	      end
      End
      ELSE -- Tipo Calculo = 'Vacaciones' 
      BEGIN
         IF @tipo_calculo_grupo = 'P'
         Begin
            insert into no_nomina_emplcalc (
              codigo_tipo,
              periodo_id,
              grupo_id,
              no_calculo,
              codigo_empleado,
              estado_empleado,
              fecha_emision,
              usuario_emision,
			  tipo_pago ) --agregado de tipo de pago

             select  @codigo_tipo,
                @periodo_id,
                @grupo_id,
                @no_calculo,
                a.codigo_empleado,
                a.estado_empleado,
                getdate(),
                system_user,
				a.tipo_pago
             from no_empleados a, no_nomina_empleado b
             where  a.codigo_empleado = b.codigo_empleado
               and b.codigo_tipo = @codigo_tipo 
               and ((a.estado_empleado  in ( 'A' , 'S' ) AND fecha_inicio_rel_lab < @fecha_ini_mes)
               or ( a.estado_empleado='B' and  a.fecha_baja between @fecha_ini_mes and @fecha_fin_mes))
              

              if @@error <> 0 
              begin
                 raiserror (' No se puede insertar  el detalle de empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
                 rollback work
                 return 9
              end
         End
         Else -- Tipo caculo grupo = 'P'
         Begin
            if @solo_reportado = 'S'
            Begin
               insert into no_nomina_emplcalc (
                 codigo_tipo,
                 periodo_id,
                 grupo_id,
                 no_calculo,
                 codigo_empleado,
                 estado_empleado,
                 fecha_emision,
                 usuario_emision, 
				 tipo_pago)  --Agregado de tipo de pago

               select  @codigo_tipo,
                       @periodo_id,
                       @grupo_id,
                       @no_calculo,
                       a.codigo_empleado,
                       a.estado_empleado,
                       getdate(),
                       system_user,
					   a.tipo_pago
                from no_empleados a, no_nomina_empleado b
                where  a.codigo_empleado = b.codigo_empleado
                  and b.codigo_tipo = @codigo_tipo 
                  and ((a.estado_empleado  in ( 'A' , 'S' ) AND fecha_inicio_rel_lab <= @fecha_fin)
                  or ( a.estado_empleado='B' and  a.fecha_baja between @fecha_ini and @fecha_fin))
                  and a.codigo_empleado in (
                   select distinct codigo_empleado
                   from no_reporte_valores_ingreso 
                   where codigo_tipo = @codigo_tipo
                     and grupo_id = @grupo_id
                     and periodo_id = @periodo_id
                     and no_calculo = @no_calculo )


                  if @@error <> 0 
                  begin
                     raiserror (' No se puede insertar  el detalle de empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
                     rollback work
                     return 9
                  end
		     END  -- solo reportado
         End -- Prestaciones P
      End -- Vacaciones
   End -- Liquidaciones
End -- Nomina Normal


-- Procedemos a calcular las vacaciones por periodo 
exec @error = stp_UDnoCalculoVacaciones  @codigo_tipo ,   @periodo_id  ,   @grupo_id ,   @no_calculo 

if @error <> 0
Begin
   Raiserror ('No se pueden calcular las vacaciones - stp_UDnoCalculo_Nomina ',16,1,5000)
   Rollback work
   Return 9
End

-- Procedemos a insertar campos definidos por el usuario que sean numericos 

insert into no_nomina_valores_calculados (
      codigo_tipo, periodo_id,  grupo_id,
      no_calculo, codigo_valor,  valor, codigo_empleado )

select @codigo_tipo, 
       @periodo_id,
       @grupo_id,
       @no_calculo, 
       a.nombre_campo,
	   a.valor,
       a.codigo_empleado 
from no_empleado_campos a
  join no_campos_usuario b on a.nombre_campo = b.nombre_campo
  join no_nomina_emplcalc c on c.codigo_tipo = @codigo_tipo and
      c.periodo_id = @periodo_id and c.grupo_id = @grupo_id and 
      c.no_calculo = @no_calculo and a.codigo_empleado = c.codigo_empleado 
    and b.es_numerico = 'S'

if @@error <> 0
Begin
    Raiserror ('No se pudieron insertar los campos definidos por usuario numericos ' , 16,1,5000)
    Rollback work
    Return 9
End



-- Procedemos a calcular las variables del sistema para cada empleado

exec @error = stp_UDnoCalcula_VariablesSistema
    @codigo_tipo ,
    @periodo_id ,
    @grupo_id ,
    @no_calculo 


if @error <> 0
Begin
   Raiserror ('Sistema no puede crear variables de sistema por empleado - stp_UDnoCalculoNomina ',16,1,5000)
   Rollback work
   Return 9
End

-- Procedemos a calcular las variable con formula o procedimiento almacenado

exec @error = stp_UDnoCalculaVariablesCalc
    @codigo_tipo ,
    @periodo_id ,
    @grupo_id ,
    @no_calculo 

if @error <> 0
Begin
   Raiserror ('Sistema no puede crear variables de sistema por empleado - stp_UDnoCalculoNomina ',16,1,5000)
   Rollback work
   Return 9
End

-- Obtenemos las caracteristicas de cada ingreso para ser procesados 

declare cur_ingresos cursor for
   select a.codigo_ingreso,
          a.tipo_ingreso,
          a.perioricidad,
          a.tipo_calculo,
          a.procedimiento
   from no_nomina_ingresos a  , #ingresos b
   where a.codigo_tipo = @codigo_tipo
      and a.codigo_ingreso = b.codigo_ingreso
      and a.tipo_ingreso <> 'U'
order by orden_calculo

open cur_ingresos 
fetch cur_ingresos into @codigo_ingreso, 
                        @tipo_ingreso,
                        @perioricidad,
                        @tipo_calculo,
                        @procedimiento

 
   while @@fetch_status = 0
   begin

      -- Tipo Ingreso puede ser 'R' reportado 'V' Valor Fijo 'C' Calculado 'F' Formula 
      if @tipo_ingreso = 'R' 
      begin

            exec  stp_UDNoCalculoIngReportado  @codigo_tipo, @periodo_id, @grupo_id , @no_calculo, @codigo_ingreso

    
            if @@error <> 0 
             begin
                raiserror (' Procedimiento stp_UDNoCalculoIngReportado  para el ingreso %s tiene error- stp_UDNoCalculo_Nomina ', 16,1,  @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return 9
             end 
          
      end 
     if @tipo_ingreso = 'V'
     begin  
           exec stp_UDNoCalculoIngValorFijo  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_ingreso 
           if @@error <> 0 
             begin
                raiserror (' Procedimiento stp_UDNoCalculoIngValorFijo  para el ingreso %s tiene error- stp_UDNoCalculo_Nomina ', 16,1,  @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return 9
             end     

    end
    if @tipo_ingreso = 'C'
          if exists ( select 1 from sysobjects where name = @procedimiento ) 
          begin
             exec @procedimiento  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_ingreso
             if @@error <> 0 
             begin
                raiserror (' Procedimiento %s  para el ingreso %s tiene error- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return 9
             end 
          end
          else
          begin
                raiserror (' Procedimiento %s No existe para el ingreso %s- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return 9
          end 

      if @tipo_ingreso = 'F'
       Begin 
      
          exec stp_UDNoCalculoIngFormula  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_ingreso    
          
          if @@error <> 0
          Begin
             Raiserror ('No se pudo actualizar el calculo de de la formual para el ingreso %s - stp_UDnoCalculo_Nomina ',16,1,@codigo_ingreso )
             Rollback work
             Close cur_ingresos
             Deallocate cur_ingresos
             return 9
          End
       End

 
       fetch cur_ingresos into @codigo_ingreso, 
                                           @tipo_ingreso,
                                           @perioricidad,
                                           @tipo_calculo,
                                           @procedimiento
 
   end 


close cur_ingresos
deallocate cur_ingresos 

-- Obtenemos las caracteristicas de cada ingreso para ser procesados 

declare cur_deducciones cursor for
   select a.codigo_deduccion,
          a.tipo_deduccion,
          a.perioricidad,
          a.procedimiento
   from no_nomina_deducciones a, #deducciones b
   where codigo_tipo = @codigo_tipo
       and a.codigo_deduccion = b.codigo_deduccion
   order by orden_calculo

open cur_deducciones
fetch cur_deducciones into @codigo_deduccion, 
                        @tipo_deduccion,
                        @perioricidad,
                        @procedimiento


   while @@fetch_status = 0
   begin
      -- Tipo Ingreso puede ser 'R' reportado 'V' Valor Fijo 'C' Calculado 'F' Formula

      if @tipo_deduccion = 'R' 
      begin
            exec  stp_UDNoCalculoDedReportado  @codigo_tipo, @periodo_id, @grupo_id , @no_calculo, @codigo_deduccion
            if @@error <> 0 
             begin
                raiserror (' Procedimiento stp_UDNoCalculoDedReportado  para la deduccion %s tiene error- stp_UDNoCalculo_Nomina ', 16,1, @codigo_deduccion )
                rollback work
                close cur_deducciones
                deallocate cur_deducciones
                return 9
             end

     end

     if @tipo_deduccion = 'V'  
     begin
           exec stp_UDNoCalculoDedValorFijo  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_deduccion
            if @@error <> 0 
             begin
                raiserror (' Procedimiento stp_UDNoCalculoDedValorFijo  para la deduccion %s tiene error- stp_UDNoCalculo_Nomina ', 16,1, @codigo_deduccion )
                rollback work
                close cur_deducciones
                deallocate cur_deducciones
                return 9
             end
           
    end

    if @tipo_deduccion = 'C'
       if exists ( select 1 from sysobjects where name = @procedimiento )
       begin
        

          exec @procedimiento  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_deduccion
          if @@error <> 0 
             begin
                raiserror (' Procedimiento %s  para la deduccion %s tiene error- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_deduccion )
                rollback work
                close cur_deducciones
                deallocate cur_deducciones
                return 9
             end
       end
       else
          begin
            
                raiserror (' Procedimiento %s No existe para la deduccion  %s- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_deduccion )
                rollback work
                close cur_deducciones
                deallocate cur_deducciones
                return
          end 


   if @tipo_deduccion = 'P'
   Begin
         -- Primero llamamos al procedimiento que calcula prestamos sin cuota variable 
         exec @error = stp_UDNoCalculoDedPrestamo  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_deduccion
         if  @error <> 0
         Begin
            Raiserror ('No se puede calcular la deduccion %s - stp_UDNoCalculo_Nomina',16,1,@codigo_deduccion )
            rollback work
            close cur_deducciones
            deallocate cur_deducciones
            return 9
         End

         -- Segundo llamamos al procedimiento que calcula prestamos con cuota variable 
         /* 
         exec @error = stp_UDNoCalculoDedPrestamoCuota  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_deduccion
         if  @error <> 0
         Begin
            Raiserror ('No se puede calcular la deduccion %s - stp_UDNoCalculo_Nomina',16,1,@codigo_deduccion )
            rollback work
            close cur_deducciones
            deallocate cur_deducciones
            return 9
         End
         */

   End


   if @tipo_deduccion = 'F'
   Begin
         exec stp_UDNoCalculoDedFormula  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_deduccion 
         if  @@error <> 0
         Begin
            Raiserror ('No se puede calcular la deduccion %s - stp_UDNoCalculo_Nomina',16,1,@codigo_deduccion )
            rollback work
            close cur_deducciones
            deallocate cur_deducciones
            return
         End
   end 


      fetch cur_deducciones into @codigo_deduccion, 
                        @tipo_deduccion,
                        @perioricidad,
                        @procedimiento
 
   end 
close cur_deducciones
deallocate cur_deducciones 


-- Calculamos los ultimos ingresos  se usa para calculo de comisiones o incentivos

declare cur_ingresos cursor for
   select a.codigo_ingreso,
          a.tipo_ingreso,
          a.perioricidad,
          a.tipo_calculo,
          a.procedimiento
   from no_nomina_ingresos a  , #ingresos b
   where a.codigo_tipo = @codigo_tipo
      and a.codigo_ingreso = b.codigo_ingreso
      and a.tipo_ingreso = 'U'
order by orden_calculo

open cur_ingresos 
fetch cur_ingresos into @codigo_ingreso, 
                        @tipo_ingreso,
                        @perioricidad,
                        @tipo_calculo,
                        @procedimiento

 
   while @@fetch_status = 0
   begin

      -- Tipo Ingreso puede ser 'U' Calculado de ultimo   'X'  Calculado de Formula 

    if @tipo_ingreso = 'U'
          if exists ( select 1 from sysobjects where name = @procedimiento ) 
          begin
             
             exec @procedimiento  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_ingreso
             if @@error <> 0 
             begin
              
                raiserror (' Procedimiento %s  para el ingreso %s tiene error- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return
             end 
          end
          else
          begin
                raiserror (' Procedimiento %s No existe para el ingreso %s- stp_UDNoCalculo_Nomina ', 16,1, @procedimiento, @codigo_ingreso )
                rollback work
                close cur_ingresos
                deallocate cur_ingresos
                return
          end 

      if @tipo_ingreso = 'F'
      Begin 
    
          exec stp_UDNoCalculoIngFormula  @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_ingreso    
          if @@error <> 0
          Begin
             Raiserror ('No se pudo actualizar el calculo de de la formual para el ingreso %s - stp_UDnoCalculo_Nomina ',16,1,@codigo_ingreso )
             Rollback work
             Close cur_ingresos
             Deallocate cur_ingresos
             return 9
          End
       End

       -- Procedemos a saldar las provisiones con saldo 

       select @codigo_provision = codigo_provision,
                 @lleva_saldo = lleva_saldo
       from no_nomina_provisiones
       where  codigo_tipo = @codigo_tipo
           and  codigo_ingreso = @codigo_ingreso

      if @lleva_saldo is not null and @lleva_saldo = 'S' -- Procedemos a generar el registro de liquidacion de saldos 
      begin
           -- I Ingresos
           exec stp_UDNoCancela_Provision  @codigo_provision , @periodo_id , @grupo_id, @no_calculo 
           if @@error <> 0
           begin
                raiserror ('No se pudo cancelar la provision  %s para el ingreso s%s ' ,16,1, @codigo_provision, @codigo_ingreso )
                rollback tran
                deallocate cur_ingresos
                return
           end
      end
                 
       fetch cur_ingresos into @codigo_ingreso, 
                                           @tipo_ingreso,
                                           @perioricidad,
                                           @tipo_calculo,
                                           @procedimiento
 
   end 

close cur_ingresos
deallocate cur_ingresos 

-- Calculamos el liquido 

insert into #Liquido ( codigo_empleado, ingresos, deducciones, liquido )
select codigo_empleado,
          sum(monto_ingreso),  sum( monto_deduccion ),
           sum(monto_ingreso) - sum(monto_deduccion )
from no_nomina_det
where codigo_tipo = @codigo_tipo
    and periodo_id = @periodo_id
    and grupo_id = @grupo_id
    and no_calculo = @no_calculo
group by codigo_empleado

update no_nomina_emplcalc
    set no_nomina_emplcalc.ingresos = #Liquido.ingresos,
          no_nomina_emplcalc.deducciones = #Liquido.deducciones
from #Liquido 
where no_nomina_emplcalc.codigo_empleado = #Liquido.codigo_empleado
    and no_nomina_emplcalc.codigo_tipo = @codigo_tipo
    and no_nomina_emplcalc.periodo_id = @periodo_id
    and no_nomina_emplcalc.grupo_id = @grupo_id
    and no_nomina_emplcalc.no_calculo = @no_calculo

if @@error <> 0 
begin
      raiserror (' No se puede actualizar el liquido de  empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
      rollback work
      return
end

update no_nomina_emplcalc
    set no_nomina_emplcalc.liquido = #Liquido.liquido
from #Liquido 
where no_nomina_emplcalc.codigo_empleado = #Liquido.codigo_empleado
    and no_nomina_emplcalc.codigo_tipo = @codigo_tipo
    and no_nomina_emplcalc.periodo_id = @periodo_id
    and no_nomina_emplcalc.grupo_id = @grupo_id
    and no_nomina_emplcalc.no_calculo = @no_calculo
    and #Liquido.liquido >= 0

update no_nomina_emplcalc
    set no_nomina_emplcalc.liquido_negativo = #Liquido.liquido
from #Liquido 
where no_nomina_emplcalc.codigo_empleado = #Liquido.codigo_empleado
    and no_nomina_emplcalc.codigo_tipo = @codigo_tipo
    and no_nomina_emplcalc.periodo_id = @periodo_id
    and no_nomina_emplcalc.grupo_id = @grupo_id
    and no_nomina_emplcalc.no_calculo = @no_calculo
    and #Liquido.liquido < 0

if @@error <> 0 
begin
      raiserror (' No se puede actualizar el liquido de  empleados de calculo de nomina - stp_UDNoCalculo_Nomina ' ,16,1,5000 )
      rollback work
      return
end
	
Commit Tran

SET ANSI_NULLS ON

go

