create procedure stp_UDnoFormula54
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @BaseBoni_Decre decimal(18,4) 

begin
  Select @BaseBoni_Decre= case tipo_moneda when '1' then isnull(monto,0)  when '2' then isnull(round(monto/tasa_cambio,2),0)  when '3' then isnull(round(monto*tasa_cambio,2),0) end from no_empleado_ingresos a, no_catalogo_ingresos b , no_nomina_ingresos c, no_nomina_enc d where a.codigo_tipo = @codigo_tipo  and a.codigo_tipo = c.codigo_tipo and a.codigo_ingreso = c.codigo_ingreso and d.codigo_tipo = @codigo_tipo and d.grupo_id = @grupo_id and d.periodo_id = @periodo_id and d.no_calculo = @no_calculo and a.codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Boni_Decre'

  set @result=isnull(@BaseBoni_Decre,0)
end
go

