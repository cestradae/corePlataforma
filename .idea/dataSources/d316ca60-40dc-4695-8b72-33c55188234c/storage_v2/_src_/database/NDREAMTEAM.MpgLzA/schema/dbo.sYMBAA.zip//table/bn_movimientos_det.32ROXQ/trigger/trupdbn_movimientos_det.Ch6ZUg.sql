CREATE TRIGGER [dbo].[trupdbn_movimientos_det] ON [dbo].[bn_movimientos_det] 
FOR UPDATE
AS


declare  @codigo_banco smallint,
              @id_cuenta varchar(32),
              @codigo_tipo smallint,
              @numero_documento int,
              @correlativo smallint,
              @cuenta_contable varchar(30),
              @codigo_centro varchar(20),
              @auxiliar_id int,
              @cargo money,
              @abono money,
              @contabiliza char(1),
              @tipo_conta char(1),
              @ano smallint,
              @periodo smallint,
              @tipo_partida char(2),
              @numero_partida int,
              @acepta_partidas char(1),
              @acepta_centros char(1),
              @acepta_auxiliares char(1)

select @codigo_banco = codigo_banco,
           @id_cuenta = id_cuenta,
           @codigo_tipo = codigo_tipo,
           @numero_documento = numero_documento,
           @correlativo = correlativo 
      
from deleted

select @contabiliza = contabiliza,
          @tipo_conta = tipo_conta
from bn_generales

-- Insertamos el detalle de la partida
if @contabiliza = 'S' and @tipo_conta = 'E'
begin

    select  @ano = ano,
               @periodo = periodo,
               @tipo_partida = tipo_partida,
               @numero_partida = numero_partida
    from bn_partidas_generadas
    where id_cuenta = @id_cuenta
        and codigo_tipo = @codigo_tipo
        and numero_documento = @numero_documento
        and tipo_transaccion = 'I'

  delete from cn_partidas_det where ano = @ano and periodo = @periodo and codigo_tipo = @tipo_partida and numero_partida = @numero_partida
     and correlativo = @correlativo

   if @@error <> 0 
   begin
        raiserror ( 'No se puede eliminar la cuenta contable en el detalle de partida - trupdbn_movimientos_det ' ,16,1,5000 )
        rollback work
        return
   end
   
end


select @codigo_banco = codigo_banco,
           @id_cuenta = id_cuenta,
           @codigo_tipo = codigo_tipo,
           @numero_documento = numero_documento,
           @correlativo = correlativo ,
           @cuenta_contable = cuenta_contable,
           @codigo_centro = codigo_centro,
           @auxiliar_id = auxiliar_id,
           @cargo = cargo, 
           @abono = abono
from inserted

--- Validamos que existan los datos ingresados 

select @acepta_partidas = acepta_partidas,
           @acepta_centros  = acepta_centros,
           @acepta_auxiliares = acepta_auxiliares
from cn_catalogo_cuentas
where cuenta_contable = @cuenta_contable 

if @acepta_partidas = 'N' 
begin
   raiserror ( ' Cuenta contable %s no acepta movimientos no se puede ingresar - trupdbn_movimientos_det ' ,16,1, @cuenta_contable )
   rollback work
   return
end


if @acepta_centros = 'N' and @codigo_centro is not null
begin
   raiserror ('No se pueden ingresar centros para este tipo de cuenta  %s -trupdbn_movimientos_det ' ,16,1,@cuenta_contable )
   rollback work
   return
end


if @acepta_auxiliares = 'N' and @auxiliar_id is not null
begin
    raiserror ('No se pueden ingresar auxiliares para esta cuenta - trupdbn_movimientos_det', 16,1,5000)
    rollback work
    return
end


if not exists ( select 1 from cn_catalogo_centros where codigo_centro = @codigo_centro ) and @codigo_centro is not null
begin
   raiserror (' Codigo de centro %s no existe - trupdbn_movimientos_det ' , 16,1, @codigo_centro )
   rollback work
   return
end

if not exists ( select 1 from cn_catalogo_auxiliares where auxiliar_id = @auxiliar_id ) and @auxiliar_id is not null
begin
   raiserror ( ' Auxiliar %i para la cuenta %s no existe - trupdbn_movimientos_det ' , 16,1, @auxiliar_id, @cuenta_contable )
   rollback work
   return
end


-- Insertamos el detalle de la partida
if @contabiliza = 'S' and @tipo_conta = 'E'
begin

    select  @ano = ano,
               @periodo = periodo,
   @tipo_partida = tipo_partida,
               @numero_partida = numero_partida
    from bn_partidas_generadas
    where id_cuenta = @id_cuenta
        and codigo_tipo = @codigo_tipo
        and numero_documento = @numero_documento
       and tipo_transaccion = 'I'  

    insert into cn_partidas_det ( 
      ano,
      periodo,
      codigo_tipo,
      numero_partida,
      correlativo,
      cuenta_contable,
      codigo_centro,
      auxiliar_id,
      cargo,
      abono )
      values (
      @ano,
      @periodo,
      @tipo_partida,
      @numero_partida,
      @correlativo,
      @cuenta_contable,
      @codigo_centro,
      @auxiliar_id,
      @cargo,
      @abono )

   if @@error <> 0 
   begin
        raiserror ( 'No se puede insertar la cuenta contable en el detalle de partida - trupdbn_movimientos_det ' ,16,1,5000 )
        rollback work
        return
   end
   
end


go

