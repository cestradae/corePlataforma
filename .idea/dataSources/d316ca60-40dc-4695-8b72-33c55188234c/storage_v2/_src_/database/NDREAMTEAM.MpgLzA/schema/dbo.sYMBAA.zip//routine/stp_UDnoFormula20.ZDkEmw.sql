create procedure stp_UDnoFormula20   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @Ord decimal(18,4) 
declare @Hrs_extS decimal(18,4) 
declare @Hrs_extD decimal(18,4) 

begin
  Select @Ord= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Ord'
Select @Hrs_extS= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Hrs_extS'
Select @Hrs_extD= isnull(sum(monto_ingreso),0) from no_nomina_det a, no_catalogo_ingresos b where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo and codigo_empleado = @codigo_empleado  and a.codigo_ingreso = b.codigo_ingreso and b.nombre_corto = 'Hrs_extD'

  set @result=(isnull(@Ord,0)+isnull(@Hrs_extS,0)+isnull(@Hrs_extD,0))*0.01
end
go

