
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_phn_municipios(  @oldcodigo_patrono smallint ,
  @oldid_municipio smallint ,
  @codigo_patrono smallint ,
  @id_municipio smallint ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_patronos_hn_municipios] 
WHERE codigo_patrono =  @oldcodigo_patrono AND 
id_municipio =  @oldid_municipio 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_patronos_hn_municipios] Set 
    codigo_patrono = @codigo_patrono,
    id_municipio = @id_municipio 
WHERE 	( codigo_patrono =  @oldcodigo_patrono AND 
id_municipio =  @oldid_municipio )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_patronos_hn_municipios]
  WHERE ( codigo_patrono =  @codigo_patrono AND 
id_municipio =  @id_municipio )
go

