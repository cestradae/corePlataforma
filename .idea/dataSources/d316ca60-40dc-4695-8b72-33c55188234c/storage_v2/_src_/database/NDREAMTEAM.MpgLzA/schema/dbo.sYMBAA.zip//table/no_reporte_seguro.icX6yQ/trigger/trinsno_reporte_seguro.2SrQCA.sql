CREATE TRIGGER [trinsno_reporte_seguro] ON [dbo].[no_reporte_seguro] 
FOR INSERT
AS

declare @ano smallint,
            @periodo smallint,
            @fecha_ingreso datetime,
            @usuario_ingreso varchar(35),
            @codigo_deduccion char(3),
            @error char(1) 


select @fecha_ingreso = getdate(),
           @usuario_ingreso = system_user

select @ano = ano,
          @periodo = periodo,
         @codigo_deduccion = codigo_seguro
from inserted


update no_reporte_seguro
    set fecha_ingreso = @fecha_ingreso,
         usuario_ingreso = @usuario_ingreso
where ano = @ano
    and periodo = @periodo

exec stp_UDnoGeneraSegSocial @ano, @periodo, @codigo_deduccion, @error out



go

