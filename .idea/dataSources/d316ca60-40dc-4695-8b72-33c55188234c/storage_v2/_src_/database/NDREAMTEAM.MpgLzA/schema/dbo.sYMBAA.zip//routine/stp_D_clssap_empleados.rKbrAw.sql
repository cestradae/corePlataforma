-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_empleados]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_empleado char (10)  )
As DELETE [dbo].[sap_empleados] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
codigo_empleado =  @oldcodigo_empleado)
go

