-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_puestos_ingresos](  @oldcodigo_tipo char (2) ,
  @oldcodigo_puesto char (10) ,
  @oldcodigo_ingreso char (3) ,
  @codigo_tipo char (2) ,
  @codigo_puesto char (10) ,
  @codigo_ingreso char (3) ,
  @monto_inicial money ,
  @monto_final money ,
  @promedio money  )
As 
UPDATE [dbo].[no_puestos_ingresos] Set 
    codigo_tipo = @codigo_tipo,
    codigo_puesto = @codigo_puesto,
    codigo_ingreso = @codigo_ingreso,
    monto_inicial = @monto_inicial,
    monto_final = @monto_final,
    promedio = @promedio 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_puesto =  @oldcodigo_puesto AND 
codigo_ingreso =  @oldcodigo_ingreso )
go

