-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoProcVar]
As
  SELECT procedimiento, descripcion
FROM no_nomina_proc
WHERE tipo_proc = 'V'
go

