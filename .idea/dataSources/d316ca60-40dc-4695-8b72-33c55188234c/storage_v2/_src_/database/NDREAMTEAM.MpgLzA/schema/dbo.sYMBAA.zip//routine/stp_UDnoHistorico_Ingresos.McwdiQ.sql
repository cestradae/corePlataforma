CREATE procedure [dbo].[stp_UDnoHistorico_Ingresos] 
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint
as 

--------------------------------------------
-- Obtiene el historico de Ingresos por periodo de pago
--------------------------------------------
-- Este proceso se llena con cada calculo de nomina 
-- y graba las bases de los ingresos cuyo valor sea > 0
----------------------------------------------------

declare @ano smallint
declare @mes smallint
declare @codigo_empleado char(10)
declare @perioricidad char(1)
declare @codigo_ingreso char(3)
declare @monto money
declare @error int

select @ano = substring(@periodo_id, 3,4)
select @mes = substring(@periodo_id, 7,2)

Begin Tran

delete from no_empleado_ingresos_historico 
  where codigo_tipo = @codigo_tipo
    and periodo_id = @periodo_id
    and grupo_id = @grupo_id
    and no_calculo = @no_calculo

if @@error <> 0
Begin
   Raiserror ('No se puede eliminar el historico de ingresos - stp_UDnoHistorico_Ingresos' ,16,1,5000)
   Rollback work
   Return 9
End

--- Procedemos a insertar el ingreso 

Declare cur_historico_ingresos cursor for
   select b.codigo_empleado,
          b.codigo_ingreso,
          b.perioricidad
   from  no_empleado_ingresos b 
   where b.codigo_tipo = @codigo_tipo



open cur_historico_ingresos
fetch cur_historico_ingresos into @codigo_empleado , @codigo_ingreso, @perioricidad

while @@fetch_status = 0
Begin
--- Procedemos a obtener el costo 

   select @monto = 0
   exec  @error  =  stp_Udno_IngresoMes  
   	     @codigo_tipo ,
	     @codigo_ingreso,
	     @codigo_empleado,
         @ano,
         @mes,
         @monto out 

   if @monto > 0
   Begin
      INSERT INTO no_empleado_ingresos_historico
             ([codigo_empleado]
             ,[codigo_tipo]
             ,[codigo_ingreso]
             ,[periodo_id]
             ,[grupo_id]
             ,[no_calculo]
             ,[perioricidad]
             ,[monto]
             ,[ano]
             ,[mes])
       VALUES
             (@codigo_empleado
             ,@codigo_tipo
             ,@codigo_ingreso
             ,@periodo_id
             ,@grupo_id
             ,@no_calculo
             ,@perioricidad
             ,@monto
             ,@ano
             ,@mes)

      if @@error <> 0
      Begin
         Raiserror ('No se puede insertar no_empleado_ingresos_historico - stp_UDnoHistorico_Ingresos' , 16,1,5000)
         Rollback work
         deallocate cur_historico_ingresos
         return 9
      End
   End
   fetch cur_historico_ingresos into @codigo_empleado , @codigo_ingreso, @perioricidad

End
Close cur_historico_ingresos
deallocate cur_historico_ingresos 

Commit Tran
go

