-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNo_cingresos]
  (  @oldCodigo_ingreso char (3)  )
As SELECT a.codigo_ingreso,a.descripcion,a.linea1_reporte,a.linea2_reporte,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.cuenta_contable,a.nombre_corto FROM [dbo].[no_catalogo_ingresos] a
WHERE (a.codigo_ingreso =  @oldCodigo_ingreso)
go

