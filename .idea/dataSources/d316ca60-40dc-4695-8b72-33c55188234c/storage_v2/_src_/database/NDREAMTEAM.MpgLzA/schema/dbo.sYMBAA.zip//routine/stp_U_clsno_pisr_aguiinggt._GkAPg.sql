
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_pisr_aguiinggt(  @oldcodigo_impuesto char (3) ,
  @oldcodigo_ingreso char (3) ,
  @codigo_ingreso char (3) ,
  @tipo_monto smallint ,
  @no_meses smallint ,
  @tipo_ingreso smallint ,
  @codigo_impuesto char (3)  )
As 
UPDATE [dbo].[no_parametros_isr_aguiinggt] Set 
    codigo_ingreso = @codigo_ingreso,
    tipo_monto = @tipo_monto,
    no_meses = @no_meses,
    tipo_ingreso = @tipo_ingreso,
    codigo_impuesto = @codigo_impuesto 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_ingreso =  @oldcodigo_ingreso )
go

