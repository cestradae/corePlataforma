CREATE PROCEDURE [dbo].[stp_udno_Lookup_igssplanilla]
As

-------------------------------------------------
-- Creado por Jhurtarte
-- Fecha 21/07/2011
-- Lookup de seleccion tipo de planilla
-------------------------------------------------
  SELECT 'O' Codigo , 'Original' Descripcion union all    
  SELECT 'C', 'Complementaria'

go

