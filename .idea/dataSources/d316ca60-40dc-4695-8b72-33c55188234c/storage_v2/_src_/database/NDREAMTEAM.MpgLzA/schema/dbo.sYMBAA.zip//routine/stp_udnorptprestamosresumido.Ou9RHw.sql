CREATE  procedure [dbo].[stp_udnorptprestamosresumido]
--Filtros
	@deduccion1 char(10),
	@deduccion2 char(10),
	@tipo1 char(10),
	@tipo2 char(10),
	@empleado1 char(10),
	@empleado2 char(10)
as

set nocount on
if @deduccion1 = '' select @deduccion1 = min(codigo_deduccion) from no_catalogo_deducciones 
if @deduccion2 = '' select @deduccion1 = max(codigo_deduccion) from no_catalogo_deducciones 
if @empleado1 = '' select @empleado1 = min(codigo_empleado) from no_empleados 
if @empleado2 = '' select @empleado2 = max(codigo_empleado) from no_empleados
if @tipo1 = '' select @tipo1 = min(codigo_tipo) from no_tipos_nomina 
if @tipo2 = '' select @tipo2 = max(codigo_tipo) from no_tipos_nomina 


select  a.codigo_deduccion,
	a.descripcion descripciondeduccion,
	b.codigo_tipo,
	b.descripcion,
	c.codigo_empleaDo,
	c.nombre_usual

into #temp1
	
from  	no_catalogo_deducciones a,
	no_tipos_nomina b,
	no_empleados c

where 	(a.codigo_deduccion between @deduccion1 and @deduccion2) 
	and (b.codigo_tipo between @tipo1 and @tipo2) 
	and (c.codigo_empleado between @empleado1 and @empleado2)


select  a.codigo_deduccion,
	a.descripciondeduccion,
	a.codigo_tipo,
	a.descripcion,
	a.codigo_eMpleado,
	a.nombre_usual,
	b.correlativo,
	b.monto_original,
	b.monto,
	b.cuota,
	b.saldo,
	b.periodo_id

from 	#temp1 a,
	no_deducciones_enc b

where 
	a.codigo_deduccion=b.codigo_deduccion
	and a.codigo_tipo=b.codigo_tipo
	and a.codigo_empleado=b.codigo_empleado
order by b.codigo_deduccion, b.codigo_empleado
go

