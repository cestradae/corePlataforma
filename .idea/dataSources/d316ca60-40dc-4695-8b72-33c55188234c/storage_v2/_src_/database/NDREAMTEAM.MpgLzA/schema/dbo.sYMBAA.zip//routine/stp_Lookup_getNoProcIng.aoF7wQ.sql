-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoProcIng]
As
  SELECT procedimiento, descripcion
FROM no_nomina_proc
WHERE tipo_proc = 'I'
go

