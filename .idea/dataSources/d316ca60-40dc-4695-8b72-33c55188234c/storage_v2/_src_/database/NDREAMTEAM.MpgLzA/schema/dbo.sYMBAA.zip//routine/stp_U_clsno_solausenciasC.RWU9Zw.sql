-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_solausenciasC](  @oldcodigo_empleado char (10) ,
  @oldcorr_solicitud smallint ,
  @codigo_empleado char (10) ,
  @corr_solicitud smallint ,
  @codigo_tipo char (2) ,
  @fecha_solicitud datetime ,
  @dias_solicitar decimal (8,2) ,
  @descuenta_sabados char (1) ,
  @fecha_inicio datetime ,
  @tipo_solicitud char (1) ,
  @motivo char (1) ,
  @observaciones varchar (100) ,
  @dia_descontado char (1) ,
  @estado_solicitud char (10) ,
  @fecha_autoriza datetime ,
  @usuario_autoriza varchar (35) ,
  @fecha_alta datetime ,
  @usuario_alta varchar (35) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_solicitud_ausencias] 
WHERE codigo_empleado =  @oldcodigo_empleado AND 
corr_solicitud =  @oldcorr_solicitud 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_solicitud_ausencias] Set 
    codigo_empleado = @codigo_empleado,
    corr_solicitud = @corr_solicitud,
    codigo_tipo = @codigo_tipo,
    fecha_solicitud = @fecha_solicitud,
    dias_solicitar = @dias_solicitar,
    descuenta_sabados = @descuenta_sabados,
    fecha_inicio = @fecha_inicio,
    tipo_solicitud = @tipo_solicitud,
    motivo = @motivo,
    observaciones = @observaciones,
    dia_descontado = @dia_descontado,
    estado_solicitud = @estado_solicitud,
    fecha_autoriza = @fecha_autoriza,
    usuario_autoriza = @usuario_autoriza,
    fecha_alta = @fecha_alta,
    usuario_alta = @usuario_alta 
WHERE 	( codigo_empleado =  @oldcodigo_empleado AND 
corr_solicitud =  @oldcorr_solicitud )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_solicitud_ausencias]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
corr_solicitud =  @corr_solicitud )
go

