
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_crrenta_hn(  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @codigo_impuesto char (3) ,
  @ano smallint ,
  @mes smallint ,
  @no_cuotas smallint ,
  @fecha_generacion datetime ,
  @usuario_generacion int ,
  @estado char (1) ,
  @fecha_cierre datetime ,
  @usuario_cierre int ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_reporte_renta_hn] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_reporte_renta_hn] Set 
    codigo_impuesto = @codigo_impuesto,
    ano = @ano,
    mes = @mes,
    no_cuotas = @no_cuotas,
    fecha_generacion = @fecha_generacion,
    usuario_generacion = @usuario_generacion,
    estado = @estado,
    fecha_cierre = @fecha_cierre,
    usuario_cierre = @usuario_cierre 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_reporte_renta_hn]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
ano =  @ano AND 
mes =  @mes )
go

