-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_bitacora_det_clssap_bitacora_encRelated]
(  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldcalculo int  )
  As 
SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.calculo,a.correlativo,a.cuenta_contable,a.cargos,a.abonos,a.codigo_asociado,a.codigo_centro,a.nombre_asociado,a.nombre_centro FROM [dbo].[sap_bitacora_det] a
WHERE 
a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id AND 
a.grupo_id =  @oldgrupo_id AND 
a.calculo =  @oldcalculo
go

