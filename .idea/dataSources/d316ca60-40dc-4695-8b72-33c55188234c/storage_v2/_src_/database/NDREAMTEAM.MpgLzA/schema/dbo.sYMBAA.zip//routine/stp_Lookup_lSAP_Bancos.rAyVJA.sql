-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_Bancos]
As
  SELECT bankcode, bankname Banco
  FROM sap_tr_bancos
  ORDER BY bankname
go

