-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_prentahn_ingresos](@AUTO_EditStamp varchar(30) OUT,
  @codigo_impuesto char (3) ,
  @codigo_ingreso char (3)  )
As 
	INSERT INTO [dbo].[no_parametros_rentahn_ingresos]
(  codigo_impuesto ,
  codigo_ingreso  )
VALUES (  @codigo_impuesto ,
  @codigo_ingreso  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_parametros_rentahn_ingresos]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
codigo_ingreso =  @codigo_ingreso )
go

