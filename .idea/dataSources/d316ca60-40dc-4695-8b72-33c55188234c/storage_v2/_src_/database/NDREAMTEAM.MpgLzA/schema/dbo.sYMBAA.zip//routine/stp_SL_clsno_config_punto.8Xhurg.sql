-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_config_punto]
  As SELECT a.codigo_tipo FROM [dbo].[no_configuracion_punto] a
go

