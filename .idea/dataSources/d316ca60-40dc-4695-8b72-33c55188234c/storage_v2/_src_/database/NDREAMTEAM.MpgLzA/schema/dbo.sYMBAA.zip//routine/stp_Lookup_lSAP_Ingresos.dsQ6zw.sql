-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_Ingresos]
As
  SELECT codigo_ingreso, codigo_ingreso +' - '+ descripcion Ingreso
 FROM no_catalogo_ingresos
ORDER BY descripcion
go

