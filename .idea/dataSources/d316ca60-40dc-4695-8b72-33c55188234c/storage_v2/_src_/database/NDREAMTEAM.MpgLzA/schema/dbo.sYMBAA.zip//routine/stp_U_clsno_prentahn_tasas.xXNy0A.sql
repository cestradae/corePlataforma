-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_prentahn_tasas](  @oldcodigo_impuesto char (3) ,
  @oldcorrelativo smallint ,
  @codigo_impuesto char (3) ,
  @correlativo smallint ,
  @monto_de money ,
  @monto_a money ,
  @tasa decimal (18,4) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_parametros_rentahn_tasas] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
correlativo =  @oldcorrelativo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_parametros_rentahn_tasas] Set 
    codigo_impuesto = @codigo_impuesto,
    correlativo = @correlativo,
    monto_de = @monto_de,
    monto_a = @monto_a,
    tasa = @tasa 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
correlativo =  @oldcorrelativo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_parametros_rentahn_tasas]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
correlativo =  @correlativo )
go

