-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_parametros]
  (  @oldcodigo_tipo char (2)  )
As SELECT a.codigo_tipo,a.procedimiento_nomina,a.procedimiento_provisionesq,a.servidor,a.basedatos,a.usuario,a.clave,a.tipo_servidor,a.cuenta_salios_sap,a.lenguaje,a.UsuarioDB,a.ClaveDB FROM [dbo].[sap_parametros] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo)
go

