-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_cdeducciones_depto](@AUTO_EditStamp varchar(30) OUT,
  @codigo_deduccion char (3) ,
  @codigo_departamento smallint ,
  @cuenta_contable varchar (30)  )
As 
	INSERT INTO [dbo].[no_catalogo_deducciones_depto]
(  codigo_deduccion ,
  codigo_departamento ,
  cuenta_contable  )
VALUES (  @codigo_deduccion ,
  @codigo_departamento ,
  @cuenta_contable  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_catalogo_deducciones_depto]
  WHERE ( codigo_deduccion =  @codigo_deduccion AND 
codigo_departamento =  @codigo_departamento )
go

