-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_cprovisiones]
  (  @oldcodigo_provision char (3)  )
As DELETE [dbo].[no_catalogo_provisiones] 
WHERE (codigo_provision =  @oldcodigo_provision)
go

