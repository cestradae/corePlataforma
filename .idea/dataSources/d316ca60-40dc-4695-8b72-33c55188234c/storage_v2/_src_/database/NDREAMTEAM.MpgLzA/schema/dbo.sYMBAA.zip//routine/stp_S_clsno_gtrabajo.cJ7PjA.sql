-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_gtrabajo]
  (  @oldgrupo_trabajo smallint  )
As SELECT a.grupo_trabajo,a.nombre_grupo,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_grupos_trabajo] a
WHERE (a.grupo_trabajo =  @oldgrupo_trabajo)
go

