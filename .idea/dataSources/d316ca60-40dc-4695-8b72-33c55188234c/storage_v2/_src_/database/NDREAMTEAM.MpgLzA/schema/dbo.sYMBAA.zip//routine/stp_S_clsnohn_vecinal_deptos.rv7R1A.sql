-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsnohn_vecinal_deptos]
  (  @oldimpuesto_vecinal smallint ,
  @oldcodigo_departamento smallint  )
As SELECT a.impuesto_vecinal,a.codigo_departamento,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_vechn_deptos] a
WHERE (a.impuesto_vecinal =  @oldimpuesto_vecinal AND 
a.codigo_departamento =  @oldcodigo_departamento)
go

