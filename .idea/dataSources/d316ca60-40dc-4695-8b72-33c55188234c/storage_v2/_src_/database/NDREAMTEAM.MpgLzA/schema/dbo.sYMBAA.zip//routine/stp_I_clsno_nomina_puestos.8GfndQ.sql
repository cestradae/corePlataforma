-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_nomina_puestos](  @codigo_puesto char (10) ,
  @codigo_tipo char (2) ,
  @fecha_asignacion datetime  )
As 
	INSERT INTO [dbo].[no_nomina_puestos]
(  codigo_puesto ,
  codigo_tipo ,
  fecha_asignacion  )
VALUES (  @codigo_puesto ,
  @codigo_tipo ,
  @fecha_asignacion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

