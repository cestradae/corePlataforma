CREATE FUNCTION [dbo].[func_MontoAnticipos] (@codigo_proveedor varchar(20) )  
RETURNS money AS  
BEGIN 
---
-- Creado por lsao
-- fecha 03-11-2007
-- monto anticipos del proveedor 
declare @resultado money

select @resultado = sum(saldo)
from cp_abonos_a_cuenta
where codigo_proveedor = @codigo_proveedor
and saldo > 0

if @resultado is null select @resultado = 0

return @resultado

END
go

