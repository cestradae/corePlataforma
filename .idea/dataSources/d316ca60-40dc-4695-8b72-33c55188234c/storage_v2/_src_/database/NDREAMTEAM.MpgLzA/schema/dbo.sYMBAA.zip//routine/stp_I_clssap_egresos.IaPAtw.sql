-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_egresos](  @codigo_tipo char (2) ,
  @codigo_deduccion char (3) ,
  @cuenta_sap nchar (15)  )
As 
	INSERT INTO [dbo].[sap_egresos]
(  codigo_tipo ,
  codigo_deduccion ,
  cuenta_sap  )
VALUES (  @codigo_tipo ,
  @codigo_deduccion ,
  @cuenta_sap  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

