CREATE procedure [dbo].[stp_UDnoAnalisisEmpleadosVariables]
   @tipo_inicial char(2),
   @tipo_final char(2),
   @fecha_inicial datetime,
   @fecha_final datetime
as
--------------------------------------------------------------
-- Hecho por lsao
-- Fecha 12/06/2008
-- Asunto Consulta de Variables Reportadas 
---------------------------------------------------------------
set nocount on

declare @periodo_inicial char(10)
declare @periodo_final char(10)

select @periodo_inicial = min(periodo_id)
from no_periodos_pago
where fecha_inicial >= @fecha_inicial

select @periodo_final = max(periodo_id)
from no_periodos_pago
where fecha_final <= @fecha_final


select @fecha_final = @fecha_final  + ' 23:59:59' 


select a.codigo_tipo,
       a.periodo_id,
       a.grupo_id,
       a.codigo_empleado,
       a.codigo_departamento,
       a.codigo_centro,
       a.codigo_valor codigo,
       a.valor cantidad ,
       b.valor valor,
       c.codigo_valor+' ' +c.descripcion descripcion,
       d.codigo_puesto,
       d.codigo_seccion,
       a.fecha_reporte,
       a.correlativo,
       e.codigo_clase +' '+e.descripcion Clase,
       e.tipo_valor ,
       c.unidad_medida
into #DetalleValores 
from no_reporte_valores_ingreso a, no_nomina_valores b,  no_valores_reportados c, no_empleados d,
     no_clases_variables e
where a.codigo_tipo between @tipo_inicial and @tipo_final
  and a.fecha_reporte between @fecha_inicial and @fecha_final
  and a.codigo_tipo = b.codigo_tipo
  and a.codigo_valor = b.codigo_valor
  and a.codigo_valor = c.codigo_valor
  and a.codigo_empleado = d.codigo_empleado
  and c.codigo_clase *= e.codigo_clase


select a.codigo_tipo+ '-'+ g.descripcion TipoNomina,
       convert(char(10),f.fecha_inicial,103) + '-'+ convert(char(10),f.fecha_final,103) Periodo,
       i.descripcion Grupo,
       a.codigo_empleado + '-' + c.nombre_usual nombre,
       isnull(d.nombre_centro,'<Sin Centro>') Centro,
       a.codigo,
       a.cantidad cantidad ,
       a.valor,
       round(a.cantidad * a.valor,2) total,
       a.descripcion,
       b.descripcion Departamento,
       isnull(e.descripcion,'<Sin Puesto>') Puesto,
       isnull(h.nombre_seccion, '<Sin Sección>') Seccion,
       a.fecha_reporte fecha,
       a.correlativo,
       a.clase,
       a.tipo_valor + j.descripcion tipo,
       a.unidad_medida
from #DetalleValores a, gn_departamentos b, no_empleados c, cn_catalogo_centros d,
      no_puestos e, no_periodos_pago f, no_tipos_nomina g, no_secciones h,
      no_grupos_valores i, no_tipos_valores j
where a.codigo_departamento *= b.codigo_departamento
  and a.codigo_empleado *= c.codigo_empleado
  and a.codigo_centro *= d.codigo_centro
  and a.codigo_puesto *= e.codigo_puesto
  and a.periodo_id = f.periodo_id
  and a.codigo_tipo = g.codigo_tipo
  and a.codigo_seccion *= h.codigo_seccion
  and a.grupo_id = i.grupo_id
go

