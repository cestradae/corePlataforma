
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_pisr_aguiinggt
  As SELECT a.codigo_ingreso,a.tipo_monto,a.no_meses,a.tipo_ingreso,a.codigo_impuesto FROM [dbo].[no_parametros_isr_aguiinggt] a
go

