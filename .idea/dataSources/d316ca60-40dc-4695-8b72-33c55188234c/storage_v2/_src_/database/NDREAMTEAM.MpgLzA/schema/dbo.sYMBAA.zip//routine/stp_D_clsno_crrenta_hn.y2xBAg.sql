
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_crrenta_hn
  (  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint  )
As DELETE [dbo].[no_reporte_renta_hn] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes)
go

