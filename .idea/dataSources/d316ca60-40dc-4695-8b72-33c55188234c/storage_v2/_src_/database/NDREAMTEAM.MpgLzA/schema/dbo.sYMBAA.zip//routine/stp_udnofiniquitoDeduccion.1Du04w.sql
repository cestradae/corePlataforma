Create procedure [dbo].[stp_udnofiniquitoDeduccion]
   @codigo_tipo char(2),
   @grupo_id char(5),
   @periodo_id char(10),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @codigo_valor char(10)
as 
set nocount on

----------------------
-- Hecho por ldr
-- fecha 03/03/2011
-- Para presentar una deduccion
----------------------

declare @strsql varchar(100)

select isnull(sum(monto_deduccion),0) monto
into #Deducciones 
from no_nomina_det
where codigo_tipo = @codigo_tipo
and grupo_id = @grupo_id
and periodo_id = @periodo_id
and no_calculo= @no_calculo
and codigo_empleado = @codigo_empleado
and codigo_deduccion = substring(@codigo_valor,1,3) 

if  ( select count(*) from #Deducciones ) = 0
   select @strsql = 'Select 0.00 deduccion'+@codigo_valor 
else
   select @strsql = 'Select monto deduccion'+@codigo_valor + ' from #Deducciones'


exec (@strsql)

drop table #Deducciones
go

