
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_pisr_vargt(  @oldcodigo_impuesto char (3) ,
  @oldcodigo_variable char (10) ,
  @codigo_impuesto char (3) ,
  @codigo_variable char (10) ,
  @tipo_variable smallint ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_parametros_isr_vargt] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_variable =  @oldcodigo_variable 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_parametros_isr_vargt] Set 
    codigo_impuesto = @codigo_impuesto,
    codigo_variable = @codigo_variable,
    tipo_variable = @tipo_variable 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_variable =  @oldcodigo_variable )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_parametros_isr_vargt]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
codigo_variable =  @codigo_variable )
go

