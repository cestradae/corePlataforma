-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_sausencias]
  As SELECT a.codigo_empleado,a.corr_solicitud,a.fecha_solicitud,a.codigo_tipo,a.dias_solicitar,a.descuenta_sabados,a.fecha_inicio,a.tipo_solicitud,a.observaciones,a.dia_descontado,a.estado_solicitud,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_solicitud_ausencias] a 
        where estado_solicitud = 'O'
go

