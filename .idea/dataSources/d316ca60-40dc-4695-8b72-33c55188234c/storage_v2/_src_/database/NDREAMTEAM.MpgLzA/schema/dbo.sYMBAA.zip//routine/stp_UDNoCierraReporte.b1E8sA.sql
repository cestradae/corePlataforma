CREATE procedure [dbo].[stp_UDNoCierraReporte]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @no_reporte smallint 
as

---------------------------------------------------------------
--Creado por LSAO
--Fecha 07/07/2003
--Asunto Pone el reporte como Cerrado para no poderse modificar  
---------------------------------------------------------------
begin tran
update no_reporte_valores
   set estado_reporte = 'A'
where codigo_tipo =@codigo_tipo
  and periodo_id = @periodo_id
  and no_reporte = @no_reporte

if @@error <> 0 
begin
   raiserror ( 'Reporte no se pudo Cerrar - stp_UDNoCierraReporte ', 16,1,5000)
   rollback tran
   return
end
commit tran
go

