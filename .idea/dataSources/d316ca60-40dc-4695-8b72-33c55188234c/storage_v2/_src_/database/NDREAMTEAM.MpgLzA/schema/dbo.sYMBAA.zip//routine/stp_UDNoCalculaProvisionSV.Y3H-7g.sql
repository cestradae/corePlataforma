CREATE procedure [dbo].[stp_UDNoCalculaProvisionSV]

       @codigo_tipo char(2),
       @periodo_id  char(10),
       @codigo_provision char(3),
       @codigo_ingreso char(3),
       @porcentaje decimal(8,4),
       @lleva_saldo char(1),
       @grupo_id char(5),
       @no_calculo smallint

as

 

-------------------------------------------------------------------------------------

--Creado por LSAO

--Fecha 25/08/2003

--Calculo de cuota patronal del IGSS

-------------------------------------------------------------------------------------

declare @periodo_inicial char(10),

         @periodo_final   char(10),

         @ano smallint,

         @periodo smallint

 

Declare @Total       money
Declare @BoniDecreto money
Declare @sumTotal money
Declare @sumAsueto money
Declare @sumSeptimo money
Declare @Asueto      money
Declare @septimos    money
Declare @codigo_empleado char(10)
Declare @valor money
Declare @monto_ingreso money

 

Create table #Temporal (

      codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
      total money,
      codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
      cuenta_sap varchar(15) COLLATE Modern_Spanish_CI_AS,
      codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS

  )

 

Create table #Bonificacion (

      codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
      codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
      Bonificacion money,
      codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS

  )

 

 

Create table #Asuetos (

      codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
      codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
      Asueto money,
      codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS

  )

 

 

Create table #Septimos (

      codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
      codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
      Septimo money,
      codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS

  )

 

 

select @ano = ano,
        @periodo = periodo
from no_periodos_pago
where periodo_id = @periodo_id

 

insert into #temporal

select a.codigo_valor,

        total ,

        a.codigo_centro,

        isnull(b.cuenta_sap,d.codigo_clase),

        a.codigo_empleado

from no_reporte_valores_ingreso a, sap_valores_reportados_ing b, no_valores_reportados c,

      no_clases_variables d

where a.codigo_tipo = @codigo_tipo

and periodo_id = @periodo_id

and grupo_id = @grupo_id

and no_calculo = @no_calculo

and a.tipo_valor = 1

and b.codigo_tipo = @codigo_tipo

and a.codigo_valor *= b.codigo_valor

and b.codigo_ingreso = @codigo_ingreso

and total > 0

and a.codigo_valor = c.codigo_valor

and c.codigo_clase = d.codigo_clase

 

 

select codigo_centro, cuenta_sap, sum(total) Total into #Tareas from #temporal group by codigo_centro, cuenta_sap

 

select @Total = sum(total)
from #Tareas

 

select codigo_empleado, sum(total) Total into #TotalEmpleado from #Temporal group by codigo_empleado
 

select codigo_centro, codigo_valor, sum(a.total) Total,convert(decimal(18,8),(convert(decimal(18,8),sum(a.total))/convert(decimal(18,8),b.total))) Factor, a.codigo_empleado 
into #Factores from #temporal a, #TotalEmpleado b 
where a.codigo_empleado = b.codigo_empleado 
group by a.codigo_centro, a.codigo_valor, a.codigo_empleado, b.total

 

select @Asueto = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '04'

 

select @Septimos = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '05'


 

select codigo_empleado, sum(monto_ingreso) monto_ingreso 
into #TotalBoni 
from no_nomina_det 
where codigo_tipo = @codigo_tipo and periodo_id = @periodo_id 
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '03'

group by codigo_empleado

 

 

INSERT INTO #Bonificacion

 

select a.codigo_valor, a.codigo_centro, round(b.monto_ingreso *Factor,2) Bonificacion , a.codigo_empleado 
from #Factores a, #TotalBoni b where a.codigo_empleado = b.codigo_empleado group by a.codigo_valor, a.codigo_centro, a.codigo_empleado, b.monto_ingreso, factor

Declare cur_mov_prov cursor for
     select  a.codigo_empleado, sum(bonificacion), monto_ingreso
     from #Bonificacion a,  #totalBoni b
     where a.codigo_empleado = b.codigo_empleado
     group by a.codigo_empleado , monto_ingreso
     having sum(bonificacion) <> monto_ingreso

 

open cur_mov_prov

fetch cur_mov_prov into  @codigo_empleado, @valor, @monto_ingreso while @@fetch_status = 0 Begin

    set rowcount 1

    update #Bonificacion

       set Bonificacion = Bonificacion + @monto_ingreso - @valor

    where codigo_empleado = @codigo_empleado

    set rowcount 0

    fetch cur_mov_prov into @codigo_empleado, @valor, @monto_ingreso End close cur_mov_prov deallocate cur_mov_prov

 

print 'salio'

select codigo_empleado, sum(monto_ingreso) monto_ingreso 
into #TotalAsueto 
from no_nomina_det 
where codigo_tipo = @codigo_tipo 
and periodo_id = @periodo_id 
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '04'

group by codigo_empleado

 

 

 

INSERT INTO #Asuetos

select a.codigo_valor, a.codigo_centro, round(b.monto_ingreso *

Factor,2) Bonificacion , a.codigo_empleado from #Factores a, #TotalAsueto b where a.codigo_empleado = b.codigo_empleado

  group by a.codigo_valor, a.codigo_centro, a.codigo_empleado, b.monto_ingreso, factor

 

 

Declare cur_mov_prov cursor for

     select  a.codigo_empleado, sum(Asueto), monto_ingreso

     from #Asuetos a,  #totalAsueto b

     where a.codigo_empleado = b.codigo_empleado

     group by a.codigo_empleado , monto_ingreso

     having sum(asueto) <> monto_ingreso

 

open cur_mov_prov

fetch cur_mov_prov into  @codigo_empleado, @valor, @monto_ingreso while @@fetch_status = 0 Begin

    set rowcount 1

    update #Asuetos

       set Asueto = Asueto + @monto_ingreso - @valor

    where codigo_empleado = @codigo_empleado

    set rowcount 0

    fetch cur_mov_prov into @codigo_empleado, @valor, @monto_ingreso End close cur_mov_prov deallocate cur_mov_prov

 

 

select codigo_empleado, sum(monto_ingreso) monto_ingreso 
into #TotalSeptimos 
from no_nomina_det 
where codigo_tipo = @codigo_tipo 
and periodo_id = @periodo_id 
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '05'
group by codigo_empleado



INSERT INTO #Septimos

select a.codigo_valor, a.codigo_centro, round(b.monto_ingreso * Factor,2) Bonificacion , a.codigo_empleado 
from #Factores a, #totalSeptimos b 
where a.codigo_empleado = b.codigo_empleado 
group by a.codigo_valor, a.codigo_centro, a.codigo_empleado, b.monto_ingreso, factor
 

Declare cur_mov_prov cursor for

     select  a.codigo_empleado, sum(Septimo), monto_ingreso
     from #Septimos a,  #totalSeptimos b
     where a.codigo_empleado = b.codigo_empleado
     group by a.codigo_empleado , monto_ingreso
     having sum(septimo) <> monto_ingreso



open cur_mov_prov

fetch cur_mov_prov into  @codigo_empleado, @valor, @monto_ingreso while @@fetch_status = 0 Begin

    set rowcount 1

    update #Septimos

       set septimo = septimo + @monto_ingreso - @valor

    where codigo_empleado = @codigo_empleado

    set rowcount 0

    fetch cur_mov_prov into @codigo_empleado, @valor, @monto_ingreso End close cur_mov_prov deallocate cur_mov_prov

 

 

---------------

-- Procedemos a calcular el Ordinario

---------------

 

INSERT INTO #Temporal

   select a.codigo_valor, Bonificacion * -1, a.codigo_centro, isnull(b.cuenta_sap,d.codigo_clase), a.codigo_empleado

   from #Bonificacion a , sap_valores_reportados_ing b, no_valores_reportados c, no_clases_variables d

   where b.codigo_tipo = @codigo_tipo

     and b.codigo_tipo = @codigo_tipo

     and a.codigo_valor *= b.codigo_valor

     and b.codigo_ingreso = @codigo_ingreso

     and a.codigo_valor = c.codigo_valor

     and c.codigo_clase = d.codigo_clase

 

 

 

INSERT INTO #Temporal

   select a.codigo_valor, Asueto, a.codigo_centro, isnull(b.cuenta_sap,d.codigo_clase), a.codigo_empleado

   from #Asuetos a , sap_valores_reportados_ing b , no_valores_reportados c, no_clases_variables d

   where b.codigo_tipo = @codigo_tipo

     and b.codigo_tipo = @codigo_tipo

     and a.codigo_valor *= b.codigo_valor

     and b.codigo_ingreso = @codigo_ingreso

     and a.codigo_valor = c.codigo_valor

     and c.codigo_clase = d.codigo_clase

 

 

INSERT INTO #Temporal

   select a.codigo_valor, Septimo, a.codigo_centro, isnull(b.cuenta_sap,d.codigo_clase), a.codigo_empleado

   from #Septimos a , sap_valores_reportados_ing b , no_valores_reportados c, no_clases_variables d

   where b.codigo_tipo = @codigo_tipo

     and b.codigo_tipo = @codigo_tipo

     and a.codigo_valor *= b.codigo_valor

     and b.codigo_ingreso = @codigo_ingreso

     and a.codigo_valor = c.codigo_valor

     and c.codigo_clase = d.codigo_clase

 

Begin Tran

 

delete from no_provisiones_sap

    where codigo_tipo = @codigo_tipo

     and periodo_id = @periodo_id

     and codigo_provision = @codigo_provision

 

Insert into no_provisiones_empleados (

    codigo_tipo ,

    periodo_id ,

    codigo_provision ,

    codigo_empleado ,

    codigo_departamento ,

    codigo_centro  ,

    porcentaje,

    monto_base,

    monto_provision,

    saldo_provision )

 

select @codigo_tipo,

        @periodo_id,

        @codigo_provision ,

        a.codigo_empleado,

        b.codigo_departamento,

        a.codigo_centro,

        @porcentaje,

        sum(total),

        round(sum(total)/42 * 52 * @porcentaje  /100,2),

        round(sum(total)/42 * 52 * @porcentaje  /100,2) from #Temporal a, no_empleados b, no_empleado_provision_enc c where a.codigo_empleado = b.codigo_empleado

  and a.codigo_empleado = c.codigo_empleado

  and c.codigo_tipo = @codigo_tipo

  and c.codigo_provision = @codigo_provision group by a.codigo_empleado, codigo_departamento, a.codigo_centro

 

if @@error <> 0

begin

    raiserror ('No se pudo insertar el detalle de cuota patronal - stp_UDNoCalcCuota_IGSS ' , 16,1,5000 )

    rollback tran

    return

end

 

 

insert into no_provisiones_sap (

   codigo_tipo,

   periodo_id,

   codigo_provision,

   codigo_empleado,

   cuenta_sap,

   monto_provision,

   codigo_centro )

 

select @codigo_tipo,

        @periodo_id,

        @codigo_provision ,

        a.codigo_empleado,

        a.cuenta_sap,

        round(sum(total)/42*52 * @porcentaje /100,2),

        a.codigo_centro

from #Temporal a, no_empleado_provision_enc b where a.codigo_empleado = b.codigo_empleado

   and b.codigo_provision = @codigo_provision

   and b.codigo_tipo = @codigo_tipo

group by a.codigo_empleado, cuenta_sap, codigo_centro

 

 

if @@error <> 0

begin

    raiserror ('No se pudo insertar el detalle de cuota patronal - stp_UDNoCalcaCuotaSV', 16,1,5000 )

    rollback tran

    return

end

 

Commit tran
go

