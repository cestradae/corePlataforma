create procedure [dbo].[stp_UDnoFormula44]   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(18,4) out ) AS

  declare @SSDiasSGS decimal(18,4) 

begin
   select @SSDiasSGS = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSDiasASG' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 

  set @result=30-@SSDiasSGS
end
go

