-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_ffiniquitos_det_clsno_ffiniquito_gtRelated]
(  @oldcodigo_formato smallint  )
  As 
SELECT a.codigo_formato,a.correlativo,a.nombre_procedimiento,a.tipo_resultado,a.prefijo,a.no_meses,a.codigo_valor,a.condensa FROM [dbo].[no_formatos_finiquitos_det] a
WHERE 
a.codigo_formato =  @oldcodigo_formato
go

