-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_centros]
As
  SELECT PrcCode, PrcName Centro
  FROM sap_tr_centros
  ORDER BY PrcName
go

