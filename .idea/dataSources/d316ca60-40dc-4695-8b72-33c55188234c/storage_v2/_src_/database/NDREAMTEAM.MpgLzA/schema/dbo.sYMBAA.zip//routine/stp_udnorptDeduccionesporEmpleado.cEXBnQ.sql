
CREATE	procedure [dbo].[stp_udnorptDeduccionesporEmpleado]
--filtros
	@tipo char(10),
	@periodo1 char (10),
	@periodo2 char (10),
	@deduccion1 char (10),
	@deduccion2 char (10),
	@empleado1 char (10),
	@empleado2 char (10),
	@depto1 char (10),
	@depto2 char (10)
as
set nocount on

if @deduccion1 = '' select @deduccion1 = min(codigo_deduccion) from no_catalogo_deducciones 
if @deduccion2 = '' select @deduccion1 = max(codigo_deduccion) from no_catalogo_deducciones 
if @empleado1 = '' select @empleado1 = min(codigo_empleado) from no_empleados 
if @empleado2 = '' select @empleado2 = max(codigo_empleado) from no_empleados


select a.codigo_tipo, b.descripcion des_tipo, c.fecha_inicial, c.fecha_final,
	a.codigo_deduccion, d.descripcion des_deduccion, a.codigo_departamento,
	e.descripcion des_depto, a.codigo_empleado, f.nombre_usual,
	a.monto_deduccion, a.monto_base,convert(varchar(10),c.fecha_inicial,103)+'-'+convert(varchar(10),c.fecha_final,103) des_fecha,
	g.descripcion des_grupo, a.no_calculo,
	a.periodo_id	
from    no_nomina_det a, no_tipos_nomina b, no_periodos_pago c, 
	no_catalogo_deducciones d, gn_departamentos e, no_empleados f,
	no_grupos_valores g
where a.codigo_deduccion between @deduccion1 and @deduccion2 and
	a.codigo_tipo = @tipo and
	a.periodo_id between @periodo1 and @periodo2 and
	a.codigo_empleado between @empleado1 and @empleado2 and
	a.codigo_departamento between @depto1 and @depto2 and
	a.codigo_tipo = b.codigo_tipo and
	a.periodo_id = c.periodo_id and
	a.codigo_deduccion = d.codigo_deduccion and
	a.codigo_departamento = e.codigo_departamento and
	a.codigo_empleado = f.codigo_empleado and
	a.grupo_id = g.grupo_id and 
	a.monto_deduccion > 0

order by a.codigo_tipo,
	 a.codigo_departamento,	
	a.codigo_empleado

go

