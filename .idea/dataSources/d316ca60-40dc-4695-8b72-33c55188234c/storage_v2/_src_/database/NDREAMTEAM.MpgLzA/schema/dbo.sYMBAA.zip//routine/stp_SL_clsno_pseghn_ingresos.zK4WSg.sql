-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_pseghn_ingresos]
  As SELECT TOP 1000 a.codigo_seguro,a.ingreso_afecto FROM [dbo].[no_parametros_seghn_ingresos] a
go

