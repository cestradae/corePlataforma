create procedure stp_UDnoFormula68   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @tmp1 decimal(18,4)
declare @tmp2 decimal(18,4)
declare @VMESAGUIBONO decimal(22,6) 
declare @tmp4 decimal(18,4) 
declare @tmp3 decimal(18,4) 
declare @DIASBONO decimal(22,6) 

begin
  exec stp_UDnoPromUMesesIngresos 'Ord',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  12 ,  @tmp1 out
exec stp_UDnoBasUMesesIngresos 'Boni_Ince',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  12 ,  @tmp2 out
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '001       ' ) = '1'  begin Select @VMESAGUIBONO= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '001       ' end else begin Select @VMESAGUIBONO= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '001       ' end 
if ((isnull(@VMESAGUIBONO,0)=0)) select @tmp4=1 else select @tmp4=isnull(@VMESAGUIBONO,0)
if ((isnull(@VMESAGUIBONO,0)>12)) select @tmp3=12 else select @tmp3=@tmp4
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '09        ' ) = '1'  begin Select @DIASBONO= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '09        ' end else begin Select @DIASBONO= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '09        ' end 

  set @result=(@tmp1+@tmp2/@tmp3)/365*isnull(@DIASBONO,0)
end
go

