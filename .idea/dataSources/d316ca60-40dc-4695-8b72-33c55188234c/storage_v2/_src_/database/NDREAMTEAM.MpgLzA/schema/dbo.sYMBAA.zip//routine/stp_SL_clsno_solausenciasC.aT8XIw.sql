-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_solausenciasC]
  As SELECT a.codigo_empleado,a.corr_solicitud,a.codigo_tipo,a.fecha_solicitud,a.dias_solicitar,a.descuenta_sabados,a.fecha_inicio,a.tipo_solicitud,a.motivo,a.observaciones,a.dia_descontado,a.estado_solicitud,a.fecha_autoriza,a.usuario_autoriza,a.fecha_alta,a.usuario_alta,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_solicitud_ausencias] a
go

