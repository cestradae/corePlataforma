
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_ffiniquito_gt
  (  @oldcodigo_formato smallint  )
As SELECT a.codigo_formato,a.descripcion_formato,a.nombre_formato FROM [dbo].[no_formatos_finiquitos] a
WHERE (a.codigo_formato =  @oldcodigo_formato)
go

