-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_bitacora_det]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldcalculo int ,
  @oldcorrelativo int  )
As DELETE [dbo].[sap_bitacora_det] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
calculo =  @oldcalculo AND 
correlativo =  @oldcorrelativo)
go

