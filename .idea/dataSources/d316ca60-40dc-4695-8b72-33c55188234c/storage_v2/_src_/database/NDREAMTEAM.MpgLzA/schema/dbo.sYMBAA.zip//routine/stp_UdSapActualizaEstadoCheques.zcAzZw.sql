--                exec stp_UdSapActualizaEstadoCheques '01','0120100502','015  ',0,0,12252

CREATE procedure [dbo].[stp_UdSapActualizaEstadoCheques] --'01','0220081101',0,0,null
  @codigo_tipo char(2),
  @periodo char(10),
  @grupo char(5),
  @no_pago smallint,
  @no_pago2 SMALLINT,
  @numero_cheque INT
as
  
	BEGIN TRAN

   update no_nomina_emplcalc_det
	set trasladado = 'S'
   where  --estado_cheque = 'I' and 
		codigo_tipo = @codigo_tipo
    and periodo_id = @periodo
    and grupo_id = @grupo
    and no_calculo between @no_pago AND @no_pago2  
	and trasladado = 'N'
	and numero_cheque = @numero_cheque

	IF @@error <> 0 
	BEGIN
		raiserror ( ' No se pudo Actualizar trasladado en no_nomina_emplcalc_det - [stp_UdSapActualizaEstadoCheques] ', 16,1,5000)
		ROLLBACK work
		return
	END

	COMMIT TRAN    

Return
go

