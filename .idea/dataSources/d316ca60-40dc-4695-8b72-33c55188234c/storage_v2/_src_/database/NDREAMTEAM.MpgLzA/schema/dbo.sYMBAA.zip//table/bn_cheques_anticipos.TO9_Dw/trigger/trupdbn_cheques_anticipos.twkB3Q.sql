CREATE TRIGGER [dbo].[trupdbn_cheques_anticipos] ON [dbo].[bn_cheques_anticipos] 
FOR UPDATE
AS

----------------------------------------------------------------------------------
-- Modificado por lsao
-- fecha 27-11-2007
-- Asunto : Creo para que grabe la partida
--------------------------------------------------------------------------------------
declare @cuenta_anticipo varchar(30)
declare @centro_anticipo varchar(20)
declare @monto_anticipo money,
             @codigo_banco smallint,
             @id_cuenta varchar(32),
             @codigo_tipo smallint,
             @numero_cheque int,
             @correlativo smallint,
              @codigo_proveedor varchar(20),
              @cta smallint,
             @moneda_cheque smallint,
             @moneda_proveedor smallint,
             @es_localcheque char(1),
             @es_localproveedor char(1),
             @tasa_cheque decimal(18,4)



if update (cta)
    return

select @monto_anticipo = monto_anticipo,
          @codigo_banco = codigo_banco,
          @id_cuenta = id_cuenta,
          @codigo_tipo = codigo_tipo,
          @numero_cheque = numero_cheque,
          @codigo_proveedor = codigo_proveedor,
          @cta = cta
from deleted

Begin Tran

delete from bn_cheques_det
   where codigo_banco = @codigo_banco
       and id_cuenta = @id_cuenta
       and codigo_tipo= @codigo_tipo
      and numero_cheque = @numero_cheque
     and correlativo = @cta

if @@error <> 0
Begin
    Raiserror ('No se puede eliminar la cuenta contable - trupdbn_cheques_anticipos',16,1,5000)
    Rollback work
    Return
End


select @cuenta_anticipo = cuenta_anticipo
from bn_generales

select @monto_anticipo = monto_anticipo,
          @codigo_banco = codigo_banco,
          @id_cuenta = id_cuenta,
          @codigo_tipo = codigo_tipo,
          @numero_cheque = numero_cheque,
          @codigo_proveedor = codigo_proveedor
from inserted 

select @moneda_cheque = a.codigo_moneda ,
           @es_localcheque = es_local,
           @tasa_cheque= tasa_cambio
from bn_cheques_enc a, gn_monedas b
where a.codigo_banco = @codigo_banco
    and a.id_cuenta = @id_cuenta
    and a.codigo_tipo = @codigo_tipo
    and a.numero_cheque = @numero_cheque
    and a.codigo_moneda = b.codigo_moneda 

select @moneda_proveedor = a.codigo_moneda,
           @es_localproveedor = es_local
from cp_proveedores a, gn_monedas b
where a.codigo_proveedor = @codigo_proveedor
   and a.codigo_moneda = b.codigo_moneda 

---- Procedemos a insertar el valor

if @moneda_proveedor <> @moneda_cheque 
Begin
   if @es_localcheque = 'S'
   Begin
        select @monto_anticipo = round(@monto_anticipo * @tasa_cheque,2)
   End
   Else
   Begin
      if @es_localproveedor = 'S'
      Begin
           select @monto_anticipo = round(@monto_anticipo / @tasa_cheque,2)
      End
   End
End

---- Procedemos a insertar el valor
select @correlativo = max(correlativo) + 1
from bn_cheques_det
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque

if @correlativo is null select @correlativo = 1
Insert into bn_cheques_det ( 
codigo_banco, 
id_cuenta,
codigo_tipo,
numero_cheque,
correlativo,
cuenta_contable,
cargo )
values (
@codigo_banco,
@id_cuenta,
@codigo_tipo,
@numero_cheque,
@correlativo,
@cuenta_anticipo,
@monto_anticipo )

if @@error <> 0
Begin
   Raiserror ('No se pueden actualizar las cuentas de anticipos - trupdbn_cheques_anticipos', 16,1,5000)
   Rollback work
   Return
End

update bn_cheques_anticipos
    set cta = @correlativo
where codigo_banco = @codigo_banco
    and id_cuenta  = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and codigo_proveedor = @codigo_proveedor


if @@error <> 0
Begin
   Raiserror ('No se pueden actualizar la cta de anticipos en el movmiento - trupdbn_cheques_anticipos', 16,1,5000)
   Rollback work
   Return

End

Commit Tran


go

