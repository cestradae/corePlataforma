-------------------------------------------------------------
--Creado por Daniel Ortiz
--Fecha 15/01/2011
--Asunto Se unifico el trigger de trino_liquidaciones y trinsno_liquidaciones
-------------------------------------------------------------
-------------------------------------------------------------
--Creado por Daniel Ortiz
--Fecha 10/01/2011
--Asunto Si el porcentaje de liquidacion es mayor a 100% no debe de guardar
-------------------------------------------------------------
----------------
-- Cambio hecho por dortiz
-- Fecha 25-11-2010
-- Valida que el grupo de pago este asociado al tipo de Nomina
----------------
CREATE TRIGGER trinsno_liquidaciones
   ON  no_liquidaciones
 FOR INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

DECLARE @porcentaje DECIMAL
declare      @codigo_tipo VARCHAR(2),
             @grupo_id smallint,
             @validaciongrupo SMALLINT

SELECT @porcentaje=por_indemnizacion,
		@codigo_tipo = codigo_tipo,
          @grupo_id = grupo_id
FROM INSERTED

IF @porcentaje>100
BEGIN
	RAISERROR ('El porcentaje no puede ser mayor a 100 - trino_liquidaciones',16,1,5000)
	return 
END


SELECT @validaciongrupo=grupo_id
 FROM dbo.no_grupos_valores
		WHERE grupo_id=@grupo_id
		AND codigo_tipo=@codigo_tipo
		
if @validaciongrupo is  null 
BEGIN 
   Raiserror ('El grupo de pago no esta asociado a la Nomina ', 16,1,5000)
   Rollback work
   Return 
END 

END


go

