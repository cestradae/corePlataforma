-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_parametros](  @oldcodigo_tipo char (2) ,
  @codigo_tipo char (2) ,
  @procedimiento_nomina varchar (50) ,
  @procedimiento_provisionesq varchar (50) ,
  @servidor varchar (30) ,
  @basedatos varchar (20) ,
  @usuario varchar (20) ,
  @clave varchar (20) ,
  @tipo_servidor smallint ,
  @cuenta_salios_sap varchar (15) ,
  @lenguaje smallint ,
  @UsuarioDB varchar (20) ,
  @ClaveDB varchar (20)  )
As 
UPDATE [dbo].[sap_parametros] Set 
    codigo_tipo = @codigo_tipo,
    procedimiento_nomina = @procedimiento_nomina,
    procedimiento_provisionesq = @procedimiento_provisionesq,
    servidor = @servidor,
    basedatos = @basedatos,
    usuario = @usuario,
    clave = @clave,
    tipo_servidor = @tipo_servidor,
    cuenta_salios_sap = @cuenta_salios_sap,
    lenguaje = @lenguaje,
    UsuarioDB = @UsuarioDB,
    ClaveDB = @ClaveDB 
WHERE 	( codigo_tipo =  @oldcodigo_tipo )
go

