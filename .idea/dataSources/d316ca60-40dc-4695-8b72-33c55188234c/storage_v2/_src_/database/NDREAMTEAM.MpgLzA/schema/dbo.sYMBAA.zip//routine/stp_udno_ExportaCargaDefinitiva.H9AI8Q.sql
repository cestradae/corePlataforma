--stp_udno_ExportaCargaDefinitiva '36','36',1,6,2010
create PROCEDURE [dbo].[stp_udno_ExportaCargaDefinitiva]
		@codigo_tipoI	CHAR(2),
		@codigo_tipoF	CHAR(2),
		@periodoI	SMALLINT,
		@periodoF	SMALLINT,
		@ano	SMALLINT
		
AS
------------------------------------------------
--Cambio por Daniel Ortiz
--Fecha:02/02/2011
-- Agrupa por nit sinimportar que este en varias nominas
------------------------------------------------
------------------------------------------------
--Cambio por Daniel Ortiz
--Fecha:02/02/2011
--Toma empleados de alta con fecha de baja null 
--  y fecha de baja igual a fecha de inicio relacion laboral
------------------------------------------------
------------------------------------------------
--Cambio por Daniel Ortiz
--Fecha:02/02/2011
--Si no cuenta con telefono o fax escribe 0 (cero)
-- se agrego tablas de parametrizacion de nomina, ingresos, deducciones
------------------------------------------------
------------------------------------------------
--Cambio por Mario Juarros
--Fecha:22/06/2010
--Se modifico para que agrupara por NIT y no por codigo de empleado, se agrega filtro por mes, se agrega campo de telefono
--que hacia falta para el proceso.
------------------------------------------------

------------------------------------------------
--Hecho por Mario Juarros
--Fecha:17/11/2009
--Procedimiento para exportar la Carga de definitiva.
------------------------------------------------

SET NOCOUNT ON

DECLARE @cod_tipo CHAR(10),
		@nit VARCHAR(30),
		@monto	MONEY,
		@impuesto	MONEY,
		@nombre_campo	VARCHAR(10),
		@valor	MONEY,
		@deduccion MONEY
		

CREATE TABLE #CargaDef (
		codigo_tipo			CHAR(2) COLLATE Modern_Spanish_CI_AS,
		codigo_empleado		CHAR (10) COLLATE Modern_Spanish_CI_AS,
		nit					VARCHAR (30) COLLATE Modern_Spanish_CI_AS,
		Nombre				VARCHAR (150) COLLATE Modern_Spanish_CI_AS,
		calle_avenida		VARCHAR (10) COLLATE Modern_Spanish_CI_AS,
		numero_casa			VARCHAR (5) COLLATE Modern_Spanish_CI_AS,
		apartamento			VARCHAR (10) COLLATE Modern_Spanish_CI_AS,
		zona				SMALLINT,
		colonia_barrio		VARCHAR (35) COLLATE Modern_Spanish_CI_AS,
		codigo_depto		SMALLINT,
		codigo_municipio	SMALLINT,
		telefono			VARCHAR(50) COLLATE Modern_Spanish_CI_AS,
		fax					VARCHAR(50) COLLATE Modern_Spanish_CI_AS,
		apartado_postal		VARCHAR(10) COLLATE Modern_Spanish_CI_AS,
		correo_e			VARCHAR(65) COLLATE Modern_Spanish_CI_AS,
		fecha_inicio_rel	DATETIME,
		fecha_fin_rel		DATETIME,
		renta_neta			MONEY,
		total_renta_neta	MONEY,
		deduccion_personal	MONEY,
		cuota_igss			MONEY,
		primas_seguro		MONEY,
		gastos_medicos		MONEY,
		pensiones			MONEY,
		otras_deducciones	MONEY,
		otros_gastos		MONEY,
		total_deducciones	MONEY,
		renta_imponible		MONEY,
		impuesto_anual		MONEY,
		credito_x_iva		MONEY,
		impuesto_anual_def	MONEY,
		otros_creditos		MONEY,
		subtotal			MONEY,
		retenciones_practicadas	MONEY,
		impuesto_a_retener	MONEY,
		impuesto_retenido_exceso	MONEY,
		numero_constancia	SMALLINT,
		valor_constancia	MONEY,
		)
		
CREATE TABLE #impuestoanual (
	codigo_tipo	CHAR(2)COLLATE Modern_Spanish_CI_AS,
	nit	VARCHAR(30)COLLATE Modern_Spanish_CI_AS,
	impuesto	MONEY,
)		

CREATE TABLE #impuestodefinitivo (
	codigo_tipo	CHAR(2)COLLATE Modern_Spanish_CI_AS,
	nit	VARCHAR(30)COLLATE Modern_Spanish_CI_AS,
	impuesto	MONEY,
)

CREATE TABLE #impuestoret (
	codigo_tipo	CHAR(2)COLLATE Modern_Spanish_CI_AS,
	nit	VARCHAR(30)COLLATE Modern_Spanish_CI_AS,
	impuesto	MONEY,
)

--Insertamos valores generales del empleado
INSERT INTO #CargaDef (
	codigo_tipo,
	codigo_empleado,
	nit,
	Nombre,
	calle_avenida,
	numero_casa,
	apartamento,
	zona,
	colonia_barrio,
	codigo_depto,
	codigo_municipio,
	telefono,
	fax,
	apartado_postal,
	correo_e,	
	fecha_inicio_rel,
	fecha_fin_rel,
	deduccion_personal
) SELECT b.codigo_tipo, a.codigo_empleado, numero_tributario, nombres + ' ' + apellidos + ' ' + ISNULL(apellido_casada,'') NombreCompleto, calle_avenida, numero_casa, apartamento, 
zona, colonia_barrio, sextendida_depto, c.codigo_alterno, telefono, fax, apartado_postal, correo_e, fecha_inicio_rel_lab, NULL, 36000.00 
FROM dbo.no_empleados AS a
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
LEFT JOIN no_siex_municipios c
ON a.sextendida_depto = c.codigo_departamento
AND a.sextendida_municipio = c.codigo_municipio
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF) AND
	--a.estado_empleado = 'A' AND --Activo
	numero_tributario IS NOT NULL AND 
	LEN(RTRIM(LTRIM(numero_tributario)))>0 AND	
	a.fecha_baja <= a.fecha_inicio_rel_lab and
	b.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
	
UNION ALL

SELECT b.codigo_tipo, a.codigo_empleado, numero_tributario, nombres + ' ' + apellidos + ' ' + ISNULL(apellido_casada,'') NombreCompleto, calle_avenida, numero_casa, apartamento, 
zona, colonia_barrio, sextendida_depto, c.codigo_alterno, telefono, fax, apartado_postal, correo_e, fecha_inicio_rel_lab, NULL, 36000.00 
FROM dbo.no_empleados AS a
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
LEFT JOIN no_siex_municipios c
ON a.sextendida_depto = c.codigo_departamento
AND a.sextendida_municipio = c.codigo_municipio
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF) AND
	a.estado_empleado = 'A' AND --Activo
	numero_tributario IS NOT NULL AND 
	LEN(RTRIM(LTRIM(numero_tributario)))>0 AND	
	a.fecha_baja IS NULL and
	b.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
	
UNION ALL

SELECT b.codigo_tipo, a.codigo_empleado, numero_tributario, nombres + ' ' + apellidos + ' ' + ISNULL(apellido_casada,'') NombreCompleto, calle_avenida, numero_casa, apartamento, 
zona, colonia_barrio, sextendida_depto, c.codigo_alterno, telefono, fax, apartado_postal, correo_e, fecha_inicio_rel_lab, fecha_baja, 36000.00 
FROM dbo.no_empleados AS a
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
LEFT JOIN no_siex_municipios c
ON a.sextendida_depto = c.codigo_departamento
AND a.sextendida_municipio = c.codigo_municipio
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF) AND
	--a.estado_empleado = 'A' AND --Activo
	numero_tributario IS NOT NULL AND 
	LEN(RTRIM(LTRIM(numero_tributario)))>0 AND	
	a.fecha_baja > a.fecha_inicio_rel_lab AND
	 b.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
	
UPDATE #CargaDef SET nit = REPLACE(nit,'-','')
UPDATE #CargaDef SET nit = REPLACE(nit,' ','')
UPDATE #CargaDef SET nit = REPLACE(nit,',','')

--Obtenemos solo los que tienen retencion ISR
SELECT DISTINCT codigo_empleado
INTO #excluye
FROM dbo.no_nomina_det
WHERE codigo_deduccion = '02' AND --Retencion ISR
	(codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)AND
	CONVERT(SMALLINT,SUBSTRING(periodo_id,3,4))=@ano
	AND codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
	
--Borramos todos los que no tienen retencion ISR
DELETE FROM #CargaDef 
WHERE codigo_empleado NOT IN (SELECT codigo_empleado FROM #excluye)

--Obtenemos los periodos del año
SELECT codigo_tipo, ano, periodo, periodo_id
INTO #periodospago
FROM dbo.no_periodos_pago
WHERE ano = @ano AND 
periodo BETWEEN @periodoI AND @periodoF AND
codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF
AND codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
--Renta neta es igual a total renta neta.

--Se calcula el total de ingresos
SELECT a.codigo_tipo, d.nit, SUM(a.monto_ingreso)monto_ingreso
INTO #totalingresos
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_ingresos AS b
ON (a.codigo_ingreso = b.codigo_ingreso AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
INNER JOIN #CargaDef d
ON a.codigo_empleado = d.codigo_empleado
WHERE (a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)
AND a.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
AND a.codigo_ingreso in ( select codigo_ingreso from no_ingreso_afecto_isr_gt)
GROUP BY a.codigo_tipo, d.nit
ORDER BY nit

--Se calcula el total de egresos
SELECT a.codigo_tipo, d.nit, SUM(a.monto_deduccion)monto_deduccion
INTO #totalegresos
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_deducciones AS b
ON (a.codigo_deduccion = b.codigo_deduccion AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
INNER JOIN #CargaDef d
ON a.codigo_empleado = d.codigo_empleado
WHERE (a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)
AND a.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
AND a.codigo_deduccion in ( select codigo_deduccion from no_deduccion_afecto_isr_gt)
GROUP BY a.codigo_tipo, d.nit
ORDER BY d.nit


--Se calcula el total de cuota laboral
SELECT a.codigo_tipo, d.nit, SUM(a.monto_deduccion)cuota_laboral
INTO #cuota_laboral
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_deducciones AS b
ON (a.codigo_deduccion = b.codigo_deduccion AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
INNER JOIN #CargaDef d
ON a.codigo_empleado = d.codigo_empleado
WHERE a.codigo_deduccion = '01' AND --Cuota Laboral
(a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)
AND a.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
GROUP BY a.codigo_tipo, d.nit
ORDER BY d.nit

--Se calcula la renta imponible
SELECT a.codigo_tipo, a.nit, (monto_ingreso - monto_deduccion)renta_imponible
INTO #rentaimponible
FROM #totalingresos AS a 
INNER JOIN #totalegresos AS b
ON (a.nit = b.nit AND
	a.codigo_tipo = b.codigo_tipo)

--Calculamos el impuesto anual a pagar
DECLARE curimpuesto CURSOR FOR
	SELECT codigo_tipo, nit, renta_imponible FROM #rentaimponible
OPEN curimpuesto
FETCH curimpuesto INTO @cod_tipo, @nit, @monto
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @impuesto = 0
			--Se calcula el impuesto anual a pagar según tabla de sat
			IF @monto <= 65000
				SELECT @impuesto = (@monto * 0.15)
			IF @monto > 65000 AND @monto <= 180000
				SELECT @impuesto = 9750.00 + ((@monto - 65000)* 0.20)
			IF @monto > 180000 AND @monto <= 295000
				SELECT @impuesto = 32750.00 + ((@monto - 180000)* 0.25)
			IF @monto >	295000
				SELECT @impuesto = 61500.00 + ((@monto - 295000)* 0.31)
				
			INSERT INTO #impuestoanual (
				codigo_tipo,
				nit,
				impuesto
			) VALUES ( 
				@cod_tipo,
				@nit,
				@impuesto ) 	
				
			FETCH curimpuesto INTO @cod_tipo, @nit, @monto	
		END
CLOSE curimpuesto
DEALLOCATE curimpuesto

--Calculamos el Credito por IVA
SELECT @nombre_campo = 'iva' + CONVERT(VARCHAR,@ano)

SELECT b.codigo_tipo, c.nit, nombre_campo, a.valor 
INTO #creditoiva
FROM dbo.no_empleado_campos AS a 
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
INNER JOIN #CargaDef c
ON a.codigo_empleado = c.codigo_empleado
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF) AND
		a.nombre_campo = @nombre_campo
		AND b.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)


--Calculamos el impuesto anual definitivo
DECLARE curimpuestodefinitivo CURSOR for
SELECT a.codigo_tipo, a.nit, impuesto, valor FROM #impuestoanual AS a
INNER JOIN #creditoiva AS b
ON (a.nit = b.nit AND
	a.codigo_tipo = b.codigo_tipo)
OPEN curimpuestodefinitivo
FETCH curimpuestodefinitivo INTO @cod_tipo, @nit, @impuesto, @valor	
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @monto = 0
			SELECT @monto = @impuesto - @valor
			
			INSERT INTO #impuestodefinitivo (
				codigo_tipo,
				nit,
				impuesto
			) VALUES ( 
				@cod_tipo,
				@nit,
				@monto ) 
			FETCH curimpuestodefinitivo INTO @cod_tipo, @nit, @impuesto, @valor
		END
CLOSE curimpuestodefinitivo
DEALLOCATE curimpuestodefinitivo

--Subtotal es igual a impuesto anual a pagar ya que no se manejan otros creditos

--Calculamos el monto de retenciones practicadas
SELECT a.codigo_tipo, d.nit, SUM(a.monto_deduccion)monto_deduccion
INTO #totalretpracticada
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_deducciones AS b
ON (a.codigo_deduccion = b.codigo_deduccion AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
INNER JOIN #CargaDef d
ON a.codigo_empleado = d.codigo_empleado
WHERE a.codigo_deduccion = '02' AND --Retencion ISR
(a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)
AND a.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)
GROUP BY a.codigo_tipo, d.nit
ORDER BY d.nit

--Calculamos el impuesto a retener
DECLARE curimpuestoret CURSOR for
SELECT a.codigo_tipo, a.nit, a.impuesto, b.monto_deduccion FROM #impuestoanual AS a
INNER JOIN #totalretpracticada AS b
ON (a.nit = b.nit AND
	a.codigo_tipo = b.codigo_tipo)
OPEN curimpuestoret
FETCH curimpuestoret INTO @cod_tipo, @nit, @impuesto, @deduccion
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @monto = @impuesto - @deduccion
			
			INSERT INTO #impuestoret (
				codigo_tipo,
				nit,
				impuesto
			) VALUES ( 
				@cod_tipo,
				@nit,
				@monto) 
			FETCH curimpuestoret INTO @cod_tipo, @nit, @impuesto, @deduccion
		END
CLOSE curimpuestoret
DEALLOCATE curimpuestoret

--Impuesto retenido en exceso es igual al impuesto a retener segun documento que enviaron

--Obtenemos los numeros de constancia
SELECT @nombre_campo = 'nconst' + CONVERT(VARCHAR,@ano)

SELECT b.codigo_tipo, c.nit, nombre_campo, a.valor 
INTO #nconstancia
FROM dbo.no_empleado_campos AS a 
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
INNER JOIN #CargaDef c
ON a.codigo_empleado = c.codigo_empleado
WHERE (b.codigo_tipo between @codigo_tipoI AND @codigo_tipoF) AND
		a.nombre_campo = @nombre_campo
		AND b.codigo_tipo in ( select codigo_tipo from no_nomina_afecto_isr_gt)

--Valor constancia = retencion practicada

--Actualizamos datos de la tabla temporal.
update #CargaDef set renta_neta = (SELECT monto_ingreso 
FROM #totalingresos 
WHERE #cargadef.nit	= #totalingresos.nit AND
		#cargadef.codigo_tipo = #totalingresos.codigo_tipo)

update #CargaDef set total_renta_neta = (SELECT monto_ingreso 
FROM #totalingresos 
WHERE #cargadef.nit	= #totalingresos.nit AND
		#cargadef.codigo_tipo = #totalingresos.codigo_tipo)

update #CargaDef set cuota_igss = (SELECT cuota_laboral
FROM #cuota_laboral 
WHERE #cargadef.nit	= #cuota_laboral.nit AND
		#cargadef.codigo_tipo = #cuota_laboral.codigo_tipo)
		
update #CargaDef set total_deducciones = (SELECT monto_deduccion
FROM #totalegresos 
WHERE #cargadef.nit	= #totalegresos.nit	AND
		#cargadef.codigo_tipo = #totalegresos.codigo_tipo)
		
update #CargaDef set renta_imponible = (SELECT renta_imponible
FROM #rentaimponible 
WHERE #cargadef.nit	= #rentaimponible.nit AND
		#cargadef.codigo_tipo = #rentaimponible.codigo_tipo)
		
update #CargaDef set impuesto_anual = (SELECT impuesto
FROM #impuestoanual 
WHERE #cargadef.nit	= #impuestoanual.nit AND
		#cargadef.codigo_tipo = #impuestoanual.codigo_tipo)
		
update #CargaDef set credito_x_iva = (SELECT valor
FROM #creditoiva 
WHERE #cargadef.nit	= #creditoiva.nit AND
		#cargadef.codigo_tipo = #creditoiva.codigo_tipo)
		
update #CargaDef set impuesto_anual_def = (SELECT impuesto
FROM #impuestodefinitivo 
WHERE #cargadef.nit	= #impuestodefinitivo.nit AND
		#cargadef.codigo_tipo = #impuestodefinitivo.codigo_tipo)

update #CargaDef set subtotal = (SELECT impuesto
FROM #impuestoanual 
WHERE #cargadef.nit	= #impuestoanual.nit AND
		#cargadef.codigo_tipo = #impuestoanual.codigo_tipo)
		
update #CargaDef set retenciones_practicadas = (SELECT monto_deduccion
FROM #totalretpracticada 
WHERE #cargadef.nit	= #totalretpracticada.nit AND
		#cargadef.codigo_tipo = #totalretpracticada.codigo_tipo)
		
update #CargaDef set impuesto_a_retener = (SELECT impuesto
FROM #impuestoret 
WHERE #cargadef.nit	= #impuestoret.nit AND
		#cargadef.codigo_tipo = #impuestoret.codigo_tipo)
		
update #CargaDef set impuesto_retenido_exceso = (SELECT impuesto
FROM #impuestoret 
WHERE #cargadef.nit	= #impuestoret.nit AND
		#cargadef.codigo_tipo = #impuestoret.codigo_tipo)
		
update #CargaDef set numero_constancia = (SELECT valor
FROM #nconstancia 
WHERE #cargadef.nit	= #nconstancia.nit AND
		#cargadef.codigo_tipo = #nconstancia.codigo_tipo)
		
update #CargaDef set valor_constancia = (SELECT monto_deduccion
FROM #totalretpracticada 
WHERE #cargadef.nit	= #totalretpracticada.nit AND
		#cargadef.codigo_tipo = #totalretpracticada.codigo_tipo)

SELECT  ISNULL(nit,'')nit,ISNULL(Nombre,'')Nombre,ISNULL(calle_avenida,'')calle_avenida,ISNULL(numero_casa,'')numero_casa,ISNULL(apartamento,'')apartamento,
ISNULL(zona,'')zona,ISNULL(colonia_barrio,'')colonia_barrio,ISNULL(codigo_depto,'')codigo_depto,ISNULL(codigo_municipio,'')codigo_municipio,ISNULL(telefono,0)telefono,ISNULL(fax,0)fax,
ISNULL(apartado_postal,'')apartado_postal,ISNULL(correo_e,'')correo_e,ISNULL(fecha_inicio_rel,'')fecha_inicio_rel,ISNULL(fecha_fin_rel,'')fecha_fin_rel,
ISNULL(SUM(renta_neta),'')renta_neta,ISNULL(SUM(total_renta_neta),'')total_renta_neta,ISNULL(deduccion_personal,'')deduccion_personal,ISNULL(SUM(cuota_igss),'')cuota_igss,
ISNULL(SUM(primas_seguro),'')primas_seguro,ISNULL(SUM(gastos_medicos),'')gastos_medicos,ISNULL(SUM(pensiones),'')pensiones,ISNULL(SUM(otras_deducciones),'')otras_deducciones,
ISNULL(SUM(otros_gastos),'')otros_gastos,ISNULL(SUM(total_deducciones),'')total_deducciones,ISNULL(SUM(renta_imponible),'')renta_imponible,ISNULL(SUM(impuesto_anual),'')impuesto_anual,
ISNULL(SUM(credito_x_iva),'')credito_x_iva,ISNULL(SUM(impuesto_anual_def),'')impuesto_anual_def,ISNULL(SUM(otros_creditos),'')otros_creditos,ISNULL(SUM(subtotal),'')subtotal,
ISNULL(SUM(retenciones_practicadas),'')retenciones_practicadas,ISNULL(SUM(impuesto_a_retener),'')impuesto_a_retener,ISNULL(SUM(impuesto_retenido_exceso),'')impuesto_retenido_exceso,
/*ISNULL(numero_constancia,'')*/0 numero_constancia,ISNULL(SUM(valor_constancia),'')valor_constancia
FROM #CargaDef
GROUP BY nit, Nombre,calle_avenida,numero_casa,apartamento,zona,colonia_barrio,codigo_depto,codigo_municipio,telefono,fax,
apartado_postal,correo_e,fecha_inicio_rel,fecha_fin_rel,deduccion_personal
go

