-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_No_empleado_campos](@AUTO_EditStamp varchar(30) OUT,
  @Codigo_empleado char (10) ,
  @Nombre_campo varchar (10) ,
  @Valor_lista varchar (20) ,
  @Valor varchar (50)  )
As 
	INSERT INTO [dbo].[no_empleado_campos]
(  codigo_empleado ,
  nombre_campo ,
  valor_lista ,
  valor  )
VALUES (  @Codigo_empleado ,
  @Nombre_campo ,
  @Valor_lista ,
  @Valor  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_empleado_campos]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
nombre_campo =  @Nombre_campo AND 
valor_lista =  @Valor_lista )
go

