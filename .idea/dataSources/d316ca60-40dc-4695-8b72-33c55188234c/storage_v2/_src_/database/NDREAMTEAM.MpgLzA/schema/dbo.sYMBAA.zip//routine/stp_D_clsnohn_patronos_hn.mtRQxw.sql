
-- Procedure definition
CREATE PROCEDURE stp_D_clsnohn_patronos_hn
  (  @oldcodigo_patrono smallint  )
As DELETE [dbo].[no_patronos_hn] 
WHERE (codigo_patrono =  @oldcodigo_patrono)
go

