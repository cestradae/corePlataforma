-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_No_empleado_campos](  @oldCodigo_empleado char (10) ,
  @oldNombre_campo varchar (10) ,
  @oldValor_lista varchar (20) ,
  @Codigo_empleado char (10) ,
  @Nombre_campo varchar (10) ,
  @Valor_lista varchar (20) ,
  @Valor varchar (50) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_empleado_campos] 
WHERE codigo_empleado =  @oldCodigo_empleado AND 
nombre_campo =  @oldNombre_campo AND 
valor_lista =  @oldValor_lista 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_empleado_campos] Set 
    codigo_empleado = @Codigo_empleado,
    nombre_campo = @Nombre_campo,
    valor_lista = @Valor_lista,
    valor = @Valor 
WHERE 	( codigo_empleado =  @oldCodigo_empleado AND 
nombre_campo =  @oldNombre_campo AND 
valor_lista =  @oldValor_lista )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_empleado_campos]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
nombre_campo =  @Nombre_campo AND 
valor_lista =  @Valor_lista )
go

