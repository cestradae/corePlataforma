-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clssap_provisiones]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_provision char (3)  )
As SELECT a.codigo_tipo,a.codigo_provision,a.cuenta_sap,a.cuenta_sap_gasto FROM [dbo].[sap_provisiones] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.codigo_provision =  @oldcodigo_provision)
go

