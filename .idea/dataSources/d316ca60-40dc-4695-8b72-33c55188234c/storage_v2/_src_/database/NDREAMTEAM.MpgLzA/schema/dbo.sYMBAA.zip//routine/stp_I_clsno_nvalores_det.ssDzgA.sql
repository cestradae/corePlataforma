-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_nvalores_det](@AUTO_EditStamp varchar(30) OUT,
  @codigo_tipo char (2) ,
  @codigo_valor char (10) ,
  @codigo_dato char (10) ,
  @unidad varchar (10) ,
  @estandar decimal (18,4) ,
  @orden smallint ,
  @obligatorio char (1)  )
As 
	INSERT INTO [dbo].[no_nomina_valores_det]
(  codigo_tipo ,
  codigo_valor ,
  codigo_dato ,
  unidad ,
  estandar ,
  orden ,
  obligatorio  )
VALUES (  @codigo_tipo ,
  @codigo_valor ,
  @codigo_dato ,
  @unidad ,
  @estandar ,
  @orden ,
  @obligatorio  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_nomina_valores_det]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
codigo_valor =  @codigo_valor AND 
codigo_dato =  @codigo_dato )
go

