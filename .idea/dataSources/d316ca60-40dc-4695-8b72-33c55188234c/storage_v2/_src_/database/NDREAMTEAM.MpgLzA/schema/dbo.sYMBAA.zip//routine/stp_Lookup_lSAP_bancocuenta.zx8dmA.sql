-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_bancocuenta]
As
  SELECT dfltacct, dfltacct Cuenta FROM sap_tr_bancos
where dfltacct is not null and dfltacct <> ''
go

