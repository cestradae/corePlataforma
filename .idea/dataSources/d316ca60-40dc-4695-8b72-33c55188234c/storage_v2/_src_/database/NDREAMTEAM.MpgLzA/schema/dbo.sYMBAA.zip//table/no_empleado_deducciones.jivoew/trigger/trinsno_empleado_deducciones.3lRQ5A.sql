CREATE TRIGGER [dbo].[trinsno_empleado_deducciones] ON dbo.no_empleado_deducciones 
FOR INSERT, UPDATE
AS

-------------------------------------------------------------------------------------------------------------------
-- Creado por LSAO
-- Fecha 03/07/2003
-- Asunto Actualizacion de perioricidad en las deducciones
----------------------------------------------------------------------------------------------------------------------

update no_empleado_deducciones
     set no_empleado_deducciones.perioricidad = no_nomina_deducciones.perioricidad
from no_nomina_deducciones , inserted
where inserted.codigo_tipo = no_empleado_deducciones.codigo_tipo
    and inserted.codigo_empleado = no_empleado_deducciones.codigo_empleado
    and inserted.codigo_deduccion = no_empleado_deducciones.codigo_deduccion 
    and inserted.codigo_tipo = no_nomina_deducciones.codigo_tipo
    and inserted.codigo_deduccion = no_nomina_deducciones.codigo_deduccion


go

