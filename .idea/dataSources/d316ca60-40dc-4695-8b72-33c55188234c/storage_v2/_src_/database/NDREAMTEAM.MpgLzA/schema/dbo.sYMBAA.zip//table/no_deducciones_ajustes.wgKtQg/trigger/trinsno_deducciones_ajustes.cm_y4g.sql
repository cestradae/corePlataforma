CREATE TRIGGER [dbo].[trinsno_deducciones_ajustes] ON dbo.no_deducciones_ajustes 
FOR INSERT
AS

declare @fecha datetime,
            @usuario varchar(35)

select @fecha = getdate(),
          @usuario = system_user

------------------------------------
--Actualizamos la fecha y el usuario de ajuste
------------------------------------

update no_deducciones_ajustes 
    set fecha_ajuste = GETDATE(),
         usuario_ajuste = system_user
from inserted
where no_deducciones_ajustes.codigo_empleado = inserted.codigo_empleado
   and no_deducciones_ajustes.codigo_tipo = inserted.codigo_tipo
   and no_deducciones_ajustes.codigo_deduccion = inserted.codigo_deduccion
   and no_deducciones_ajustes.correlativo = inserted.correlativo
   and no_deducciones_ajustes.corr_ajuste = inserted.corr_ajuste

if @@error <> 0
begin
   raiserror ('No se pudo actualizar la fecha de ingreso en los ajustes - trinsno_deducciones_ajustes',16,1,5000 )
   rollback work
   return
end

update no_deducciones_enc
   set monto = monto + inserted.monto_ajuste,
        saldo = saldo + inserted.monto_ajuste
from inserted 
where no_deducciones_enc.codigo_empleado = inserted.codigo_empleado
   and no_deducciones_enc.codigo_tipo = inserted.codigo_tipo
   and no_deducciones_enc.codigo_deduccion = inserted.codigo_deduccion
   and no_deducciones_enc.correlativo = inserted.correlativo

if @@error <> 0
begin
   raiserror ('No se pudo actualizar el monto del ajuste al saldo - trinsno_deducciones_ajustes',16,1,5000 )
   rollback work
   return
end



go

