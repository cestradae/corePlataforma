CREATE PROC [dbo].[stp_udnotiponominapuntoremoto]
AS
----------------------------------------------
--Hecho por Mario Juarros
--09/06/2010
--obtiene el tipo de nomina que posee el punto remoto
----------------------------------------------
SET NOCOUNT ON	

SELECT codigo_tipo FROM dbo.no_configuracion_punto
go

