-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_nempleado](@AUTO_EditStamp varchar(30) OUT,
  @Codigo_empleado char (10) ,
  @Codigo_tipo char (2) ,
  @Fecha_asignacion datetime ,
  @Usuario_asignacion varchar (35)  )
As 
	INSERT INTO [dbo].[no_nomina_empleado]
(  codigo_empleado ,
  codigo_tipo ,
  fecha_asignacion ,
  usuario_asignacion  )
VALUES (  @Codigo_empleado ,
  @Codigo_tipo ,
  @Fecha_asignacion ,
  @Usuario_asignacion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_nomina_empleado]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
codigo_tipo =  @Codigo_tipo )
go

