
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_pisr_vargt
  As SELECT a.codigo_impuesto,a.codigo_variable,a.tipo_variable,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_isr_vargt] a
go

