CREATE procedure [dbo].[stp_UDNoCalculoProvFormula]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo int,
   @codigo_provision char(3)
as 
----------------------------------------------------------------
--Cambio por dortiz
--Fecha 31/01/2012
--Asunto Se agrego el campo codigo_seccion
----------------------------------------------------------------
----------------------------------------------------------------
--Cambio por dortiz
--Fecha 01/04/2011
--Asunto Se arreglo el calculo para cuando un empleadoe esta asignado a varias nominas
-- solo calcula para la nomina seleccionada.
----------------------------------------------------------------
----------------------------------------------------------------
--Cambio por LDR
--Fecha 19/10/2010
--Asunto Calculo de provisiones estaba tomando mal el departamento y centro de costo
----------------------------------------------------------------
----------------------------------------------------------------
--Cambio por LSAO
--Fecha 27/11/2008
--Asunto Calculo de deducciones por formula para la nomina.
----------------------------------------------------------------
----------------------------------------------------------------
--Creado por LSAO
--Fecha 04/08/2008
--Asunto Calculo de deducciones por formula para la nomina.
----------------------------------------------------------------
declare @nombreproc varchar(60)
declare @codigo_formula char(5)
declare @resultado decimal(22,4)
declare @codigo_empleado char(10)
declare @codigo_departamento smallint
declare @codigo_centro varchar(20)
declare @porcentaje decimal(18,4)
declare @codigo_seccion VARCHAR(5)

create table #Empleados (
	codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS ,
	codigo_departamento smallint,
	codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS ,
	codigo_seccion VARCHAR(5) COLLATE Modern_Spanish_CI_AS 
)

insert into #Empleados (
codigo_empleado,
	codigo_departamento,
	codigo_centro,
	codigo_seccion
)
select codigo_empleado,
	codigo_departamento,
	codigo_centro,
	codigo_seccion 

from no_nomina_det a, no_generales b
where a.codigo_tipo = @codigo_tipo
and a.periodo_id = @periodo_id
and a.grupo_id = @grupo_id
and a.no_calculo = @no_calculo
and a.codigo_ingreso=b.ing_ordinario


if not exists (select 1 from #Empleados)
begin 

	insert into #Empleados (
		codigo_empleado,
		codigo_departamento,
		codigo_centro,
		codigo_seccion
	)
	select codigo_empleado,
		codigo_departamento,
		codigo_centro,
		codigo_seccion 
	from no_nomina_det a
	inner join no_nomina_provisiones b
		on a.codigo_tipo=b.codigo_tipo
	where a.codigo_tipo = @codigo_tipo
	and a.periodo_id = @periodo_id
	and a.grupo_id = @grupo_id
	and a.no_calculo = @no_calculo
	and (a.codigo_ingreso=b.codigo_ingreso
	or  a.codigo_deduccion=b.codigo_deduccion)

end 

-- Buscamos la formula asociada al ingreso que se esta trabajando
select @codigo_formula = codigo_formula
from no_nomina_provisiones
where codigo_tipo = @codigo_tipo
  and codigo_provision = @codigo_provision

select @nombreproc = 'stp_UDnoFormula' + @codigo_formula

if not exists ( select 1 from sysobjects where name = @nombreproc )
Begin
   Raiserror ('Formula no ha sido correctamente definida - stp_UDNoCalculoProvFormula',16,1,5000)
   Return 9
End
-- Procedemos a crear los ingresos

Begin Tran 
declare cur_formula_calculo_prov cursor for

    select a.codigo_empleado,
           isnull(e.codigo_departamento,a.codigo_departamento),
           isnull(e.codigo_centro,a.codigo_centro),
           isnull(e.codigo_seccion,a.codigo_seccion)
    from  no_empleados a
    INNER JOIN  no_nomina_empleado b
		 ON a.codigo_empleado = b.codigo_empleado 
    INNER JOIN no_empleado_provision_enc c
		ON a.codigo_empleado = c.codigo_empleado  
		AND b.codigo_tipo=c.codigo_tipo
		AND b.codigo_tipo=c.codigo_tipo
    INNER JOIN no_nomina_emplcalc d
		 ON a.codigo_empleado = d.codigo_empleado
	left join #Empleados e
		on a.codigo_empleado=e.codigo_empleado
    where b.codigo_tipo = @codigo_tipo
      and d.codigo_tipo = @codigo_tipo
      and d.periodo_id = @periodo_id
      and d.grupo_id = @grupo_id
      and d.no_calculo = @no_calculo
      and c.codigo_provision = @codigo_provision
    order by a.codigo_empleado

select @porcentaje = porcentaje
from no_nomina_provisiones
where codigo_tipo = @codigo_tipo
  and codigo_provision = @codigo_provision

if @porcentaje is null select @porcentaje = 0.00

open cur_formula_calculo_prov
fetch cur_formula_calculo_prov into @codigo_Empleado , @codigo_departamento, @codigo_centro,@codigo_seccion
while @@fetch_status = 0
Begin

  exec @nombreproc @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado , @resultado out

  if @resultado is null select @resultado = 0
   
  select @resultado = round(@resultado,2)

  insert into no_provisiones_empleados (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_provision,
        codigo_empleado,
        codigo_departamento,
        codigo_centro,
        codigo_seccion,
        porcentaje,
        monto_base,
        monto_provision )
   values (
        @codigo_tipo,
        @periodo_id,
        @grupo_id,
        @no_calculo,
        @codigo_provision, 
        @codigo_empleado,
        @codigo_departamento,
        @codigo_centro,
        @codigo_seccion,
        @porcentaje,
        @resultado,
        @resultado )

 
  if @@error <> 0
  Begin
      Raiserror ('No se puede insertar el ingreso del empleado %s - stp_UDNoCalculoProvFormula ',16,1,@codigo_empleado)
      Rollback work
      Deallocate cur_formula_calculo_prov
      Return 9
  End

  fetch cur_formula_calculo_prov into @codigo_empleado , @codigo_departamento, @codigo_centro,@codigo_seccion
End
close cur_formula_calculo_prov
deallocate cur_formula_calculo_prov
 
commit tran
go

