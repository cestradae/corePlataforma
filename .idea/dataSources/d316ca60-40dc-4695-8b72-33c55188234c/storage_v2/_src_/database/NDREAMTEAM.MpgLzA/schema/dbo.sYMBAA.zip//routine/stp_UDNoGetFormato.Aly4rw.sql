create procedure [dbo].[stp_UDNoGetFormato] 
    @codigo_tipo char(2),
    @periodo_id char(10),
    @grupo_id char(5),
    @no_calculo int,
    @formato varchar(50) out,
    @cheque_inicial int out,
    @cheque_final int OUT,
    @id_cuenta VARCHAR(32)=NULL
AS

------------------------------------------------------------
--Creado por Daniel Ortiz
--Fecha 06/01/2011
--Se agrego id_cuenta como parametro y si el id_cuenta
--  viniera null busca la cuenta del tipo de nomina
------------------------------------------------------------
------------------------------------------------------------
--Creado por LSAO
--Fecha 10/10/2003
--Obtenemos el formato para el tipo de nomina especificado
------------------------------------------------------------
--si la cuenta_id viene null
IF @id_cuenta IS NULL 
BEGIN 
	select @id_cuenta = id_cuenta
	from no_tipos_nomina
	where codigo_tipo = @codigo_tipo 
END

if @id_cuenta is null select @formato = ''
else
begin
   select @formato = formato
   from bn_cuentas
   where id_cuenta = @id_cuenta

   if @formato is null select @formato = ''
end

select @cheque_inicial = min(numero_cheque)
from no_nomina_emplcalc_det
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id
  and grupo_id = @grupo_id
  and no_calculo = @no_calculo

select @cheque_final = max(numero_cheque)
from no_nomina_emplcalc_det
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id
  and grupo_id = @grupo_id
  and no_calculo = @no_calculo

if @cheque_inicial is null select @cheque_inicial = 0
if @cheque_final is null select @cheque_final = 0
go

