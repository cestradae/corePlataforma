-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_rcvalores](@AUTO_EditStamp varchar(30) OUT,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @no_reporte smallint ,
  @grupo_id char (5) ,
  @no_calculo smallint ,
  @fecha_reporte datetime ,
  @genera_aut char (1) ,
  @estado_reporte char (1) ,
  @fecha_ingreso datetime ,
  @usuario_ingreso varchar (35)  )
As 
	INSERT INTO [dbo].[no_reporte_valores]
(  codigo_tipo ,
  periodo_id ,
  no_reporte ,
  grupo_id ,
  no_calculo ,
  fecha_reporte ,
  genera_aut ,
  estado_reporte ,
  fecha_ingreso ,
  usuario_ingreso  )
VALUES (  @codigo_tipo ,
  @periodo_id ,
  @no_reporte ,
  @grupo_id ,
  @no_calculo ,
  @fecha_reporte ,
  @genera_aut ,
  @estado_reporte ,
  @fecha_ingreso ,
  @usuario_ingreso  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_reporte_valores]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
no_reporte =  @no_reporte )
go

