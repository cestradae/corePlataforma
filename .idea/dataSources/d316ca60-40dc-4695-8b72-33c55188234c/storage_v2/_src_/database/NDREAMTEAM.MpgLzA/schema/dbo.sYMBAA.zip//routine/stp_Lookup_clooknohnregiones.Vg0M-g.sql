-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohnregiones]
As
  SELECT codigo_region, nombre_region
FROM no_siex_regiones
go

