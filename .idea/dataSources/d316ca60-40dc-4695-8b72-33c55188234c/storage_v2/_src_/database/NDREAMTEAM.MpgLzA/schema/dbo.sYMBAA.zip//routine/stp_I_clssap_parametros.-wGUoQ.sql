-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_parametros](  @codigo_tipo char (2) ,
  @procedimiento_nomina varchar (50) ,
  @procedimiento_provisionesq varchar (50) ,
  @servidor varchar (30) ,
  @basedatos varchar (20) ,
  @usuario varchar (20) ,
  @clave varchar (20) ,
  @tipo_servidor smallint ,
  @cuenta_salios_sap varchar (15) ,
  @lenguaje smallint ,
  @UsuarioDB varchar (20) ,
  @ClaveDB varchar (20)  )
As 
	INSERT INTO [dbo].[sap_parametros]
(  codigo_tipo ,
  procedimiento_nomina ,
  procedimiento_provisionesq ,
  servidor ,
  basedatos ,
  usuario ,
  clave ,
  tipo_servidor ,
  cuenta_salios_sap ,
  lenguaje ,
  UsuarioDB ,
  ClaveDB  )
VALUES (  @codigo_tipo ,
  @procedimiento_nomina ,
  @procedimiento_provisionesq ,
  @servidor ,
  @basedatos ,
  @usuario ,
  @clave ,
  @tipo_servidor ,
  @cuenta_salios_sap ,
  @lenguaje ,
  @UsuarioDB ,
  @ClaveDB  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

