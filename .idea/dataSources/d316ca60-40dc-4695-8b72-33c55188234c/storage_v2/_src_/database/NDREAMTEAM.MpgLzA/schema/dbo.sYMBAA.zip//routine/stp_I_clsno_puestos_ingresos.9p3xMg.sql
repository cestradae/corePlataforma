-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_puestos_ingresos](  @codigo_tipo char (2) ,
  @codigo_puesto char (10) ,
  @codigo_ingreso char (3) ,
  @monto_inicial money ,
  @monto_final money ,
  @promedio money  )
As 
	INSERT INTO [dbo].[no_puestos_ingresos]
(  codigo_tipo ,
  codigo_puesto ,
  codigo_ingreso ,
  monto_inicial ,
  monto_final ,
  promedio  )
VALUES (  @codigo_tipo ,
  @codigo_puesto ,
  @codigo_ingreso ,
  @monto_inicial ,
  @monto_final ,
  @promedio  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

