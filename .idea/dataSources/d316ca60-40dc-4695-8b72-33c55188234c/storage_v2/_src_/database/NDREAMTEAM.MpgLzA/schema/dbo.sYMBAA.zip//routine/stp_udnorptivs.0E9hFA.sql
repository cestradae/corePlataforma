CREATE procedure [dbo].[stp_udnorptivs]
			@Departamento_Inicial	varchar(10),      
			@Departamento_Final		varchar(10),
			@Centro_Inicial			varchar(20),
			@Centro_Final			varchar(20),
			@Empleado_Inicial		char(10),
			@Empleado_Final			char(10)
as
-----------------------------------------------------
--Hecho por: Mario Juarros
--Fecha: 21/01/2009
--Script para el reporte de IVS
-----------------------------------------------------
set nocount on 
Declare @strsql varchar(500),
		@contador smallint,
		@mes	varchar(5),
		@codigo_ingreso	varchar(5)

CREATE table #ResultadosIvs (
		Codigo_empleado			char(10) collate Modern_Spanish_CI_AS,
		nombres					varchar(50) collate Modern_Spanish_CI_AS,
		apellidos				varchar(50) collate Modern_Spanish_CI_AS,
		apellido_casada			varchar(50) collate Modern_Spanish_CI_AS,	
		numero_seguro_social	varchar(20) collate Modern_Spanish_CI_AS,
		patrono					varchar(60) collate Modern_Spanish_CI_AS,
		direccion_patrono		varchar(100) collate Modern_Spanish_CI_AS,
		no_patronal				varchar(20) collate Modern_Spanish_CI_AS,
		ano						smallint,		
		mes1					money default 0,
		mes2					money default 0,
		mes3					money default 0,
		mes4					money default 0,
		mes5					money default 0,
		mes6					money default 0,
		mes7					money default 0,
		mes8					money default 0,
		mes9					money default 0,
		mes10					money default 0,
		mes11					money default 0,
		mes12					money default 0
)

if @Departamento_Inicial= ''
Begin
	select @departamento_inicial = min(codigo_departamento) from gn_departamentos	
end 

if @Departamento_Final= ''
Begin
	select @departamento_Final = max(codigo_departamento) from gn_departamentos	
end 

if @Centro_Inicial = ''
Begin
	select @Centro_Inicial = min(codigo_centro) from cn_catalogo_centros	
end

if @Centro_Final = ''
Begin
	select @Centro_Final = max(codigo_centro) from cn_catalogo_centros	
end

if @Empleado_Inicial = ''
Begin
	select @Empleado_Inicial = min(codigo_empleado) from no_empleados	
end

if @Empleado_Final = ''
Begin
	select @Empleado_Final = max(codigo_empleado) from no_empleados	
end
select @codigo_ingreso = codigo_ingreso from no_parametros_gt_det 

insert into #ResultadosIvs (
			Codigo_empleado,
			nombres,
			apellidos,
			apellido_casada,
			numero_seguro_social,
			ano)
select distinct ne.codigo_empleado, 
				ne.nombres , 
				ne.apellidos, 
				ne.apellido_casada, 
				ne.numero_seguro_social, 
				pp.ano				
from no_periodos_pago pp,no_nomina_det nd, no_empleados ne
where	nd.codigo_empleado = ne.codigo_empleado
		and pp.periodo_id = nd.periodo_id
		and pp.codigo_tipo = nd.codigo_tipo	
		and nd.codigo_ingreso in ( select distinct codigo_ingreso from no_parametros_gt_det )	
		and nd.monto_ingreso>0
		and nd.monto_ingreso is not null
		and nd.codigo_empleado between @Empleado_Inicial and @Empleado_Final
		and nd.codigo_departamento between @Departamento_Inicial and @Departamento_Final
		and nd.codigo_centro between @Centro_Inicial and @Centro_Final					
order by  ne.codigo_empleado, pp.ano

select top 1 patrono, direccion_patrono, no_patronal 
into #patrono
from gn_generales

select nd.codigo_empleado, pp.ano, pp.periodo, sum(nd.monto_ingreso)ingreso
into #ingresos  
from no_periodos_pago pp, no_nomina_det nd, no_empleados ne
where	nd.codigo_empleado = ne.codigo_empleado
		and pp.periodo_id = nd.periodo_id
		and pp.codigo_tipo = nd.codigo_tipo
		and nd.codigo_ingreso in ( select distinct codigo_ingreso from no_parametros_gt_det )
		and nd.monto_ingreso>0	
		and nd.monto_ingreso is not null 
		and nd.codigo_departamento between @Departamento_Inicial and @Departamento_Final
		and nd.codigo_centro between @Centro_Inicial and @Centro_Final
		and nd.codigo_empleado between @Empleado_Inicial and @Empleado_Final			
group by nd.codigo_empleado, pp.ano, pp.periodo

		select @strsql= 'update #ResultadosIvs  set patrono = b.patrono , direccion_patrono = b.direccion_patrono , no_patronal = b.no_patronal'+
				' from #patrono b'
		exec(@strsql)

Select @contador = 1

while @contador <= 12
	begin
		Select @mes = 'mes'+ ltrim(rtrim(convert(varchar(2),@contador)))
		select @strsql= 'update #ResultadosIvs set ' + @mes + ' = b.ingreso from #ingresos b where #ResultadosIvs.codigo_empleado = b.codigo_empleado and ' +
						'#ResultadosIvs.ano = b.ano and b.periodo = ' + convert(varchar,@contador)
		exec(@strsql)
	Set @contador =  @contador + 1		
end 

select 
		Codigo_empleado,
		nombres,
		apellidos,
		apellido_casada,	
		numero_seguro_social,
		patrono,
		direccion_patrono,
		no_patronal,
		ano,
		mes1,
		mes2,
		mes3,
		mes4,
		mes5,
		mes6,
		mes7,
		mes8,
		mes9,
		mes10,
		mes11,
		mes12
 from #ResultadosIvs
go

