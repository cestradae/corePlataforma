-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_secciones]
  (  @oldcodigo_seccion varchar (5)  )
As DELETE [dbo].[no_secciones] 
WHERE (codigo_seccion =  @oldcodigo_seccion)
go

