CREATE TRIGGER [dbo].[trinsno_empleado_vacdet] ON dbo.no_empleado_vacdet 
FOR INSERT, UPDATE
AS
------------------------
-- Fecha : 11/06/2008
-- Asunto : Se modificó para incluir estandares 
-- Hecho por : lsao
------------------------
--Restamos el valor eliminado 

update no_empleado_vacaciones 
    set no_empleado_vacaciones.dias_derecho = no_empleado_vacaciones.dias_derecho - deleted.dias_derecho
from deleted
where no_empleado_vacaciones.codigo_empleado = deleted.codigo_empleado
    and no_empleado_vacaciones.periodo = deleted.periodo

if @@error <> 0
Begin
   Raiserror ('No se puede actualizar la tabla de empleado vacaciones - trinsno_empleado_vacdet' ,16,1,5000)
   Rollback work
   Return
End
--Sumamos el valor sumado
update no_empleado_vacaciones 
    set no_empleado_vacaciones.dias_derecho = no_empleado_vacaciones.dias_derecho + inserted.dias_derecho
from inserted
where no_empleado_vacaciones.codigo_empleado = inserted.codigo_empleado
    and no_empleado_vacaciones.periodo = inserted.periodo

if @@error <> 0
Begin
   Raiserror ('No se puede actualizar la tabla de empleado vacaciones - trinsno_empleado_vacdet ' ,16,1,5000)
   Rollback work
   Return
End

-- Actualizamos el ultimo valor de calculo a

select a.codigo_empleado,
          max(a.fecha_calculo) fecha_calculo
into #fecha_calculo
from no_empleado_vacdet a, inserted b
where a.codigo_empleado = b.codigo_empleado
group by a.codigo_empleado

update no_empleados
    set fecha_ult_vacacion = fecha_calculo
from #fecha_calculo
where no_empleados.codigo_empleado = #fecha_calculo.codigo_empleado   

if @@error <> 0
Begin
   Raiserror ('No se puede actualizar la ultima fecha de calculo de vacaciones - trinsno_empleado_vacdet ',16,1,5000)
   Rollback work
   Return
End


go

