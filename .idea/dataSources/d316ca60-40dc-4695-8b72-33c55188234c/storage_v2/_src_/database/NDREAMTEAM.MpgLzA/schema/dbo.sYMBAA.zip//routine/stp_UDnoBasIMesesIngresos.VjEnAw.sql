

CREATE procedure [dbo].[stp_UDnoBasIMesesIngresos]  
   @Ingreso varchar(30),  
   @codigo_tipo char(2),  
   @periodo_id char(10),  
   @grupo_id char(5),  
   @no_calculo smallint,  
   @codigo_empleado char(10),  
   @no_meses smallint,   
   @resultado decimal(18,4) out  
as  
  
set nocount ON  
------------------------
--- MOdificado por ldr
-- fecha 03/12/2013
-- Se modifica para tome el salario proporcional si hubieron aumentos en el mes
-------------------------
-- hecho por ldr 
-- fecha 16/10/2013
-- Se modifica para que tome el mes 0
-----------------------------------------------------  
-- hecho por dortiz  
-- fecha 14-07-2010  
-- Asunto se toma desde el periodo actual  
-----------------------------------------------------  
-----------------------------------------------------  
-- hecho por lsao  
-- fecha 04-03-2007  
-- Asunto Registra el monto base  de los ultimos meses   
-----------------------------------------------------  
  
select @resultado = 1  
declare @codigo_ingreso char(3)  
declare @monto money  
declare @fecha_ingreso datetime  
declare @fecha_inicial datetime  
declare @fecha_final datetime  
declare @periodo_final char(10)  
declare @periodo_inicial char(10)  
declare @fecha_inicio_rel_lab datetime  
declare @contador smallint  
declare @fecha_baja datetime  
declare @fecha datetime  
declare @fecha_fin_mes datetime  
declare @mes char(2)  
declare @correlativo smallint  
declare @dias_mes decimal(18,4)  
declare @dias decimal(18,4)  
declare @detalle char(1)
declare @strsql varchar(500)
declare @fecha_final_per datetime
declare @fecha_inicial_per datetime
declare @fecha_suspension datetime
declare @corr_solicitud int  
declare @tipo_ano char(1)
declare @periodo_xx char(10)

select @corr_solicitud = 0
  
select @fecha_final_per = fecha_final,
       @fecha_inicial_per  = fecha_inicial
from no_periodos_pago
where periodo_id = @periodo_id

select @tipo_ano = tipo_ano
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

if @tipo_ano is null select @tipo_ano = '1'

select @corr_solicitud = a.corr_solicitud
from no_solicitud_ausencias a
  left join no_solicitud_ausdet b on a.codigo_empleado = b.codigo_empleado
        and a.corr_solicitud = b.corr_solicitud 
        and a.estado_solicitud in ('A','C')
        and a.tipo_solicitud = 'S' 
        and b.a_fecha between @fecha_inicial_per and  @fecha_final_per
where a.codigo_empleado=@codigo_empleado
  and b.a_fecha is not null

if @corr_solicitud <> 0
Begin
    select @fecha_suspension = null

    select @fecha_suspension = fecha_inicio
    from no_solicitud_ausencias 
    where codigo_empleado = @codigo_empleado
      and corr_solicitud = @corr_solicitud

    if @fecha_suspension is not null  
    Begin
          set rowcount 1 
          select @periodo_id = periodo_id
          from no_periodos_pago
          where @fecha_suspension between fecha_inicial and fecha_final
          order by periodo_id
          set rowcount 0
    End
End




if @no_meses >=1 
Begin
   select @fecha_final = fecha_final  
   from no_periodos_pago  
   where periodo_id = @periodo_id  
   select @fecha_final=dateadd(mm,1,@fecha_final)
   select @fecha_inicial = dateadd(mm,@no_meses * -1 , @fecha_final )  
   select @fecha_final   = dateadd(dd,-1, @fecha_final)  

End
Else
Begin
   select @fecha_inicial = fecha_inicial,
          @fecha_final = fecha_final  
   from no_periodos_pago  
   where periodo_id = @periodo_id  
   
End

  
select @fecha_inicio_rel_lab = fecha_inicio_rel_lab  
from no_empleados  
where codigo_empleado = @codigo_empleado  

if substring(@ingreso,1,1) = '#' 
Begin
   select @detalle = 'S'
   select @codigo_ingreso = substring(@ingreso,2,3)
End
else
Begin
   select @detalle = 'N'
   
   select @codigo_ingreso = codigo_ingreso  
   from no_catalogo_ingresos  
   where nombre_corto = @Ingreso  
End

 
select @fecha_baja  = fecha_liquidacion  
from no_liquidaciones   
where periodo_id = @periodo_id  
and codigo_empleado = @codigo_empleado  
and no_calculo is null  
  
IF OBJECT_ID(N'tempdb..#Meses_bases') IS NOT NULL
BEGIN
     DROP TABLE #Meses_bases
END
    
  
Create table #Meses_bases (  
    ano_mes smallint,
    numero_mes smallint,  
    monto_mes money )  
  
  
select @resultado = 0  
  
  
select @fecha = @fecha_inicial  

    
select @contador = 1  

if @no_meses = 0
Begin
   select @no_meses = 1
End

  
while @contador <= @no_meses  
Begin  

  select @periodo_xx = @codigo_tipo + convert(char(4),datepart(yy,@fecha)) + 
            replicate('0',2-len(convert(char(2),datepart(mm,@fecha))))+convert(varchar(2),datepart(mm,@fecha)) + '00'
  
  select @monto = dbo.FnNo_IngresoMes ( @codigo_tipo, @codigo_ingreso, @codigo_empleado, @periodo_xx )
   --select @monto,@codigo_tipo, @codigo_ingreso, @codigo_empleado, @periodo_xx
   --select @contador, @monto  
  insert into #Meses_bases ( ano_mes, numero_mes, monto_mes )  
     values ( datepart(yy,@fecha), datepart(mm,@fecha), @monto )  
       
  select @contador = @contador + 1  
  select @fecha = dateadd(mm,1,@fecha)  
  
end  
  
select @resultado = sum(monto_mes)  
from #Meses_bases
  
if @Detalle = 'S' 
Begin
  select @strsql = ' Select ano_mes Basano' + @codigo_ingreso + ' ,'+
           ' numero_mes BasMes' + @codigo_ingreso + ' ,' +
           ' monto_mes BaseIng'+ @codigo_ingreso +
           ' From #Meses_bases order by ano_mes,numero_mes ' 
  exec (@strsql)  
End 

drop table #Meses_bases
if @resultado is null select @resultado = 0


go

