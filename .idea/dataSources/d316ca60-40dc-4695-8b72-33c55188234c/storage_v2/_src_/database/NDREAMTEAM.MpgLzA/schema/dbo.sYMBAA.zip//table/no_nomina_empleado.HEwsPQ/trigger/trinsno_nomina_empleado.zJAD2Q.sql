Create TRIGGER [trinsno_nomina_empleado] ON [dbo].[no_nomina_empleado] 
FOR INSERT
AS
-- FEcha 26/10/2010
-- uSUARIO LDR
-- ASUNTO SE MODIFICO PARA QUE TOMARA EN CUENTA SI YA HABIAN INRESOS ASIGNADOS

-- Fecha Modificación: 15.julio.2009
-- Usuario Modificación: Estuardo Arévalo
-- Cambio. Se agrega el funcionamiento de no_puestos_ingresos, deducciones, provisiones
-- si existe el registro se ingresa en base a esa tabla, de lo contrario sigue con  no_nomina_ingresos, deducciones, provisiones

declare @fecha_asignacion datetime,
            @usuario_asignacion varchar(35),
            @codigo_empleado char(10),
            @codigo_tipo char(2),
            @fecha_inicio_rel_lab datetime,
            @codigo_puesto char(10)

select @codigo_empleado= codigo_empleado,
          @codigo_tipo = codigo_tipo
from inserted


select @fecha_inicio_rel_lab = fecha_inicio_rel_lab,
		  @codigo_puesto = codigo_puesto
from no_empleados
where codigo_empleado = @codigo_empleado

select @fecha_asignacion = getdate(),
          @usuario_asignacion = system_user

update no_nomina_empleado
   set fecha_asignacion = @fecha_asignacion,
         usuario_asignacion = @usuario_asignacion
where codigo_empleado = @codigo_empleado
    and codigo_tipo = @codigo_tipo

if @@error <> 0 
begin
    raiserror ('No se puede actualizar no_nomina_empleado - trinsno_nomina_empleado ', 16,1,5000 )
    rollback work
    return
end



-- Insertamos los ingresos automaticamente

-- verificamos si existe la configuracion de tipo de nomina por puesto (no_nomina_puestos)
-- de ser asi, tomamos los ingresos de no_puestos_ingresos, deducciones y provisiones
if exists ( select top 1 1 from no_nomina_puestos where codigo_tipo = @codigo_tipo and  codigo_puesto = @codigo_puesto )
begin
		insert into no_empleado_ingresos (
		  codigo_empleado,
		  codigo_tipo,
		  codigo_ingreso,
		  monto,
		  fecha_inicio )
		  
		select @codigo_empleado,
				  @codigo_tipo,
				  codigo_ingreso ,
				  promedio,				  
				 @fecha_inicio_rel_lab
		from no_puestos_ingresos
		where codigo_tipo = @codigo_tipo
		and codigo_puesto = @codigo_puesto
        and codigo_ingreso not in ( select codigo_ingreso 
                                    from no_empleado_ingresos 
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      


		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar ingresos a no_nomina_ingresos - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end


		-- Insertamos los egresos automaticamente

		insert into no_empleado_deducciones (
		   codigo_empleado,
		   codigo_tipo,
		   codigo_deduccion,
		   monto  )
		select @codigo_empleado,
				  @codigo_tipo,
				  codigo_deduccion,
				  promedio
		from no_puestos_deducciones
		where codigo_tipo = @codigo_tipo
		and codigo_puesto = @codigo_puesto
        and codigo_deduccion not in ( select codigo_deduccion 
                                    from no_empleado_deducciones 
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      
		 

		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar ingresos a no_nomina_deducciones - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end

		-- Insertamos los anticipados automaticamente
/*
		insert into no_empleado_anticipos ( 
			 codigo_empleado,
			 codigo_tipo,
			 codigo_anticipo,
			 monto )
		select  @codigo_empleado,
				   @codigo_tipo,
					codigo_anticipo,
				   0.00
		from no_nomina_anticipos
		where  codigo_tipo = @codigo_tipo

		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar anticipos a no_nomina_deducciones - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end
*/
		insert into no_empleado_provision_enc (
		   codigo_empleado,
		   codigo_tipo,
		   codigo_provision )

		select @codigo_empleado ,
			   @codigo_tipo,
			   codigo_provision
		from no_puestos_provisiones
		where codigo_tipo = @codigo_tipo
		and codigo_puesto = @codigo_puesto
        and codigo_provision not in ( select codigo_provision 
                                    from no_empleado_provision_enc 
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      


		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar provisiones a no_empleado_provision_enc - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end


end 
else
begin
		insert into no_empleado_ingresos (
		  codigo_empleado,
		  codigo_tipo,
		  codigo_ingreso,
		  monto,
		  perioricidad,
		  fecha_inicio )

		select @codigo_empleado,
				  @codigo_tipo,
				  codigo_ingreso ,
				  0.00,
				  perioricidad,
				 @fecha_inicio_rel_lab
		from no_nomina_ingresos
		where codigo_tipo = @codigo_tipo
          and codigo_ingreso not in ( select codigo_ingreso 
                                    from no_empleado_ingresos 
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      

		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar ingresos a no_nomina_ingresos - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end


		-- Insertamos los egresos automaticamente

		insert into no_empleado_deducciones (
		   codigo_empleado,
		   codigo_tipo,
		   codigo_deduccion,
		   monto,
		   perioricidad )

		select @codigo_empleado,
				  @codigo_tipo,
				  codigo_deduccion,
				  0.00,
				  perioricidad
		from no_nomina_deducciones
		where codigo_tipo = @codigo_tipo
		  and codigo_deduccion not in ( select codigo_deduccion
                                    from no_empleado_deducciones
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      


		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar ingresos a no_nomina_deducciones - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end

		-- Insertamos los anticipados automaticamente

		insert into no_empleado_anticipos ( 
			 codigo_empleado,
			 codigo_tipo,
			 codigo_anticipo,
			 monto )
		select  @codigo_empleado,
				   @codigo_tipo,
					codigo_anticipo,
				   0.00
		from no_nomina_anticipos
		where  codigo_tipo = @codigo_tipo

		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar anticipos a no_nomina_deducciones - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end

		insert into no_empleado_provision_enc (
		   codigo_empleado,
		   codigo_tipo,
		   codigo_provision )

		select @codigo_empleado ,
			   @codigo_tipo,
			   codigo_provision
		from no_nomina_provisiones
		where codigo_tipo = @codigo_tipo
          and codigo_provision not in ( select codigo_provision
                                    from no_empleado_provision_enc	 
                                    where codigo_tipo = @codigo_tipo
                                      and codigo_empleado = @codigo_empleado )                      


		if @@error <> 0
		begin 
		   raiserror ('No se pudieron insertar provisiones a no_empleado_provision_enc - triinsno_nomina_empleado ', 16,1,5000 )
		   rollback work
		   return
		end
end



go

