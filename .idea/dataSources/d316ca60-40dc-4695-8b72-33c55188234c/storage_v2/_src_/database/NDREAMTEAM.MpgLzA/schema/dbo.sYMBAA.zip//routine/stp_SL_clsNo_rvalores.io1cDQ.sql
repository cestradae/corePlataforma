-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_rvalores]
  As SELECT a.codigo_tipo,a.periodo_id,a.no_reporte,a.grupo_id,a.no_calculo,a.fecha_reporte,a.genera_aut,a.estado_reporte,a.fecha_ingreso,a.usuario_ingreso,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_valores] a
go

