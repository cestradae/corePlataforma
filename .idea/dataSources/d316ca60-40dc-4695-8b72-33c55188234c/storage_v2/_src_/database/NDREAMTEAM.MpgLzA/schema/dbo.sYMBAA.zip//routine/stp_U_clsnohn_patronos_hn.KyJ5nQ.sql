
-- Procedure definition
CREATE PROCEDURE stp_U_clsnohn_patronos_hn(  @oldcodigo_patrono smallint ,
  @codigo_patrono smallint ,
  @nombre_patrono varchar (100) ,
  @direccion_patrono varchar (100) ,
  @numero_patronal varchar (50) ,
  @codigo_rap char (3) ,
  @codigo_infop char (3) ,
  @codigo_seguro char (3) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_patronos_hn] 
WHERE codigo_patrono =  @oldcodigo_patrono 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_patronos_hn] Set 
    codigo_patrono = @codigo_patrono,
    nombre_patrono = @nombre_patrono,
    direccion_patrono = @direccion_patrono,
    numero_patronal = @numero_patronal,
    codigo_rap = @codigo_rap,
    codigo_infop = @codigo_infop,
    codigo_seguro = @codigo_seguro 
WHERE 	( codigo_patrono =  @oldcodigo_patrono )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_patronos_hn]
  WHERE ( codigo_patrono =  @codigo_patrono )
go

