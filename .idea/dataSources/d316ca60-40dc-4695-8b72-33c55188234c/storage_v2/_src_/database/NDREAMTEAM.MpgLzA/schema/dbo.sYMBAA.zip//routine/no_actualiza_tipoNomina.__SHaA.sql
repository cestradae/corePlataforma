CREATE proc [dbo].[no_actualiza_tipoNomina]
as

begin tran
	select count(*) from no_nomina_empleado
	declare @codigo_empleado varchar(350),
			@tipo_nomina	varchar(350)
	declare cur_tiposnomina cursor for
	select codigo_empleado, tipo_nomina from tmpno_empleados
open cur_tiposnomina
fetch cur_tiposnomina into @codigo_empleado, @tipo_nomina	
		while @@fetch_status = 0
			Begin
				insert into 
				no_nomina_empleado (codigo_empleado, codigo_tipo, fecha_asignacion, usuario_asignacion)
				values (@codigo_empleado, @tipo_nomina, getdate(), 'SA')
					if @@error <> 0
						Begin
							raiserror('No se pudo actualizar el tipo de nomina',16,1)
							rollback work
							return
						end
			fetch cur_tiposnomina into @codigo_empleado, @tipo_nomina
			end
close cur_tiposnomina
deallocate cur_tiposnomina
select count(*) from no_nomina_empleado
commit tran
go

