-- Fecha Creación:  29.Mayo.2009
-- Usuario Creación: Estuardo Arévalo
-- Procedimiento para Boletas de Pago SolBoGua Administrativas
-- DETALLE DE INGRESOS

CREATE PROCEDURE[dbo].[stp_UDnorptBoletasSolbogua_ing]
@codigo_tipo char(2),
@periodo char(10),
@grupo char(5),
@no_pago smallint,
@depto1 smallint,
@depto2 smallint

AS



set nocount on

/*
SELECT * FROM dbo.no_puestos
SELECT * FROM no_empleados
SELECT * FROM dbo.no_periodos_pago
stp_UDnorptBoletasSolbogua_ing '02','0220090301','021',0,0,5
select * from dbo.no_grupos_valores

*/


SELECT 
	NULL AS cantidad
	,a.codigo_empleado
	,ISNULL(SUM(a.monto_ingreso),0) AS monto
	,b.descripcion AS descripcion
FROM dbo.no_nomina_det a
	INNER JOIN dbo.no_catalogo_ingresos b
		ON a.codigo_ingreso = b.codigo_ingreso
WHERE a.codigo_tipo = @codigo_tipo
AND a.periodo_id = @periodo
AND a.grupo_id = @grupo
AND a.no_calculo = @no_pago
AND a.codigo_departamento BETWEEN @depto1 AND @depto2
AND a.codigo_ingreso IS NOT NULL
AND a.monto_ingreso > 0
GROUP BY a.codigo_empleado , b.descripcion
go

