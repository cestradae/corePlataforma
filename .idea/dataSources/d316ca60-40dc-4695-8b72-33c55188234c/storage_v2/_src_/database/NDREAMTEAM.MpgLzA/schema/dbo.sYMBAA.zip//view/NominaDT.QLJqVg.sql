CREATE VIEW dbo.NominaDT
AS
SELECT     a.periodo_id, a.codigo_empleado, a.codigo_centro, a.codigo_ingreso AS codigo, a.monto_ingreso AS monto, b.descripcion, c.nombre_centro
FROM         dbo.no_nomina_det AS a CROSS JOIN
                      dbo.no_catalogo_ingresos AS b CROSS JOIN
                      dbo.cn_catalogo_centros AS c
WHERE     (b.descripcion LIKE 'Ordinario')
go

