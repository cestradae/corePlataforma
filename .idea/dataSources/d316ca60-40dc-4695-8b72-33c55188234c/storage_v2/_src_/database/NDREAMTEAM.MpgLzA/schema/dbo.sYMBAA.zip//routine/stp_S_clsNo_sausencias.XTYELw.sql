-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNo_sausencias]
  (  @oldcodigo_empleado char (10) ,
  @oldcorr_solicitud smallint  )
As SELECT a.codigo_empleado,a.corr_solicitud,a.codigo_tipo,a.fecha_solicitud,a.dias_solicitar,a.descuenta_sabados,a.fecha_inicio,a.tipo_solicitud,a.motivo,a.observaciones,a.dia_descontado,a.estado_solicitud,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_solicitud_ausencias] a
WHERE (a.codigo_empleado =  @oldcodigo_empleado AND 
a.corr_solicitud =  @oldcorr_solicitud)
go

