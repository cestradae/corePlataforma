-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_cprovisiones](@AUTO_EditStamp varchar(30) OUT,
  @codigo_provision char (3) ,
  @descripcion varchar (50) ,
  @linea_1Reporte varchar (10) ,
  @linea_2Reporte varchar (10) ,
  @cuenta_contable varchar (30) ,
  @nombre_corto varchar (30)  )
As 
	INSERT INTO [dbo].[no_catalogo_provisiones]
(  codigo_provision ,
  descripcion ,
  linea_1Reporte ,
  linea_2Reporte ,
  cuenta_contable ,
  nombre_corto  )
VALUES (  @codigo_provision ,
  @descripcion ,
  @linea_1Reporte ,
  @linea_2Reporte ,
  @cuenta_contable ,
  @nombre_corto  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_catalogo_provisiones]
  WHERE ( codigo_provision =  @codigo_provision )
go

