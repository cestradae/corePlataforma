-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoProcAnt]
As
  SELECT procedimiento Procedimiento, descripcion Descripcion
FROM no_nomina_proc
WHERE tipo_proc = 'A'
go

