-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_provisiones]
As
  SELECT codigo_provision, codigo_provision + ' - '+ descripcion Provision
  FROM no_catalogo_provisiones
 ORDER BY descripcion
go

