create procedure stp_UDnoFormula06   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @tmp1 decimal(18,4)
declare @AguiInc decimal(22,6) 
declare @tmp2 decimal(18,4) 

begin
  exec stp_UDnoDiasDiferencia @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  12 , 01 ,11 , 30 , @tmp1 out
Select @AguiInc= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = 'AguiInc'
if ((isnull(@AguiInc,0)=1)) select @tmp2=365 else select @tmp2=0

  set @result=@tmp1+1-@tmp2
end
go

