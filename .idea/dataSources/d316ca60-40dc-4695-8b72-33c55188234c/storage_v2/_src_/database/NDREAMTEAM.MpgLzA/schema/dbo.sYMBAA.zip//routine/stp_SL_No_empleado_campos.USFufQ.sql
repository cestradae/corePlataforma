-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_No_empleado_campos]
  As SELECT a.codigo_empleado,a.nombre_campo,a.valor_lista,a.valor,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_empleado_campos] a
go

