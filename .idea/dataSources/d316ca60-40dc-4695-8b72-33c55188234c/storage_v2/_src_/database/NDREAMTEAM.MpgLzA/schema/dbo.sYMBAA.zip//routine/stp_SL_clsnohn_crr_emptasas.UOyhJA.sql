
-- Procedure definition
CREATE PROCEDURE stp_SL_clsnohn_crr_emptasas
  As SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.correlativo,a.hasta,a.porcentaje,a.monto_impuesto,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_rentahn_emptasas] a
go

