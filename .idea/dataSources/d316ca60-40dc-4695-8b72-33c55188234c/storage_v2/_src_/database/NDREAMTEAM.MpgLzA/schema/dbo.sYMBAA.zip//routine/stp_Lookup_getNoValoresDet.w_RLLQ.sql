-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoValoresDet]
As
  SELECT valor Valor, descripcion Descripcion
FROM notipo_valoresv
go

