create procedure [dbo].[stp_sapTraeStp]
   @codigo_tipo char(2)
as

set nocount on
 
Select procedimiento_nomina nomina,
      procedimiento_provisionesq provisionQ
  from sap_parametros
  where codigo_tipo = @codigo_tipo

Return
go

