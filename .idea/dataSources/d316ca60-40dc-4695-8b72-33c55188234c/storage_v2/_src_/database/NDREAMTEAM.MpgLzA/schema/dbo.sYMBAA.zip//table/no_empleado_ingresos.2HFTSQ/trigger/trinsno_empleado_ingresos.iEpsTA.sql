

CREATE TRIGGER [dbo].[trinsno_empleado_ingresos] ON [dbo].[no_empleado_ingresos] 
FOR INSERT, UPDATE
AS

-------------------------------------------------------------------------------------------------------------------
-- Modificación Estuardo Arévalo
-- Fecha 15.julio.2009
-- Asunto Validar que si viene a partir de la conf. de un puesto, respete el minimo y el maximo valor
----------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------
-- Creado por LSAO
-- Fecha 03/07/2003
-- Asunto Actualizacion de perioricidad en el ingreso
----------------------------------------------------------------------------------------------------------------------


declare @codigo_empleado char(10),
			@codigo_puesto char(10),
			@codigo_tipo char(2),
			@codigo_ingreso char(3),
			@monto money
				
select @codigo_empleado =  codigo_empleado
		,@codigo_tipo = codigo_tipo		
		,@codigo_ingreso = codigo_ingreso
		,@monto = monto
from inserted

select @codigo_puesto = codigo_puesto 
from no_empleados
where codigo_empleado = @codigo_empleado


begin tran

if exists(Select top 1 1 from no_nomina_puestos where codigo_tipo = @codigo_tipo and codigo_puesto = @codigo_puesto)
begin
	declare @monto_inicial money,
				@monto_final money
				
	select @monto_inicial = monto_inicial,  
				@monto_final = monto_final
	from no_puestos_ingresos
	where codigo_puesto = @codigo_puesto
	and codigo_tipo = @codigo_tipo
	and codigo_ingreso = @codigo_ingreso

	if @monto > @monto_final 
	begin
		raiserror ('El monto del ingreso no debe ser mayor al definico en los ingresos del puesto - trinsno_empleado_ingresos ', 16,1,5000 )	
		rollback work
		return
	end

end


update no_empleado_ingresos
     set no_empleado_ingresos.perioricidad = no_nomina_ingresos.perioricidad
from no_nomina_ingresos , inserted
where inserted.codigo_tipo = no_empleado_ingresos.codigo_tipo
    and inserted.codigo_empleado = no_empleado_ingresos.codigo_empleado
    and inserted.codigo_ingreso = no_empleado_ingresos.codigo_ingreso 
    and inserted.codigo_tipo = no_nomina_ingresos.codigo_tipo
    and inserted.codigo_ingreso = no_nomina_ingresos.codigo_ingreso


if @@error <> 0
begin
	raiserror ('Ocurrió un error al intentar actualizar el registro - trinsno_empleado_ingresos ', 16,1,5000 )	
	rollback work
	return
end

commit tran



go

