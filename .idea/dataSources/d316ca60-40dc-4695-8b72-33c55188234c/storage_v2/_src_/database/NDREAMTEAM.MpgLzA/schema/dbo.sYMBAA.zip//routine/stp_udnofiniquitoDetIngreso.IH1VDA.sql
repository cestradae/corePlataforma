Create procedure [dbo].[stp_udnofiniquitoDetIngreso]
   @codigo_tipo char(2),
   @grupo_id char(5),
   @periodo_id char(10),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @codigo_valor char(10)
as 
set nocount on

----------------------
-- Hecho por ldr
-- fecha 03/03/2011
-- Para presentar una deduccion
----------------------

declare @strsql varchar(100)

select a.codigo_ingreso codigo_ingreso, b.descripcion desc_ingreso,  sum(monto_ingreso) monto_deduccion 
into #Ingresos 
from no_nomina_det a
  inner join no_catalogo_ingresos b on a.codigo_ingreso = b.codigo_ingreso 
where a.codigo_tipo = @codigo_tipo
and a.grupo_id = @grupo_id
and a.periodo_id = @periodo_id
and a.no_calculo= @no_calculo
and a.codigo_empleado = @codigo_empleado
group by a.codigo_ingreso , b.descripcion

select *
from #Ingresos
order by codigo_ingreso

drop table #Ingresos
go

