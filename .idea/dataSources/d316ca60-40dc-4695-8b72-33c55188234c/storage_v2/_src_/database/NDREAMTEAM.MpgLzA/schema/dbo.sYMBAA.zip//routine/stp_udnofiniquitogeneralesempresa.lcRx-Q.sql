create procedure [dbo].[stp_udnofiniquitogeneralesempresa] 
   @codigo_tipo char(2),
   @grupo_id char(5),
   @periodo_id char(10),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @codigo_valor char(10) 
as 
-----------------------------
-- Hecho por Daniel Ortiz
-- Fecha 02/12/2013
-- Asunto se generan todos los datos generales de la empresa
-----------------------------
-- Hecho por Daniel Ortiz
-- Fecha 19/02/2014
-- Asunto se agrego el campo de no_patronal
-----------------------------

select nombre_empresa, 
		nit empresa_nit, 
		no_patente, 
		direccion empresa_direccion,
		telefono1 empresa_telefono1, 
		telefono2 empresa_telefono2, 
		nombre_comercial, 
		no_patronal
from gn_generales


go

