-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_cls_Users]
  As SELECT TOP 1000 a.UserID,a.UserName,a.Password,a.caduca_clave,a.dias_expira,a.fecha_exprira,a.fecha_ultima_expiro,a.e_mail FROM [dbo].[_Users] a
go

