-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_nempleado]
  (  @oldCodigo_empleado char (10) ,
  @oldCodigo_tipo char (2)  )
As DELETE [dbo].[no_nomina_empleado] 
WHERE (codigo_empleado =  @oldCodigo_empleado AND 
codigo_tipo =  @oldCodigo_tipo)
go

