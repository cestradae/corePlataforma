
CREATE procedure [dbo].[stp_udnofiniquitoVariableSistema]
   @codigo_tipo char(2),
   @grupo_id char(5),
   @periodo_id char(10),
   @no_calculo smallint,
   @codigo_empleado char(10),
   @no_meses smallint,
   @codigo_valor char(15)
as 
----------------------
-- Hecho por ldr
-- fecha 03/03/2011
-- Para llamar devengado y presente la lista de valores 
----------------------
set nocount on

declare @res_var money
declare @strsql varchar(500)

select valor
into #Variable
from no_nomina_variables_sistema
where codigo_tipo =@codigo_tipo
and grupo_id = @grupo_id
and periodo_id = @periodo_id
and no_calculo = @no_calculo
and codigo_empleado = @codigo_empleado
and codigo_variable = convert(char(10),@codigo_valor)

if @res_var is null select @res_var = 0

select @strsql = 'Select valor ' + @codigo_valor + ' from #Variable'

exec (@strsql)

drop table #Variable

go

