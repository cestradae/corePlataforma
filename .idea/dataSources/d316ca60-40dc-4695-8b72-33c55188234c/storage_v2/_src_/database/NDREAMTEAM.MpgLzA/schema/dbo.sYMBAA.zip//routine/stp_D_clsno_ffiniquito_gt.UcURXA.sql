
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_ffiniquito_gt
  (  @oldcodigo_formato smallint  )
As DELETE [dbo].[no_formatos_finiquitos] 
WHERE (codigo_formato =  @oldcodigo_formato)
go

