CREATE TRIGGER [dbo].[trupdbn_cheques_cargos] ON [dbo].[bn_cheques_cargos] 
FOR  UPDATE
AS
---------------------------------
-- Cambio hecho por lsao
-- Fecha 12-12-2007
-- Se cambio para que no pusiera en negativos la ganancia cambiaria
----------------------------------

declare  
           
             @documento_id varchar(44),
             @codigo_clase smallint,
             @cuenta_contable varchar(100),
             @codigo_centro varchar(20),
             @monto_abono money,
             @correlativo smallint,
             @cuenta_impuestos varchar(30),
             @centro_impuestos varchar(20),
             @codigo_banco smallint,
             @id_cuenta varchar(32),
             @codigo_tipo smallint,
             @numero_cheque int,
             @act_retenciones char(1),
             @impto_ventas char(2),
             @impto_retencion char(2),
             @otro_impto char(2),
             @monto_i_ventas money,
             @monto_i_retencion money,
             @monto_i_otros money,
             @ventas_retenido char(1),
             @retencion_retenido char(1),
             @otros_retenido char(1),
             @monto_retencion money,
             @car smallint,
             @aju1 smallint,
             @aju2 smallint,
             @aju3 smallint,
             @aju4 smallint,
             @tasa_cambio decimal(18,6),
             @moneda_cargo smallint,
             @moneda_cheque smallint,
             @tasa_cheque decimal(18,6),
             @es_local char(1),
	@es_local2 char(1),
             @cuenta_ingresos varchar(30),
             @cuenta_egresos varchar(30),
             @monto_abono_tran money,
             @monto_i_ventasc money,
             @monto_i_retencionc money,
             @monto_i_otrosc money,
             @monto_abonoc money,
             @diferencia money,
             @monto_retencionc money

--fin  declare

if update(car) or update(aju1) or update(aju2) or update(aju3) or update(aju4) 
   return

select    @codigo_banco =codigo_banco,
             @id_cuenta = id_cuenta,
             @codigo_tipo = codigo_tipo,
             @numero_cheque = numero_cheque,
             @documento_id = documento_id,
             @car = car,
             @aju1 = aju1,
             @aju2 = aju2,
             @aju3 = aju3,
	@aju4 = aju4    
from deleted


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @car

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trupdbn_cheques_cargos ' ,16,1, @documento_id )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @aju1

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trupdbn_cheques_cargos ' ,16,1, @documento_id )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @aju2

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trupdbn_cheques_cargos ' ,16,1, @documento_id )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @aju3

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trupdbn_cheques_cargos ' ,16,1, @documento_id )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @aju4

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trupdbn_cheques_cargos ' ,16,1, @documento_id )
   rollback work
   return
end

--insertamos nuevos valores

select @documento_id = documento_id,
          @monto_abono = monto_abono,
          @codigo_banco = codigo_banco,
          @id_cuenta = id_cuenta,
          @codigo_tipo = codigo_tipo,
          @numero_cheque = numero_cheque
from inserted

select @tasa_cheque = tasa_cambio,
          @moneda_cheque = codigo_moneda
from bn_cheques_enc
where codigo_banco = @codigo_banco
   and id_cuenta = @id_cuenta
   and codigo_tipo = @codigo_tipo
   and numero_cheque = @numero_cheque


select @codigo_clase = codigo_clase,
           @act_retenciones = isnull(act_retenciones,'N'),
           @impto_ventas = impto_ventas,
           @impto_retencion = impto_retencion,
           @otro_impto = otro_impto,
           @monto_i_ventas = isnull(monto_i_ventas,0),
           @monto_i_retencion = isnull(monto_i_retencion,0),
           @monto_i_otros = isnull(monto_i_otros,0),
           @ventas_retenido = isnull(ventas_retenido,'N'),
           @retencion_retenido = isnull(retencion_retenido,'N'),
           @otros_retenido = isnull(otros_retenido,'N') ,
           @tasa_cambio = tasa_cambio,
           @moneda_cargo = codigo_moneda
from cp_cuentas_a_pagar
where documento_id = @documento_id


select @cuenta_contable = cuentaxpagar,
          @codigo_centro = codigo_centro
from cp_clases_provision
where codigo_clase = @codigo_clase


select @monto_retencion = 0
select @monto_retencionc = 0
-- Se convierten los valores 
if @moneda_cheque <> @moneda_cargo 
begin
    select @es_local = es_local
    from gn_monedas
    where codigo_moneda = @moneda_cheque 
 

    select @es_local2 = es_local
    from gn_monedas
    where codigo_moneda = @moneda_cargo 

    if @es_local = 'S'
    Begin
          select @monto_i_ventasc = round(@monto_i_ventas * @tasa_cheque ,2),
                    @monto_i_retencionc = round(@monto_i_retencion * @tasa_cheque ,2),
                    @monto_i_otrosc = round(@monto_i_otros  *@tasa_cheque , 2),
                    @monto_abonoc = round(@monto_abono * @tasa_cheque ,2)

          select @monto_i_ventas = round(@monto_i_ventas * @tasa_cambio ,2),
                    @monto_i_retencion = round(@monto_i_retencion * @tasa_cambio ,2),
                    @monto_i_otros = round(@monto_i_otros  *@tasa_cambio , 2),
                    @monto_abono = round(@monto_abono * @tasa_cambio ,2)

    

         
    End
    else
    Begin

	--------------------------------------------------------------------------------------------agregado,    si moneda cargo es local  no debe calcular diferencial cambiario
	if @es_local2 = 'S'
	begin

                     select @monto_i_ventasc = round(@monto_i_ventas / @tasa_cheque ,2),
                    	     @monto_i_retencionc = round(@monto_i_retencion / @tasa_cheque ,2),
                    	     @monto_i_otrosc = round(@monto_i_otros  /@tasa_cheque , 2),
                    	     @monto_abonoc = round(@monto_abono / @tasa_cheque ,2)

          	       select @monto_i_ventas = @monto_i_ventasc,
                    	    @monto_i_retencion = @monto_i_retencionc,
                    	    @monto_i_otros = @monto_i_otrosc,
                    	    @monto_abono = @monto_abonoc
	end
	else
	begin
	         select @monto_i_ventasc = round(@monto_i_ventas / @tasa_cheque ,2),
	                    @monto_i_retencionc = round(@monto_i_retencion / @tasa_cheque ,2),
	                    @monto_i_otrosc = round(@monto_i_otros  /@tasa_cheque , 2),
	                    @monto_abonoc = round(@monto_abono / @tasa_cheque ,2)
	
	          select @monto_i_ventas = round(@monto_i_ventas / @tasa_cambio ,2),
	                    @monto_i_retencion = round(@monto_i_retencion / @tasa_cambio ,2),
	                    @monto_i_otros = round(@monto_i_otros  /@tasa_cambio , 2),
	                    @monto_abono = round(@monto_abono / @tasa_cambio ,2)
	end
    End

end
else
begin
    select @es_local = es_local
    from gn_monedas
    where codigo_moneda = @moneda_cheque 

    if @es_local = 'N' 
    Begin
          select @monto_i_ventas = round(@monto_i_ventas * @tasa_cambio / @tasa_cheque ,4),
                    @monto_i_retencion = round(@monto_i_retencion * @tasa_cambio / @tasa_cheque,4),
                    @monto_i_otros = round(@monto_i_otros  *@tasa_cambio / @tasa_cheque, 4),
                    @monto_abono = round(@monto_abono * @tasa_cambio / @tasa_cheque,4)

          select @monto_i_ventasc = @monto_i_ventas ,
                    @monto_i_retencionc = @monto_i_retencion,
                    @monto_i_otrosc = @monto_i_otros ,
                    @monto_abonoc = @monto_abono 
         
    End
end

if @act_retenciones = 'N'
begin
   if @monto_i_ventas  > 0 and @ventas_retenido  = 'S' 
   begin
       select @monto_retencion = @monto_i_ventas
       select @monto_retencionc = @monto_i_ventasc
 
      select @cuenta_impuestos = cuenta_contable,
                 @centro_impuestos = codigo_centro 
       from gn_impuestos
       where codigo_impuesto = @impto_ventas

       if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_impuestos ) = 'N' 
          select @centro_impuestos = null

       insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
           values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @aju1, @cuenta_impuestos, @centro_impuestos, 0, @monto_i_ventas , 'C' )

       if @@error <> 0
       begin
            raiserror (' No se puede insertar el impuesto de compras - trinsbn_cheques_cargos' ,16,1,5000 )
            rollback work
            return

       end

   end

   if @monto_i_retencion > 0 and @retencion_retenido = 'S'
   begin
       select @monto_retencion = @monto_retencion + @monto_i_retencion
       select @monto_retencionc = @monto_retencionc + @monto_i_retencionc
 
       select @cuenta_impuestos = cuenta_contable,
                 @centro_impuestos = codigo_centro 
       from gn_impuestos
       where codigo_impuesto = @impto_retencion

       if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_impuestos ) = 'N' 
          select @centro_impuestos = null

       insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
           values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @aju2, @cuenta_impuestos, @centro_impuestos, 0, @monto_i_retencion, 'C'  )

       if @@error <> 0
       begin
            raiserror (' No se puede insertar el impuesto de compras - trinsbn_cheques_cargos' ,16,1,5000 )
            rollback work
            return

       end


   end

   if @monto_i_otros > 0 and @otros_retenido = 'S'
   begin
       select @monto_retencion = @monto_retencion + @monto_i_otros
       select @monto_retencionc = @monto_retencionc + @monto_i_otrosc
 
       select @cuenta_impuestos = cuenta_contable,
                 @centro_impuestos = codigo_centro 
       from gn_impuestos
       where codigo_impuesto = @otro_impto

       if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_impuestos ) = 'N' 
          select @centro_impuestos = null

       insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
           values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @aju3, @cuenta_impuestos, @centro_impuestos, 0, @monto_i_otros , 'C' )

       if @@error <> 0
       begin
            raiserror (' No se puede insertar el impueso de comrpas - trinsbn_cheques_cargos' ,16,1,5000 )
            rollback work
            return

       end


   end

end


select @monto_abono = @monto_abono + @monto_retencion 
select @monto_abonoc = @monto_abonoc + @monto_retencionc



if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_contable ) = 'N' 
          select @codigo_centro = null
 
insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
           values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @car, @cuenta_contable, @codigo_centro, @monto_abono, 0 , 'C' )

if @@error <> 0
begin
       raiserror (' No se puede insertar el monto de la factura - trinsbn_cheques_cargos' ,16,1,5000 )
       rollback work
       return

end

-- Calculamos el diferencial cambiario 

select @diferencia = @monto_abono - @monto_abonoc

declare @error varchar(100)

select @error  = convert(varchar(12) , @monto_abono ) + '    ' +isnull( convert(varchar(12), @monto_abonoc ), '0')

/*
raiserror ( @error ,16,1,5000)
rollback work
return
*/

select @cuenta_ingresos = cuenta_ingresos,
          @cuenta_egresos = cuenta_egresos,
          @codigo_centro = codigo_centro
from gn_monedas
where codigo_moneda = @moneda_cheque


if @diferencia < 0 
begin

    if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_egresos ) = 'N' 
      select @codigo_centro = null

    insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
           values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @aju4, @cuenta_egresos, @codigo_centro, @diferencia* -1, 0 ,'C' )

    if @@error <> 0
   begin
       raiserror (' No se puede insertar el impueso de comrpas - trinsbn_cheques_cargos' ,16,1,5000 )
       rollback work
       return

   end

        
end
else
begin

   if @diferencia > 0 
   begin

       if ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_ingresos ) = 'N' 
         select @codigo_centro = null

       insert into bn_cheques_det ( codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado )
             values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @aju4, @cuenta_ingresos, @codigo_centro, 0, @diferencia, 'C'  )

       if @@error <> 0
      begin
          raiserror (' No se puede insertar el impueso de comrpas - trinsbn_cheques_cargos' ,16,1,5000 )
          rollback work
          return

      end
   end


end

update bn_cheques_cargos
    set car = @car,
         aju1 = @aju1,
         aju2 = @aju2,
         aju3 = @aju3,
         aju4 = @aju4
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and documento_id = @documento_id

if @@error <> 0
begin
      raiserror (' No se puede insertar el impueso de comrpas - trinsbn_cheques_cargos' ,16,1,5000 )
      rollback work
      return
 end


go

