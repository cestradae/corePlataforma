-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_prenta_hn]
  As SELECT TOP 1000 a.codigo_impuesto,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.observaciones FROM [dbo].[no_parametros_renta_hn] a
go

