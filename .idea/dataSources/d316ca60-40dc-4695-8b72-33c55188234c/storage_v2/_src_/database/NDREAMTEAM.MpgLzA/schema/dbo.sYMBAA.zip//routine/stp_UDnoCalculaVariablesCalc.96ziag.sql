CREATE procedure [dbo].[stp_UDnoCalculaVariablesCalc]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint
as
---------------------------
-- Creado por LDR
-- Fecha 18/05/2009
-- Asunto Calculo de Variables Formuladas
---------------------------
declare @codigo_valor char(10)
declare @formula varchar(30)
declare @codigo_empleado char(10)
declare @error smallint
declare @result decimal(18,4)
declare @procedimiento varchar(30)
declare @tipo_variable	char(1)

declare cur_formulavar cursor for
   select codigo_valor,
          formula,
          procedimiento ,
          tipo_variable  
   from no_nomina_valores
   where codigo_tipo = @codigo_tipo
     and tipo_variable in ('2','3') 

Begin Tran
open cur_formulavar
fetch cur_formulavar into @codigo_valor , @formula, @procedimiento , @tipo_variable
while @@fetch_status = 0
Begin

   if @tipo_variable = '3'
   Begin


      select @formula = 'stp_UDnoFormula'+@formula
      if not exists ( select 1 from sysobjects where name = @formula )
      Begin
         Raiserror ('No existe la formula %s para la variable calculada %s - stp_UDnoCalculaVariablesCalc ' , 16,1,@formula, @codigo_valor)
         Rollback work
         Close cur_formulavar
         Deallocate cur_formulavar
         Return 9
      End
      Else
	    Begin

        exec @error = stp_UDnoCalcFormulaVar @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @formula ,@codigo_valor
        if @error <> 0
        Begin
           Raiserror ('No se puedo efectuar el calculo de formula %s con variable %s - stp_UDnoCalculaVariablesCalc ' , 16,1, @formula, @codigo_valor )
           Rollback work
           Close cur_formulavar
           Deallocate cur_formulavar
           Return 9  
        End 
      End
   End
   Else
   Begin 
      if not exists ( select 1 from sysobjects where name = @procedimiento )
      Begin
         Raiserror ('No existe el procedimiento %s para la variable calculada %s ' , 16,1,@procedimiento, @codigo_valor)
         Rollback work
         Close cur_formulavar
         Deallocate cur_formulavar
         Return 9
      End
      Else
	    Begin
        exec @error = @procedimiento @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_valor
        if @error <> 0
        Begin
           Raiserror ('No se puedo efectuar el calculo procedimiento %s con variable %s ' , 16,1, @formula, @codigo_valor )
           Rollback work
           Close cur_formulavar
           Deallocate cur_formulavar
           Return 9  
        End 
      End
   End
   fetch cur_formulavar into @codigo_valor , @formula , @procedimiento , @tipo_variable
End
close cur_formulavar
deallocate cur_formulavar
Commit Tran
go

