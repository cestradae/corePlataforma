-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_nvarsistema]
  (  @oldcodigo_empleado char (10) ,
  @oldcodigo_variable varchar (20) ,
  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint  )
As DELETE [dbo].[no_nomina_variables_sistema] 
WHERE (codigo_empleado =  @oldcodigo_empleado AND 
codigo_variable =  @oldcodigo_variable AND 
codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
no_calculo =  @oldno_calculo)
go

