-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_referencias]
  (  @oldreferencia varchar (20)  )
As SELECT a.referencia,a.descripcion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_referencias] a
WHERE (a.referencia =  @oldreferencia)
go

