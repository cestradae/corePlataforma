----------------------------------------------------------------------------------------------------------------
Create PROCEDURE [dbo].[stp_udno_obtieneconfiguracionpunto]
AS
SET NOCOUNT ON
DECLARE @descripcion VARCHAR(60)
SELECT @descripcion = descripcion 
FROM dbo.no_tipos_nomina a
INNER JOIN dbo.no_configuracion_punto b
ON a.codigo_tipo = b.codigo_tipo

SELECT ISNULL(@descripcion,'Sin configuracion')
go

