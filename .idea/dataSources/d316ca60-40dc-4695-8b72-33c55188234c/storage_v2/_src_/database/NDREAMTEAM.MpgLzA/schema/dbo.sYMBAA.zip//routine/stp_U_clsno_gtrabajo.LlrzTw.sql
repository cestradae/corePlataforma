-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_gtrabajo](  @oldgrupo_trabajo smallint ,
  @grupo_trabajo smallint ,
  @nombre_grupo varchar (50) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_grupos_trabajo] 
WHERE grupo_trabajo =  @oldgrupo_trabajo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_grupos_trabajo] Set 
    grupo_trabajo = @grupo_trabajo,
    nombre_grupo = @nombre_grupo 
WHERE 	( grupo_trabajo =  @oldgrupo_trabajo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_grupos_trabajo]
  WHERE ( grupo_trabajo =  @grupo_trabajo )
go

