-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_referencias](@AUTO_EditStamp varchar(30) OUT,
  @referencia varchar (20) ,
  @descripcion varchar (100)  )
As 
	INSERT INTO [dbo].[no_referencias]
(  referencia ,
  descripcion  )
VALUES (  @referencia ,
  @descripcion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_referencias]
  WHERE ( referencia =  @referencia )
go

