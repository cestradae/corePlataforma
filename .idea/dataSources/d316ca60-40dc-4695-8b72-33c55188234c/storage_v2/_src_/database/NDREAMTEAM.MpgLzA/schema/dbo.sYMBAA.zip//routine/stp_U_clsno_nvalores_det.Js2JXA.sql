-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsno_nvalores_det](  @oldcodigo_tipo char (2) ,
  @oldcodigo_valor char (10) ,
  @oldcodigo_dato char (10) ,
  @codigo_tipo char (2) ,
  @codigo_valor char (10) ,
  @codigo_dato char (10) ,
  @unidad varchar (10) ,
  @estandar decimal (18,4) ,
  @EditStamp varchar(30) OUT ,
  @orden smallint ,
  @obligatorio char (1)  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_nomina_valores_det] 
WHERE codigo_tipo =  @oldcodigo_tipo AND 
codigo_valor =  @oldcodigo_valor AND 
codigo_dato =  @oldcodigo_dato 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_nomina_valores_det] Set 
    codigo_tipo = @codigo_tipo,
    codigo_valor = @codigo_valor,
    codigo_dato = @codigo_dato,
    unidad = @unidad,
    estandar = @estandar,
    orden = @orden,
    obligatorio = @obligatorio 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_valor =  @oldcodigo_valor AND 
codigo_dato =  @oldcodigo_dato )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_nomina_valores_det]
  WHERE ( codigo_tipo =  @codigo_tipo AND 
codigo_valor =  @codigo_valor AND 
codigo_dato =  @codigo_dato )
go

