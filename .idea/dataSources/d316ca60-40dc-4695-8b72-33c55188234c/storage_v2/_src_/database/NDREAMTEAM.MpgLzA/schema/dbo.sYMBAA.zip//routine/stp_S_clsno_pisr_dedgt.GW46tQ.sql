
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_pisr_dedgt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_Deduccion char (3)  )
As SELECT a.codigo_impuesto,a.codigo_Deduccion,a.tipo_deduccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_isr_dedgt] a
WHERE (a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.codigo_Deduccion =  @oldcodigo_Deduccion)
go

