-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_nomina_puestos]
  (  @oldcodigo_puesto char (10) ,
  @oldcodigo_tipo char (2)  )
As DELETE [dbo].[no_nomina_puestos] 
WHERE (codigo_puesto =  @oldcodigo_puesto AND 
codigo_tipo =  @oldcodigo_tipo)
go

