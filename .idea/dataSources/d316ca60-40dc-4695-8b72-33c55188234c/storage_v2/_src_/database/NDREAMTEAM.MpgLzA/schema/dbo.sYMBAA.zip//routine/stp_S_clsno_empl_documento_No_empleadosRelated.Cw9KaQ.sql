-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_empl_documento_No_empleadosRelated]
(  @oldcodigo_empleado char (10)  )
  As 
SELECT a.codigo_empleado,a.correlativo,a.nombre_documento,a.path_documento,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_empleado_documento] a
WHERE 
a.codigo_empleado =  @oldcodigo_empleado
go

