create procedure stp_UDnoFormula05   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @tmp1 decimal(18,4)

begin
  exec stp_UDnoDiasDiferencia @codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  07 , 01 ,06 , 30 , @tmp1 out

  set @result=@tmp1+1
end
go

