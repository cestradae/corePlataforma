-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_tipos_nomina](  @oldCodigo_tipo char (2) ,
  @Codigo_tipo char (2) ,
  @Descripcion varchar (60) ,
  @no_autorizaciones smallint ,
  @EditStamp varchar(30) OUT ,
  @Codigo_moneda smallint ,
  @Codigo_banco smallint ,
  @Id_cuenta varchar (32) ,
  @cuenta_nomina varchar (30) ,
  @centro_nomina varchar (20) ,
  @formato_recibo varchar (50) ,
  @monto_maximo money ,
  @formato_banco varchar (50) ,
  @formato_lote_cheque varchar (50) ,
  @referencia_cheque varchar (40) ,
  @reporte_libro smallint ,
  @nombre_corto varchar (30) ,
  @formato_depositos varchar (60) ,
  @impresora varchar (50) ,
  @orden smallint ,
  @observaciones_cheque varchar (50) ,
  @ch_aut_por varchar (40) ,
  @ch_rev_por varchar (40)  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_tipos_nomina] 
WHERE codigo_tipo =  @oldCodigo_tipo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_tipos_nomina] Set 
    codigo_tipo = @Codigo_tipo,
    descripcion = @Descripcion,
    no_autorizaciones = @no_autorizaciones,
    codigo_moneda = @Codigo_moneda,
    codigo_banco = @Codigo_banco,
    id_cuenta = @Id_cuenta,
    cuenta_nomina = @cuenta_nomina,
    centro_nomina = @centro_nomina,
    formato_recibo = @formato_recibo,
    monto_maximo = @monto_maximo,
    formato_banco = @formato_banco,
    formato_lote_cheque = @formato_lote_cheque,
    referencia_cheque = @referencia_cheque,
    reporte_libro = @reporte_libro,
    nombre_corto = @nombre_corto,
    formato_depositos = @formato_depositos,
    impresora = @impresora,
    orden = @orden,
    observaciones_cheque = @observaciones_cheque,
    ch_aut_por = @ch_aut_por,
    ch_rev_por = @ch_rev_por 
WHERE 	( codigo_tipo =  @oldCodigo_tipo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_tipos_nomina]
  WHERE ( codigo_tipo =  @Codigo_tipo )
go

