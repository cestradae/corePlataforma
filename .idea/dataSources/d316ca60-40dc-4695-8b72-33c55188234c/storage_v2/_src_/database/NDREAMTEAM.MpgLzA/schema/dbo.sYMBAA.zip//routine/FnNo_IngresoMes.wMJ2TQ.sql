

CREATE FUNCTION [dbo].[FnNo_IngresoMes] ( 
   @codigo_tipo char(2),
   @codigo_ingreso char(3),
   @codigo_empleado char(10),
   @periodo_id char(10) )
RETURNS varchar(100) AS  
Begin

-----------------------------
-- hecho por ldr
-- fecha 02/12/2014
-- Asunto Calcula el mes completo sin importar si entro a principio o fin de mes
-----------------------------

-----------------------------
-- hecho por dortiz
-- fecha 22/08/2014
-- Asunto Calcula el proporcional correcto cuando hay aumentos dentro de un mes
-----------------------------
-- hecho por dortiz
-- fecha 20/01/2014
-- Asunto cuando existe un aumento salarial en el mes en el que el empleado esta de baja hace el proporcional 
-----------------------------
-- hecho por ldr
-- fecha 03/12/2013
-- Asunto se modifica para que agrege un dia a la resta de 30 dias 
-------------------------------
-- hecho por ldr
-- fecha 16/10/2013
-- Asunto se modifica para que tome tipo ano de 30 dias
-------------------------------
-- Hecho por ldr
-- Fecha 13/10/2013
-- Asunto Se copio del stp con el mismo nombre  
-------------------------------

-------------------------------
-- Hecho por ldr
-- Fecha 04/10/2010
-- Asunto Devuelve el ingreso correspondiente al mes  
-------------------------------

declare @anostr char(4)
declare @messtr char(2)
declare @fecha_inicial datetime
declare @fecha_final datetime
declare @fecha_inicio datetime
declare @monto money
declare @fecha_baja datetime
declare @fecha_inicio_rel_lab datetime
declare @dias_inicio smallint
declare @dias_baja smallint
declare @perioricidad char(1)
declare @dias smallint
declare @fin smallint
declare @monto_calculo money
declare @fecha datetime
declare @ano smallint
declare @mes smallint
declare @tipo_ano char(1)
declare @fecha_fin_periodo datetime
declare @mensaje varchar(100)
declare @usa_base_completa char(1)
declare @fecha_fin_mes datetime  
declare @dias_mes decimal(18,4)
declare @dias_fin smallint

select @tipo_ano = tipo_ano, 
	@usa_base_completa=usa_base_completa
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

if @usa_base_completa is null 
	select @usa_base_completa='2'
	
select @ano = substring(@periodo_id,3,4)
select @mes = substring(@periodo_id,7,2)

  
---------------------------------
-- Obtenemos el monto correspondiente al mes que estamos solicitando 
---------------------------------
select @anostr = convert(char(4),@ano)

if @mes <10 
   select @messtr = '0'+ convert(varchar(2),@mes)
else
   select @messtr = convert(varchar(2),@mes)

select @fecha_inicial = @anostr + @messtr + '01'
select @fecha_final = dateadd(mm,1,@fecha_inicial)
select @fecha_final = dateadd(dd,-1,@fecha_final)

select @fecha_baja = fecha_baja
from no_empleados
where codigo_empleado = @codigo_empleado
and estado_empleado = 'B'

if @tipo_ano is null select @tipo_ano = '1'

select @fecha_inicio_rel_lab = fecha_inicio_rel_lab
from no_empleados
where codigo_empleado = @codigo_empleado


select @dias = datepart(dd,@fecha_final),
       @fin = 0,
       @monto = 0 ,
       @fecha = @fecha_final


if @fecha_baja is not null and datepart(yyyy,@fecha_baja)*100+datepart(mm,@fecha_baja)=@ano*100+@mes 
  
  select @fecha_final = @fecha_baja, 
         @fecha = @fecha_baja

if @tipo_ano = '2'  --- Ano comercial 
   select @dias = 30

if @fecha_baja < @fecha_inicial select @fin = 1

while @fin = 0
Begin

  select @monto_calculo = 0

  select @monto_calculo = monto,
         @fecha_inicio = fecha_inicio,
         @perioricidad = perioricidad
  from no_empleado_ingresos_detv
  where fecha_inicio < @fecha
    and codigo_empleado = @codigo_empleado
    and codigo_tipo = @codigo_tipo
    and codigo_ingreso = @codigo_ingreso
  order by fecha_inicio asc

  if @@rowcount = 0 select @fin = 1  
/*
	if @fecha_inicio > @fecha_inicio_rel_lab
	begin 
	
		select @fecha_inicio=@fecha_inicio_rel_lab
	
	end */
	
  if datepart(yy,@fecha_inicio) * 100 + datepart(mm,@fecha_inicio ) = 
     datepart(yy,@fecha) * 100 + datepart(mm,@fecha)
  Begin
     if datepart(dd,@fecha_inicio) = 1 
     Begin
        select @fin = 1
        select @dias_inicio = 0
        -- cambio realizado dortiz 20/01/2014
        if @tipo_ano = '2'
        Begin
            select @messtr = datepart(mm,@fecha_inicio)
            if len(@messtr) = 1 select @messtr = '0' + @messtr 
            select @fecha_fin_periodo = convert(char(4),datepart(yy,@fecha_inicio)) +
                                  @messtr + '01'
            select @fecha_fin_periodo = dateadd(mm,1,@fecha_fin_periodo)
            select @fecha_fin_periodo = dateadd(dd,-1, @fecha_fin_periodo)
            
            if @fecha_fin_periodo = @fecha 
               select @dias_inicio = 0
            else
               select @dias_inicio = @dias-datepart(dd,@fecha) + 1 
              
        End
        Else
        Begin
           select @dias_inicio = @dias-datepart(dd,@fecha) 
        End 
        -- fin cambio dortiz 
        
     End
     else
     Begin

        if @tipo_ano = '2'
        Begin
            select @messtr = datepart(mm,@fecha_inicio)
            if len(@messtr) = 1 select @messtr = '0' + @messtr 
            select @fecha_fin_periodo = convert(char(4),datepart(yy,@fecha_inicio)) +
                                  @messtr + '01'
            select @fecha_fin_periodo = dateadd(mm,1,@fecha_fin_periodo)
            select @fecha_fin_periodo = dateadd(dd,-1, @fecha_fin_periodo)
            
            if @fecha_fin_periodo = @fecha_inicio 
               select @dias_inicio = 29
            else
               select @dias_inicio = datepart(dd,@fecha_inicio) - 1
                  
           -- cambio realizado dortiz 20/01/2014
           
           if @fecha_fin_periodo = @fecha 
               select @dias_inicio =@dias_inicio+ 0
            else
               select @dias_inicio = @dias_inicio+@dias-datepart(dd,@fecha) 
               
			-- fin cambio dortiz
		   
	        		 
        End
        Else
        Begin
           select @dias_inicio = datepart(dd,@fecha_inicio) - 1 +@dias-datepart(dd,@fecha) -- cambio dortiz
                  

        End  
        
        select @fecha = @fecha_inicio
     End 
  End
  Else
  Begin
     select @fin = 1
     select @dias_inicio = @dias - datepart(dd,@fecha) 
     
     if @tipo_ano = '2'
     Begin
        select @messtr = datepart(mm,@fecha)
        if len(@messtr) = 1 select @messtr = '0' + @messtr 
        select @fecha_fin_periodo = convert(char(4),datepart(yy,@fecha)) +
                                  @messtr + '01'
       
        select @fecha_fin_periodo = dateadd(mm,1,@fecha_fin_periodo)
        select @fecha_fin_periodo = dateadd(dd,-1, @fecha_fin_periodo)
        
        if convert(char(10),@fecha_fin_periodo,103) = convert(char(10),@fecha,103) 
           select @dias_inicio = 0
        else
           select @dias_inicio = @dias - datepart(dd,@fecha) + 1 
 
     End
     Else
     Begin
	 -- cambio dortiz 22/08/2014
           if convert(char(10),@fecha_final,103) = convert(char(10),@fecha,103) 
           select @dias_inicio = 0
        else
           select @dias_inicio = @dias - datepart(dd,@fecha) +1
           
     End  
    end
    
     -- fin cambio dortiz 22/08/2014

 
--  select @monto =   @monto + @dias_inicio
 
 if @usa_base_completa='2'
begin
	select @monto = @monto + round(@monto_calculo - (@monto_calculo/ @dias) * @dias_inicio,2)

end 
 
   select @monto =@monto +@monto_calculo --+ round(@monto_calculo - (@monto_calculo/ @dias) * @dias_inicio,2)
  
end


if datepart(yy,@fecha) * 100 + datepart(mm,@fecha ) = 
   datepart(yy,@fecha_inicio_rel_lab) * 100 + datepart(mm,@fecha_inicio_rel_lab) 
Begin

   if @tipo_ano = '2'
   BEgin
      select @messtr = datepart(mm,@fecha_inicio)
      if len(@messtr) = 1 select @messtr = '0' + @messtr 

      select @fecha_fin_periodo = convert(char(4),datepart(yy,@fecha_inicio_rel_lab)) +
                                  @messtr + '01'
      select @fecha_fin_periodo = dateadd(mm,1,@fecha_fin_periodo)
      select @fecha_fin_periodo = dateadd(dd,-1, @fecha_fin_periodo)
     
      if @fecha_fin_periodo = @fecha_inicio_rel_lab 
          select @dias_inicio = 30
      else 
          select @dias_inicio = datepart(dd,@fecha_inicio_rel_lab) - 1
      
   End
   Else
   Begin
      select @dias_inicio = datepart(dd,@fecha_inicio_rel_lab) - 1
   End
   
   
End
Else
Begin
   select @dias_inicio = 0
End


if datepart(yy,@fecha) * 100 + datepart(mm,@fecha ) = 
   datepart(yy,@fecha_baja) * 100 + datepart(mm,@fecha_baja) 
Begin
   if @tipo_ano = '2'
   BEgin
      select @messtr = datepart(mm,@fecha_inicio)
      if len(@messtr) = 1 select @messtr = '0' + @messtr 
 
      select @fecha_fin_periodo = convert(char(4),datepart(yy,@fecha_baja)) +
                                  @messtr + '01'
      select @fecha_fin_periodo = dateadd(mm,1,@fecha_fin_periodo)
      select @fecha_fin_periodo = dateadd(dd,-1, @fecha_fin_periodo)
      if @fecha_fin_periodo = @fecha_baja 
         select @dias_baja = 0
      else 
         select @dias_baja = 30 - datepart(dd,@fecha_baja)
      
   End
   Else
   Begin
      select @dias_baja = datepart(dd,@fecha_final)- datepart(dd,@fecha_baja)
   End
End
Else
Begin
   select @dias_baja = 0
End


if @fecha_baja is null select @dias_baja = 0


if @perioricidad = 'M' 
Begin
   select @monto = @monto 
    
End
if @perioricidad = 'Q' 
   select @monto = @monto - ( @monto / @dias ) * (@dias_baja)
if @perioricidad = 'D' 
   select @monto = (@monto * @dias) - @monto  * (@dias_inicio + @dias_baja)
if @perioricidad = 'A' 
   select @monto = (@monto /12) - (@monto/12/30)  * (@dias_inicio + @dias_baja)

if @monto is null select @monto = 0
/*
if @usa_base_completa='1'
begin 
	select @fecha_fin_mes=  convert(char(10),SUBSTRING(@periodo_id,3,4) +
                                  SUBSTRING(@periodo_id,7,2) + '01')
            select @fecha_fin_mes = dateadd(mm,1,@fecha_fin_mes)
            select @fecha_fin_mes = dateadd(dd,-1, @fecha_fin_mes)
    select @dias_inicio=0
  
     select @dias_mes = datepart(dd,@fecha_fin_mes)

	if substring(convert(char(10),@fecha,112),1,6) = substring(convert(char(10),@fecha_inicio_rel_lab,112),1,6)
		 select @dias_inicio = datepart(dd,@fecha_inicio_rel_lab)-1
	   
	  select @dias_fin = 0

	  if convert(char(10),@fecha,112) = convert(char(10),@fecha_baja,112)
	  Begin
		 if convert(char(10),@fecha_baja,112) <> convert(char(10),@fecha_fin_mes,112)
		 Begin 
		    if @tipo_ano = '2'  
		    	select @dias_fin = 30 - datepart(dd,@fecha_baja)
			else
				select @dias_fin = @dias_mes - datepart(dd,@fecha_baja)
		 End
		 else
		 Begin
			select @dias_fin = 0
		 End
	  End
	  
      if @tipo_ano = '2'
    	  select @dias = 30 - @dias_inicio - @dias_fin 
	  else
	      select @dias = @dias_mes - @dias_inicio - @dias_fin

	  if @dias > 0
	  begin 
	   if @tipo_ano = '2'
    	  select @monto = @monto / @dias * 30
	  else
	      select @monto = @monto / @dias * 31
	   
	  end 
end 
*/

return @monto

End


go

