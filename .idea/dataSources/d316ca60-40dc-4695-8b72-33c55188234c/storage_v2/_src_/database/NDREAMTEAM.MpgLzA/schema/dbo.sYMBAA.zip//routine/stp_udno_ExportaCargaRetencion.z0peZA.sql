--stp_udno_ExportaCargaRetencion '01','50', 2009
Create PROCEDURE [dbo].[stp_udno_ExportaCargaRetencion]
		@codigo_tipoI	CHAR(2),
		@codigo_tipoF	CHAR(2),
		@ano	SMALLINT
		
AS
------------------------------------------------
--Hecho por Mario Juarros
--Fecha:19/11/2009
--Procedimiento para exportar la Carga de Retencion
------------------------------------------------

SET NOCOUNT ON

DECLARE @cod_tipo CHAR(10),
		@codigo_empleado CHAR(10),
		@monto	MONEY,
		@impuesto	MONEY,
		@nombre_campo	VARCHAR(10),
		@valor	MONEY,
		@deduccion MONEY
		

CREATE TABLE #CargaRetencion (
		codigo_tipo			CHAR(2) COLLATE Modern_Spanish_CI_AS,
		codigo_empleado		CHAR (10) COLLATE Modern_Spanish_CI_AS,
		numero_const		VARCHAR(50)COLLATE Modern_Spanish_CI_AS,
		nit					VARCHAR (30) COLLATE Modern_Spanish_CI_AS,
		Nombre				VARCHAR (150) COLLATE Modern_Spanish_CI_AS,
		Actividad			VARCHAR(250)COLLATE Modern_Spanish_CI_AS,
		Concepto			VARCHAR(250)COLLATE Modern_Spanish_CI_AS,
		renta_imponible		MONEY,
		impuesto_anual		MONEY		
		)
		
CREATE TABLE #impuestoanual (
	codigo_tipo	CHAR(2)COLLATE Modern_Spanish_CI_AS,
	codigo_empleado	CHAR(10)COLLATE Modern_Spanish_CI_AS,
	impuesto	MONEY,
)		

--Insertamos valores generales del empleado
INSERT INTO #CargaRetencion (
	codigo_tipo,
	codigo_empleado,	
	nit,
	Nombre	
	)
SELECT b.codigo_tipo, a.codigo_empleado, numero_tributario, nombres + ' ' + apellidos + ' ' + ISNULL(apellido_casada,'')
FROM dbo.no_empleados AS a
INNER JOIN no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)
AND a.estado_empleado = 'A'

--Obtenemos solo los que tienen retencion ISR
SELECT DISTINCT codigo_empleado
INTO #excluye
FROM dbo.no_nomina_det
WHERE codigo_deduccion = '02' AND 
	(codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)AND
	CONVERT(SMALLINT,SUBSTRING(periodo_id,3,4))=@ano

--Obtenemos los periodos del año
SELECT codigo_tipo, ano, periodo, periodo_id
INTO #periodospago
FROM dbo.no_periodos_pago
WHERE ano = @ano AND
codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF

--Se calcula el total de ingresos
SELECT a.codigo_tipo, a.codigo_empleado, SUM(a.monto_ingreso)monto_ingreso
INTO #totalingresos
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_ingresos AS b
ON (a.codigo_ingreso = b.codigo_ingreso AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
WHERE a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF
GROUP BY a.codigo_tipo, a.codigo_empleado
ORDER BY codigo_empleado

--Se calcula el total de egresos
SELECT a.codigo_tipo, a.codigo_empleado, SUM(a.monto_deduccion)monto_deduccion
INTO #totalegresos
FROM no_nomina_det AS a 
INNER JOIN dbo.no_nomina_deducciones AS b
ON (a.codigo_deduccion = b.codigo_deduccion AND
	a.codigo_tipo = b.codigo_tipo)
INNER JOIN #periodospago AS c
ON (a.periodo_id = c.periodo_id)
WHERE a.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF
GROUP BY a.codigo_tipo, a.codigo_empleado
ORDER BY codigo_empleado

--Se calcula la renta imponible
SELECT a.codigo_tipo, a.codigo_empleado, (monto_ingreso - monto_deduccion)renta_imponible
INTO #rentaimponible
FROM #totalingresos AS a 
INNER JOIN #totalegresos AS b
ON (a.codigo_empleado = b.codigo_empleado AND
	a.codigo_tipo = b.codigo_tipo)

--Calculamos el impuesto anual a pagar
DECLARE curimpuesto CURSOR FOR
	SELECT codigo_tipo, codigo_empleado, renta_imponible FROM #rentaimponible
OPEN curimpuesto
FETCH curimpuesto INTO @cod_tipo, @codigo_empleado, @monto
	WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @impuesto = 0
			--Se calcula el impuesto anual a pagar según tabla de sat
			IF @monto <= 65000
				SELECT @impuesto = (@monto * 0.15)
			IF @monto > 65000 AND @monto <= 180000
				SELECT @impuesto = 9750.00 + ((@monto - 65000)* 0.20)
			IF @monto > 180000 AND @monto <= 295000
				SELECT @impuesto = 32750.00 + ((@monto - 180000)* 0.25)
			IF @monto >	295000
				SELECT @impuesto = 61500.00 + ((@monto - 295000)* 0.31)
				
			INSERT INTO #impuestoanual (
				codigo_tipo,
				codigo_empleado,
				impuesto
			) VALUES ( 
				@cod_tipo,
				@codigo_empleado,
				@impuesto ) 	
				
			FETCH curimpuesto INTO @cod_tipo, @codigo_empleado, @monto	
		END
CLOSE curimpuesto
DEALLOCATE curimpuesto

--Obtenemos los numeros de constancia
SELECT @nombre_campo = 'nconst' + CONVERT(VARCHAR,@ano)

SELECT b.codigo_tipo, a.codigo_empleado, nombre_campo, a.valor 
INTO #nconstancia
FROM dbo.no_empleado_campos AS a 
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF) AND
		a.nombre_campo = @nombre_campo

--Obtenemos la actividad para la constancia de Retencion
SELECT @nombre_campo = 'ActISR' + CONVERT(VARCHAR,@ano)

SELECT b.codigo_tipo, a.codigo_empleado, nombre_campo, a.valor 
INTO #actISR
FROM dbo.no_empleado_campos AS a 
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)AND
		a.nombre_campo = @nombre_campo

--Obtenemos el concepto para la constancia de retencion
SELECT @nombre_campo = 'conISR' + CONVERT(VARCHAR,@ano)

SELECT b.codigo_tipo, a.codigo_empleado, nombre_campo, a.valor 
INTO #conISR
FROM dbo.no_empleado_campos AS a 
INNER JOIN dbo.no_nomina_empleado AS b
ON (a.codigo_empleado = b.codigo_empleado)
WHERE (b.codigo_tipo BETWEEN @codigo_tipoI AND @codigo_tipoF)AND	
		a.nombre_campo = @nombre_campo
		
update #CargaRetencion set numero_const = (SELECT valor 
FROM #nconstancia 
WHERE #CargaRetencion.codigo_empleado= #nconstancia.codigo_empleado AND
		#CargaRetencion.codigo_tipo = #nconstancia.codigo_tipo)

update #CargaRetencion set actividad = (SELECT valor 
FROM #actISR 
WHERE #CargaRetencion.codigo_empleado= #actISR.codigo_empleado AND
		#CargaRetencion.codigo_tipo = #actISR.codigo_tipo)
		
update #CargaRetencion set concepto = (SELECT valor 
FROM #conISR 
WHERE #CargaRetencion.codigo_empleado= #conISR.codigo_empleado AND
		#CargaRetencion.codigo_tipo = #conISR.codigo_tipo)

update #CargaRetencion set renta_imponible = (SELECT renta_imponible
FROM #rentaimponible 
WHERE #CargaRetencion.codigo_empleado= #rentaimponible.codigo_empleado AND
		#CargaRetencion.codigo_tipo = #rentaimponible.codigo_tipo)

update #CargaRetencion set impuesto_anual = (SELECT impuesto
FROM #impuestoanual 
WHERE #CargaRetencion.codigo_empleado= #impuestoanual.codigo_empleado AND
		#CargaRetencion.codigo_tipo = #impuestoanual.codigo_tipo)
		
DELETE FROM #CargaRetencion WHERE codigo_empleado NOT IN (SELECT codigo_empleado FROM #excluye)		
		
SELECT ISNULL(numero_const,'')numero_const, ISNULL(nit,'')nit, ISNULL(Nombre,'')Nombre, ISNULL(Actividad,'')Actividad, ISNULL(Concepto,'')Concepto,
ISNULL(renta_imponible,'')renta_imponible, ISNULL(impuesto_anual,'')impuesto_anual
FROM #CargaRetencion
go

