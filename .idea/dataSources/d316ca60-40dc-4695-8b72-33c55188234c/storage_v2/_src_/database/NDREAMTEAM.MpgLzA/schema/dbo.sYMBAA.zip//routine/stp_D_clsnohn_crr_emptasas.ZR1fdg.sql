
-- Procedure definition
CREATE PROCEDURE stp_D_clsnohn_crr_emptasas
  (  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10) ,
  @oldcorrelativo smallint  )
As DELETE [dbo].[no_reporte_rentahn_emptasas] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo)
go

