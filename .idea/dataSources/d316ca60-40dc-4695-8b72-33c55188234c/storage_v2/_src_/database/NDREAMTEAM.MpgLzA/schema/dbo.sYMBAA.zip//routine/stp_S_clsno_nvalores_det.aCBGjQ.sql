-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_nvalores_det]
  (  @oldcodigo_tipo char (2) ,
  @oldcodigo_valor char (10) ,
  @oldcodigo_dato char (10)  )
As SELECT a.codigo_tipo,a.codigo_valor,a.codigo_dato,a.unidad,a.estandar,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.orden,a.obligatorio FROM [dbo].[no_nomina_valores_det] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.codigo_valor =  @oldcodigo_valor AND 
a.codigo_dato =  @oldcodigo_dato)
go

