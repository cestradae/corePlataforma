-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohndeptos]
As
  SELECT codigo_departamento, nombre_departamento
FROM no_siex_departamentos
go

