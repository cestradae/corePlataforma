
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_ffiniquitosdet_gt(  @codigo_formato smallint ,
  @correlativo smallint ,
  @nombre_procedimiento varchar (50) ,
  @tipo_resultado char (1) ,
  @prefijo varchar (20) ,
  @no_meses smallint ,
  @codigo_valor varchar (50) ,
  @condensa char (1)  )
As 
	INSERT INTO [dbo].[no_formatos_finiquitos_det]
(  codigo_formato ,
  correlativo ,
  nombre_procedimiento ,
  tipo_resultado ,
  prefijo ,
  no_meses ,
  codigo_valor ,
  condensa  )
VALUES (  @codigo_formato ,
  @correlativo ,
  @nombre_procedimiento ,
  @tipo_resultado ,
  @prefijo ,
  @no_meses ,
  @codigo_valor ,
  @condensa  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

