CREATE VIEW dbo.rrrhhrep
AS
SELECT     a.codigo_empleado, a.codigo_centro, a.nombre_usual, b.nombre_centro, a.fecha_inicio_rel_lab, a.fecha_baja, a.estado_empleado
FROM         dbo.no_empleados AS a INNER JOIN
                      dbo.cn_catalogo_centros AS b ON a.codigo_centro = b.codigo_centro
go

