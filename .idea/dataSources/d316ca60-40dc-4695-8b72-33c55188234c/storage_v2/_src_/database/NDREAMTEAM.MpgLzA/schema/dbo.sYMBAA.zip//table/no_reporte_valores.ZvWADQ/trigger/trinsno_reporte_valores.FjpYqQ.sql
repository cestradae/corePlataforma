
cREATE TRIGGER [trinsno_reporte_valores] ON [dbo].[no_reporte_valores] 
FOR INSERT
AS

declare  @codigo_tipo char(2),
             @periodo_id char(10),
             @no_reporte smallint,
             @grupo_id char(5),
             @genera_aut char(1),
              @fecha_ingreso datetime,
              @usuario_ingreso varchar(35)

select @codigo_tipo = codigo_tipo,
           @periodo_id = periodo_id,
           @no_reporte = no_reporte,
           @grupo_id = grupo_id,
           @genera_aut = genera_aut
from inserted


select @fecha_ingreso = getdate(),
           @usuario_ingreso = system_user

update no_reporte_valores 
     set estado_reporte = 'O',
           fecha_ingreso = @fecha_ingreso,
           usuario_ingreso = @usuario_ingreso
where codigo_tipo = @codigo_tipo
    and periodo_id = @periodo_id
    and no_reporte = @no_reporte


if @genera_aut = 'S'   -- Genera Empleados  automaticamente 
begin
     insert into no_reporte_empleado ( 
         codigo_tipo,
         periodo_id,
         no_reporte,
         codigo_empleado,
         codigo_departamento,
         codigo_centro )
     select @codigo_tipo,
               @periodo_id,
               @no_reporte,
               a.codigo_empleado,
               a.codigo_departamento,
               a.codigo_centro
     from no_empleados a, no_nomina_empleado b
     where a.estado_empleado in ( 'A' , 'S' )
        and a.codigo_empleado not in ( select codigo_empleado 
                                                       from no_reporte_empleado 
                                                       where codigo_tipo = @codigo_tipo
                                                            and periodo_id = @periodo_id
                                                            and no_reporte = @no_reporte )
        and a.codigo_empleado = b.codigo_empleado
        and b.codigo_tipo = @codigo_tipo

     if @@error <> 0
     begin
          raiserror (' No se pudieron insertar los empleados en el no_reporte_empleado - trinsno_reporte_valores ', 16,1,5000 )
          rollback work
          return
     end 
end



go

