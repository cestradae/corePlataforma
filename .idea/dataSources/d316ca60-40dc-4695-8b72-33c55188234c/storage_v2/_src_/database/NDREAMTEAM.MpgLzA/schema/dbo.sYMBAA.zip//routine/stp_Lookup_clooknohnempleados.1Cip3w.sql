-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohnempleados]
As
  SELECT codigo_empleado, nombre_usual
FROM no_empleados
go

