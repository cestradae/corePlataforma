-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_pvecinal_hn]
  (  @oldimpuesto_vecinal smallint  )
As SELECT TOP 1000 a.impuesto_vecinal,a.nombre_impuesto,a.codigo_impuesto,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_parametros_vecinal_hn] a
WHERE (a.impuesto_vecinal =  @oldimpuesto_vecinal)
go

