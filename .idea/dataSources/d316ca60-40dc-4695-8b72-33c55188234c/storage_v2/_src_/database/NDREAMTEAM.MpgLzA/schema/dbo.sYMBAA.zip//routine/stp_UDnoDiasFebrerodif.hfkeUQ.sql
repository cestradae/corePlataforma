CREATE procedure [dbo].[stp_UDnoDiasFebrerodif]-- '1','1 20120301','1 1',0,'01'
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_valor char(10)
AS

-------------------------------------------------------------
-- Creado por dortiz
-- Fecha 25/02/2013
-- Asunto Procedimiento que calcula dias diferencias del mes de febrero 
--   diferencia para ser mes comercial
-------------------------------------------------------------

declare @fecha_inicial datetime
declare @fecha_final datetime
declare @suma decimal(22,6)
declare @basedatos varchar(30)
declare @servidor varchar(30)
declare @conexion varchar(60)
declare @ssql varchar(8000)
declare @ano smallint
declare @mes smallint
declare @fecha_baja datetime

 declare @codigo_empleado as varchar(10)
 
 
 create Table #empleadosdias(codigo_Empleado varchar(10)  COLLATE Modern_Spanish_CI_AS, 
 dias smallint)

select @fecha_inicial = fecha_inicial,
       @fecha_final = fecha_final, 
       @ano=ano, 
       @mes=periodo
from no_periodos_pago
where periodo_id = @periodo_id

select @basedatos=basedatos, 
@servidor=servidor
from sap_parametros
where codigo_tipo=@codigo_tipo


        declare Cursor_empleados cursor for
  select A.codigo_empleado
  from no_nomina_emplcalc A
  INNER JOIN  NO_lIQUIDACIONES B
  ON A.CODIGO_EMPLEADO=B.CODIGO_EMPLEADO
  AND A.CODIGO_TIPO=B.CODIGO_TIPO
  where A.codigo_tipo=@codigo_tipo
  and A.periodo_id=@periodo_id 
  and A.grupo_id=@grupo_id 
  and A.no_Calculo=@no_Calculo
  AND B.FECHA_LIQUIDACION BETWEEN @fecha_inicial AND @fecha_final
  
  
    open Cursor_empleados
        -- Avanzamos un registro y cargamos en las variables los valores encontrados en el primer registro
  fetch next from Cursor_empleados
  into @codigo_empleado
      while @@fetch_status = 0
    begin

select @fecha_baja=fecha_baja
from no_Empleados
where codigo_empleado=@codigo_Empleado


if @mes=2
begin
	if datepart(dd,@fecha_baja)<>datepart(dd,@fecha_final)
	begin
		insert into #empleadosdias
		select @codigo_empleado,30-datepart(dd,@fecha_final)
	
	end
end 

    -- Avanzamos otro registro
    fetch next from Cursor_empleados
    into @codigo_empleado
    end
    -- cerramos el cursor
        close Cursor_empleados
  deallocate Cursor_empleados



Begin Tran

  insert into no_nomina_valores_calculados (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        codigo_valor,
        valor )

select @codigo_tipo,
       @periodo_id,
       @grupo_id,
       @no_calculo,
       c.codigo_empleado, 
       @codigo_valor,
       sum(ISNULL(d.dias,0))
from no_nomina_emplcalc b
inner join no_empleados c
	on b.codigo_empleado=c.codigo_empleado
inner join  #empleadosdias d
	on c.codigo_empleado=d.codigo_empleado
where b.codigo_tipo = @codigo_tipo
  and b.periodo_id = @periodo_id
  and b.grupo_id = @grupo_id
  and b.no_calculo = @no_calculo
group by c.codigo_empleado, c.codigo_departamento, c.codigo_centro


if @@error <> 0
Begin
   Raiserror ('No se puede calcular la variable %s - stp_UDnoDiasFebrerodif', 16,1,@codigo_valor)
   Rollback work
   Return 9
End

Commit Tran
go

