create procedure [dbo].[stp_UDnoAbreSegSocial]
    @ano smallint,
    @periodo smallint
as
---------------------------------------------------------------------
--Creado por LSAO
--Fecha 25/10/2003
--Asunto Abre Reporte del igss
---------------------------------------------------------------------


update no_reporte_seguro
  set estado_reporte = 'O'
where ano = @ano
  and periodo = @periodo

if @@error <> 0 
begin
   raiserror ('Reporte de Seguro no pudo ser abierto - stp_UDnoCierreSegSocial ', 16,1,5000)
   rollback work
   return
end
go

