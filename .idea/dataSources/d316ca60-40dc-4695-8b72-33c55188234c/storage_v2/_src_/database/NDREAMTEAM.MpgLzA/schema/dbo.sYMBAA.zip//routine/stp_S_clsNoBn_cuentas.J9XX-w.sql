-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsNoBn_cuentas]
  (  @oldCodigo_banco smallint ,
  @oldCodigo_cuenta varchar (30)  )
As SELECT a.codigo_banco,a.codigo_cuenta,a.codigo_moneda,a.nombre_cuenta,a.tipo_cuenta,a.numero_cheque,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.formato,a.cuenta_contable,a.codigo_centro,a.numero_cta_banco,a.formato_lote FROM [dbo].[bn_cuentas] a
WHERE (a.codigo_banco =  @oldCodigo_banco AND 
a.codigo_cuenta =  @oldCodigo_cuenta)
go

