-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_prov_enc]
  As SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.usuario_ingreso,a.fecha_ingreso,a.estado,a.usuario_cierre,a.fecha_cierre,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_provisiones_enc] a
go

