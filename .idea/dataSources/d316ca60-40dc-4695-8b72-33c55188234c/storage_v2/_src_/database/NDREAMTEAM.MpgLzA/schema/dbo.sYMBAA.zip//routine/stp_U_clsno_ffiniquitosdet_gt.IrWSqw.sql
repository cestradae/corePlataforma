
-- Procedure definition
CREATE PROCEDURE stp_U_clsno_ffiniquitosdet_gt(  @oldcodigo_formato smallint ,
  @oldcorrelativo smallint ,
  @codigo_formato smallint ,
  @correlativo smallint ,
  @nombre_procedimiento varchar (50) ,
  @tipo_resultado char (1) ,
  @prefijo varchar (20) ,
  @no_meses smallint ,
  @codigo_valor varchar (50) ,
  @condensa char (1)  )
As 
UPDATE [dbo].[no_formatos_finiquitos_det] Set 
    codigo_formato = @codigo_formato,
    correlativo = @correlativo,
    nombre_procedimiento = @nombre_procedimiento,
    tipo_resultado = @tipo_resultado,
    prefijo = @prefijo,
    no_meses = @no_meses,
    codigo_valor = @codigo_valor,
    condensa = @condensa 
WHERE 	( codigo_formato =  @oldcodigo_formato AND 
correlativo =  @oldcorrelativo )
go

