CREATE FUNCTION [dbo].[func_MontoAplicado] (@codigo_cartera char(3),
  @tipo_movimiento char(2), @serie_movimiento char(2), @numero_movimiento int )  
RETURNS money AS  
BEGIN 
---
-- Creado por lsao
-- fecha 19-07-2007
-- monto aplicado del abono
declare @resultado money

select @resultado = sum(monto_abono)
from cc_abonos_det 
where codigo_cartera = @codigo_cartera
  and tipo_movimiento = @tipo_movimiento
  and numero_movimiento = @numero_movimiento
  and serie_movimiento = @serie_movimiento 

if @resultado is null select @resultado = 0

return @resultado

END
go

