-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoCuentasCont]
As
  SELECT cuenta_contable, dbo.func_cnmascara(cuenta_contable) + replicate(' ',30 - len(cuenta_contable)) + nombre_cuenta Descripcion
FROM cn_catalogo_cuentas
WHERE acepta_partidas = 'S'
order by cuenta_contable
go

