-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_cingresos]
  As SELECT a.codigo_ingreso,a.descripcion,a.linea1_reporte,a.linea2_reporte,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.cuenta_contable,a.nombre_corto FROM [dbo].[no_catalogo_ingresos] a
go

