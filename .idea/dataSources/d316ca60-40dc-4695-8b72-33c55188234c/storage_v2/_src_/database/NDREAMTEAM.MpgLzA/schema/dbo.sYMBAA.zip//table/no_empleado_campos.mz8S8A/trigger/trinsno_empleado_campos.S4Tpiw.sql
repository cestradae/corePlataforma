
CREATE TRIGGER trinsno_empleado_campos
   ON  no_empleado_campos
for INSERT,UPDATE
AS 

------------------------
-- Cambiado por Daniel Ortiz
-- Fecha 06/01/2011
-- Asunto si el campo de usuario es numerico no se debe de dejar ingresar null o vacio
-------------------------
BEGIN
	SET NOCOUNT ON;
DECLARE @nombre_campo VARCHAR(10), @valor VARCHAR(50)

	SELECT @nombre_campo=nombre_campo ,
		@valor=valor
	FROM INSERTED
	
	IF (@valor IS NULL OR @valor='') AND EXISTS(SELECT 1 FROM dbo.no_campos_usuario 
					WHERE nombre_campo=@nombre_campo AND es_numerico='S' )
    Begin
       Raiserror ('No se puede insertar un valor Null o vacio si el campo de usuario es numerico - trinsno_empleado_campos' ,16,1,5000)
       Rollback work
       Return
    End

END


go

