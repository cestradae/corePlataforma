
CREATE TRIGGER [dbo].[trinsno_periodos_pago] ON [dbo].[no_periodos_pago] 
FOR INSERT, UPDATE
AS

-- Cambio por Estuardo Arévalo
-- Fecha de Cambio 16.08.2009
-- Condición para que no se pueda tener mas de 1 período abierdo por tipo de nómina

BEGIN TRAN

declare @codigo_tipo char(2),
             @ano smallint,
             @periodo smallint,
             @numero_pago smallint

select  @codigo_tipo = codigo_tipo,
           @ano = ano,
           @periodo = periodo,
           @numero_pago = numero_pago
from inserted





update no_periodos_pago
   set periodo_id = codigo_tipo + convert(char(8), @ano * 10000 + @periodo * 100 + @numero_pago )
where codigo_tipo =@codigo_tipo
    and ano = @ano
    and periodo= @periodo
    and numero_pago = @numero_pago

if @@error <> 0
begin
   raiserror (' No se puede actualizar el periodo de pago - trinsno_periodos_pago ' ,16,1,5000 )
   rollback work
   return
END


IF  ( SELECT COUNT(*) FROM dbo.no_periodos_pago WHERE estado_periodo = 'A' AND codigo_tipo = @codigo_tipo ) > 1
BEGIN
	RAISERROR ('Solamente puede existir un periodo abierto, verifique y vuelva a intentarlo',16,1)
	ROLLBACK WORK
	return
END


COMMIT TRAN



go

