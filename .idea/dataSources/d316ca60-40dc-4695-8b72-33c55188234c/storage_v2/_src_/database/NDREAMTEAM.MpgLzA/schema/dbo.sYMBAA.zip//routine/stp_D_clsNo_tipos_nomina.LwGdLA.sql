-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_tipos_nomina]
  (  @oldCodigo_tipo char (2)  )
As DELETE [dbo].[no_tipos_nomina] 
WHERE (codigo_tipo =  @oldCodigo_tipo)
go

