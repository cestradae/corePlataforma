-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_cdeducciones_depto]
  As SELECT a.codigo_deduccion,a.codigo_departamento,a.cuenta_contable,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_catalogo_deducciones_depto] a
go

