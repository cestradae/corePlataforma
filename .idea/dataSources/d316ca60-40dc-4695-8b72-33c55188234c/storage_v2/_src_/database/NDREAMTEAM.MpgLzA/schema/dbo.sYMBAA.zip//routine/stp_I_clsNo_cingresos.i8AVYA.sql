-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_cingresos](@AUTO_EditStamp varchar(30) OUT,
  @Codigo_ingreso char (3) ,
  @Descripcion varchar (50) ,
  @Linea1_reporte varchar (15) ,
  @Linea2_reporte varchar (15) ,
  @cuenta_contable varchar (30) ,
  @nombre_corto varchar (30)  )
As 
	INSERT INTO [dbo].[no_catalogo_ingresos]
(  codigo_ingreso ,
  descripcion ,
  linea1_reporte ,
  linea2_reporte ,
  cuenta_contable ,
  nombre_corto  )
VALUES (  @Codigo_ingreso ,
  @Descripcion ,
  @Linea1_reporte ,
  @Linea2_reporte ,
  @cuenta_contable ,
  @nombre_corto  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_catalogo_ingresos]
  WHERE ( codigo_ingreso =  @Codigo_ingreso )
go

