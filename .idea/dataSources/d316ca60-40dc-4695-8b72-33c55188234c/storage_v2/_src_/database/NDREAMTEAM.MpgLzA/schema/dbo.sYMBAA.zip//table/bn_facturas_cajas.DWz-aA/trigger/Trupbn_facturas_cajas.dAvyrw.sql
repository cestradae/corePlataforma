CREATE TRIGGER [dbo].[Trupbn_facturas_cajas] ON [dbo].[bn_facturas_cajas] 
FOR  UPDATE
AS
-- Se declaran las variables del INSERTED
declare	@codigo_caja smallint,
	@codigo_proveedor varchar (20) ,
	@no_cedula_nit varchar (20) ,
	@nombre_proveedor varchar (100),
	@numero_documento varchar (20),
	@fecha_documento datetime,
	@referencia char (50),
	@tipo_producto char (1) ,
	@monto money,
	@codigo_gasto varchar (10),
	@codigo_centro varchar (20) ,
	@impuesto_ventas char (2) ,
	@impuesto_retencion char (2),
	@otro_impuesto char (2) ,
	@afecto_ventas money, 
	@afecto_retencion money,
	@afecto_otros  money,
	@monto_iventas money,
	@monto_iretencion money,
	@monto_iotros money,
	@retenido_ventas char (1) ,
	@retenido_retencion char (1),
	@retenido_otros char (1),
	@fecha_ingreso  datetime,
	@usuario_ingreso int,
	@estado_documento char(1),
-- Variables para la nota
	@serie_nota char(1),
	@numero_nota int,
	@total_ventas money,
	@tipo_documento smallint,
	@es_devolucion char(1),
	@autorizado char(1)

Select 	@codigo_caja = codigo_caja,
	@codigo_proveedor = codigo_proveedor,
	@no_cedula_nit = no_cedula_nit,
	@nombre_proveedor = nombre_proveedor,
	@numero_documento = numero_documento,
	@fecha_documento = fecha_documento,
	@referencia = referencia,
	@tipo_producto = tipo_producto,
	@monto = monto,
	@codigo_gasto = codigo_gasto,
	@codigo_centro  = codigo_centro,
	@impuesto_ventas = impuesto_ventas,
	@impuesto_retencion = impuesto_retencion,
	@otro_impuesto = otro_impuesto,
	@afecto_ventas = afecto_ventas,
	@afecto_retencion = afecto_retencion,
	@afecto_otros = afecto_otros,
	@monto_iventas = monto_iventas,
	@monto_iretencion = monto_iretencion,
	@monto_iotros = monto_iotros,
	@retenido_ventas = retenido_ventas,
	@retenido_retencion = retenido_retencion,
	@retenido_otros = retenido_otros,
	@fecha_ingreso = fecha_ingreso,	
	@usuario_ingreso = usuario_ingreso,
	@serie_nota = serie_nota,
	@numero_nota = numero_nota,
	@tipo_documento = tipo_documento
from inserted


-- Se verifica el estado de la cuenta
declare @no_liquidacion int

-- Si se modifica solo el no_liquidacion se manda un return
   if update(no_liquidacion) or update(estado_documento)
          return


Select @autorizado = autorizado 
from deleted

if @autorizado = '1'
Begin
  raiserror('El documento ya fue autorizado, no se puede modificar - Trupbn_facturas_cajas ',16,1,5000)
  rollback work
  return
end

-- Si se ingreso un tipo de documento se verifica si el tipo que se ingreso es_devolucion
if not @tipo_documento = 0 
Begin
  Select  @es_devolucion = es_devolucion 
  from bn_tipo_documentos 
  where tipo_documento = @tipo_documento
  -- Si es devolucion se verifica que se halla ingresado una nota de credito 
  if @es_devolucion = 'S' 
  Begin
    -- Se trae el monto de la nota
    Select @total_ventas = total_ventas
    from pv_ncredito_enc
    where serie = @serie_nota and numero = @numero_nota

    -- Si el monto ingresado es mayor que el monto de la venta se retorna un error al usuario y se deshace la operacion
    if @monto > @total_ventas
    Begin
	raiserror('No se puede ingresar un monto mayor al monto de la Nota de Credito - Trupbn_facturas_cajas ',16,1,5000)
	return
	rollback work
    end
  end
end

select @no_liquidacion = no_liquidacion,
	@estado_documento = estado_documento
from bn_facturas_cajas
where codigo_caja = @codigo_caja and 	no_cedula_nit = @no_cedula_nit and numero_documento = @numero_documento

if (@no_liquidacion > 0 and not @estado_documento is null)
Begin
  raiserror('La caja ya fue liquidada, no se puede modificar ',16,1,5000)
  rollback work
  return
end

else
begin tran
Begin
   declare @monto_d money
   Select    @monto_d = monto from deleted
   if (@monto <> @monto_d)
   Begin
      -- se elimina el detalle
      delete bn_facturas_ctas
      where generado = '1' and codigo_caja = @codigo_caja and no_cedula_nit = @no_cedula_nit and numero_documento = @numero_documento
      if @@error <> 0
      begin
        raiserror('No se pudo eliminar el detalle en bn_facturas_ctas -  Trupbn_facturas_cajas',16,1,5000)
        rollback work
        return
      end	

      -- Se actualiza el saldo de la caja
      update bn_cajas set saldo = saldo - @monto_d where codigo_caja = @codigo_caja
      if @@error <> 0
      begin
         raiserror('No se pudo actualizar el saldo de bn_cajas -  Trupbn_facturas_cajas',16,1,5000)
         rollback work
         return
      end	

      -- Se calcula el monto de la caja
      declare @monto_caja money
      set @monto_caja = @monto
      if (@retenido_ventas = 'S' )    set @monto_caja = @monto_caja - @monto_iventas
      if (@retenido_retencion = 'S') set @monto_caja = @monto_caja - @monto_iretencion
      if (@retenido_otros = 'S')        set @monto_caja = @monto_caja - @monto_iotros
    
      -- Se calcula el correlativo
      declare @correlativo smallint
      select @correlativo = (isnull(max(correlativo),0)+1) from bn_facturas_ctas 
      where 	codigo_caja = @codigo_caja
		and no_cedula_nit = @no_cedula_nit
		and numero_documento = @numero_documento

      -- Se actualiza el saldo de la caja
      update bn_cajas set saldo = (saldo + @monto) where codigo_caja = @codigo_caja
      if @@error <> 0
      begin
        raiserror('No se pudo actualizar el saldo de la caja -  Trupbn_facturas_cajas',16,1,5000)
        rollback work
        return
      end		

      -- Se ingresa en bn_facturas_ctas la cuenta del encabezado
      declare 	@cuenta_contable varchar(30),
	             @codigo_centro_caja varchar(20),
     		@codigo_centro2 varchar(20)

      select 	@cuenta_contable = cuenta_contable, @codigo_centro_caja = codigo_centro
      from bn_cajas where codigo_caja = @codigo_caja
	
       insert bn_facturas_ctas
       (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado)
       values
       (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro_caja, 0.00, @monto_caja, '1')
       if @@error <> 0
       begin
         raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trupbn_facturas_cajas',16,1,5000)
         rollback work
         return
       end	
       -- Se ingresa en bn_facturas_ctas la cuenta del impuesto de ventas, se hace si el monto_iventas <> 0
       if (@monto_iventas <> 0.00)
       Begin
          Select @correlativo = (isnull(max(correlativo),0)+1) from bn_facturas_ctas 
          where codigo_caja = @codigo_caja
		and no_cedula_nit = @no_cedula_nit
		and numero_documento = @numero_documento

          select @cuenta_contable = cuenta_contable,@codigo_centro2 = codigo_centro
          from gn_impuestos where codigo_impuesto = @impuesto_ventas

          if isnull(@codigo_centro2,0) = 0 
            Begin
   	      insert bn_facturas_ctas
	      (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, abono, generado)
	      values
	      (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @monto_iventas, 0.00, '1')
	      if @@error <> 0
	      begin
	        raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trupbn_facturas_cajas',16,1,5000)
	        rollback work
	        return
	      end	
            end
          else
            Begin
   	      insert bn_facturas_ctas
	      (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado)
	      values
	      (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro2, @monto_iventas, 0.00, '1')
	      if @@error <> 0
	      begin
	        raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trupbn_facturas_cajas',16,1,5000)
	        rollback work
	    return

	      end	
            end
       end

       -- Se ingresa en bn_facturas_ctas la cuenta del impuesto de retencion, se hace si el monto_iretencion <> 0
       if (@monto_iretencion <> 0.00)
         Begin

           Select @correlativo = (isnull(max(correlativo),0)+1) from bn_facturas_ctas 
           where 	codigo_caja = @codigo_caja
	   and no_cedula_nit = @no_cedula_nit
	   and numero_documento = @numero_documento

	   select 	@cuenta_contable = cuenta_contable, @codigo_centro2 = codigo_centro
	   from gn_impuestos where codigo_impuesto = @impuesto_retencion

	   if isnull(@codigo_centro2,0) = 0 
  	    Begin
 	      insert bn_facturas_ctas
	      (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, abono, generado)
              values
	      (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, 0.00, @monto_iretencion, '1')
  	      if @@error <> 0
		begin
		  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
		  rollback work
		  return
		end	
	    end
	   else
	    Begin
	      insert bn_facturas_ctas
              (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado)
       	      values
	      (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro2, 0.00, @monto_iretencion, '1')
	      if @@error <> 0
	      begin
	        raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
	        rollback work
	        return
	      end	
            end
         end

	-- Se ingresa en bn_facturas_ctas la cuenta del impuesto_otros, se hace si el monto_iotros <> 0
	if (@monto_iotros <> 0.00)
	  Begin
		Select @correlativo = (isnull(max(correlativo),0)+1) from bn_facturas_ctas 
		where 	codigo_caja = @codigo_caja
			and no_cedula_nit = @no_cedula_nit
			and numero_documento = @numero_documento

		select 	@cuenta_contable = cuenta_contable,
			@codigo_centro2 = codigo_centro
		from gn_impuestos where codigo_impuesto = @otro_impuesto

		if (@retenido_otros = 'N')
		Begin
		  if isnull(@codigo_centro2,0) = 0 
	  	    Begin
	 		insert bn_facturas_ctas
			(codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, abono, generado)
			values
			(@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @monto_iotros, 0.00, '1')
			if @@error <> 0
			begin
			  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
			  rollback work
			  return
			end	
	  	    end
           	  else
	  	    Begin
	 	       insert bn_facturas_ctas
		       (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado)
		       values
		       (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro2, @monto_iotros, 0.00, '1')
		       if @@error <> 0
		       begin
		         raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
		         rollback work
		         return
		       end	
		    end
	         end
		else
    	  	  Begin
            	    if isnull(@codigo_centro2,0) = 0
	      	     Begin
		       insert bn_facturas_ctas
		       (codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, abono, generado)
		       values
		       (@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, 0.00, @monto_iotros, '1')
		       if @@error <> 0
		       begin
		  	 raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
		  	 rollback work
		   	 return
		       end	
	      	     end
	    	   else
	      	     Begin
			insert bn_facturas_ctas
			(codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, abono, generado)
			values
			(@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro2, 0.00, @monto_iotros, '1')
			if @@error <> 0
			begin
			  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
			  rollback work
			  return
			end	
	      	     end
	          end	
	  end

	  if (@codigo_gasto <> ' ')
	  Begin
  
	  	Select @correlativo = (isnull(max(correlativo),0)+1) from bn_facturas_ctas 
	  	where 	codigo_caja = @codigo_caja
			and no_cedula_nit = @no_cedula_nit
			and numero_documento = @numero_documento

--	  	Select @cuenta_contable = cuenta_contable from gn_impuestos where codigo_impuesto = @impuesto_retencion
		Select @cuenta_contable = cuenta_contable 
		from bn_concepto_gasto 
		where codigo_gasto = @codigo_gasto

		if (@codigo_centro is null)
		Begin
	  		insert bn_facturas_ctas
	  		(codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, Abono, generado)
	  		values
		  	(@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @monto - @monto_iventas, 0.00, '1')
		  	if @@error <> 0
	  		begin
		    	  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
		    	  rollback work
	    		  return
		  	end	
		end
		else
		Begin
			if ((Select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_contable) = 'S') and (not @codigo_centro is null)
			Begin
	  			insert bn_facturas_ctas
			  	(codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, codigo_centro, cargo, Abono, generado)
			  	values
			  	(@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @codigo_centro, @monto - @monto_iventas, 0.00, '1')
			  	if @@error <> 0
			  	begin
			    	  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
			    	  rollback work
			    	  return
			  	end	
			end
			else
			Begin
		  		insert bn_facturas_ctas
		  		(codigo_caja, no_cedula_nit, numero_documento, correlativo, cuenta_contable, cargo, Abono, generado)
		  		values
			  	(@codigo_caja, @no_cedula_nit, @numero_documento, @correlativo, @cuenta_contable, @monto - @monto_iventas, 0.00, '1')
			  	if @@error <> 0
		  		begin
			    	  raiserror('No se pudo insertar el detalle en bn_facturas_ctas -  Trinsbn_facturas_cajas',16,1,5000)
			    	  rollback work
		    		  return
			  	end							
			end
		end

	   end

   end
 

end
commit tran


go

