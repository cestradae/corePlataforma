CREATE PROCEDURE [dbo].[stp_sy_no_cargadeduccionessecciones]
		@codigo_tipo CHAR(2),
		@codigo_deduccion CHAR(3),
		@codigo_seccion CHAR(10),
		@cuenta_sap VARCHAR(50)
AS
----------------------------------------------------
--Hecho por Mario Juarros
--Fecha:13/08/2010
--Asunto:Carga de deducciones por seccion
----------------------------------------------------
SET NOCOUNT ON

DECLARE @status int
            DECLARE @mensaje varchar(100)
            set @mensaje=''
            set @status=0
declare @cuenta varchar(50)            

             IF  @codigo_tipo is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_tipo esta en blanco, es llave primaria'
             END
             
             IF  @codigo_deduccion is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_deduccion esta en blanco, es llave primaria'
             END
             
             IF  @codigo_seccion is null and @status<1
             begin
                         set @status=2
                         set @mensaje='codigo_seccion esta en blanco, es llave primaria'
             END
             
             IF  @cuenta_sap is null and @status<1
             begin
                         set @status=2
                         set @mensaje='cuenta_sap esta en blanco, es llave primaria'
             END



delete from sap_Tr_cuentas where len(acctname) =0

select  @cuenta = acctcode 
from sap_tr_cuentas 
where substring(acctname,1,charindex('-',acctname)-1) = @cuenta_sap
and charindex('-', acctname ) > =0


INSERT INTO dbo.sap_deducciones_secciones (
	codigo_tipo,
	codigo_deduccion,
	codigo_seccion,
	cuenta_sap
) VALUES
(	@codigo_tipo,
	@codigo_deduccion,
	@codigo_seccion,
	@cuenta
)

SELECT @status AS status, @mensaje AS mensaje
go

