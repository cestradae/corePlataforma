create   procedure [dbo].[stp_UDNo_pro_empleado] 
@CampoBusqueda Varchar(100) = null,
@Textobusqueda Varchar(100) = null
as

Declare @StrSqla varchar(400),
              @StrSql varchar(400)          

set nocount on

Set @StrSqla = 'Select codigo_empleado Codigo, nombre_usual Descripcion from no_empleados A'


If @textobusqueda is null or len(rtrim(ltrim(@textobusqueda))) = 0
   Set @STrSql = @StrSqla
Else
  Begin
   if UPPER(@campobusqueda) = 'CODIGO'  
        Set @STrSql = @STrSqla + ' where A.codigo_empleado like ' + char(39)+@TextoBusqueda+'%'+char(39)
  If Upper(@campobusqueda) = 'DESCRIPCION'
       Set @STrSql = @STrSqla + ' where A.nombre_usual like ' + char(39) + upper(@TextoBusqueda) + '%' + char(39) 
  End

Exec (@StrSql)
go

