CREATE Procedure [dbo].[stp_UDnoObtieneAgrupacionesReporte]
As
------------------------------
-- Creado por Estuardo Arévalo
-- fecha 16.julio.2009
-- Asunto Devuelve las posibles agrupación en las que puede estar un reporte
------------------------------
Set Nocount On

	create table #agrupaciones ( codigo char(2) , descripcion varchar(100) )
	
	insert into #agrupaciones select '01', 'Departamento'	
	insert into #agrupaciones select '02', 'Centro de Costo'	
	insert into #agrupaciones select '03', 'Seccion'	
	insert into #agrupaciones select '04', 'Puesto'	
	insert into #agrupaciones select '05', 'Tipo Pago'	
    Insert into #agrupaciones SELECT '06','Codigo Tipo'
	
	select * from #agrupaciones
go

