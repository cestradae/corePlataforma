/*
alter table sap_empleados
add codigo_renglon int
go
*/

create TRIGGER trinsSap_Empleados
   ON sap_empleados
   AFTER INSERT,UPDATE
AS 
BEGIN	

-- =============================================
-- Author:		Estuardo Arévalo
-- Create date: 07.ago.2009
-- Description:	Busca el Renglon al que pertenece la cuenta y coloca el valor en sap_empleados.codigo_renglon
-- =============================================


	SET NOCOUNT ON;
	
	declare @cuenta_sap  varchar(30)
	declare @codigo_renglon int
	declare @codigo_empleado char(10)
	declare @codigo_tipo char(2)
	declare @Segment_0 nchar(40)
	

	
	select @cuenta_sap = cuenta_sap ,
				@codigo_tipo = codigo_tipo,
				@codigo_empleado = codigo_empleado
	from inserted
	
	
	select @Segment_0 = Segment_0 from sap_tr_cuentas
		where AcctCode = @cuenta_sap
		
		

	select @codigo_renglon = codigo_renglon  
	from sap_renglones a
			inner join sap_tr_cuentas b
					on  a.renglon = b.AcctCode
	where Segment_0 = @Segment_0
	
	
	update  sap_empleados
			set codigo_renglon = @codigo_renglon
	where codigo_tipo = @codigo_tipo
	and codigo_empleado = @codigo_empleado

END


go

