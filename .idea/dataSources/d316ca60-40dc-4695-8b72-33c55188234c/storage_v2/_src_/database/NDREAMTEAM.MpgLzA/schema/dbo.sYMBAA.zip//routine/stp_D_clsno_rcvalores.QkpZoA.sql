-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_rcvalores]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldno_reporte smallint  )
As DELETE [dbo].[no_reporte_valores] 
WHERE (codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
no_reporte =  @oldno_reporte)
go

