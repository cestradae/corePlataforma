create procedure [dbo].[stp_UDnoInsertaEmpleados] 
   @codigo_empleado char(10),
   @usuarioid int
as

SET NOCOUNT ON

Begin Tran
Insert into no_reportes_empleados ( usuarioid, codigo_empleado )
   values  ( @usuarioid , @codigo_empleado)

if @@error <> 0
Begin
  Raiserror ('Empleado no pudo ser insertado - stp_UDnoInsertaEmpleados  ' ,16,1,5000)
  Rollback work
  Return
END

SELECT 1
Commit Tran
go

