-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clssap_ingresos_proy]
  As SELECT a.codigo_tipo,a.codigo_ingreso,a.codigo_clase,a.codigo_centro,a.cuenta_sap FROM [dbo].[sap_ingresos_proyectos] a
go

