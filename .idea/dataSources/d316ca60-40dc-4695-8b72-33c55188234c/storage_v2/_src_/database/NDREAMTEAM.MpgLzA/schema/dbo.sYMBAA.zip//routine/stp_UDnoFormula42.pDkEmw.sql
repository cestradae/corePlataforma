create procedure [dbo].[stp_UDnoFormula42]
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(18,4) out ) AS

  declare @tmp1 decimal(18,4)

begin
  exec stp_UDnoDevUMesesIngresos 'Ant_B14_Ing',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  12 , @tmp1 out

  set @result=@tmp1
end
go

