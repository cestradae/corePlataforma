
-- Procedure definition
CREATE PROCEDURE stp_U_clsnohn_crr_emptasas(  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10) ,
  @oldcorrelativo smallint ,
  @codigo_impuesto char (3) ,
  @ano smallint ,
  @mes smallint ,
  @codigo_empleado char (10) ,
  @correlativo smallint ,
  @hasta money ,
  @porcentaje decimal (18,4) ,
  @monto_impuesto money ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_reporte_rentahn_emptasas] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_reporte_rentahn_emptasas] Set 
    codigo_impuesto = @codigo_impuesto,
    ano = @ano,
    mes = @mes,
    codigo_empleado = @codigo_empleado,
    correlativo = @correlativo,
    hasta = @hasta,
    porcentaje = @porcentaje,
    monto_impuesto = @monto_impuesto 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado AND 
correlativo =  @oldcorrelativo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_reporte_rentahn_emptasas]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
ano =  @ano AND 
mes =  @mes AND 
codigo_empleado =  @codigo_empleado AND 
correlativo =  @correlativo )
go

