-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_clooknohnusuarios]
As
  SELECT userid, username
FROM _users
go

