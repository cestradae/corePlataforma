CREATE  procedure [dbo].[stp_udnoObtieneCuentasPorBanco]
	@codigo_banco int
as
BEGIN
	
	select id_cuenta, isnull(codigo_cuenta,'') + ' - ' + isnull(nombre_cuenta,'') as nombre_cuenta from bn_cuentas 
                            where codigo_banco = @codigo_banco
                            
                
END
go

