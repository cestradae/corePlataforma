Create procedure [dbo].[stp_UDnoEliminaEmpleados]
   @usuarioid int
as

SET NOCOUNT ON

delete from no_reportes_empleados
  where usuarioid = @usuarioid

SELECT 1
go

