-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_ndet](  @oldCodigo_tipo char (2) ,
  @oldPeriodo_id char (10) ,
  @oldCodigo_empleado char (10) ,
  @oldCorrelativo smallint ,
  @oldGrupo_id char (5) ,
  @oldNo_calculo smallint ,
  @Periodo_id char (10) ,
  @Codigo_tipo char (2) ,
  @Grupo_id char (5) ,
  @No_calculo smallint ,
  @Codigo_empleado char (10) ,
  @Codigo_ingreso char (3) ,
  @Monto_ingreso money ,
  @Codigo_deduccion char (3) ,
  @Monto_deduccion money ,
  @EditStamp varchar(30) OUT ,
  @Monto_base money ,
  @codigo_departamento smallint ,
  @codigo_centro varchar (20)  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_nomina_det] 
WHERE codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
codigo_empleado =  @oldCodigo_empleado AND 
correlativo =  @oldCorrelativo AND 
grupo_id =  @oldGrupo_id AND 
no_calculo =  @oldNo_calculo 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_nomina_det] Set 
    periodo_id = @Periodo_id,
    codigo_tipo = @Codigo_tipo,
    grupo_id = @Grupo_id,
    no_calculo = @No_calculo,
    codigo_empleado = @Codigo_empleado,
    codigo_ingreso = @Codigo_ingreso,
    monto_ingreso = @Monto_ingreso,
    codigo_deduccion = @Codigo_deduccion,
    monto_deduccion = @Monto_deduccion,
    monto_base = @Monto_base,
    codigo_departamento = @codigo_departamento,
    codigo_centro = @codigo_centro 
WHERE 	( codigo_tipo =  @oldCodigo_tipo AND 
periodo_id =  @oldPeriodo_id AND 
codigo_empleado =  @oldCodigo_empleado AND 
correlativo =  @oldCorrelativo AND 
grupo_id =  @oldGrupo_id AND 
no_calculo =  @oldNo_calculo )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_nomina_det]
  WHERE ( codigo_tipo =  @Codigo_tipo AND 
periodo_id =  @Periodo_id AND 
codigo_empleado =  @Codigo_empleado AND 
correlativo =  @oldCorrelativo AND 
grupo_id =  @Grupo_id AND 
no_calculo =  @No_calculo )
go

