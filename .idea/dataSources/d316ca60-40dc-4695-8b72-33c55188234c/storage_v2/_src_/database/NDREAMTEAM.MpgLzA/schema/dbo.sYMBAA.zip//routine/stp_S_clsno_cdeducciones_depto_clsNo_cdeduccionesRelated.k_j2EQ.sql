-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_cdeducciones_depto_clsNo_cdeduccionesRelated]
(  @oldcodigo_deduccion char (3)  )
  As 
SELECT a.codigo_deduccion,a.codigo_departamento,a.cuenta_contable,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_catalogo_deducciones_depto] a
WHERE 
a.codigo_deduccion =  @oldcodigo_deduccion
go

