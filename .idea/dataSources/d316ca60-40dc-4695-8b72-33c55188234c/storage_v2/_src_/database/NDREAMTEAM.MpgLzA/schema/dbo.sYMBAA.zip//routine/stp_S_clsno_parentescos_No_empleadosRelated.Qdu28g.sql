-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_parentescos_No_empleadosRelated]
(  @oldcodigo_empleado char (10)  )
  As 
SELECT a.codigo_empleado,a.correlativo,a.nombre_pariente,a.fecha_nacimiento,a.codigo_parentesco,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.edad FROM [dbo].[no_parentescos] a
WHERE 
a.codigo_empleado =  @oldcodigo_empleado
go

