
-- Procedure definition
CREATE PROCEDURE stp_S_clsnohn_crr_emping
  (  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10) ,
  @oldcodigo_ingreso char (3)  )
As SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.codigo_ingreso,a.monto_devengado,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_rentahn_emping] a
WHERE (a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.ano =  @oldano AND 
a.mes =  @oldmes AND 
a.codigo_empleado =  @oldcodigo_empleado AND 
a.codigo_ingreso =  @oldcodigo_ingreso)
go

