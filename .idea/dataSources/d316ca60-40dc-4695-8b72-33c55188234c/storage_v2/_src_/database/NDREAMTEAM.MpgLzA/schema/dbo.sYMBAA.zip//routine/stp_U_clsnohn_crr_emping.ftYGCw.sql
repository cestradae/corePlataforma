
-- Procedure definition
CREATE PROCEDURE stp_U_clsnohn_crr_emping(  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint ,
  @oldcodigo_empleado char (10) ,
  @oldcodigo_ingreso char (3) ,
  @codigo_impuesto char (3) ,
  @ano smallint ,
  @mes smallint ,
  @codigo_empleado char (10) ,
  @codigo_ingreso char (3) ,
  @monto_devengado money ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_reporte_rentahn_emping] 
WHERE codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado AND 
codigo_ingreso =  @oldcodigo_ingreso 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_reporte_rentahn_emping] Set 
    codigo_impuesto = @codigo_impuesto,
    ano = @ano,
    mes = @mes,
    codigo_empleado = @codigo_empleado,
    codigo_ingreso = @codigo_ingreso,
    monto_devengado = @monto_devengado 
WHERE 	( codigo_impuesto =  @oldcodigo_impuesto AND 
ano =  @oldano AND 
mes =  @oldmes AND 
codigo_empleado =  @oldcodigo_empleado AND 
codigo_ingreso =  @oldcodigo_ingreso )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_reporte_rentahn_emping]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
ano =  @ano AND 
mes =  @mes AND 
codigo_empleado =  @codigo_empleado AND 
codigo_ingreso =  @codigo_ingreso )
go

