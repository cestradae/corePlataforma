CREATE PROCEDURE [dbo].[stp_udnoCambiasueldominimo]
			@codigo_tipo AS CHAR(2),
			@codigo_tipo_fin CHAR(2),
			@codigo_departamento SMALLINT,
			@codigo_departamento_fin SMALLINT,
			@codigo_ingreso CHAR(3),
			@sueldo_nuevo MONEY,
			@fecha_salario DATETIME,
			@actualiza CHAR(1)
AS

set nocount on

DECLARE @codigo_empleado VARCHAR(10),@fecha_inicio_rel_lab DATETIME, @fecha DATETIME

-- muestra los empleados que les cambiara el sueldo
SELECT b.codigo_empleado,b.nombre_usual,
		a.codigo_tipo+ ' - '+c.descripcion tipo_nomina,
		CONVERT(VARCHAR(10),b.codigo_departamento)+' - '+ d.descripcion departamento,
		LTRIM(RTRIM(e.codigo_puesto))+' - '+e.nombre_puesto puesto,
		a.monto Sueldo_anterior,
		@sueldo_nuevo sueldo_nuevo
into #cambiosueldominimo
FROM no_empleado_ingresos a
INNER JOIN no_empleados b
	ON a.codigo_empleado=b.codigo_empleado
INNER JOIN no_tipos_nomina c
	ON a.codigo_tipo=c.codigo_tipo
	AND a.codigo_tipo=c.codigo_tipo
left JOIN gn_departamentos d
	ON b.codigo_departamento=d.codigo_departamento
LEFT JOIN no_puestos e 
	ON b.codigo_puesto=e.codigo_puesto
WHERE a.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND b.codigo_departamento BETWEEN @codigo_departamento AND @codigo_departamento_fin
AND a.codigo_ingreso=@codigo_ingreso
AND a.monto<@sueldo_nuevo
AND a.monto<>0.00
AND b.estado_empleado in ('A','S')

-- si Actualiza entra al cursor
IF @actualiza='S'
BEGIN 
	declare empleados_salario cursor for
	SELECT a.codigo_empleado , b.fecha_inicio_rel_lab
	FROM no_empleado_ingresos a, no_empleados b
	WHERE a.codigo_empleado=b.codigo_empleado
	AND a.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
	AND b.codigo_departamento BETWEEN @codigo_departamento AND @codigo_departamento_fin
	AND a.codigo_ingreso=@codigo_ingreso
	AND a.monto<@sueldo_nuevo
	AND a.monto<>0.00
	AND b.estado_empleado in ('A','S')

	open empleados_salario

	fetch next from empleados_salario into @codigo_empleado, @fecha_inicio_rel_lab
	while @@fetch_status = 0
	BEGIN
	    
	    IF @fecha_inicio_rel_lab>@fecha_salario
			SELECT  @fecha=@fecha_inicio_rel_lab
		ELSE
			SELECT @fecha=@fecha_salario
	    	    
	   UPDATE no_empleado_ingresos 
		SET monto=@sueldo_nuevo,
			fecha_asignacion=GETDATE(),
			fecha_inicio=@fecha
		WHERE codigo_empleado=@codigo_empleado
		AND codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
		AND codigo_ingreso=@codigo_ingreso
		AND monto<@sueldo_nuevo
		 
		   if @@error <> 0
		   Begin
			  Raiserror ('No se pudo cambiar el sueldo del empleado %s - stp_udnoCambiasueldominimo', 16,1,@codigo_empleado)
			  close empleados_salario
			  deallocate empleados_salario
			  Rollback work
			  Return 9
			  
		   End

	fetch next from empleados_salario into @codigo_empleado, @fecha_inicio_rel_lab
	-- cerramos el cursor
	END 
	close empleados_salario
	deallocate empleados_salario
END

select * from #cambiosueldominimo

go

