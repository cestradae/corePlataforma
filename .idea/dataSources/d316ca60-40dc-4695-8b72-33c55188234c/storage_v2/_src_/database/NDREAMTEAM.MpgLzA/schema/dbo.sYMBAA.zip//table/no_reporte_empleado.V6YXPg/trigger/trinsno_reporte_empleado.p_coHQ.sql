CREATE TRIGGER [trinsno_reporte_empleado] ON [dbo].[no_reporte_empleado] 
FOR INSERT
AS
-------------------------------------
-- HECHO POR ldr
-- asunto 10/10/2010
-- para que no generara automaticamente los valores reportados
-----------------------------------
--- Procedemos a insertar Valores Reportados

 
insert into no_reporte_detalle (
   codigo_tipo,
   periodo_id,
   no_reporte,
   codigo_empleado,
   codigo_valor,
   valor,
   estado )
select a.codigo_tipo,
          a.periodo_id,
          a.no_reporte,
          a.codigo_empleado,
          d.codigo_valor,
          d.valor_omision,
          'O' -- Operado
from inserted a, no_reporte_valores b, no_grupos_valores c, no_grupos_detalle d 
where a.codigo_tipo  = b.codigo_tipo
    and a.periodo_id    = b.periodo_id
    and a.no_reporte   = b.no_reporte
    and b.codigo_tipo = c.codigo_tipo
    and b.grupo_id = c.grupo_id
    and c.codigo_tipo = d.codigo_tipo
    and c.codigo_grupo = d.codigo_grupo
    and substring(d.codigo_valor,1,1 ) = '1'
    and b.genera_aut = 'S'

--- Procedemos a insertar Ingresos Reportados 
 
insert into no_reporte_detalle (
   codigo_tipo,
   periodo_id,
   no_reporte,
   codigo_empleado,
   codigo_valor,
   valor,
   estado )

select a.codigo_tipo,
          a.periodo_id,
          a.no_reporte,
          a.codigo_empleado,
          d.codigo_valor,
          d.valor_omision,
          'O' -- Operado
from inserted a, no_reporte_valores b, no_grupos_valores c, no_grupos_detalle d , no_nomina_ingresos e
where a.codigo_tipo  = b.codigo_tipo
    and a.periodo_id    = b.periodo_id
    and a.no_reporte   = b.no_reporte
    and b.codigo_tipo = c.codigo_tipo
    and b.grupo_id = c.grupo_id
    and c.codigo_tipo = d.codigo_tipo
    and c.codigo_grupo = d.codigo_grupo
    and substring(d.codigo_valor,1,1 ) = '2'
    and d.codigo_tipo = e.codigo_tipo
    and substring(d.codigo_valor,2,3 ) = e.codigo_ingreso
    and e.tipo_ingreso = 'R'
    and b.genera_aut = 'S'

--- Procedemos a insertar Deducciones Reportadas
 
insert into no_reporte_detalle (
   codigo_tipo,
   periodo_id,
   no_reporte,
   codigo_empleado,
   codigo_valor,
   valor,
   estado )

select a.codigo_tipo,
          a.periodo_id,
          a.no_reporte,
          a.codigo_empleado,
          d.codigo_valor,
          d.valor_omision,
          'O' -- Operado
from inserted a, no_reporte_valores b, no_grupos_valores c, no_grupos_detalle d , no_nomina_deducciones e
where a.codigo_tipo  = b.codigo_tipo
    and a.periodo_id    = b.periodo_id
    and a.no_reporte   = b.no_reporte
    and b.codigo_tipo = c.codigo_tipo
    and b.grupo_id = c.grupo_id
    and c.codigo_tipo = d.codigo_tipo
    and c.codigo_grupo = d.codigo_grupo
    and substring(d.codigo_valor,1,1 ) = '3'
    and d.codigo_tipo = e.codigo_tipo
    and substring(d.codigo_valor,2,3 ) = e.codigo_deduccion
    and e.tipo_deduccion = 'R'
    and b.genera_aut = 'S'

--- Procedemos a insertar Anticipos  Reportados cuyo tipo sea pago
 
insert into no_reporte_detalle (
   codigo_tipo,
   periodo_id,
   no_reporte,
   codigo_empleado,
   codigo_valor,
   valor,
   estado )

select a.codigo_tipo,
          a.periodo_id,
          a.no_reporte,
          a.codigo_empleado,
          d.codigo_valor,
          d.valor_omision,
          'O' -- Operado
from inserted a, no_reporte_valores b, no_grupos_valores c, no_grupos_detalle d , no_nomina_anticipos e
where a.codigo_tipo  = b.codigo_tipo
    and a.periodo_id    = b.periodo_id
    and a.no_reporte   = b.no_reporte
    and b.codigo_tipo = c.codigo_tipo
    and b.grupo_id = c.grupo_id
    and c.codigo_tipo = d.codigo_tipo
    and c.codigo_grupo = d.codigo_grupo
    and substring(d.codigo_valor,1,1 ) = '4'
    and d.tipo_anticipo = 'P'   -- Para el tipo que se paga
    and d.codigo_tipo = e.codigo_tipo
    and substring(d.codigo_valor,2,3 ) = e.codigo_anticipo
    and e.tipo_anticipo = 'R'
    and b.genera_aut = 'S'



go

