-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clssap_parametros]
  (  @oldcodigo_tipo char (2)  )
As DELETE [dbo].[sap_parametros] 
WHERE (codigo_tipo =  @oldcodigo_tipo)
go

