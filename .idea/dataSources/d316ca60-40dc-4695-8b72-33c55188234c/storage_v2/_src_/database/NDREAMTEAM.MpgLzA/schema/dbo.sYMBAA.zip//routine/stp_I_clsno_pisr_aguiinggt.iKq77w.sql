
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_pisr_aguiinggt(  @codigo_ingreso char (3) ,
  @tipo_monto smallint ,
  @no_meses smallint ,
  @tipo_ingreso smallint ,
  @codigo_impuesto char (3)  )
As 
	INSERT INTO [dbo].[no_parametros_isr_aguiinggt]
(  codigo_ingreso ,
  tipo_monto ,
  no_meses ,
  tipo_ingreso ,
  codigo_impuesto  )
VALUES (  @codigo_ingreso ,
  @tipo_monto ,
  @no_meses ,
  @tipo_ingreso ,
  @codigo_impuesto  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

