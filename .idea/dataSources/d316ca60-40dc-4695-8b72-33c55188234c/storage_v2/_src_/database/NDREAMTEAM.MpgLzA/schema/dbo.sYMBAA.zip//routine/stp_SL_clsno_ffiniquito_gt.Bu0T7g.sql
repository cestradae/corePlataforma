
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_ffiniquito_gt
  As SELECT a.codigo_formato,a.descripcion_formato,a.nombre_formato FROM [dbo].[no_formatos_finiquitos] a
go

