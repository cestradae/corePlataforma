
-- Procedure definition
CREATE PROCEDURE stp_SL_clsno_phn_municipios
  As SELECT a.codigo_patrono,a.id_municipio,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_patronos_hn_municipios] a
go

