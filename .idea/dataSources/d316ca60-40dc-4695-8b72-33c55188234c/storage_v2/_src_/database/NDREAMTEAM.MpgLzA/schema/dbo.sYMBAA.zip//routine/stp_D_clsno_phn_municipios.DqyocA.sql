
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_phn_municipios
  (  @oldcodigo_patrono smallint ,
  @oldid_municipio smallint  )
As DELETE [dbo].[no_patronos_hn_municipios] 
WHERE (codigo_patrono =  @oldcodigo_patrono AND 
id_municipio =  @oldid_municipio)
go

