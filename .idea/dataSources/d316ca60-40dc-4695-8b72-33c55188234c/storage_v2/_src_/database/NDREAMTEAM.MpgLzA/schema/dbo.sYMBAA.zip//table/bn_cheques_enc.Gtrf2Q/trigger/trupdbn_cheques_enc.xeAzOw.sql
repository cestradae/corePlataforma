CREATE TRIGGER [dbo].[trupdbn_cheques_enc] ON dbo.bn_cheques_enc 
FOR  UPDATE
AS
-------------------------------------------------------------------------------------
-- Modificado por lsao
-- Fecha 21-06-2007
-- Se modifico para que no se pueda modificar si el cheque está conciliado, tambien se modifica para que si hay una actualización del dato lo elimine
-- de la conciliacion activa en que se encuentre
-------------------------------------------------------------------------------------


declare @id_cuenta varchar(32),
             @codigo_tipo smallint,
             @numero_cheque int,
             @id_cuenta_ant varchar(32),
             @codigo_tipo_ant varchar(32),
              @numero_cheque_ant int,
              @codigo_moneda smallint,
              @codigo_moneda_ant smallint,
              @monto_cheque money,
              @monto_cheque_ant money,
              @fecha_cheque datetime,
              @fecha_cheque_ant datetime,
              @tasa_cambio decimal(8,6),
              @tasa_cambio_ant decimal(8,6),
              @tasa_c decimal(8,6),
              @usuario_ingreso varchar(35),
              @fecha_ingreso datetime,
               @es_local char(1),
               @es_dolar char(1),
               @contabiliza char(1),
               @tipo_conta char(1),
               @ano smallint,
               @periodo smallint,
               @ano_ant smallint,
               @periodo_ant smallint,
               @estado char(1),
               @estado_ant char(1),
               @codigo_banco smallint,
                @codigo_banco_ant smallint,
               @monto_O money,
               @saldo_inicial money,
               @saldo_inicial_O money,
               @codigo_cuenta varchar(30),
               @cuenta_contable varchar(30),
               @codigo_centro varchar(20),
               @tasa_c_ant decimal(8,4),
               @estado_actual char(1),
               @beneficiario varchar(100),
               @beneficiario_ant varchar(100),
               @observaciones varchar(100),
               @observaciones_ant varchar(100),
               @contabilizado char(1),
               @tipo_partida char(2),
               @numero_partida int,
               @correlativo smallint,
               @cargo money,
               @abono money,
               @conciliado char(1),
   	  @estado_cheque char(1),
               @corr_concilia char(1),
               @corr_cta smallint,
               @corr_tra  smallint,
               @id_cuenta_traslado varchar(32),
               @id_cuenta_traslado_ant varchar(32),
               @cuenta_traslado varchar(30),
               @centro_traslado varchar(20)
       
select @contabiliza = contabiliza,
          @tipo_conta  = tipo_conta
from bn_generales


select @id_cuenta_ant = id_cuenta,
          @codigo_tipo_ant = codigo_tipo,
          @numero_cheque_ant = numero_cheque,
          @monto_cheque_ant = monto_cheque,
          @fecha_cheque_ant = fecha_cheque,
          @tasa_cambio_ant = tasa_cambio,
          @codigo_moneda_ant = codigo_moneda,
          @codigo_banco_ant = codigo_banco, 
          @tasa_c_ant = tasa_c,
           @ano_ant = ano,
           @periodo_ant = periodo,
           @beneficiario_ant = beneficiario,
           @observaciones_ant = concepto,
          @conciliado = conciliado,
           @id_cuenta_traslado_ant = id_cuenta_traslado
from deleted

select @id_cuenta = id_cuenta,
          @codigo_tipo = codigo_tipo,
          @numero_cheque = numero_cheque,
          @monto_cheque = monto_cheque,
          @fecha_cheque  = fecha_cheque,
          @tasa_cambio = tasa_cambio,
          @codigo_moneda = codigo_moneda,
          @codigo_banco = codigo_banco,
          @estado_actual = estado,
          @beneficiario = beneficiario,
          @observaciones= concepto,
          @contabilizado = contabilizado,
          @ano = ano,
          @periodo = periodo,
          @estado_cheque = estado,
          @corr_cta =  cta,
          @corr_tra = tra,
          @id_cuenta_traslado = id_cuenta_traslado
from inserted

-- Si cambio el estado a Anulado no hacemos nada
if update(estado)
   return

if @conciliado = 'S'
Begin
    Raiserror (' Cheque ya fue conciliado no se puede modificar - trupdbn_cheques_enc ' ,16,1,5000)
    Rollback work
    Return
End


set @fecha_cheque = isnull(@fecha_cheque,getdate())


if @contabiliza = 'S'
begin
    select @ano = a.ano,
               @periodo = a.periodo,
               @estado = a.abierto_cerrado
    from bn_periodos a, gn_periodos b
    where a.ano = b.ano
        and a.periodo  = b.periodo
        and @fecha_cheque between b.fecha_inicial and b.fecha_final 

    if @estado is  null 
    begin
         raiserror ( 'No hay definido un periodo para la fecha solicitada - trinsbn_cheques_enc ' ,16,1,5000)
         rollback work
         return
    end

   if @estado = 'C'
   begin
        raiserror ( 'Periodo esta cerrado para la fecha solicitada - trinsbn_cheques_enc ',16,1,5000 )
        rollback work
         return
   end

end
else
begin

    select  @ano         = datepart(yy, @fecha_cheque), 
               @periodo   = datepart(mm,@fecha_cheque)

end

-- Procedemos a validar que no se pueda cambiar la fecha si se genero partida

if ( @contabilizado = 'S' ) and ( @ano <> @ano_ant or @periodo <> @periodo_ant )
begin
    raiserror ( 'Periodo no puede cambiar porque la partida ya fue generada - trupdbn_cheques_enc' ,16,1,5000 )
    rollback work
    return 
end

if @contabilizado = 'S' and @numero_cheque <> @numero_cheque_ant 
begin
   raiserror ('No de cheque no se pude cambiar ya se genero la partida con este numero - trupdbn_cheques_enc ', 16,1,5000 ) 
   rollback work
   return
end

-- Procedemos actualizar los saldo de las cuentas si el codigo de cuenta y los montos y las tasas fueron cambiados 

if  @codigo_moneda <> @codigo_moneda_ant  or
    @tasa_cambio <> @tasa_cambio_ant or
    @id_cuenta <> @id_cuenta_ant or
    @monto_cheque_ant <> @monto_cheque or
    @ano <> @ano_ant or
    @periodo <> @periodo_ant 
begin

    -- Procedemos a eliminar los datos anteriores 
if @estado_cheque <> 'A'
Begin
    select @monto_O = round(  @tasa_c_ant * @monto_cheque_ant, 2 )

    update bn_cuentas
          set saldo_cuenta = saldo_cuenta + @monto_cheque_ant ,
                saldo_cuenta_O = saldo_cuenta_O + @monto_O
    where id_cuenta = @id_cuenta

    if @@error <> 0
    begin
         raiserror ( ' Saldo de Cuenta bancaria no pudo actualizar - trupdbn_cheques_enc ', 16,1,5000 ) 
         rollback work
         return
    end

    -- Procedemos a actualizar el saldo del periodo


    select @codigo_cuenta =codigo_cuenta
    from bn_cuentas
    where id_cuenta = @id_cuenta_ant

    update bn_cuentas_saldos
           set abonos = abonos - @monto_cheque,
                 abonos_O = abonos_O - @monto_O
     where codigo_banco = @codigo_banco_ant
         and codigo_cuenta = @codigo_cuenta
         and ano = @ano_ant
         and periodo = @periodo_ant

    if @@error <> 0
    begin
         raiserror ( ' No se pudo actualizar saldos mensuales de la cuenta - trupdbn_cheques_enc ' ,16,1,5000 )
         rollback work
         return
    end 
 
     -- Procedemos a actualizar el movimiento de periodos posteriores

     update bn_cuentas_saldos
          set saldo_inicial = saldo_inicial + @monto_cheque,
                saldo_inicial_O = saldo_inicial_O + @monto_O
      where codigo_banco = @codigo_banco_ant
          and codigo_cuenta = @codigo_cuenta
          and anoperiodo > @ano_ant * 100 + @periodo_ant

    if @@error <> 0
    begin
         raiserror ( ' No se pudo actualizar saldos mensuales de la cuenta - trupdbn_cheques_enc' ,16,1,5000 )
         rollback work
         return
    end 

   -- Procedemos  a actualizar los nuevos datos

   select @codigo_cuenta =codigo_cuenta,
	@cuenta_contable = cuenta_contable,
	@codigo_centro = codigo_centro
    from bn_cuentas
    where id_cuenta = @id_cuenta


   --- Calculamos la tasa de cambio local

   select @es_local = es_local,
             @es_dolar = es_dolar
   from gn_monedas
   where codigo_moneda =@codigo_moneda

   if @es_local = 'S'  select @tasa_c = 1
   else 
   if @es_dolar = 'S' select @tasa_c = @tasa_cambio


-- Calculamos el ano y periodo para la fecha del cheque que se esta trabajando



-- Procedemos a actualizar el cheque 

   update bn_cheques_enc
        set tasa_c               = @tasa_c,
              ano                   = @ano,
              periodo             = @periodo          
   where codigo_banco     = @codigo_banco
       and id_cuenta            = @id_cuenta
       and codigo_tipo         = @codigo_tipo
       and numero_cheque  = @numero_cheque

   if @@error <> 0
   Begin
        Raiserror ('No se puede actualizar los datos del encabezado del cheque - trupdbn_cheques_enc ' ,16,1,5000)
        Rollback work
        Return
   End


if @contabiliza = 'S' 
Begin
-- Procedemos a actualizar el cheque

     if @monto_cheque <> @monto_cheque_ant or @id_cuenta <>@id_cuenta_ant
    Begin
     update bn_cheques_det
        set cuenta_contable = @cuenta_contable,
    	 codigo_centro = @codigo_centro,
	 abono = @monto_cheque
      where codigo_banco     = @codigo_banco
          and id_cuenta            = @id_cuenta
          and codigo_tipo         = @codigo_tipo
          and numero_cheque  = @numero_cheque
          and correlativo = @corr_cta

        if @@error <> 0
       Begin
             Raiserror ( 'No se pudo actualizar el monto de la cuenta - trupdbn_cheques_enc ' ,16,1,5000)
             rollback work
             return
       End
     End

     if @id_cuenta_traslado <> @id_cuenta_traslado_ant 
     Begin
           select @centro_traslado = codigo_centro,
                      @cuenta_traslado = cuenta_contable
           from bn_cuentas
           where id_cuenta = @id_cuenta_traslado

           if isnull( ( select acepta_centros from cn_catalogo_cuentas where cuenta_contable = @cuenta_traslado ),'N') = 'N'
          Begin
             select @centro_traslado = null
          End
          Else
          Begin
               if not exists ( select codigo_centro  from cn_catalogo_centros where codigo_centro = @centro_traslado ) 
               Begin
                     Raiserror ('No existe el codigo de centro para el traslado favor verificar - trupdbn_cheques_enc ' ,16,1,5000)
                     Rollback work
                     Return
               End 
           End 
           update bn_cheques_det 
                   set codigo_centro = @centro_traslado,
                        cuenta_contable = @cuenta_traslado,
                        cargo = @monto_cheque
           where codigo_banco = @codigo_banco
               and id_cuenta = @id_cuenta
               and codigo_tipo = @codigo_tipo
               and numero_cheque = @numero_cheque
               and correlativo = @corr_tra

           if @@error <> 0
           Begin
                 Raiserror ('No se pudo actualizar la cuenta de traslado - trupdbn_cheques_enc' ,16,1,5000)
                 Rollback work
                 Return
           End
       
     End

End

-- Procedemos a actualizar los saldos 

   select @monto_O = round(@monto_cheque * @tasa_c,2)

-- Actualizamos el saldo global de la cuenta 

   update bn_cuentas
         set saldo_cuenta = saldo_cuenta - @monto_cheque,
               saldo_cuenta_O = saldo_cuenta_O - @monto_O
   where id_cuenta = @id_cuenta

   if @@error <> 0
   Begin
        Raiserror ( 'No se pudieron actualizar los saldos a las cuentas - trupdbn_cheques_enc ' ,16,1,5000)
        Rollback work
        Return
   End

   -- Actualizamos el saldo por mes de la cuenta

   if exists ( select 1 from bn_cuentas_saldos where codigo_banco = @codigo_banco and codigo_cuenta = @codigo_cuenta and ano = @ano and periodo = @periodo )
   begin

      update bn_cuentas_saldos
           set abonos = abonos + @monto_cheque,
                abonos_O = abonos_O + @monto_O
      where codigo_banco = @codigo_banco
          and codigo_cuenta = @codigo_cuenta
          and ano = @ano 
          and periodo = @periodo
       if @@error <> 0
      Begin
           Raiserror ('No se pudieron actualizar los saldos a las cuentas de los saldos - trupdbn_cheques_enc ' ,16,1,5000)
           Rollback work
           Return
      End


   end
   else
   begin

      set rowcount 1

      select @saldo_inicial = saldo_final,
                 @saldo_inicial_O = saldo_final_O
      from bn_cuentas_saldos 
      where codigo_banco = @codigo_banco
          and codigo_cuenta = @codigo_cuenta
           and anoperiodo < @ano * 100 + @periodo
      order by anoperiodo desc

      set rowcount 0

      if @saldo_inicial = 0 select @saldo_inicial = 0
      if @saldo_inicial_O = 0 select @saldo_inicial_O = 0

     insert into bn_cuentas_saldos (
     codigo_banco,
     codigo_cuenta,
     ano,
     periodo,
     saldo_inicial,
     cargos,
     abonos,
     saldo_inicial_O,
      cargos_O,
      abonos_O)
     values (
      @codigo_banco,
      @codigo_cuenta,
      @ano,
      @periodo,
      @saldo_inicial,
      0,
      @monto_cheque,
      @saldo_inicial_O,
      0,
      @monto_O)

      if @@error <> 0
      Begin
           Raiserror ( 'No se pueden insertar un nuevo saldo - trupdbn_cheques_enc ' , 16,1,5000)
           Rollback work
           Return
      End
   
   end

   -- Procedemos a actualizar los saldos en meses posteriores si los hubiera

   update  bn_cuentas_saldos
          set saldo_inicial  = saldo_inicial - @monto_cheque,
                saldo_inicial_O = saldo_inicial_O - @monto_O
   where codigo_banco = @codigo_banco
       and codigo_cuenta = @codigo_cuenta
       and anoperiodo > @ano * 100 + @periodo    


   if @@error <> 0
  Begin
       Raiserror ( 'No se pudo actualizar los saldo de la cuenta - trupdbn_cheques_enc ' ,16,1,5000)
       Rollback
       Return
  End
end


if @contabiliza = 'S' and @tipo_conta = 'E' 
begin

    if @id_cuenta <> @id_cuenta_ant or
       @codigo_tipo <> @codigo_tipo_ant 
   begin

       update bn_partidas_generadas 
           set id_cuenta= @id_cuenta,
                codigo_tipo = @codigo_tipo
       where id_cuenta= @id_cuenta_ant
           and codigo_tipo = @codigo_tipo_ant
           and numero_documento =@numero_cheque
           and tipo_transaccion = 'I' 
    
        if @@error <> 0 
        begin
              raiserror ( ' Bitacora de partidas no pudo ser actualizada - trupdbn_cheques_enc ' ,16,1,5000 )
              rollback work
              return
        end
   end 
      
    if @tasa_cambio <> @tasa_cambio_ant or
       @beneficiario <> @beneficiario_ant or
       @observaciones <> @observaciones_ant or
       @fecha_cheque <> @fecha_cheque_ant or
       @tasa_c_ant <> @tasa_c 
    begin

          select @tipo_partida = tipo_partida,
                     @numero_partida = numero_partida
          from bn_partidas_generadas
          where id_cuenta= @id_cuenta
              and codigo_tipo = @codigo_tipo
              and numero_documento = @numero_cheque
              and tipo_transaccion = 'I' 
       
          update cn_partidas_enc 
                   set  fecha_partida = @fecha_cheque,
                         concepto = @beneficiario + '  '+@observaciones,
                         tasa_cambio = @tasa_cambio
          where ano = @ano
               and periodo  = @periodo
               and codigo_tipo = @tipo_partida
               and numero_partida = @numero_partida

           if @@error <> 0 
           begin
                raiserror ( ' Partida contable no pudo ser modificada - trupdbn_cheques_enc ' , 16,1,5000 )
                rollback work
                return
           end

           if @tasa_c_ant <> @tasa_c
           begin
                declare cur_detalle_par cursor for
                       select correlativo,
                                 cargo,
                                 abono
                        from bn_cheques_det
                       where codigo_banco = @codigo_banco 
                           and id_cuenta  = @id_cuenta
                           and codigo_tipo = @codigo_tipo
                           and numero_cheque = @numero_cheque

                   open cur_detalle_par
                   fetch cur_detalle_par into @correlativo , @cargo, @abono

                   while @@fetch_status = 0
                   begin
                         update cn_partidas_det
                                  set cargo = round(@cargo * @tasa_c ,2),
                                        abono = round(@abono * @tasa_c, 2)
                         where ano = @ano
                             and periodo = @periodo
                             and codigo_tipo = @tipo_partida
                             and numero_partida = @numero_partida
                             and correlativo = @correlativo

                          if @@error <> 0
                         Begin
                              Raiserror ( 'No se puede actualizar la partida contable - trupdbn_cheques_enc ' ,16,1,5000)
                              Rollback work
                              deallocate cur_detalle_par 
                              Return
                         End

                         fetch cur_detalle_par into @correlativo , @cargo, @abono

                   end
                   close cur_detalle_par
                   deallocate cur_detalle_par
           end
    end 
end


End -- de si estado_cheque <> 'A'


-- Procedemos a verificar si esta en alguna conciliacion y borrarlo si tuvo modificación 

select @corr_concilia = null

select @corr_concilia = a.correlativo
from bn_conciliacion_det a, bn_conciliacion_enc b
where a.id_cuenta = @id_cuenta 
    and codigo_tipo = @codigo_tipo
    and numero_documento = @numero_cheque
    and a.id_cuenta = b.id_cuenta
    and a.correlativo = b.correlativo 
    and b.estado = '1'


if @corr_concilia is not null  -- procedemos a borrar el movimiento
Begin
   delete from bn_conciliacion_det
      where id_cuenta = @id_cuenta
          and codigo_tipo = @codigo_tipo 
          and numero_documento = @numero_cheque
          and correlativo = @corr_concilia

    if @@error <> 0
   Begin
        Raiserror ('No se pudo borrar de la conciliacion -  trupdbn_cheques_enc ' ,16,1,5000)
        Rollback work
        Return
   End

   update bn_conciliacion_enc
        set modificado = '1'
   where id_cuenta = @id_cuenta
       and correlativo = @corr_concilia

    if @@error <> 0
   Begin
        Raiserror ('No se pudo actualizar la conciliacion -  trupdbn_cheques_enc ' ,16,1,5000)
        Rollback work
        Return
   End

          
End


go

