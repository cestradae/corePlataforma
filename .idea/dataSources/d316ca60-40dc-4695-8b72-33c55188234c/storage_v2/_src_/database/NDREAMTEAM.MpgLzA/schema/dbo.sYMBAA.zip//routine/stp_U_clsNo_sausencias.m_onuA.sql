-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clsNo_sausencias](  @oldcodigo_empleado char (10) ,
  @oldcorr_solicitud smallint ,
  @codigo_empleado char (10) ,
  @corr_solicitud smallint OUT  ,
  @codigo_tipo char (2) ,
  @fecha_solicitud datetime ,
  @dias_solicitar decimal (8,2) ,
  @descuenta_sabados char (1) ,
  @fecha_inicio datetime ,
  @tipo_solicitud char (1) ,
  @motivo char (1) ,
  @observaciones varchar (100) ,
  @dia_descontado char (1) ,
  @estado_solicitud char (10) ,
  @EditStamp varchar(30) OUT  )
As 
Declare @NewStamp varchar(30)
Select @NewStamp=CONVERT(varchar(30), CONVERT(INT, EditStamp),
	13) from [dbo].[no_solicitud_ausencias] 
WHERE codigo_empleado =  @oldCodigo_empleado AND 
corr_solicitud =  @oldCorr_solicitud 
If RTrim(@NewStamp) != RTrim(@EditStamp)
  Begin
    RAISERROR(51000, 16, 1)
    ROLLBACK TRANSACTION
  End
Else
UPDATE [dbo].[no_solicitud_ausencias] Set 
    codigo_empleado = @Codigo_empleado,
    fecha_solicitud = @Fecha_solicitud,
    codigo_tipo = @codigo_tipo,
    dias_solicitar = @Dias_solicitar,
    descuenta_sabados = @Descuenta_sabados,
    fecha_inicio = @fecha_inicio,
    tipo_solicitud = @Tipo_solicitud,
    observaciones = @Observaciones,
    dia_descontado = @Dia_descontado,
    motivo = @motivo 
WHERE 	( codigo_empleado =  @oldCodigo_empleado AND 
corr_solicitud =  @oldCorr_solicitud )
  Select @EditStamp=CONVERT(varchar(30), CONVERT(INT, @@DBTS),
  	13)
  -- Return computed fields
  Select @Corr_solicitud = corr_solicitud, @Estado_solicitud = estado_solicitud, @EditStamp = convert(varchar(30),convert(INT,EditStamp )) From [dbo].[no_solicitud_ausencias]
  WHERE ( codigo_empleado =  @Codigo_empleado AND 
corr_solicitud =  @oldCorr_solicitud )
go

