-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_secciones]
  As SELECT a.codigo_seccion,a.nombre_seccion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_secciones] a
go

