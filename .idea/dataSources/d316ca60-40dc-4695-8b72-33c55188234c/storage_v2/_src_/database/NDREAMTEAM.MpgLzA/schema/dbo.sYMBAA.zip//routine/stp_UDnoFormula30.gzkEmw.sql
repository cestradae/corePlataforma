create procedure stp_UDnoFormula30   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @SSPorLiq decimal(18,4) 
declare @PROMLIQ decimal(22,6) 
declare @SSDiasAntiguedad decimal(18,4) 
declare @tmp1 decimal(18,4) 

begin
  select  @SSPorLiq = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSPorLiq' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '30        ' ) = '1'  begin Select @PROMLIQ= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '30        ' end else begin Select @PROMLIQ= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '30        ' end 
select @SSDiasAntiguedad = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSDiasAnt' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
if ((isnull(@SSPorLiq,0)<0.2)) select @tmp1=0 else select @tmp1=isnull(@PROMLIQ,0)/12*14/365*isnull(@SSDiasAntiguedad,0)*isnull(@SSPorLiq,0)

  set @result=@tmp1
end
go

