-- Procedure definition
CREATE PROCEDURE [dbo].[stp_S_clsno_prov_enc]
  (  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldno_calculo smallint  )
As SELECT a.codigo_tipo,a.periodo_id,a.grupo_id,a.no_calculo,a.usuario_ingreso,a.fecha_ingreso,a.estado,a.usuario_cierre,a.fecha_cierre,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_provisiones_enc] a
WHERE (a.codigo_tipo =  @oldcodigo_tipo AND 
a.periodo_id =  @oldperiodo_id AND 
a.grupo_id =  @oldgrupo_id AND 
a.no_calculo =  @oldno_calculo)
go

