/*
stp_UDnoPartidaPlanillatmpSV
    @codigo_tipo = '01',
    @periodo_id = '0120081101',
    @grupo_id = '011',
    @no_calculo = 0

*/


CREATE procedure [dbo].[stp_UDnoPartidaPlanillatmpSV]
    @codigo_tipo char(2),
    @periodo_id char(10),
    @grupo_id char(5),
    @no_calculo smallint
as 

----------------------------------------------------------------------------------------
--- Procedemos a hacer los respectivos Calculos de las planillas -----------------------
----------------------------------------------------------------------------------------
--------------------------
-- Hecho por lsao
-- Fecha 27/11/2008
-- Asunto : Creacion de partidas de Nomina, Esta partida no usa proyectos
---------------------------

set nocount on

Create table #Partida (
     codigo_ingreso char(2) COLLATE Modern_Spanish_CI_AS,
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,
     cargo money,
     abono money,
     asociado varchar(20) COLLATE Modern_Spanish_CI_AS,
     codigo_centro  varchar(20) COLLATE Modern_Spanish_CI_AS
)



Create table #Partida2 (
     cuenta_contable varchar(20) COLLATE Modern_Spanish_CI_AS ,
     cargo money,
     abono money,
     asociado varchar(20) COLLATE Modern_Spanish_CI_AS,
     codigo_centro  varchar(20) COLLATE Modern_Spanish_CI_AS
)


Create table #Temporal (
     codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
     total money,
     codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
     cuenta_sap varchar(15) COLLATE Modern_Spanish_CI_AS
 )

Create table #Bonificacion (
     codigo_valor varchar(10) COLLATE Modern_Spanish_CI_AS,
     codigo_centro varchar(20) COLLATE Modern_Spanish_CI_AS,
     Bonificacion money
     
 )


-------------------------------------------------------------
-- Procedemos on Ordinario, Asueto y Septimo 
-------------------------------------------------------------
Declare @Asueto      money
Declare @Total       money
Declare @septimos    money
Declare @BoniDecreto money
Declare @BoniLatex   money
Declare @sumTotal    money
Declare @sumAsueto   money
Declare @sumSeptimo  money
Declare @sumLatex    money
Declare @TotalLatex  money

insert into #temporal
select a.codigo_valor, 
       total ,
       case isnull(b.proyecto,'') when 'S' then a.codigo_centro else '' end,
       b.cuenta_sap
from no_reporte_valores_ingreso a, sap_valores_reportados_ing b 
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and tipo_valor = 1
and b.codigo_tipo = @codigo_tipo
and a.codigo_valor *= b.codigo_valor
and b.codigo_ingreso = '01'
and total > 0

select codigo_centro, cuenta_sap, sum(total) Total
into #Tareas
from #temporal
group by codigo_centro, cuenta_sap

select @Total = sum(total) 
from #Tareas


select @Asueto = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '04'

select @Septimos = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '05'

select @BoniDecreto = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '03'


INSERT INTO #Bonificacion
select a.codigo_valor, codigo_centro, round(( sum(total) * @BoniDecreto )/@Total,2) Bonificacion 
from #temporal a
group by a.codigo_valor, codigo_centro

select @sumTotal = sum(Bonificacion)
from #bonificacion

if @sumTotal <> @BoniDecreto 
Begin
set rowcount 1
update #Bonificacion 
   Set bonificacion = Bonificacion  + ( @BoniDecreto - @sumTotal )
set rowcount 0
End


insert into #Partida ( 
		   codigo_ingreso,
		   cuenta_contable,
		   cargo,
		   abono,
		   asociado,
		   codigo_centro )


select  '04',
	cuenta_sap, 
	round((@Asueto * Total) / @total,2),
	0,
	'',
	codigo_centro
from #Tareas



select @sumAsueto = sum(cargo)
from #Partida
where codigo_ingreso = '04'

if @sumAsueto <> @Asueto
Begin
   set rowcount 1
   Update #Partida
     set cargo = cargo + ( @Asueto - @sumAsueto)
   where codigo_ingreso = '04'
   set rowcount 0
End


insert into #Partida ( 
   codigo_ingreso,
   cuenta_contable,
   cargo,
   abono,
   asociado,
   codigo_centro )


select  '05',
		cuenta_sap, 
		round((@Septimos * Total) / @total,2),
		0,
		'',
		codigo_centro
from #Tareas


select @sumSeptimo = sum(cargo)
from #Partida
where codigo_ingreso = '05'

if @sumSeptimo <> @Septimos
Begin
   set rowcount 1
   Update #Partida
     set cargo = cargo + ( @septimos - @sumSeptimo)
   where codigo_ingreso = '05'
   set rowcount 0
End

insert into #Partida ( 
   codigo_ingreso,
   cuenta_contable,
   cargo,
   abono,
   asociado,
   codigo_centro )


select  '03',
	cuenta_sap,
    sum(Bonificacion),
    0,
    '',
    a.codigo_centro 
from #Bonificacion a, sap_valores_reportados_ing b 
where b.codigo_ingreso = '03'
and b.codigo_tipo = @codigo_tipo
and a.codigo_valor *= b.codigo_valor
group by cuenta_sap, a.codigo_centro


---- Procedemos a calcular el Ordinario --------------

INSERT INTO #Temporal
  select a.codigo_valor, Bonificacion * -1, a.codigo_centro, ''
  from #Bonificacion a



insert into #Partida ( 
   codigo_ingreso,
   cuenta_contable,
   cargo,
   abono,
   asociado,
   codigo_centro )


SELECT '01',  b.cuenta_sap,  sum(total), 0, '', a.codigo_centro
FROM #TEMPORAL A, sap_valores_reportados_ing b
WHERE a.codigo_valor *= b.codigo_valor
and  b.codigo_tipo = @codigo_tipo
and  b.codigo_ingreso = '01'
group by b.cuenta_sap, a.codigo_centro


select @BoniLatex  = sum(monto_ingreso)
from no_nomina_det
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_ingreso = '12'

select @TotalLatex = sum(valor)
from no_reporte_valores_ingreso
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and codigo_valor = 'A3333'
and tipo_valor = '1'

insert into #Partida ( 
   codigo_ingreso,
   cuenta_contable,
   cargo,
   abono,
   asociado,
   codigo_centro )

SELECT '12',  b.cuenta_sap,  round((sum(valor) * @BoniLatex)/ @TotalLatex,2) , 0, '', a.codigo_centro
FROM  no_reporte_valores_ingreso a, sap_ingresos b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and a.codigo_valor = 'A3333'
and b.codigo_tipo = @codigo_tipo
and b.codigo_ingreso = '12'
and tipo_valor = '1'
group by b.cuenta_sap, a.codigo_centro


SELECT @sumLatex = sum(cargo)
from #Partida
where codigo_ingreso = '12'


if @sumLatex <> @BoniLatex
Begin
   set rowcount 1
   Update #Partida
     set cargo = cargo + ( @BoniLatex - @sumLatex)
   where codigo_ingreso = '12'
   set rowcount 0
End

insert into #Partida ( 
   codigo_ingreso,
   cuenta_contable,
   cargo,
   abono,
   asociado,
   codigo_centro )

select a.codigo_ingreso,
       b.cuenta_sap,
       sum(monto_ingreso),
       0,
       '',
       codigo_centro
from no_nomina_det a, sap_ingresos b 
where a.codigo_tipo = @codigo_tipo
and a.periodo_id = @periodo_id
and a.grupo_id = @grupo_id
and a.no_calculo = @no_calculo
and a.codigo_tipo = b.codigo_tipo
and a.codigo_ingreso = b.codigo_ingreso
and a.codigo_ingreso not in ( '01','03','04','05','12')
group by a.codigo_ingreso, b.cuenta_sap, codigo_centro
--------------------------------------------------
--------------------------------------------------

insert into #Partida2
select cuenta_contable,
       sum(cargo),
       0,
       '',
       codigo_centro
from #Partida
group by cuenta_contable, codigo_centro


--- Sueldos por Liquidar
insert into #Partida2
select b.cuenta_salios_sap,
       0,
       sum(liquido),
       '',
       ''
from no_nomina_emplcalc a, sap_parametros b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
group by b.cuenta_salios_sap


--- Cuenta de descuentos que no sean prestamos

insert into #Partida2
select cuenta_sap,
       0,
       sum(monto_deduccion),
       '',
       ''
from no_nomina_det a, sap_egresos b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_deduccion <> '03'
group by cuenta_sap

insert into #Partida2
select cuenta_sap,
       0,
       sum(monto_deduccion),
       c.nombre_corto,
       ''
from no_nomina_det a, sap_egresos b, no_empleados c
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and grupo_id = @grupo_id
and no_calculo = @no_calculo
and b.codigo_tipo = @codigo_tipo
and b.codigo_deduccion = a.codigo_deduccion 
and a.codigo_deduccion = '03'
and a.codigo_empleado = c.codigo_empleado
group by cuenta_sap, c.nombre_corto

------------
-- Porcedemos a insertar las partidas de provisiones laborales
-- Primero el gasto
------------

delete from #Partida2

insert into #Partida2
select cuenta_sap,
       sum(monto_provision),
       0,
       '',
       codigo_centro
from no_provisiones_sap
where codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
group by cuenta_sap, codigo_centro

------------
-- Porcedemos a insertar las partidas de provisiones laborales
-- Segundo la cuenta de provision
------------
insert into #Partida2
select b.cuenta_sap,
       0,
       sum(monto_provision),
       '',
       ''
from no_provisiones_sap a, sap_provisiones b
where a.codigo_tipo = @codigo_tipo
and periodo_id = @periodo_id
and a.codigo_tipo = b.codigo_tipo
and a.codigo_provision = b.codigo_provision
group by b.cuenta_sap



select a.cuenta_contable, a.cargo,  a.abono,
     'asociado' = CASE 
					 WHEN rtrim(ltrim(a.asociado)) <>  '' THEN a.asociado
					 ELSE a.cuenta_contable
				  END,  d.codigo_sap proyecto
	 , DATEADD(DD,-3,GETDATE()) AS fecha_final, 'Reg Nomina No.'+b.no_nomina+ ' '+ c.descripcion as concepto
from #Partida2 a, no_periodos_pago b, no_grupos_valores c, sap_centros d
where b.periodo_id = @periodo_id
and c.grupo_id = @grupo_id
and a.codigo_centro *= d.codigo_centro
go

