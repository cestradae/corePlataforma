-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_nvarsistema](@AUTO_EditStamp varchar(30) OUT,
  @codigo_empleado char (10) ,
  @codigo_variable varchar (20) ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @no_calculo smallint ,
  @valor decimal (18,4)  )
As 
	INSERT INTO [dbo].[no_nomina_variables_sistema]
(  codigo_empleado ,
  codigo_variable ,
  codigo_tipo ,
  periodo_id ,
  grupo_id ,
  no_calculo ,
  valor  )
VALUES (  @codigo_empleado ,
  @codigo_variable ,
  @codigo_tipo ,
  @periodo_id ,
  @grupo_id ,
  @no_calculo ,
  @valor  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_nomina_variables_sistema]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
codigo_variable =  @codigo_variable AND 
codigo_tipo =  @codigo_tipo AND 
periodo_id =  @periodo_id AND 
grupo_id =  @grupo_id AND 
no_calculo =  @no_calculo )
go

