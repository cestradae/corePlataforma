
-- Procedure definition
CREATE PROCEDURE stp_SL_clsnohn_rrentahn_emp
  As SELECT a.codigo_impuesto,a.ano,a.mes,a.codigo_empleado,a.monto_devengado,a.monto_proyectado,a.gastos_medicos,a.aporte_seguro,a.monto_total,a.monto_imp_calculado,a.monto_retenido,a.monto_descontar,a.monto_mensual,a.monto_cuotas,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_rentahn_empleado] a
go

