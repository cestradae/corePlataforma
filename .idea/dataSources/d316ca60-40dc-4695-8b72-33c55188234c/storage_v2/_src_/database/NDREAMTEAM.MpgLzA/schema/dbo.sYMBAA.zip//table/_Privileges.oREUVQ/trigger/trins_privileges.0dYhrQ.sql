CREATE TRIGGER  [dbo].[trins_privileges] ON [dbo].[_Privileges] 
FOR INSERT, UPDATE
AS
------------
-- hecho por dortiz
-- Fecha 27-05-2011
-- Asignacion de campos por privilegio
------------

declare @UserGroupID int
declare @ObjectName nvarchar(50)

select 
	@UserGroupID=UserGroupID,
	@ObjectName=ObjectName
from inserted 

exec stp_udAsignaCampos @ObjectName,@UserGroupID


go

