-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_sminimos]
  As SELECT a.codigo_tipo,a.periodo_id,a.salario,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_salarios_minimos] a
go

