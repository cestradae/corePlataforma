
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_pisr_aguiinggt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_ingreso char (3)  )
As SELECT a.codigo_ingreso,a.tipo_monto,a.no_meses,a.tipo_ingreso,a.codigo_impuesto FROM [dbo].[no_parametros_isr_aguiinggt] a
WHERE (a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.codigo_ingreso =  @oldcodigo_ingreso)
go

