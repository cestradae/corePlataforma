CREATE procedure [dbo].[stp_UDnoCalcula_VariablesSistema]
    @codigo_tipo char(2),
    @periodo_id char(10),
    @grupo_id char(5),
    @no_calculo int
as
--------------------------------
-- Hecho por lsao
-- Fecha 23/09/2008
-- Se crean variables de sistema
---------------------------------

declare @codigo_empleado char(10)
declare @variable_sistema varchar(20)
declare @procedimiento varchar(50)
declare @error int
declare @valor money

declare cur_empleados cursor for
     select codigo_empleado
     from no_nomina_emplcalc
     where codigo_tipo = @codigo_tipo
       and periodo_id = @periodo_id
       and grupo_id = @grupo_id
       and no_calculo = @no_calculo
     order by codigo_empleado
Begin Tran

delete from no_nomina_variables_sistema
     where codigo_tipo = @codigo_tipo
       and periodo_id = @periodo_id
       and grupo_id = @grupo_id
       and no_calculo = @no_calculo
if @@error <> 0
Begin
   Raiserror ('No se pueden eliminar las variables - stp_UDnoCalcula_VariablesSistema ', 16,1,5000)
   Rollback work
   Return 9
End  

open cur_empleados 
fetch cur_empleados into @codigo_empleado
while @@fetch_status = 0
Begin
   Declare cur_varsistema cursor for
      select variable_sistema,
             procedimiento
      from no_variables_sistema
   
   open cur_varsistema
   fetch cur_varsistema into @variable_sistema, @procedimiento 

   
   while @@fetch_status = 0
   Begin
 
      exec @error = @procedimiento @codigo_empleado,  @codigo_tipo, @periodo_id, @grupo_id , @no_calculo, @valor out

      if @error <> 0
      Begin
         Raiserror ('No se puede crear el calcular la variable %s para el empleado %s - stp_UDnoCalcula_VariablesSistema ',16,1, @variable_sistema , @codigo_empleado )
         Rollback work
         Deallocate cur_varsistema
         Deallocate cur_empleados
         Return 9
      End

      insert into no_nomina_variables_sistema (
           codigo_empleado,
           codigo_variable,
           codigo_tipo,
           periodo_id,
           grupo_id,
           no_calculo,
           valor )
       values ( @codigo_empleado,
                @variable_sistema,
                @codigo_tipo,
                @periodo_id,
                @grupo_id,
                @no_calculo,
                @valor )

       if @@error <> 0
       Begin
          Raiserror ('No se pudo insertar el valor a la tabla de variables sistema - stp_UDnoCalcula_VariablesSistema' , 16,1,5000)
          Rollback work
          Deallocate cur_varsistema
          Deallocate cur_empleados
          Return 9
       End


      Fetch cur_varsistema into @variable_sistema, @procedimiento
   End
   close cur_varsistema
   deallocate cur_varsistema
   Fetch cur_empleados into @codigo_empleado
End
Close cur_empleados
Deallocate cur_empleados

Commit Tran
go

