-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clssap_empleados](  @codigo_tipo char (2) ,
  @codigo_empleado char (10) ,
  @cuenta_sap varchar (30)  )
As 
	INSERT INTO [dbo].[sap_empleados]
(  codigo_tipo ,
  codigo_empleado ,
  cuenta_sap  )
VALUES (  @codigo_tipo ,
  @codigo_empleado ,
  @cuenta_sap  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
go

