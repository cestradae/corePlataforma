-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_secciones](@AUTO_EditStamp varchar(30) OUT,
  @codigo_seccion varchar (5) ,
  @nombre_seccion varchar (60)  )
As 
	INSERT INTO [dbo].[no_secciones]
(  codigo_seccion ,
  nombre_seccion  )
VALUES (  @codigo_seccion ,
  @nombre_seccion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_secciones]
  WHERE ( codigo_seccion =  @codigo_seccion )
go

