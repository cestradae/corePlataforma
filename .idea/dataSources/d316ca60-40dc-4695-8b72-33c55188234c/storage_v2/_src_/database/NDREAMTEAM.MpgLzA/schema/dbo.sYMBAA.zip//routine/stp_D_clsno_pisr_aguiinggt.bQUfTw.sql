
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_pisr_aguiinggt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_ingreso char (3)  )
As DELETE [dbo].[no_parametros_isr_aguiinggt] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_ingreso =  @oldcodigo_ingreso)
go

