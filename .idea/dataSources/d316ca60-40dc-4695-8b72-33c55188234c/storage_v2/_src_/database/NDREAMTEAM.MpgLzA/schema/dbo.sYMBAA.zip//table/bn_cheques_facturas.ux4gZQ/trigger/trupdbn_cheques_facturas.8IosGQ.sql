CREATE TRIGGER [dbo].[trupdbn_cheques_facturas] ON dbo.bn_cheques_facturas 
FOR UPDATE
AS
----
-- Creado por lsao
-- Fecha 12-03-2007
-- Asunto modificacion no estaba implementado
-----------------
declare  @codigo_banco smallint,
             @id_cuenta varchar(32),
             @codigo_tipo smallint,
             @numero_cheque int,
             @numero_documento char(20),
             @gasto smallint,
             @imp1 smallint,
             @imp2 smallint,
             @imp3 smallint,
            @codigo_proveedor varchar(20),
             @impto_ventas char(2),
             @impto_retencion char(2),
             @otro_impto char(2),
             @monto money,
             @afecto_impto_venta money,
             @retenido_ventas char(1),
             @retenido_retencion char(1),
             @retenido_otros char(1),
             @impto_venta money,
             @impto_retenido money,
             @impto_otros money,
             @cuenta_impuesto  varchar(30),
             @centro_impuesto varchar(30),
             @cuenta_gasto varchar(30),
             @centro_gasto varchar(30),
             @correlativo smallint,
             @monto_gasto money,
             @contabiliza char(1)

-- Procedemos con la eliminacion

if update (gasto) or update(imp1) or update(imp2) or update(imp3)
   return

select    @codigo_banco =codigo_banco,
             @id_cuenta = id_cuenta,
             @codigo_tipo = codigo_tipo,
             @numero_cheque = numero_cheque,
             @numero_documento = numero_documento,
             @gasto = gasto,
             @imp1 = imp1,
             @imp2 = imp2,
             @imp3 = imp3
from deleted

--- Borramos el gasto

delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @gasto

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trdelbn_cheques_det ' ,16,1, @numero_documento )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @imp1

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trdelbn_cheques_det ' ,16,1, @numero_documento )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @imp2

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trdelbn_cheques_det ' ,16,1, @numero_documento )
   rollback work
   return
end


delete from bn_cheques_det 
where codigo_banco = @codigo_banco
    and id_cuenta = @id_cuenta
    and codigo_tipo = @codigo_tipo
    and numero_cheque = @numero_cheque
    and correlativo = @imp3

if @@error <> 0
begin
   raiserror ( 'No se puede eliminar la factura %s - trdelbn_cheques_det ' ,16,1, @numero_documento )
   rollback work
   return
end


---- Ahora procedemos con la insersion

select @codigo_proveedor = codigo_proveedor,
             @codigo_banco =codigo_banco,
             @id_cuenta = id_cuenta,
             @codigo_tipo = codigo_tipo,
             @numero_cheque = numero_cheque,
             @numero_documento = numero_documento,
             @impto_ventas = impto_ventas,
             @impto_retencion = impto_retencion,
             @otro_impto = otro_impto,
             @monto = monto,
             @afecto_impto_venta = isnull(afecto_impto_venta,0),
             @retenido_ventas =retenido_ventas,
             @retenido_retencion = retenido_retencion,
             @retenido_otros = retenido_otros,
             @impto_venta =isnull( impto_venta,0),
             @impto_retenido=isnull( impto_retenido,0),
             @impto_otros =isnull( impto_otros,0)
from inserted


select @contabiliza = contabiliza
from bn_generales

if @contabiliza = 'S'
Begin
	select @centro_gasto = codigo_centro
	from bn_cheques_enc
	where  codigo_banco = @codigo_banco
	   and  id_cuenta        = @id_cuenta
	   and  codigo_tipo     = @codigo_tipo
	   and numero_cheque = @numero_cheque 


	select @cuenta_gasto  = cuenta_contable
	from cp_proveedores 
	where codigo_proveedor = @codigo_proveedor

	   select @correlativo = max(correlativo) + 1
	   from bn_cheques_det 
	   where  codigo_banco = @codigo_banco
	      and  id_cuenta        = @id_cuenta
	      and  codigo_tipo     = @codigo_tipo
	      and numero_cheque = @numero_cheque 

	if @correlativo is null select @correlativo = 1
	
	if @cuenta_gasto is not null 
	Begin
	   if ( select acepta_centros  from cn_catalogo_cuentas where  cuenta_contable  = @cuenta_gasto ) = 'N'
	   Begin
	         select  @centro_gasto = null
	   End
	   Else
	   Begin
	         if @centro_gasto is null  or @centro_gasto = ''
	         Begin
	              Raiserror (' Debe ingresar centro de gastos - trinsbn_cheques_facturas ' ,16,1,5000)
	              rollback work
	              return
	         End
	   End
	
	
	   select @monto_gasto = @monto - @impto_venta
	
	   Insert into bn_cheques_det (  codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo , cuenta_contable, codigo_centro, cargo, abono , generado )
	       values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @correlativo, @cuenta_gasto, @centro_gasto,  @monto_gasto, 0, 'S' )
	
	   if @@error <> 0
	   begin
	       raiserror ( 'No se pudo actualizar la cuenta de gastos para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
	       rollback work
	       return
	   end
	end
	
	--- Actualizamos el correlativo correspondiente a la factura
	
	update bn_cheques_facturas
	        set gasto = @correlativo
	where  codigo_banco        = @codigo_banco
	   and  id_cuenta                = @id_cuenta
	   and  codigo_tipo             = @codigo_tipo
	   and numero_cheque       = @numero_cheque 
	   and numero_documento = @numero_documento 
	
	if @@error <> 0
	begin
	    raiserror ( 'No se pudo actualizar el correlativo de gastos para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
	    rollback work
	    return
	end
	
	--- Procedemos con el impuesto de ventas 
	
	if @impto_venta > 0
	Begin
	     select @correlativo  = @correlativo + 1
	
	      select @cuenta_impuesto = cuenta_contable,
	                @centro_impuesto = codigo_centro
	      from gn_impuestos
	      where codigo_impuesto = @impto_ventas 
	     
	      if @cuenta_impuesto is null or @cuenta_impuesto = ''
	      Begin
	           Raiserror ('Impuesto de Compras no esta definido - trinsbn_cheques_facturas ' ,16,1,5000 )
	            rollback work
	            return
	      End
	
	      if ( select acepta_centros  from cn_catalogo_cuentas where  cuenta_contable  = @cuenta_impuesto ) = 'N'
	      Begin
	            select  @centro_impuesto = null
	      End
	      Else
	      Begin
	            if @centro_impuesto is null  or @centro_impuesto = ''
	            Begin
	                 Raiserror (' Debe ingresar centro de impuesto para impuesto a la compra - trinsbn_cheques_facturas ' ,16,1,5000)
	                 rollback work
	                 return
	            End
	      End
	      
	      -- Procedemos a insertar el impuesto de compras
	
	    Insert into bn_cheques_det (  codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo , cuenta_contable, codigo_centro, cargo, abono , generado )
	       values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @correlativo, @cuenta_impuesto, @centro_impuesto,  @impto_venta, 0, 'S' )
	
	   if @@error <> 0
	   begin
	       raiserror ( 'No se pudo actualizar la cuenta de impuesto para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
	       rollback work
	       return
	   end
	
	
	--- Actualizamos el correlativo correspondiente a la factura
	
	   update bn_cheques_facturas
	           set imp1 = @correlativo
	   where  codigo_banco        = @codigo_banco
	      and  id_cuenta                = @id_cuenta
	      and  codigo_tipo             = @codigo_tipo
	      and numero_cheque       = @numero_cheque 
	      and numero_documento = @numero_documento 
	
	   if @@error <> 0
	   begin
	       raiserror ( 'No se pudo actualizar el correlativo de impuesto para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
	       rollback work
	       return
	   end


End


if @impto_retenido > 0
Begin
     select @correlativo = @correlativo + 1

     select @cuenta_impuesto = null,
               @centro_impuesto = null

      select @cuenta_impuesto = cuenta_contable,
                @centro_impuesto = codigo_centro
      from gn_impuestos
      where codigo_impuesto = @impto_retencion 
     
      if @cuenta_impuesto is null or @cuenta_impuesto = ''
      Begin
           Raiserror ('Impuesto de Retencion no esta definido - trinsbn_cheques_facturas ' ,16,1,5000 )
            rollback work
            return
      End

      if ( select acepta_centros  from cn_catalogo_cuentas where  cuenta_contable  = @cuenta_impuesto ) = 'N'
      Begin
            select  @centro_impuesto = null
      End
      Else
      Begin
            if @centro_impuesto is null  or @centro_impuesto = ''
            Begin
                 Raiserror (' Debe ingresar centro de impuesto para impuesto retenido - trinsbn_cheques_facturas ' ,16,1,5000)
                 rollback work
                 return
            End
      End
      
      -- Procedemos a insertar el impuesto de compras

    Insert into bn_cheques_det (  codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo , cuenta_contable, codigo_centro, cargo, abono , generado )
       values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @correlativo, @cuenta_impuesto, @centro_impuesto,  0, @impto_retenido, 'S' )

   if @@error <> 0
   begin
       raiserror ( 'No se pudo actualizar la cuenta de retencion para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
       rollback work
       return
   end


--- Actualizamos el correlativo correspondiente a la factura

   update bn_cheques_facturas
           set imp2 = @correlativo
   where  codigo_banco        = @codigo_banco
      and  id_cuenta                = @id_cuenta
      and  codigo_tipo             = @codigo_tipo
      and numero_cheque       = @numero_cheque 
      and numero_documento = @numero_documento 

   if @@error <> 0
   begin
       raiserror ( 'No se pudo actualizar el correlativo impuesto retencion para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
       rollback work
       return
   end


End


if @impto_otros > 0
Begin
     select @correlativo = @correlativo + 1

     select @cuenta_impuesto = null,
               @centro_impuesto = null

      select @cuenta_impuesto = cuenta_contable,
                @centro_impuesto = codigo_centro
      from gn_impuestos
      where codigo_impuesto = @otro_impto
     
      if @cuenta_impuesto is null or @cuenta_impuesto = ''
      Begin
           Raiserror ('Impuesto otros  no esta definido - trinsbn_cheques_facturas ' ,16,1,5000 )
            rollback work
            return
      End

      if ( select acepta_centros  from cn_catalogo_cuentas where  cuenta_contable  = @cuenta_impuesto ) = 'N'
      Begin
            select  @centro_impuesto = null
      End
      Else
      Begin
            if @centro_impuesto is null  or @centro_impuesto = ''
            Begin
                 Raiserror (' Debe ingresar centro de impuesto para otro impuesto retenido - trinsbn_cheques_facturas ' ,16,1,5000)
                 rollback work
                 return
            End
      End
      
      -- Procedemos a insertar el impuesto de compras

    Insert into bn_cheques_det (  codigo_banco, id_cuenta, codigo_tipo, numero_cheque, correlativo , cuenta_contable, codigo_centro, cargo, abono , generado )
       values ( @codigo_banco, @id_cuenta, @codigo_tipo, @numero_cheque, @correlativo, @cuenta_impuesto, @centro_impuesto,  0, @impto_otros, 'S' )

   if @@error <> 0
   begin
       raiserror ( 'No se pudo actualizar la cuenta de otro impuesto para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
       rollback work
       return
   end


--- Actualizamos el correlativo correspondiente a la factura

   update bn_cheques_facturas
           set imp3 = @correlativo
   where  codigo_banco        = @codigo_banco
      and  id_cuenta                = @id_cuenta
      and  codigo_tipo             = @codigo_tipo
      and numero_cheque       = @numero_cheque 
      and numero_documento = @numero_documento 

   if @@error <> 0
   begin
       raiserror ( 'No se pudo actualizar el correlativo otro impuesto para la factura %s - trinsbn_cheques_facturas ' ,16,1,@numero_documento )
       rollback work
       return
   end


End


End


go

