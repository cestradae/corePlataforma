Create procedure [dbo].[stp_UDNoAutoriza_Ausencias]
  @codigo_empleado char(10),
  @corr_solicitud smallint,
  @username varchar(35),
  @error char(1) out
as
-------------------
-- cambio hecho por LDR
-- Fecha 05/10/2010
-- El cursor que recorre los dias no tenia un fetch y daba error de llave duplicada
-- Se agrego tambien la fecha_alta_suspension para cuando calcule la nomina darle de alta
-- De manera automatica
-----------------------------------------------------------
-------------------
-- cambio hecho por LDR
-- Fecha 05/05/2009
-- Asunto agrega correlativo dias
-----------------------------------------------------------
--Creado por LSAO 
--Fecha 30/06/2003
--Asunto Autorizacion de solicitudes
-----------------------------------------------------------

declare @codigo_tipo char(2),
        @fecha_solicitud datetime,
        @dias_solicitar decimal(8,4),
        @descuenta_sabados char(1),
        @tipo_solicitud char(1),
        @estado_solicitud char(1),
        @dias_disponibles decimal(8,4),
        @periodo datetime,
        @saldo_dias decimal(8,4),
        @dias_gozar decimal(8,4),
        @no_dias  decimal(18,4),
        @corr_dias smallint,
        @fecha_alta_suspension datetime,
        @error_int int

select @error = '' 
select @codigo_tipo = codigo_tipo,
       @fecha_solicitud = fecha_solicitud,
       @dias_solicitar = dias_solicitar,
       @descuenta_sabados = descuenta_sabados,
       @tipo_solicitud = tipo_solicitud,
       @estado_solicitud = estado_solicitud 
from no_solicitud_ausencias 
where codigo_empleado = @codigo_empleado
  and corr_solicitud = @corr_solicitud

if @estado_solicitud = 'A' 
begin
   raiserror ('Solicitud %d para Empleado %s ya fue autorizada - stp_UDNoAutoriza_Ausencias' ,16,1,@corr_solicitud, @codigo_empleado )
   return
end



if @tipo_solicitud = 'V' 
begin
   -- Calculamos las vacaciones a la fecha del calculo

   exec @error_int = stp_UDNoCalcula_Vacaciones @codigo_empleado, @codigo_empleado, @codigo_tipo, @fecha_solicitud
   if @error_int <> 0
   begin
      raiserror ('No se pudieron calcular las vacaciones para el empleado %s y solicitud %d - stp_UDNoAutoriza_Ausencias', 16,1, @codigo_empleado, @corr_solicitud )
      return 9
   end 

   -- Obtenemos los dias pendientes para ver si se cubre con los dias '
    
   select @dias_disponibles = sum(saldo_dias)
   from no_empleado_vacaciones
   where codigo_empleado = @codigo_empleado 

   if @dias_disponibles < @dias_solicitar 
   begin
      raiserror ('No hay dias suficientes de vacaciones para solventar los dias solicitados - stp_UDNoAutoriza_Ausencias', 16,1,5000 )
      return 9
   end
end

Begin Tran

-- Autorizamos la ausencia 

update no_solicitud_ausencias 
    set estado_solicitud = 'A',
          fecha_autoriza = getdate(),
          usuario_autoriza = @username
where codigo_empleado = @codigo_empleado
  and corr_solicitud = @corr_solicitud

if @@error <> 0
begin
   raiserror ('No se pudo actualizar el estado de solicitud - stp_UDNoAutoriza_Ausencias ' ,16,1,5000)
   rollback tran
   return 9
end

-- Actualizamos el registro de vacaciones si es necesario 

if @tipo_solicitud = 'V'
begin
      
   declare cur_dias cursor for
       select corr_dias,
              no_dias
       from no_solicitud_ausdet
        where codigo_empleado = @codigo_empleado
          and corr_solicitud = @corr_solicitud

   open cur_dias 
   fetch cur_dias into @corr_dias, @no_dias

   while @@fetch_status = 0 
   begin


      declare cur_vacaciones cursor for
          select periodo 
          from no_empleado_vacaciones
          where codigo_empleado = @codigo_empleado   
            and saldo_dias > 0
           order by periodo

      open cur_vacaciones 
      fetch cur_vacaciones into @periodo 

      select @dias_solicitar = @no_dias

      while @@fetch_status = 0 and @dias_solicitar > 0.00
      Begin

         -- Actualizamos los dias a descontar de las vacaciones pendientes

         select @saldo_dias = saldo_dias
         from no_empleado_vacaciones
         where codigo_empleado = @codigo_empleado
           and periodo = @periodo

         if @saldo_dias >= @dias_solicitar
         begin 
            select @dias_gozar = @dias_solicitar
            select @dias_solicitar = 0
         end
         else
         begin
            select @dias_gozar = @saldo_dias
            select @dias_solicitar = @dias_solicitar - @dias_gozar
         end
      
         select @periodo, @dias_gozar, @saldo_dias, @dias_solicitar
         update no_empleado_vacaciones
            set dias_gozados = dias_gozados + @dias_gozar
         where codigo_empleado = @codigo_empleado
           and periodo = @periodo

         if @@error <> 0 
         begin
            raiserror ( 'No se pudieron actualizar dias gozados - stp_UDNoAutoriza_Ausencias ' ,16,1,5000 )
            rollback tran
            deallocate cur_dias
            deallocate cur_vacaciones
            return 9
         end

         insert into no_solicitud_ausvac ( 
           codigo_empleado,
           corr_solicitud,
           periodo,
           corr_dias,
           dias_gozados )
         values (
           @codigo_empleado,
           @corr_solicitud,
           @periodo,
           @corr_dias,
           @dias_gozar )


         if @@error <> 0
         begin
            raiserror ('No se puede actualizar el detalle de vacaciones - stp_UDNoAutoriza_Ausencias ', 16,1,5000 )
            rollback tran
            deallocate cur_dias
            deallocate cur_vacaciones
            return  9
         end
     
         fetch cur_vacaciones into @periodo 
    
      end        
      Close cur_vacaciones
      Deallocate cur_vacaciones  

      fetch cur_dias into @corr_dias, @no_dias

   end
  
   Close cur_dias
   Deallocate cur_dias
end


-- Se marca al empleado como suspendido 
if @tipo_solicitud = 'S' 
begin
    -- Calculamos la fecha proxima de alta 

    select @fecha_alta_suspension = max(a_fecha)
    from no_solicitud_ausdet
    where codigo_empleado = @codigo_empleado
      and corr_solicitud = @corr_solicitud

    update no_empleados
        set estado_empleado = 'S'
            ,fecha_alta_suspension = @fecha_alta_suspension 
    where codigo_empleado = @codigo_empleado
      
    IF @@ERROR <> 0
    begin
         raiserror ('No se puede actualizar al empleado - stp_UDNoAutoriza_Ausencias ' ,16,1,5000)
         rollback tran 
         return 9
    end 
end 

Commit Tran
go

