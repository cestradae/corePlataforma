Create procedure [dbo].[stp_UDnoCargaCamposRepAdmin]
As
------------------------------
-- Hecho LDR
-- Fecha 05/01/2011
-- Se agrego campos usuarios 
-------------------------------

------------------------------
-- Hecho LDR
-- Fecha 18/10/2010
-- Carga los campos y llaves de las tablas para los reportes administrativos 
-------------------------------

-- Primero la tabla de empleados


delete from no_reportes_generales_campos
   where tabla = 'no_empleados'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'no_empleados.'+a.name, 
       'Empl.'+a.name,
       'no_empleados',
       null
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'no_empleados'
where a.xtype <> 189
order by a.name


-- La tabla de puestos 

delete from no_reportes_generales_campos
  where tabla = 'no_puestos'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'no_puestos.'+a.name, 
       'Puestos.'+a.name,
       'no_puestos',
       'no_puestos.codigo_puesto = no_empleados.codigo_puesto'
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'no_puestos'
where a.xtype <> 189
order by a.name


-- La tabla de gn_paises

delete from no_reportes_generales_campos
  where tabla = 'gn_paises'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'gn_paises.'+a.name, 
       'Paises.'+a.name,
       'gn_paises',
       'gn_paises.codigo_pais = no_empleados.codigo_pais'
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'gn_paises'
where a.xtype <> 189
order by a.name

-- Tabla de centros de costos

delete from no_reportes_generales_campos
  where tabla = 'cn_catalogo_centros'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'cn_catalogo_centros.'+a.name, 
       'Centros.'+a.name,
       'cn_catalogo_centros',
       'cn_catalogo_centros.codigo_centro = no_empleados.codigo_centro'
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'cn_catalogo_centros'
where a.xtype <> 189
order by a.name


-- Tabla de profesiones

delete from no_reportes_generales_campos
  where tabla = 'gn_profesiones'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


select 'gn_profesiones.'+a.name, 
       'Prof.'+a.name,
       'gn_profesiones',
       'gn_profesiones.codigo_profesion = no_empleados.codigo_profesion'
from syscolumns a
   join sysobjects b on a.id = b.id and b.name = 'gn_profesiones'
where a.xtype <> 189
order by a.name


-- Tabla de departamentos

delete from no_reportes_generales_campos
  where tabla = 'gn_departamentos'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


	select 'gn_departamentos.'+a.name, 
		   'Deptos.'+a.name,
		   'gn_departamentos',
		   'gn_departamentos.codigo_departamento = no_empleados.codigo_departamento'
	from syscolumns a
	   join sysobjects b on a.id = b.id and b.name = 'gn_departamentos'
	where a.xtype <> 189
	order by a.name


-- Tabla de Secciones

delete from no_reportes_generales_campos
  where tabla = 'no_secciones'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


	select 'no_secciones.'+a.name, 
		   'Secciones.'+a.name,
		   'no_secciones',
		   'no_secciones.codigo_seccion = no_empleados.codigo_seccion'
	from syscolumns a
	   join sysobjects b on a.id = b.id and b.name = 'no_secciones'
	where a.xtype <> 189
	order by a.name



-- Tabla de Grupos de trabajo

delete from no_reportes_generales_campos
  where tabla = 'no_grupos_trabajo'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


	select 'no_grupos_trabajo.'+a.name, 
		   'GrTrab.'+a.name,
		   'no_grupos_trabajo',
		   'no_grupos_trabajo.grupo_trabajo = no_empleados.grupo_trabajo'
	from syscolumns a
	   join sysobjects b on a.id = b.id and b.name = 'no_grupos_trabajo'
	where a.xtype <> 189
	order by a.name



-- Tabla de Jornadas

delete from no_reportes_generales_campos
  where tabla = 'no_jornadas'

insert into no_reportes_generales_campos (
  nombre_campo, nombre, tabla, llave )


	select 'no_jornadas.'+a.name, 
		   'Jornadas.'+a.name,
		   'no_jornadas',
		   'no_jornadas.codigo_jornada = no_empleados.codigo_jornada'
	from syscolumns a
	   join sysobjects b on a.id = b.id and b.name = 'no_jornadas'
	where a.xtype <> 189
	order by a.name


exec stp_UDnoCreaVistaEgresos

exec stp_UDnoCreaVistaIngresos

exec stp_UDnoCreaVistaCamposUsuario
go

