
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_crrenta_hn
  (  @oldcodigo_impuesto char (3) ,
  @oldano smallint ,
  @oldmes smallint  )
As SELECT a.codigo_impuesto,a.ano,a.mes,a.no_cuotas,a.fecha_generacion,a.usuario_generacion,a.estado,a.fecha_cierre,a.usuario_cierre,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_reporte_renta_hn] a
WHERE (a.codigo_impuesto =  @oldcodigo_impuesto AND 
a.ano =  @oldano AND 
a.mes =  @oldmes)
go

