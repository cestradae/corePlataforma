-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsNo_cingresos]
  (  @oldCodigo_ingreso char (3)  )
As DELETE [dbo].[no_catalogo_ingresos] 
WHERE (codigo_ingreso =  @oldCodigo_ingreso)
go

