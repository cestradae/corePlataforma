-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_empl_documento](  @AUTO_correlativo smallint OUT,
@AUTO_EditStamp varchar(30) OUT,
  @codigo_empleado char (10) ,
  @nombre_documento varchar (50) ,
  @path_documento varchar (100)  )
As 
declare @correlativo smallint

select @correlativo = max(correlativo)
from no_empleado_documento
where codigo_empleado = @codigo_empleado

if @correlativo is null select @correlativo = 0
select @correlativo = @correlativo + 1

	INSERT INTO [dbo].[no_empleado_documento]
(  codigo_empleado ,
  correlativo,
  nombre_documento ,
  path_documento  )
VALUES (  @codigo_empleado ,
  @correlativo, 
  @nombre_documento ,
  @path_documento  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_correlativo = correlativo, @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_empleado_documento]
  WHERE ( codigo_empleado =  @codigo_empleado AND 
correlativo =  @correlativo )
go

