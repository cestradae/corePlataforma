-- =============================================
-- Author:		Estuardo Arévalo
-- Create date: 15.julio.2009
-- Description:	Obtiene los datos del formato de un reporte para Boleta por Tipo de Nomina
-- =============================================
CREATE PROCEDURE [dbo].[stp_udnoObtieneFormatoBoleta]
											@codigo_tipo char(2)	
AS
BEGIN
	SET NOCOUNT ON;

	select nombre_formato, isnull(procedimiento,'') as procedimiento, 
             isnull(usa_facturas,'N') usa_facturas, 
             isnull(usa_cuentas,'N') usa_cuentas, 
             isnull(pro_facturas,'') pro_facturas, isnull(pro_cuentas,'') pro_cuentas, 
             isnull(nombre_sub1,'') as nombre_sub1, isnull(nombre_sub2,'') as nombre_sub2 
    from gn_formatos a, no_tipos_nomina b 
    where b.formato_recibo = a.nombre_formato and b.codigo_tipo = @codigo_tipo

END
go

