
-- Procedure definition
CREATE PROCEDURE stp_D_clsno_pisr_vargt
  (  @oldcodigo_impuesto char (3) ,
  @oldcodigo_variable char (10)  )
As DELETE [dbo].[no_parametros_isr_vargt] 
WHERE (codigo_impuesto =  @oldcodigo_impuesto AND 
codigo_variable =  @oldcodigo_variable)
go

