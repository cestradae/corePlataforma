-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_lSAP_Clases]
As
  SELECT codigo_clase,codigo_clase+' - '+descripcion  as  descripcion  FROM no_clases_variables
go

