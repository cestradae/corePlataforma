CREATE procedure [dbo].[stp_udnorptprestamosdetallado]
--Filtros
	@tipo1 char(10),
	@tipo2 char(10),
	@deduccion1 char(10),
	@deduccion2 char(10),
	@empleado1 char(10),
	@empleado2 char(10)
as

set nocount on

if @deduccion1 = '' select @deduccion1 = min(codigo_deduccion) from no_catalogo_deducciones 
if @deduccion2 = '' select @deduccion1 = max(codigo_deduccion) from no_catalogo_deducciones 
if @empleado1 = '' select @empleado1 = min(codigo_empleado) from no_empleados 
if @empleado2 = '' select @empleado2 = max(codigo_empleado) from no_empleados
if @tipo1 = '' select @tipo1 = min(codigo_tipo) from no_tipos_nomina 
if @tipo2 = '' select @tipo2 = max(codigo_tipo) from no_tipos_nomina 

select a.codigo_deduccion, c.descripcion descripciondeduccion, a.codigo_tipo, d.descripcion,
	a.codigo_empleado, e.nombre_usual, a.correlativo, a.monto_original, a.monto, a.cuota,
	a.saldo, a.periodo_id, b.grupo_id, g.descripcion des_detalle, b.monto monto_detalle,
	convert(varchar(10),f.fecha_inicial,103)+'-'+convert(varchar(10),f.fecha_final,103)as periodo_detalle
from no_deducciones_enc a, no_deducciones_det b, no_catalogo_deducciones c, no_tipos_nomina d,
	no_empleados e, no_periodos_pago f, no_grupos_valores g
where a.codigo_empleado = b.codigo_empleado and
	a.codigo_tipo = b.codigo_tipo and
	a.codigo_deduccion = b.codigo_deduccion and
	a.correlativo = b.correlativo and
	a.codigo_deduccion = c.codigo_deduccion and
	a.codigo_tipo = d.codigo_tipo and
	a.codigo_empleado = e.codigo_empleado and
	a.periodo_id = f.periodo_id and
	b.grupo_id = g.grupo_id and
	a.codigo_tipo between @tipo1 and @tipo2 and
	a.codigo_deduccion between @deduccion1 and @deduccion2 and
	a.codigo_empleado between @empleado1 and @empleado2
go

