-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_provisiones](  @oldcodigo_tipo char (2) ,
  @oldcodigo_provision char (3) ,
  @codigo_tipo char (2) ,
  @codigo_provision char (3) ,
  @cuenta_sap nchar (15) ,
  @cuenta_sap_gasto char (15)  )
As 
UPDATE [dbo].[sap_provisiones] Set 
    codigo_tipo = @codigo_tipo,
    codigo_provision = @codigo_provision,
    cuenta_sap = @cuenta_sap,
    cuenta_sap_gasto = @cuenta_sap_gasto 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
codigo_provision =  @oldcodigo_provision )
go

