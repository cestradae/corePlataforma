-- Procedure definition
CREATE PROCEDURE [dbo].[stp_U_clssap_bitacora_det](  @oldcodigo_tipo char (2) ,
  @oldperiodo_id char (10) ,
  @oldgrupo_id char (5) ,
  @oldcalculo int ,
  @oldcorrelativo int ,
  @codigo_tipo char (2) ,
  @periodo_id char (10) ,
  @grupo_id char (5) ,
  @calculo int ,
  @correlativo int ,
  @cuenta_contable varchar (20) ,
  @cargos money ,
  @abonos money ,
  @codigo_asociado varchar (20) ,
  @codigo_centro varchar (20) ,
  @nombre_asociado varchar (300) ,
  @nombre_centro varchar (300)  )
As 
UPDATE [dbo].[sap_bitacora_det] Set 
    codigo_tipo = @codigo_tipo,
    periodo_id = @periodo_id,
    grupo_id = @grupo_id,
    calculo = @calculo,
    correlativo = @correlativo,
    cuenta_contable = @cuenta_contable,
    cargos = @cargos,
    abonos = @abonos,
    codigo_asociado = @codigo_asociado,
    codigo_centro = @codigo_centro,
    nombre_asociado = @nombre_asociado,
    nombre_centro = @nombre_centro 
WHERE 	( codigo_tipo =  @oldcodigo_tipo AND 
periodo_id =  @oldperiodo_id AND 
grupo_id =  @oldgrupo_id AND 
calculo =  @oldcalculo AND 
correlativo =  @oldcorrelativo )
go

