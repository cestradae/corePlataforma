-- exec stp_UDNoCorreVacaciones '00005' , '000005' , '01', 1970, 2009


create procedure [dbo].[stp_UDnoCorreVacaciones] 
    @empleado_inicial char(10),
    @empleado_final char(10),  
    @codigo_tipo char(2),
    @ano_inicial smallint,
    @ano_final   smallint

as 
 
  declare @fecha_calculo datetime
 
  update no_empleados
     set fecha_ult_vacacion = null
      
      
 
  while @ano_inicial <= @ano_final
  Begin

   
    Select @fecha_calculo = convert(char(4),@ano_inicial) + '1231' 
   

     
    EXEC stp_UDNoCalcula_Vacaciones 
       @empleado_inicial ,
       @empleado_final ,
       @codigo_tipo ,
       @fecha_calculo 
     
     
     
     select @ano_inicial = @ano_inicial + 1
       
       
  End
go

