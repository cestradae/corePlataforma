
Create TRIGGER [trinsno_grupos_valores] ON [dbo].[no_grupos_valores] 
FOR INSERT, UPDATE
AS

update no_grupos_valores
    set grupo_id = no_grupos_valores.codigo_tipo + convert(char(3), no_grupos_valores.codigo_grupo)
from inserted
where inserted.codigo_tipo = no_grupos_valores.codigo_tipo
and inserted.codigo_grupo = no_grupos_valores.codigo_grupo

if @@error <> 0
Begin
   Raiserror ('No se puede actualizar el grupo - trinsno_grupos_valores ', 16,1,5000)
   Rollback work
   Return
End



go

