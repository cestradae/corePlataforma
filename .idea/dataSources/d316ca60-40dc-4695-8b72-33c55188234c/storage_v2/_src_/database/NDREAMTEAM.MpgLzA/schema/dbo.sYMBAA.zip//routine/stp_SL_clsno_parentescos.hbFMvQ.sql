-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsno_parentescos]
  As SELECT a.codigo_empleado,a.correlativo,a.nombre_pariente,a.fecha_nacimiento,a.codigo_parentesco,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp ,a.edad FROM [dbo].[no_parentescos] a
go

