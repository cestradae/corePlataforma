
-- Procedure definition
CREATE PROCEDURE stp_I_clsno_pisr_vargt(@AUTO_EditStamp varchar(30) OUT,
  @codigo_impuesto char (3) ,
  @codigo_variable char (10) ,
  @tipo_variable smallint  )
As 
	INSERT INTO [dbo].[no_parametros_isr_vargt]
(  codigo_impuesto ,
  codigo_variable ,
  tipo_variable  )
VALUES (  @codigo_impuesto ,
  @codigo_variable ,
  @tipo_variable  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_parametros_isr_vargt]
  WHERE ( codigo_impuesto =  @codigo_impuesto AND 
codigo_variable =  @codigo_variable )
go

