-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_config_punto]
  (  @oldcodigo_tipo char (2)  )
As DELETE [dbo].[no_configuracion_punto] 
WHERE (codigo_tipo =  @oldcodigo_tipo)
go

