
-- Procedure definition
CREATE PROCEDURE stp_S_clsno_phn_municipios
  (  @oldcodigo_patrono smallint ,
  @oldid_municipio smallint  )
As SELECT a.codigo_patrono,a.id_municipio,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_patronos_hn_municipios] a
WHERE (a.codigo_patrono =  @oldcodigo_patrono AND 
a.id_municipio =  @oldid_municipio)
go

