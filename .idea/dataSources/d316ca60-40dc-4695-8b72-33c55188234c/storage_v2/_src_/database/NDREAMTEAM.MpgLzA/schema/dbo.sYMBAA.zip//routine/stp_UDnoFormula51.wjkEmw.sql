create procedure stp_UDnoFormula51   
( @codigo_tipo char(2), @periodo_id char(10), @grupo_id char(5), @no_calculo smallint, @codigo_empleado char(10), @result decimal(22,6) out ) AS

  declare @SSDiasAntiguedad decimal(18,4) 
declare @tmp2 decimal(18,4)
declare @tmp3 decimal(18,4)
declare @DAGUI decimal(22,6) 
declare @tmp1 decimal(18,4) 

begin
  select @SSDiasAntiguedad = isnull(valor,0) from no_nomina_variables_sistema where codigo_variable = 'SSDiasAnt' and codigo_empleado = @codigo_empleado and codigo_tipo = @codigo_tipo and periodo_id = @periodo_id and grupo_id = @grupo_id and no_calculo = @no_calculo 
exec stp_UDnoPromUMesesIngresos 'Ord',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 ,  @tmp2 out
exec stp_UDnoPromUMesesIngresos 'Boni_Ince',@codigo_tipo, @periodo_id, @grupo_id, @no_calculo, @codigo_empleado,  6 ,  @tmp3 out
if ( select isnull(tipo_variable,'1') from no_nomina_valores where codigo_tipo = @codigo_tipo and codigo_valor = '11        ' ) = '1'  begin Select @DAGUI= isnull(sum(valor),0) from no_reporte_valores_ingreso a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and tipo_valor = '1' and codigo_empleado = @codigo_empleado and codigo_valor = '11        ' end else begin Select @DAGUI= isnull(sum(valor),0) from no_nomina_valores_calculados a  where codigo_tipo =@codigo_tipo  and periodo_id = @periodo_id  and grupo_id = @grupo_id and no_calculo =  @no_calculo  and codigo_empleado = @codigo_empleado and codigo_valor = '11        ' end 
if ((isnull(@SSDiasAntiguedad,0)>60)) select @tmp1=(@tmp2+@tmp3)*6/6/365*isnull(@DAGUI,0)*0.05 else select @tmp1=0

  set @result=@tmp1
end
go

