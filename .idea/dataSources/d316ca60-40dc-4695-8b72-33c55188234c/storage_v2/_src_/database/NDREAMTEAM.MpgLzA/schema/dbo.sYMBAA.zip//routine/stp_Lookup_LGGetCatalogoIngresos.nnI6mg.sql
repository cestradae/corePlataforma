-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_LGGetCatalogoIngresos]
As
  Select Codigo_Ingreso, Descripcion From No_catalogo_Ingresos
go

