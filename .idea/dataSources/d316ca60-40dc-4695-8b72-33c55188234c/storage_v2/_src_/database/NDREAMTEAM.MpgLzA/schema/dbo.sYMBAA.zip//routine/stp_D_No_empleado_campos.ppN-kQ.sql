-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_No_empleado_campos]
  (  @oldCodigo_empleado char (10) ,
  @oldNombre_campo varchar (10) ,
  @oldValor_lista varchar (20)  )
As DELETE [dbo].[no_empleado_campos] 
WHERE (codigo_empleado =  @oldCodigo_empleado AND 
nombre_campo =  @oldNombre_campo AND 
valor_lista =  @oldValor_lista)
go

