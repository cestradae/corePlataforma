-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_ereportedet]
  (  @oldcodigo_repnomina smallint ,
  @oldnumero_columna smallint ,
  @oldcodigo_elemento varchar (11)  )
As DELETE [dbo].[no_nomina_reportedet] 
WHERE (codigo_repnomina =  @oldcodigo_repnomina AND 
numero_columna =  @oldnumero_columna AND 
codigo_elemento =  @oldcodigo_elemento)
go

