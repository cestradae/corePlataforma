-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsNo_rvalores](  @AUTO_no_calculo smallint OUT,
  @AUTO_Estado_reporte char (1) OUT,
  @AUTO_Fecha_ingreso datetime OUT,
@AUTO_EditStamp varchar(30) OUT,
  @Codigo_tipo char (2) ,
  @Periodo_id char (10) ,
  @No_reporte smallint ,
  @Grupo_id char (5) ,
  @Fecha_reporte datetime ,
  @Genera_aut char (1) ,
  @Usuario_ingreso varchar (35)  )
As 
	INSERT INTO [dbo].[no_reporte_valores]
(  codigo_tipo ,
  periodo_id ,
  no_reporte ,
  grupo_id ,
  fecha_reporte ,
  genera_aut ,
  usuario_ingreso  )
VALUES (  @Codigo_tipo ,
  @Periodo_id ,
  @No_reporte ,
  @Grupo_id ,
  @Fecha_reporte ,
  @Genera_aut ,
  @Usuario_ingreso  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_no_calculo = no_calculo, @AUTO_Estado_reporte = estado_reporte, @AUTO_Fecha_ingreso = fecha_ingreso, @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_reporte_valores]
  WHERE ( codigo_tipo =  @Codigo_tipo AND 
periodo_id =  @Periodo_id AND 
no_reporte =  @No_reporte )
go

