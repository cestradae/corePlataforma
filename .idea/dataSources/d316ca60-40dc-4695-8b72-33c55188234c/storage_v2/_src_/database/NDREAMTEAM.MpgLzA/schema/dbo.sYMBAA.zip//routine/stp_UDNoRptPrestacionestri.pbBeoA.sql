--  stp_UDNoRptPrestacionestri '03','03','20100331',17
--  stp_UDNoRptPrestacionestri '01','01','20111231','17'
--  stp_UDNoRptPrestacionestri '06','06','20100630','17'
CREATE PROCEDURE [dbo].[stp_UDNoRptPrestacionestri] 
  @codigo_tipo char(2),
  @codigo_tipo_fin char(2),
  @Fecha_reporte DATETIME,
  @reporte smallint
AS


	
---------------------------------------------
--- Cambio hecho por Daniel Ortiz
--- Fecha 11/01/2011
--- Se quito el filtro de fecha de cierre de los empleados de baja sin liquidacion
---   Si un empleado esta de alta y tiene fecha de bja le coloca null en fecha baja  
---------------------------------------------

---------------------------------------------
--- Cambio hecho por Daniel Ortiz
--- Fecha 15/07/2010
--- Incluye empleados de baja sin liquidaciones con mas de 60dias
---------------------------------------------
---------------------------------------------
--- Cambio hecho por Daniel Ortiz
--- Fecha 13/07/2010
--- Incluye manejo de periodo_id y empleados suspendidos
---------------------------------------------
---------------------------------------------
--- Cambio hecho por lsao
--- Fecha 25/08/2008
--- Incluye manejo de multimoneda
---------------------------------------------

---------------------------------------------
--- Cambio hecho por dortiz
--- Fecha 21/10/2009
--- Incluye agregado de puesto
---------------------------------------------

Set NoCount On

-- Inicializacion de variables
Declare @columnas smallint
Declare @Contador smallint
Declare @tasa_cambio decimal(18,6)
Declare @no_nomina char(10)
Declare @visto_bueno varchar(50)
Declare @revisado varchar(50)
Declare @autorizado varchar(50)
DECLARE @codigo_ingreso CHAR(3)
DECLARE @codigo_formula CHAR(3)
DECLARE @nombreproc CHAR(20)
DECLARE @codigo_departamento SMALLINT
DECLARE @codigo_centro VARCHAR(20)
DECLARE @periodo_id VARCHAR(10)
DECLARE @grupo_id VARCHAR(5)
DECLARE @resultado decimal(22,6)
DECLARE @error INT
DECLARE @no_calculo SMALLINT
Declare @ingresos money
Declare @deduccion money
Declare @valor money
Declare @codigo_empleado varchar(10)
Declare @moneda_nomina MONEY

-- Variables para hacer el update de las columnas variables
Declare @columna varchar(10)
Declare @Instruccion_Sql varchar(5000)
Declare @clasificacion char(1)
Declare @numero_empleados smallint

-- Crea la tabla Temporal para almacenar los valores de la nomina
Create table #Nomina
(
   codigo_tipo char(2)COLLATE Modern_Spanish_CI_AS,
   numero_columnas smallint,
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS,
   col1 money default 0,
   col2 money default 0,
   col3 money default 0,
   col4 money default 0,
   col5 money default 0,
   col6 money default 0,
   col7 money default 0,
   col8 money default 0,
   col9 money default 0,
   col10 money default 0,
   col11 money default 0,
   col12 money default 0,
   col13 money default 0,
   col14 money default 0,
   col15 money default 0,
   col16 money default 0,
   col17 money default 0,
   col18 money default 0,
   col19 money default 0,
   col20 money default 0,
   col21 money default 0,
   col22 money default 0,
   col23 money default 0,
   col24 money default 0,
   col25 money default 0,
   col26 money default 0,
   col27 money default 0,
   col28 money default 0,
   col29 money default 0,
   col30 money default 0,
   coldesc1 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc2 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc3 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc4 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc5 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc6 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc7 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc8 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc9 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc10 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc11 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc12 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc13 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc14 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc15 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc16 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc17 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc18 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc19 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc20 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc21 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc22 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc23 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc24 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc25 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc26 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc27 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc28 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc29 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   coldesc30 varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr1   varchar(60) COLLATE Modern_Spanish_CI_AS null, --Cambio de tamaño por ingreso de puesto
   colstr2   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr3   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr4   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr5   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr6   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr7   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr8   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   colstr9   varchar(25) COLLATE Modern_Spanish_CI_AS null,
   liquido money default 0
)

Create table #Ingresos (
   codigo_empleado char(10) COLLATE Modern_Spanish_CI_AS, 
   monto_ingreso money default 0,
   numero_columna smallint 
)   

Create table #Caracteres (
		 codigo_empleado nchar(10) COLLATE Modern_Spanish_CI_AS,
   valor  nvarchar(60) COLLATE Modern_Spanish_CI_AS default '',
   numero_columna SMALLINT,
) 

Create table #ValoresCalculados (
   codigo_empleado char(10)COLLATE Modern_Spanish_CI_AS,
   valor money default 0,
   numero_columna smallint 
)   


-- Periodos donde se incluye la fecha de reporte segun las nominas
Create table #Periodos (
	periodo_id nchar(10) COLLATE Modern_Spanish_CI_AS,
	codigo_tipo NCHAR(5)COLLATE Modern_Spanish_CI_AS
)

-- Grupos de liquidaciones de las nominas seleccionadas
Create table #grupos (
	grupo_id nchar(5) COLLATE Modern_Spanish_CI_AS,
	codigo_tipo NCHAR(5) COLLATE Modern_Spanish_CI_AS
)

CREATE TABLE #repliquis (
	fecha_liquidacion datetime,
	codigo_empleado VARCHAR(10) COLLATE Modern_Spanish_CI_AS,
	fecha_inicio_rel_lab datetime
)

set rowcount 1

select @tasa_cambio = tasa_cambio
from no_nomina_enc a, no_periodos_pago b
where a.codigo_tipo = @codigo_tipo
and a.periodo_id = b.periodo_id 
and @Fecha_reporte <= fecha_final
order by a.periodo_id desc
set rowcount 0

select @moneda_nomina = codigo_moneda
from no_tipos_nomina
where codigo_tipo = @codigo_tipo

SELECT @no_calculo=100

if @tasa_cambio is null select @tasa_cambio = 1

-- Trae el numero de columnas que va  a trabajar el Reporte
insert into prestatrirep select @Fecha_reporte,@codigo_tipo , @codigo_tipo_fin, GETDATE(),'Inicio'
Select @columnas = numero_columnas, 
       @clasificacion = clasificado
from no_nomina_reporte
where codigo_repnomina = @reporte

-- Toma los periodos  de menos de 1 mes de duracion
INSERT INTO #Periodos (
	periodo_id,codigo_tipo
) SELECT periodo_id, codigo_tipo
FROM no_periodos_pago
WHERE @Fecha_reporte BETWEEN fecha_inicial AND fecha_final
AND codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
--AND DATEDIFF(dd,fecha_inicial,fecha_final)<31

	if @error <> 0
	Begin
	   Raiserror ('Sistema no encontro periodos de pago para la fecha de reporte - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   return
	End
-- Si no existen periodos para esta fecha de pago busca el periodo de pago de una fecha anterior
	if (SELECT  COUNT(periodo_id) FROM #Periodos)= 0
	begin
		INSERT INTO #Periodos (
		periodo_id,codigo_tipo
		) SELECT periodo_id, codigo_tipo
		FROM no_periodos_pago
		WHERE DATEADD(dd,-1,@Fecha_reporte) BETWEEN fecha_inicial AND fecha_final
		AND codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
	End
	if (SELECT  COUNT(periodo_id) FROM #Periodos)= 0
	begin
	   Raiserror ('Sistema no encontro periodos de pago para la fecha de reporte - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   return
	End
	
	
-- Trae grupos de pago que entran en el calculo

INSERT INTO #grupos (
	grupo_id, codigo_tipo
) SELECT grupo_id, codigo_tipo
FROM no_grupos_valores
WHERE codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND descripcion LIKE '%LIQUI%'

-- verifica que no si existen empleados de alta con fecha de alta les coloca Null de fecha de baja
UPDATE dbo.no_empleados 
SET fecha_baja=null
WHERE estado_empleado='A'
AND fecha_baja>=fecha_inicio_rel_lab

-- Ciclo para llenar las columnas
-- Llena los datos de los empleados segun la nomina
Insert Into #Nomina (
     codigo_tipo,
     numero_columnas,
     codigo_empleado,
     liquido
     )

-- Empleados de Alta con fecha_inicio_rel_lan antes de la del reporte
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'A'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND ( FECHA_BAJA  > @Fecha_reporte  OR FECHA_BAJA IS NULL  OR FECHA_BAJA <= FECHA_INICIO_REL_LAB)

union ALL
-- Empleados de Baja con fecha de baja antes que la del reporte
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'S'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND ( FECHA_BAJA  > @Fecha_reporte  OR FECHA_BAJA IS NULL  OR FECHA_BAJA <= FECHA_INICIO_REL_LAB)

UNION ALL
-- Empleados de Baja con fecha de baja antes de la del reporte y con mas de 60 dias trabajados
--  sin liquidacion cerrrada
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'B'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND datediff(dd,fecha_inicio_rel_lab,fecha_baja)>=60
AND ( FECHA_BAJA  <= @Fecha_reporte 
AND CARGA IS NULL
AND  a.CODIGO_EMPLEADO NOT IN ( SELECT CODIGO_EMPLEADO FROM NO_LIQUIDACIONES 
                             WHERE CODIGO_EMPLEADO = A.CODIGO_EMPLEADO 
                              --AND FECHA_CIERRE <= @Fecha_reporte 
							  AND ESTADO = 'C'))
union ALL
-- Empleados de Baja con fecha de baja despues de la del reporte y con mas de 60 dias trabajados
--  con liquidacion cerrada despues de la fecha de reporte
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'B'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND ( FECHA_BAJA  > @Fecha_reporte 
AND  a.CODIGO_EMPLEADO IN ( SELECT CODIGO_EMPLEADO FROM NO_LIQUIDACIONES 
                          WHERE CODIGO_EMPLEADO = A.CODIGO_EMPLEADO 
                           AND FECHA_CIERRE >= @Fecha_reporte 
                           AND ESTADO = 'C' ))
UNION ALL
-- Empleados de Baja con fecha de baja despues de la del reporte 
--  con liquidacion abierta
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'B'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND ( FECHA_BAJA  > @Fecha_reporte 
AND  a.CODIGO_EMPLEADO IN ( SELECT CODIGO_EMPLEADO FROM NO_LIQUIDACIONES 
										WHERE CODIGO_EMPLEADO = A.CODIGO_EMPLEADO 
									    AND ESTADO = 'A' ))
union all
-- Empleados de Baja con fecha de baja despues de la del reporte, con mas 60 dias hasta la fecha de reporte
--  sin liquidacion 
SELECT b.codigo_tipo, 
       @columnas,
       a.codigo_empleado,
       0
FROM no_empleados a,no_nomina_empleado b
WHERE b.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
AND a.codigo_empleado COLLATE Modern_Spanish_CI_AS =b.codigo_empleado COLLATE Modern_Spanish_CI_AS
and A.ESTADO_EMPLEADO = 'B'  AND  A.FECHA_INICIO_REL_LAB < = @Fecha_reporte
AND datediff(dd,fecha_inicio_rel_lab,@Fecha_reporte)>=60
AND ( FECHA_BAJA  > @Fecha_reporte 
AND  a.CODIGO_EMPLEADO NOT IN ( SELECT CODIGO_EMPLEADO FROM NO_LIQUIDACIONES 
										WHERE CODIGO_EMPLEADO = A.CODIGO_EMPLEADO 
									     ))					  
------ Inicial el calculo de variables 
insert into prestatrirep select @Fecha_reporte,@codigo_tipo , @codigo_tipo_fin, GETDATE(),'medio'
--declare cur_variables cursor for
declare cur_variables cursor for
SELECT DISTINCT a.codigo_tipo
from #Nomina a

open cur_variables 
fetch cur_variables into @codigo_tipo 

	SELECT @periodo_id=MAX(periodo_id) FROM #Periodos
	WHERE codigo_tipo=@codigo_tipo

	SELECT @grupo_id=grupo_id FROM #grupos
	WHERE codigo_tipo=@codigo_tipo
	
	-- Se borran los valores calculados si existieran
	
	DELETE FROM no_nomina_valores_calculados
	WHERE codigo_tipo= @codigo_tipo
	AND periodo_id= @periodo_id 
	AND grupo_id=@grupo_id 
	AND no_calculo=@no_calculo

	if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar valores calculados de sistema por empleado - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	   return
	End

	-- Se borran los valores calculados si existieran
	
	DELETE FROM no_nomina_variables_sistema
	WHERE codigo_tipo= @codigo_tipo
	AND periodo_id= @periodo_id 
	AND grupo_id=@grupo_id 
	AND no_calculo=@no_calculo

	if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar variables de sistema por empleado - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	   return
	End
	
	-- Se borran los calculos de empleados si existieran
	    
	DELETE FROM no_nomina_emplcalc
	WHERE codigo_tipo= @codigo_tipo
	AND periodo_id= @periodo_id 
	AND grupo_id=@grupo_id 
	AND no_calculo=@no_calculo
	    
	if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar calculos de empleados - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	   return
	END
    -- Se borra el encabezado de la nomina si existieran
	
    DELETE FROM no_nomina_enc
	WHERE codigo_tipo= @codigo_tipo
    AND periodo_id= @periodo_id 
    AND grupo_id=@grupo_id 
    AND no_calculo=@no_calculo 
    
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar encabezado de nomina - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	   return
	END
    
    -- Se borran los datos de las liquidaciones temporales si existieran
	
    DELETE FROM no_liquidaciones_temporal 
    
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar liquidaciones temporales - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	   return
	END

	-- Insertamos el encabezado de la nomina
	insert into no_nomina_enc (
	   codigo_tipo,
	   periodo_id,
	   grupo_id,
	   no_calculo,
	   tasa_cambio,
	   estado)
	values (
	   @codigo_tipo,
	   @periodo_id,
	   @grupo_id,
	   @no_calculo,
	   0,
	   'O' )

    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede insertar el encabezado de nomina - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END

	-- Insertar los empleados a la tabla no_nomina_emplcalc para calculo 
	-- de variables sistema y calculadas
	INSERT INTO dbo.no_nomina_emplcalc (
		codigo_tipo,
		periodo_id,
		grupo_id,
		no_calculo,
		codigo_empleado
	) SELECT DISTINCT @codigo_tipo,
		@periodo_id ,
		@grupo_id,
		@no_calculo,
		codigo_empleado
	  FROM #Nomina
	if @error <> 0
	Begin
	   Raiserror ('Sistema no puede insertar los calculos de los empleados - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
	  
	-- Insercion de empleados a tabla temporal de liquis
	INSERT INTO no_liquidaciones_temporal (
		fecha_reporte,
		codigo_empleado,
		grupo_id
	) SELECT DISTINCT @Fecha_reporte,
		codigo_empleado,
		@grupo_id
	  FROM #Nomina
	  
	if @error <> 0
	Begin
	   Raiserror ('Sistema no puede insertar las liquidaciones temporales - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END

	INSERT INTO #repliquis
		SELECT a.Fecha_reporte,
			   a.codigo_empleado,
			   b.fecha_inicio_rel_lab
		FROM no_liquidaciones_temporal a, no_empleados b
		WHERE a.codigo_empleado=b.codigo_empleado

	INSERT INTO #repliquis
  select a.fecha_liquidacion,
           a.codigo_empleado,
		   b.fecha_inicio_rel_lab
    from no_liquidaciones a, no_empleados b
    where no_calculo is null
      and a.grupo_id = @grupo_id 
	  and a.codigo_empleado=b.codigo_empleado
      AND a.codigo_empleado NOT IN ( SELECT codigo_empleado FROM #repliquis )

-- Procedemos a calcular las variables del sistema para cada empleado

exec @error = stp_UDnoCalcula_VariablesSistema
    @codigo_tipo ,
    @periodo_id ,
    @grupo_id ,
    @no_calculo
   
if @error <> 0
Begin
   Raiserror ('Sistema no puede crear variables de sistema por empleado - stp_UDnoCalculoNomina ',16,1,5000)
   Rollback WORK
   close cur_variables 
   deallocate cur_variables
    DELETE FROM no_liquidaciones_temporal 
   Return 9
End

-- Procedemos a calcular las variable con formula o procedimiento almacenado

exec @error = stp_UDnoCalculaVariablesCalc
    @codigo_tipo ,
    @periodo_id ,
    @grupo_id ,
    @no_calculo

if @error <> 0
Begin
   Raiserror ('Sistema no puede crear variables de sistema por empleado - stp_UDnoCalculoNomina ',16,1,5000)
   Rollback WORK
   close cur_variables 
   deallocate cur_variables 
    DELETE FROM no_liquidaciones_temporal 
   Return 9
End
fetch cur_variables into @codigo_ingreso 

close cur_variables 
deallocate cur_variables

---- finaliza el calculo de variables
-- Inicia
--- Ingresos Formulados : Se calculan en el momento de generacion del reporte ------------------
   
declare cur_ingresos_formulados cursor for
    select a.codigo_ingreso       
    from no_nomina_reportedet a
    where monto_base = 'F'
    AND codigo_repnomina=@reporte
    ORDER BY codigo_ingreso
    

open cur_ingresos_formulados 
fetch cur_ingresos_formulados into @codigo_ingreso 
while @@fetch_status = 0
BEGIN

-- Agarrar a todos los empleados que esten asigandos a las nominas 

  declare cur_formula_calculo cursor for
      select codigo_empleado
      from  #Nomina
      order by a.codigo_empleado

  open cur_formula_calculo
  fetch cur_formula_calculo into @codigo_Empleado
  
  while @@fetch_status = 0
  Begin 

	--- 1ro. Empleado buscar en no_liquidaciones si existe se procede sino end
  	---- 2do  Si no existe se busca el periodo por fecha final para el tipo de nomina que pertenece el empleado
  	---- 3ro. Si no existe se busca el por descripcion ( LIKE 'INDEM%'  y por tipo de nomina  que tiene el empleado ( esto hay que arreglarlo en el futuro ) 
		
		SELECT @codigo_tipo =codigo_tipo FROM no_nomina_empleado
		WHERE codigo_empleado=@codigo_empleado
		
		SELECT @periodo_id=MAX(periodo_id) FROM #Periodos
		WHERE codigo_tipo=@codigo_tipo
		
		SELECT @grupo_id=grupo_id FROM #grupos
		WHERE codigo_tipo=@codigo_tipo
		
		select @codigo_formula = formula
        from no_nomina_ingresos
        where codigo_tipo = @codigo_tipo
          and codigo_ingreso = @codigo_ingreso

        select @nombreproc = 'stp_UDnoFormula' + @codigo_formula
        
			-- select @nombreproc, @codigo_tipo, @periodo_id, @grupo_id, 100, @codigo_empleado
		exec @nombreproc @codigo_tipo, @periodo_id, @grupo_id, 100, @codigo_empleado , @resultado OUT
		--	select @nombreproc, @codigo_tipo, @periodo_id, @grupo_id, 100, @codigo_empleado		
		
    if @resultado is null select @resultado = 0
    select @resultado = round(@resultado,2) 
	
    insert into #Ingresos ( --- insert a la tabla temporal de ingresos 
          codigo_empleado,
          monto_ingreso,
          numero_columna)

    SELECT @codigo_empleado,
           @resultado ,
           numero_columna
	FROM no_nomina_reportedet
	WHERE codigo_repnomina=@reporte
	AND codigo_ingreso=@codigo_ingreso

    if @@error <> 0
    Begin
          Raiserror ('No se puede insertar el ingreso del empleado - stp_UDNoCalculoIngFormula ',16,1,5000)
          Rollback WORK
          close cur_formula_calculo
		  deallocate cur_formula_calculo
          close cur_ingresos_formulados  
		  deallocate cur_ingresos_formulados
		   DELETE FROM no_liquidaciones_temporal 
          Return 9
      END
                                           
      fetch cur_formula_calculo into @codigo_Empleado 

    END  -- Fin cursor que recorre empleados
    close cur_formula_calculo
    deallocate cur_formula_calculo

    FETCH cur_ingresos_formulados  into @codigo_ingreso 

END  -- Fin cursor de ingresos

close cur_ingresos_formulados  
deallocate cur_ingresos_formulados

-- Creamos Valores Sistema
--Fecha Inicio Relacion Laboral

Insert into #Caracteres
Select c.codigo_empleado, 
       CASE b.codigo_elemento WHEN '701' THEN convert(varchar(25),c.fecha_inicio_rel_lab,103) WHEN '702'THEN d.nombre_puesto WHEN '703'THEN convert(varchar(25),e.fecha_liquidacion,103) END,
       b.numero_columna
from  no_nomina_reportedet b, no_empleados c , no_puestos d, #repliquis  e--d agregado para ir a jalar el nombre del puesto
where  c.codigo_empleado=e.codigo_empleado
  and b.codigo_repnomina = @reporte
  and (b.codigo_elemento = '701' OR b.codigo_elemento = '702'OR b.codigo_elemento = '703')
  AND c.codigo_puesto COLLATE Modern_Spanish_CI_AS = d.codigo_puesto COLLATE Modern_Spanish_CI_AS -- Agregado para ir a jalar el nombre del puesto

union all

Select a.codigo_empleado,
       replicate(valor,'-'),
       b.numero_columna
from no_nomina_emplcalc a, no_nomina_reportedet b
where a.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
  and a.periodo_id COLLATE Modern_Spanish_CI_AS IN (SELECT periodo_id COLLATE Modern_Spanish_CI_AS FROM #periodos)
  --and a.grupo_id IN (SELECT grupo_id FROM #grupos)
  and a.no_calculo =0
  and b.codigo_repnomina = @reporte
  and b.codigo_elemento = '700'
  
Insert into #ValoresCalculados
Select a.codigo_empleado, 
       sum(a.valor * b.factor) valor,
       b.numero_columna
from no_nomina_valores_calculados a, no_nomina_reportedet b
where a.codigo_tipo BETWEEN @codigo_tipo AND @codigo_tipo_fin
  and a.periodo_id =@periodo_id
  and a.grupo_id =@grupo_id
  and a.no_calculo =@no_calculo
  and b.codigo_repnomina = @reporte
  and convert(char(10),b.codigo_valor) = convert(char(10),a.codigo_valor)
GRoup by a.codigo_empleado, b.numero_columna


-- Procedemos a Actualizar Columna por Columna cada Valor

Select @contador = 1

while @contador <= @columnas
begin
   Select @columna = 'col'+ ltrim(rtrim(convert(varchar(2),@contador)))

   -- Actualizamos los ingresos 
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= monto_ingreso '+
         'from #Ingresos a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    exec (@instruccion_Sql)
    
   -- Actualizamos los Valores Calculados

   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '='+ @columna + ' + isnull(valor,0) '+
         'from #ValoresCalculados a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
    exec (@instruccion_Sql)
    
  -- Actualizamos la descripcion de la columna

   Select @columna = 'coldesc'+ ltrim(rtrim(convert(varchar(2),@contador)))
 
   Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= linea1 + isnull(b.simbolo,'''') ' +
         'from no_nomina_repcol a , gn_monedas b '+
         'where a.codigo_repnomina  =  ' + convert(char(3), @reporte ) + ' '+
         'and a.no_columna  = '+ convert(char(2), @contador) +' '+
         'and a.codigo_moneda *= b.codigo_moneda'
  
    exec (@instruccion_Sql)
    
    Select @columna = 'colstr'+ ltrim(rtrim(convert(varchar(2),@contador)))

    Select @instruccion_Sql = 
         'Update #nomina set ' + @columna + '= valor '+
         'from #Caracteres a '+
         'where #nomina.codigo_empleado = a.codigo_empleado ' +
         'and a.numero_columna  = '+ convert(char(2), @contador)
 
    if @contador in (1,2,3,4)
        exec (@instruccion_Sql)

   -- Incrementa el contador
  Set @contador =  @contador + 1
     
end

Select @columna = 'coldesc'+ ltrim(rtrim(convert(varchar(2),@contador)))

select distinct codigo_empleado
into #empleados
from #Nomina

select @numero_empleados = count(*)
from #empleados

DECLARE cur_variables cursor for
SELECT DISTINCT a.codigo_tipo
from #Nomina a

open cur_variables 
fetch cur_variables into @codigo_ingreso 

	SELECT @periodo_id=MAX(periodo_id) FROM #Periodos
	WHERE codigo_tipo=@codigo_tipo

	SELECT @grupo_id=grupo_id FROM #grupos
	WHERE codigo_tipo=@codigo_tipo   


--SELECT @codigo_tipo,@periodo_id,@grupo_id ,@no_calculo

	DELETE FROM no_nomina_valores_calculados
	WHERE codigo_tipo= @codigo_tipo
	AND periodo_id= @periodo_id 
    AND grupo_id=@grupo_id 
    AND no_calculo=@no_calculo 
    
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar valores calculados por empleado final - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
    
   DELETE FROM no_nomina_variables_sistema
   WHERE codigo_tipo= @codigo_tipo
   AND periodo_id= @periodo_id 
   AND grupo_id=@grupo_id 
   AND no_calculo=@no_calculo
   
   if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar variables del sistema por empleado final - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
    
   DELETE FROM no_nomina_emplcalc
   WHERE codigo_tipo= @codigo_tipo
   AND periodo_id= @periodo_id 
   AND grupo_id=@grupo_id 
   AND no_calculo=@no_calculo
   
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar los calculos de los empleado final - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
    
    DELETE FROM no_nomina_enc
	WHERE codigo_tipo= @codigo_tipo
    AND periodo_id= @periodo_id 
    AND grupo_id=@grupo_id 
    AND no_calculo=@no_calculo
    
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar encabezado de la nomina final - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
    
    DELETE FROM no_liquidaciones_temporal 
    if @error <> 0
	Begin
	   Raiserror ('Sistema no puede borrar liquidaciones temporales fianl - stp_UDNoRptPrestacionestri ',16,1,5000)
	   Rollback WORK
	   close cur_variables 
	   deallocate cur_variables
	    DELETE FROM no_liquidaciones_temporal 
	   return
	END
    
-- Procedemos a calcular las variable con formula o procedimiento almacenado


fetch cur_variables into @codigo_ingreso 

close cur_variables 
deallocate cur_variables

select codigo_empleado, sum(monto_ingreso) liquido
into #liquidos
from #ingresos
group by codigo_empleado

update #Nomina
	set liquido=a.liquido
from #liquidos a
where #Nomina.codigo_empleado=a.codigo_empleado

SELECT codigo_tipo,COUNT(codigo_tipo) numero_empleados
INTO #no_empleados
from #Nomina
GROUP BY codigo_tipo

 DELETE FROM no_liquidaciones_temporal 

Select a.codigo_tipo,
   a.numero_columnas, 
   a.codigo_empleado ,
   sum(col1) col1, 
   sum(col2) col2,
   sum(col3) col3, 
   sum(col4) col4, 
   sum(col5) col5,
   sum(col6) col6, 
   sum(col7) col7, 
   sum(col8) col8, 
   sum(col9) col9, 
   sum(col10) col10, 
   sum(col11) col11, 
   sum(col12) col12, 
   sum(col13) col13, 
   sum(col14) col14, 
   sum(col15) col15, 
   sum(col16) col16, 
   sum(col17) col17, 
   sum(col18) col18, 
   sum(col19) col19, 
   sum(col20) col20, 
   sum(col21) col21, 
   sum(col22) col22, 
   sum(col23) col23, 
   sum(col24) col24, 
   sum(col25) col25, 
   sum(col26) col26, 
   sum(col27) col27, 
   sum(col28) col28, 
   sum(col29) col29,
   sum(col30) col30, 
   coldesc1 , 
   coldesc2 , 
   coldesc3 , 
   coldesc4 , 
   coldesc5 , 
   coldesc6 , 
   coldesc7 , 
   coldesc8 , 
   coldesc9 , 
   coldesc10 , 
   coldesc11 , 
   coldesc12 , 
   coldesc13 , 
   coldesc14 , 
   coldesc15 , 
   coldesc16 , 
   coldesc17 , 
   coldesc18 , 
   coldesc19 , 
   coldesc20 , 
   coldesc21 ,
   coldesc22 , 
   coldesc23 , 
   coldesc24 , 
   coldesc25 , 
   coldesc26 , 
   coldesc27 , 
   coldesc28 , 
   coldesc29 , 
   coldesc30 , 
   colstr1 , 
   colstr2 , 
   colstr3 , 
   colstr4 , 
   sum(liquido) liquido , 
   b.nombre_usual,
   c.numero_empleados
    from #Nomina a, no_empleados b, #no_empleados c
    where a.codigo_empleado = b.codigo_empleado 
    AND a.codigo_tipo=c.codigo_tipo
   group by a.codigo_empleado, coldesc1,coldesc2,coldesc3, coldesc4,coldesc5, coldesc6, 
             coldesc7,coldesc8,coldesc9,coldesc10,coldesc11,coldesc12, 
             coldesc13,coldesc14,coldesc15,coldesc16,coldesc17,coldesc18, 
             coldesc19,coldesc20,coldesc21,coldesc22,coldesc23,coldesc24, 
             coldesc25,coldesc26,coldesc27,coldesc28,coldesc29,coldesc30, 
             colstr1,colstr2,colstr3,colstr4,
             a.codigo_tipo,a.numero_columnas,b.nombre_usual,c.numero_empleados

 DELETE FROM no_liquidaciones_temporal 
 insert into prestatrirep select @Fecha_reporte,@codigo_tipo , @codigo_tipo_fin, GETDATE(),'fin '
go

