-- Procedure definition
CREATE PROCEDURE [dbo].[stp_D_clsno_plsalarios_gt]
  (  @oldcodigo_tipo char (2)  )
As DELETE [dbo].[no_parametros_libro_salarios_gt] 
WHERE (codigo_tipo =  @oldcodigo_tipo)
go

