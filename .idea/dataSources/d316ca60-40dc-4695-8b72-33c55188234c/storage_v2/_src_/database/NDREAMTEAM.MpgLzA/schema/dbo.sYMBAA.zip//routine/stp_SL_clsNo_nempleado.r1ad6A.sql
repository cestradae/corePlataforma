-- Procedure definition
CREATE PROCEDURE [dbo].[stp_SL_clsNo_nempleado]
  As SELECT a.codigo_empleado,a.codigo_tipo,a.fecha_asignacion,a.usuario_asignacion,CONVERT(varchar(30), CONVERT(INT, a.EditStamp),13) EditStamp  FROM [dbo].[no_nomina_empleado] a
go

