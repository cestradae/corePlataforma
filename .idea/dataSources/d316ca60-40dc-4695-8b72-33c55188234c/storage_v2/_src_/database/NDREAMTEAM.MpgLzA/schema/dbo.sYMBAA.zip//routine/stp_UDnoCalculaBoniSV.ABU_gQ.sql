CREATE procedure [dbo].[stp_UDnoCalculaBoniSV]
   @codigo_tipo char(2),
   @periodo_id char(10),
   @grupo_id char(5),
   @no_calculo smallint,
   @codigo_ingreso char(3)
as 

Select codigo_empleado, codigo_centro, sum(monto_ingreso) monto_ingreso 
into #Detalle
from no_nomina_det
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id
  and grupo_id = @grupo_id
  and no_calculo = @no_calculo
  and codigo_ingreso = '14' 
group by codigo_empleado, codigo_centro

Select codigo_empleado,sum(monto_ingreso) monto_ingreso 
into #Totales
from no_nomina_det
where codigo_tipo = @codigo_tipo
  and periodo_id = @periodo_id
  and grupo_id = @grupo_id
  and no_calculo = @no_calculo
  and codigo_ingreso = '14' 
group by codigo_empleado


Begin Tran
--- Procedemos a prorratear los septimos por la cantidad de Ordinario Reportado que estan ingresados
insert into no_nomina_det (
        codigo_tipo ,
        periodo_id,
        grupo_id,
        no_calculo,
        codigo_empleado,
        codigo_departamento,
        codigo_centro,
        codigo_ingreso,
        monto_ingreso,
        monto_ingreso_o )

select  @codigo_tipo,
        @periodo_id,
        @grupo_id,
        @no_calculo,
        a.codigo_empleado,
        a.codigo_departamento ,
        c.codigo_centro, 
        @codigo_ingreso, 
        round(a.monto_ingreso * ( c.monto_ingreso / b.monto_ingreso ),2) ,
        round(a.monto_ingreso * ( c.monto_ingreso / b.monto_ingreso ),2)
from no_nomina_det a, #Totales b, #Detalle c
where a.codigo_empleado = b.codigo_empleado
and a.codigo_empleado= c.codigo_empleado
and a.codigo_tipo = @codigo_tipo
and a.periodo_id = @periodo_id
and a.grupo_id = @grupo_id
and a.no_calculo = @no_calculo
and a.codigo_ingreso = '03' 

	
if @@error <> 0
Begin
   Raiserror ('No se puede actualizar el ingreso - stp_UDnoCalulaSeptimoSV ', 16,1,5000)
   Rollback work
   Return 9
End

Commit Tran
go

