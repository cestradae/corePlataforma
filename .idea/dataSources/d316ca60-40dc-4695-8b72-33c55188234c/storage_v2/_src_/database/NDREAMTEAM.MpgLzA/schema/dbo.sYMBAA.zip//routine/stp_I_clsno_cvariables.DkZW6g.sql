-- Procedure definition
CREATE PROCEDURE [dbo].[stp_I_clsno_cvariables](@AUTO_EditStamp varchar(30) OUT,
  @tipo_valor char (10) ,
  @codigo_clase varchar (20) ,
  @descripcion varchar (50)  )
As 
	INSERT INTO [dbo].[no_clases_variables]
(  tipo_valor ,
  codigo_clase ,
  descripcion  )
VALUES (  @tipo_valor ,
  @codigo_clase ,
  @descripcion  )
-- Auto Identifer table - Return the id, guid, or computed value of the record created
  
  Select @AUTO_EditStamp =CONVERT(varchar(30), CONVERT(int, EditStamp))  From [dbo].[no_clases_variables]
  WHERE ( codigo_clase =  @codigo_clase )
go

