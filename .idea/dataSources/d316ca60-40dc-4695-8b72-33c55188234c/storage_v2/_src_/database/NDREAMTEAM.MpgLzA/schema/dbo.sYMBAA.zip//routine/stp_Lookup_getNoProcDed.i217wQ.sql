-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoProcDed]
As
  SELECT procedimiento, descripcion
FROM no_nomina_proc
WHERE tipo_proc = 'D'
go

