create procedure [dbo].[stp_UDNoGetEstRepSeg]
   @ano smallint,
   @periodo smallint,
   @estado char(1) OUT
as
-------------------------------------------------------------------------------
-- Fecha > 10/10/2003
-- Asunto > Obtiene estado de reporte
-- Creado por LSAO
-------------------------------------------------------------------------------
select @estado = estado_reporte
from no_reporte_seguro 
where @ano = ano
  and periodo = periodo

if @estado is null select @estado = 'O'
go

