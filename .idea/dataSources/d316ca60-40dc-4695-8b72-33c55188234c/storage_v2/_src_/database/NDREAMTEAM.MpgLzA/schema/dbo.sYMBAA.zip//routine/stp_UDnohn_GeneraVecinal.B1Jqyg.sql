CREATE procedure [dbo].[stp_UDnohn_GeneraVecinal]
   @impuesto_vecinal smallint,
   @ano smallint,
   @usuarioid int,
   @error char(1) out
as 

--------------------
-- Hecho por ldr
-- Fecha 17/03/2011
-- Asunto aJUSTES AL IMPUESTO 
--------------------

--------------------
-- Hecho por ldr
-- Fecha 07/03/2011
-- Asunto Genera Impuesto Vecinal 
--------------------

----
select @error= 'x'
declare @codigo_empleado char(10)
declare @monto_afecto money
declare @tasa decimal(18,4)
declare @resto money
declare @monto_de money
declare @monto_a money
declare @correlativo smallint
declare @fecha_inicio_cobro datetime
declare @fin smallint
declare @impuesto money
declare @monto money
declare @codigo_municipio  char(5)
declare @codigo_patrono smallint
---
-- 1ro. Obtenemos los montos Afectos
-- tomamos los ingresos afectos y las nominas afectas 
--
set rowcount 1
select @codigo_empleado = codigo_empleado
from no_empleados a
 where a.slabora_municipio not in (select codigo_municipio from no_siex_departamentos )

set rowcount 0

if @codigo_empleado is not null
Begin
   Raiserror ('Empleado no tiene municipio asignado %s- stp_UDnohn_GeneraVecinal ' ,16,1,@codigo_empleado)
   Rollback work
   Return
End

Begin Tran

select @codigo_patrono = codigo_patrono
from no_parametros_vecinal_hn
where impuesto_vecinal = @impuesto_vecinal

delete from no_reporte_vechn_empleado where impuesto_vecinal = @impuesto_vecinal
 and ano = @ano

if @@error <> 0
Begin
  Raiserror ('No se puede borrar el impuesto vecinal -stp_UDnohn_GeneraVecinal ',16,1,5000)
  Rollback work
  Return
End

select a.codigo_empleado, sum(monto_ingreso) monto_afecto
into #Afectos
from no_nomina_det a
  inner join no_periodos_pago b on a.codigo_tipo = b.codigo_tipo and a.periodo_id = b.periodo_id and b.ano = @ano
where a.codigo_tipo in ( select b.codigo_tipo from no_parametros_vechn_nominas b where b.impuesto_vecinal = @impuesto_vecinal)
  and codigo_ingreso in (select c.ingreso_afecto from no_parametros_vechn_ingresos c where c.impuesto_vecinal = @impuesto_vecinal)
  
group by codigo_empleado

select @fecha_inicio_cobro = fecha_inicio_cobro
from no_reporte_vecinal_hn
where impuesto_vecinal = @impuesto_vecinal
and ano = @ano

-- Procedemos calcular el impuesto ---
--------------------------------------

declare cur_impuesto_vec cursor for
    select a.codigo_empleado, 
           monto_afecto
    from #Afectos a
     inner join no_empleados b on a.codigo_empleado = b.codigo_empleado and b.estado_empleado in ('A','S')
     inner join no_siex_municipios c on b.slabora_depto = c.codigo_departamento  and b.slabora_municipio = c.codigo_municipio 
     inner join no_patronos_hn_municipios d on c.id_municipio = d.id_municipio and d.codigo_patrono = @codigo_patrono
     
open cur_impuesto_vec 
fetch cur_impuesto_vec into @codigo_empleado, @monto_afecto

while @@fetch_status = 0
Begin

   select @resto = @monto_afecto
 
   declare cur_detalle_tasas cursor for
      select correlativo,
             monto_de,
             monto_a,
             tasa
       from no_parametros_vechn_tasas
       where impuesto_vecinal = @impuesto_vecinal
       order by correlativo

   open cur_detalle_tasas 
   fetch cur_detalle_tasas into @correlativo, @monto_de, @monto_a, @tasa 
   select @fin = 0
   select @impuesto = 0
   while @fin = 0
   begin

      
     if @monto_afecto <= @monto_a 
     Begin
        select @monto = @monto_afecto - @monto_de 
        select @fin = 1       
     End  
     Else
     begin
        select @monto = @monto_a - @monto_de
     End
     select @impuesto = @impuesto + round(@monto * @tasa / 100.00,2)
           
     fetch cur_detalle_tasas into @correlativo, @monto_de, @monto_a, @tasa
     if @@fetch_status <> 0
        select @fin = 1 
   end 

   close cur_detalle_tasas
   deallocate cur_detalle_tasas
   --- Insertamos el impuesto 
   
   insert into no_reporte_vechn_empleado (
              impuesto_vecinal,
              ano,
              codigo_empleado,
              monto_afecto,
              monto_impuesto,
              observaciones,
              no_cuotas,
              fecha_inicio_cobro )
     values (@impuesto_vecinal,
             @ano,
             @codigo_empleado,
             @monto_afecto,
             @impuesto,
             0,
             1,
             @fecha_inicio_cobro )

      if @@error <> 0
      Begin
        Raiserror ('No se puede borrar el impuesto vecinal -stp_UDnohn_GeneraVecinal ',16,1,5000)
        Rollback work
        close cur_impuesto_vec
        deallocate cur_impuesto_vec
        Return
      End
      fetch cur_impuesto_vec into @codigo_empleado, @monto_afecto

End

close cur_impuesto_vec
deallocate cur_impuesto_vec


update no_reporte_vecinal_hn
   set usuario_generacion = @usuarioid,
       fecha_generacion = getdate(),
       estado = '1'
where impuesto_vecinal = @impuesto_vecinal
and ano = @ano 

if @@error <>0
Begin
   Raiserror ('Reporte Vecinal no se pudo actualizar - stp_UDnohn_GeneraVecinal ' ,16,1,5000)
   Rollback work
   Return
End

commit Tran
go

