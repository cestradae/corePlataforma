-- Procedure definition
CREATE PROCEDURE [dbo].[stp_Lookup_getNoGtrabajo]
As
  SELECT grupo_trabajo Grupo, nombre_grupo Nombre
FROM no_grupos_trabajo
go

